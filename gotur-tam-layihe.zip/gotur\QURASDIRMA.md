# 🚀 Götür — pulsuz serverə qurma təlimatı

Bu layihə **heç bir asılılıq tələb etmir** (`npm install` yoxdur) — yalnız Node.js 24.
Aşağıdaki 3 yoldan birini seçin. Hər yol 5–10 dəqiqə çəkir.

---

## 0. Yerli yoxlama (əvvəlcə bunu edin)

```powershell
cd gotur
node server/index.js
# → http://127.0.0.1:4173
```

İlk işə salışda baza avtomatik yaradılır və demo data qurulur (12 mağaza, ~85 məhsul, kuponlar, sifarişlər).

| Rol | Telefon | Şifrə |
|---|---|---|
| Admin | `0500000000` | `admin123` |
| Satıcı | `0501110001` | `vendor123` |
| Müştəri | `0501234567` | `customer123` |

> ⚠️ **Canlı serverdə bu şifrələri dəyişdirin!** Şifrə `server/seed-data.js`-dəki `demoUsers`-dən gəlir.

---

## 1. Render.com (ən asan, pulsuz plan)

1. Layihə qovluğunu **GitHub-a** yükləyin (private repo da olar):
   ```powershell
   cd gotur
   git init
   git add .
   git commit -m "Götür platforması"
   git branch -M main
   git remote add origin https://github.com/<istifadəçi>/gotur.git
   git push -u origin main
   ```
2. [render.com](https://render.com) → qeydiyyat (GitHub ilə) → **New → Blueprint**
3. Reponu seçin → Render `render.yaml` faylını oxuyub servisi quracaq → **Apply**
4. 2–3 dəqiqə sonra ünvan hazır: `https://gotur-xxxx.onrender.com`

`render.yaml` artıq `GOTUR_SEED=1` verir: pulsuz planda disk olmadığı üçün konteyner yenidən
başlayanda baza sıfırlanır, amma demo data avtomatik yenidən qurulur.

**Daimi data istəyirsinizsə:** planı yüksəldin və `render.yaml`-daki `disk:` blokunun şərhini açın.

---

## 2. Fly.io (pulsuz kvota + daimi disk)

```powershell
fly launch --no-deploy      # fly.toml oxunur
fly volumes create gotur_data --size 1
fly deploy
```

Baza `/data/gotur.db`-də saxlanılır — konteyner yenilənəndə data itmir.

---

## 3. Docker ilə istənilən hostda (VPS, Railway, Koyeb…)

```powershell
docker build -t gotur .
docker run -d -p 4173:4173 -v gotur-data:/data --name gotur gotur
```

`Dockerfile` hazırdır: Node 24 Alpine, `HOST=0.0.0.0`, `GOTUR_DB=/data/gotur.db`, `GOTUR_SEED=1`,
sağlamlıq yoxlaması `/api/health`.

> ⚠️ **Vercel / Netlify uyğun DEYİL** — onlar serverless-dir, daimi fayl sistemi yoxdur və
> layihə daxili `node:sqlite` istifadə edir. Docker/VPS/Render/Fly düzgün seçimdir.

---

## 4. Müvəqqəti HTTPS ünvan (server qurmadan, kompüterdən)

Kompüterdə server işləyərkən başqa terminalda:

```powershell
# cloudflared-i bir dəfə endirin: https://github.com/cloudflare/cloudflared/releases
cloudflared tunnel --url http://localhost:4173
```

Çıxan `https://…trycloudflare.com` ünvanı telefonda açın. **HTTPS** olduğu üçün PWA quraşdırma
(«Ana ekrana əlavə et») da işləyəcək. Hesab lazım deyil; ünvan kompüter sönənə qədər yaşayır.

---

## 5. Telefon (APK)

ZIP-də hazır APK var: **`apk/out/gotur.apk`** (41 KB, imzalanmış).

Onu telefona köçürüb quraşdırın («Naməlum mənbələrə icazə ver»).

**Bulud ünvanı ilə yenidən yığmaq üçün** (APK daxilində server ünvanı sabit yazılır):

```powershell
node apk/build.mjs --server https://gotur-xxxx.onrender.com
```

Tələb: Android SDK (aapt2, d8, zipalign, apksigner) + JDK. Gradle lazım deyil.
Windows-da iki kliklə: `apk\qur.cmd`.

---

## 6. Konfiqurasiya (mühit dəyişənləri)

| Dəyişən | Default | İzah |
|---|---|---|
| `PORT` | `4173` | HTTP portu |
| `HOST` | `127.0.0.1` | `0.0.0.0` → şəbəkəyə/buluda açıq |
| `GOTUR_DB` | `data/gotur.db` | Baza faylı (`/data/gotur.db` buludda) |
| `GOTUR_SEED` | — | `1` → baza boşdursa demo data qurulur |
| `GOTUR_LOG` | açıq | `0` → API loqları söndürülür |
| `STRIPE_SECRET_KEY` | — | Verildikdə onlayn ödənişlər **real Stripe** ilə işləyir |
| `STRIPE_WEBHOOK_SECRET` | — | Webhook imzası yoxlaması |
| `PUBLIC_URL` | avtomatik | Stripe qayıdış ünvanları üçün |

---

## 7. Faydalı əmrlər

```powershell
node tests/run-all.mjs       # 229 test
node tools/live-check.mjs    # canlı serverə qarşı yoxlama
node tools/mobile-check.mjs  # mobil uyğunluq auditi
node tools/escape-check.mjs  # HTML escape auditi
node server/cli.js stats     # baza statistikası
node server/cli.js vendors   # bütün mağazalar
node server/cli.js cleanup   # test sifarişlərini təmizlə
```

---

## 8. Quraşdırmadan sonra ilk addımlar

1. `https://<ünvan>/admin.html` → `0500000000 / admin123` ilə girin → **şifrəni dəyişin**.
2. «Kateqoriyalar» → öz sahələrinizi əlavə edin (Aptek, Gül, Elektronika… artıq var).
3. «Satıcılar → ＋ Yeni mağaza» ilə real mağazaları yaradın və sahiblərinə giriş məlumatlarını göndərin.
4. Hər mağaza `https://<ünvan>/satis.html`-a girib menyusunu doldurur və «Mağaza → 📍 Mağazanın yeri»-ndə
   koordinatı təyin edir (müştəri tətbiqində məsafə/vaxt göstərilməsi üçün).
5. Müştəri tətbiqi: `https://<ünvan>/`

Uğurlar! 🛍️
