# 🛍️ Götür — "sifariş et, özün götür" platforması

Wolt tipli çox-satıcı sifariş platforması — **bir fərqlə: kuryer sistemi yoxdur.**
Müştəri restoran/marketdən sifariş verir, mağaza hazırlayır, müştəri gəlib **götürmə kodu** ilə özü götürür.

PC-də **sıfır asılılıqla** işləyir: yalnız Node.js (≥ 22.5) lazımdır — `npm install` yoxdur,
xarici kitabxana, framework, CDN, font və ya şəkil faylı yoxdur. Baza: daxili `node:sqlite`.

---

## 🚀 İşə salma (Windows)

**Ən asan yol:** `baslat.cmd` faylına iki dəfə klikləyin → brauzer avtomatik açılacaq.

**Əl ilə:**

```powershell
cd gotur
node server/index.js
```

| Səhifə | Ünvan | Nə üçündür |
|---|---|---|
| Müştəri tətbiqi | http://127.0.0.1:4173/ | Kəşf, menyu, səbət, sifariş, izləmə |
| Satıcı paneli | http://127.0.0.1:4173/satis.html | Sifarişlər, menyu, kampaniyalar, rəylər, hesablaşma |
| Admin paneli | http://127.0.0.1:4173/admin.html | Təsdiqlər, ödənişlər, kampaniyalar, komissiya |
| Ödəniş səhifəsi | `/odenis.html?token=…` | Simulyasiya kart ödənişi (və ya Stripe qayıdışı) |

### Demo girişlər

| Rol | Telefon | Şifrə |
|---|---|---|
| Müştəri | `0501234567` | `customer123` |
| Satıcı (Şirvanşah Kabab Evi) | `0501110001` | `vendor123` |
| Satıcı (Market 24/7) | `0501110009` | `vendor123` |
| Admin | `0500000000` | `admin123` |

> Bütün satıcı hesablarının şifrəsi `vendor123`-dür. Seed: 12 mağaza (8 restoran + 4 market), ~85 məhsul,
> 5 kampaniya, 3 rəy, 7 demo sifariş (müxtəlif statuslarda).

### 📱 Telefonda açmaq (3 yol)

| Yol | Nə lazımdır | Nəticə |
|---|---|---|
| **APK** (tövsiyə olunur) | `node apk/build.mjs` → `apk/out/gotur.apk` | Bir tətbiq, üç giriş: müştəri + satıcı + admin |
| **PWA quraşdırma** | HTTPS ünvan (tunnel/bulud) | Hər panel ayrı ikon kimi ana ekranda |
| **Sadəcə brauzer** | Eyni Wi-Fi | `http://<PC-IP>:4173` |

Serveri şəbəkəyə açın (telefon üçün mütləqdir):

```powershell
$env:HOST='0.0.0.0'; node server/index.js
# Telefonda: http://192.168.x.x:4173   (Windows Firewall soruşanda «İcazə ver»)
```

Ətraflı təlimat: [📱 Telefonda quraşdırma](#-telefonda-qurasdirma-apk--pwa) və
[☁️ Pulsuz serverə yerləşdirmə](#-pulsuz-serverə-yerləşdirmə).

---

## ✨ Nə var? (7 mərhələ)

### 1. Onlayn ödəniş
- **İki provayder:** `simulated` (default, şəbəkə tələb etmir) və **real Stripe** (`STRIPE_SECRET_KEY` verildikdə avtomatik aktivləşir — SDK yoxdur, birbaşa REST API).
- Kart nömrəsi **Luhn** alqoritmi ilə yoxlanılır, son istifadə tarixi və CVV validasiyası, test kartı `4000 0000 0000 0002` rədd simulyasiyası.
- **Refund:** ödənilmiş sifariş ləğv edilərsə pul avtomatik geri qaytarılır (Stripe-da `POST /v1/refunds`).
- **Kassada ödəniş:** satıcı «Ödənişi qəbul et» ilə nağd/kart ödənişini qeydə alır.
- **Stripe webhook** imzası HMAC-SHA256 ilə yoxlanılır (`node:crypto`, replay qoruması ilə).
- Ödəniş statusları: `unpaid → paid → refunded` (+ `failed`).

### 2. Real vaxt (SSE) + PWA
- **Server-Sent Events:** satıcı paneli yeni sifarişi **anında** görür (səs + toast + brauzer bildirişi), müştəri statusu canlı izləyir, admin cədvəli avtomatik yenilənir. 90 saniyəlik yavaş sorğu ehtiyat variant kimi qalır.
- Hər axının öz filtri var: satıcı yalnız öz mağazasını, müştəri yalnız öz sifariş kodunu görür.
- **PWA:** `manifest.webmanifest`, service worker (`sw.js`), app shell ön keşləmə, oflayn səhifə, kataloq üçün offline keş, quraşdırma düyməsi, `shortcuts`.
- **Bildirişlər:** «sifarişin hazırdır» / «yeni sifariş» — Notification API + service worker (`push` handler gələcək Web Push üçün hazırdır).
- Mobil görünüş tam adaptivdir.

### 3. Rəy/reytinq + kampaniyalar
- Rəy **yalnız götürülmüş** sifarişə yazılır (bir sifariş → bir rəy), ulduz + şərh, satıcı cavab yaza bilər, admin moderasiya edir (gizlədilən rəy reytinqə təsir etmir).
- Reytinq **baza + yeni rəylərin çəkili ortası** kimi hesablanır — demo mağazaların populyarlığı bir rəylə sıfırlanmır.
- **Kuponlar:** faiz və ya sabit məbləğ, minimum səbət, maksimum endirim, ümumi limit, istifadəçi limiti, tarix aralığı, platforma və ya mağaza üzrə.
- Yoxlama server tərəfində; ləğv edilən sifarişdə kupon limiti geri qaytarılır.

### 4. Çoxdillilik (AZ/EN/RU) + 58mm qəbz
- **850 açar × 3 dil**, tək mənbədən (`i18n/*.json`) yığılan `public/assets/i18n.js`.
- Dil seçici bütün səhifələrdə, seçim yadda saxlanılır, `<html lang>` və səhifə başlığı da tərcümə olunur.
- Server xətaları **kod** qaytarır (`code` + `params`), frontend onları cari dilə çevirir.
- **58mm termal qəbz:** 32 simvolluq sətirlərlə qurulan mətn, gizli iframe vasitəsilə çap (`@page { size: 58mm auto }`), satıcı və admin panellərində «🖨».
- Alətlər: `tools/build-i18n.mjs`, `tools/merge-i18n-additions.mjs`, `tools/i18n-codemod.mjs`, `tools/i18n-lint.mjs` (tərcümə olunmamış mətn yoxlaması).

### 5. Komissiya və hesablaşma
- Platforma komissiyası: **defolt faiz** (12%) + mağaza üzrə **fərdi faiz** (0 = defolt).
- Sifariş yaradılarkən hesablanır: `komissiya = round(ara cəm × faiz)`, `mağaza payı = cəmi − komissiya`.
- Kupon endirimini **platforma** öz payına götürür → platformanın xalisi = komissiya − endirimlər.
- Pulun kimin əlində olması izlənir: onlayn → platforma mağazaya borcludur; kassa → mağaza platformaya komissiya borcludur.
- **Satıcı paneli → Hesablaşma:** dövr seçimi (bu ay / keçən ay / bu il / fərdi), satış, komissiya, endirim, onlayn/kassa bölgüsü, xalis vəziyyət, sifariş cədvəli, hesablaşma tarixçəsi.
- **Admin → Hesablaşma:** platforma komissiyasını dəyişmək, bütün mağazalar üzrə cədvəl (fərdi faizi yerində redaktə), «Hesablaş» ilə dövrü bağlamaq, «Ödənildi» kimi qeyd etmək, tarixçə.

### 6. Mağaza və kateqoriya idarəsi (admin)
- **Admin → Satıcılar → «＋ Yeni mağaza»:** sahibin adı, telefonu, mağaza adı, növü, kateqoriyası, ünvanı,
  hazırlanma vaxtı, minimum sifariş və fərdi komissiya faizi ilə mağazanı **birbaşa siz yaradırsınız**.
  Şifrə boş buraxılarsa sistem güclü şifrə yaradır və **giriş məlumatları bir dəfəlik göstərilir** (kopyala → sahibə göndər).
  Yeni mağaza dərhal təsdiqli və açıq olur (istəsəniz «təsdiq gözləyən» kimi də yarada bilərsiniz).
- **Admin → Kateqoriyalar:** yeni şaquli sahələr açmaq (Aptek, Gül & Hədiyyə, Elektronika, Geyim, Kitab…),
  ad/ikon/növ/sıra düzəlişi, silmə. İstifadədə olan kateqoriya silinmir — əvvəlcə xəbərdarlıq, sonra
  təsdiqlə «məcburi sil» (mağazalar kateqoriyasız qalır, menyu və sifarişləri saxlanılır).
- Dəyişikliklər müştəri tətbiqində və satıcı panelində **dərhal** görünür (`/api/categories` canlı oxunur).
- `v6` miqrasiyası mövcud bazalara 6 yeni kateqoriya əlavə edir (Aptek daxil).

### 7. Mobil uyğunluq və yaxınlıq (məsafə + yol vaxtı)
- **Bütün panellər telefona uyğundur.** Müştəri tətbiqində alt naviqasiya (🏠 / 🍽️ / 🏪 / 📦 / 🧺),
  satıcı və admin panellərində **☰ off-canvas menyu** (yan panel ekran kənarından açılır), başlıq düymələri
  mobil rejimdə yığcam ikonlara çevrilir, modallar alt vərəq kimi açılır, toxunuş hədəfləri ≥42px,
  çentikli ekranlar üçün `safe-area` dəstəyi, geniş cədvəllərdə **ilk sütun sabit** qalır.
- **Məsafə və yol vaxtı:** müştəri «📍 Yerimi paylaş» basır → hər mağaza üçün **km**, **🚶 yerimə** və
  **🚗 avtomobil** vaxtı göstərilir; ən yaxınlar əvvələ düşür.
- Ana səhifədə **«Yaxınlıqdakılar»** bloku üç qrupa bölünür: 🍽️ restoranlar · 🏪 marketlər · 🏥 apteklər
  (ən yaxın mağazada «Ən yaxın» nişanı).
- Məsafə düz xətt üzrə (Haversine) hesablanır; vaxtlar təxminidir: **yerimə 4.8 km/saat**,
  **avtomobil 25 km/saat + 2 dəq**. Düstur `server/geo.js`-dədir, UI-da «təxmini» qeydi göstərilir.
- Satıcı öz panelindən («Mağaza» → **📍 Mağazanın yeri**) koordinatlarını təyin edir:
  «Cari yerimi istifadə et» və ya əl ilə `lat`/`lng`, «Xəritədə aç» və «Yeri sil» düymələri ilə.
  Koordinat yoxdursa müştəri həmin mağaza üçün məsafə görmür (sıralamada sona düşür).
- Geoloji icazə verilməzsə tətbiq yenə tam işləyir — sadəcə məsafə göstərilmir.

---

## 🔄 Sifariş axını

```
Müştəri menyudan seçir → səbət → sifarişi göndərir (girişsiz də mümkündür, kupon tətbiq edə bilər)
        ↓  onlayn seçilibsə → ödəniş səhifəsi (kart və ya Stripe)
Mağaza panelində sifariş ANINDA görünür (SSE + səs + bildiriş)
        ↓   Yeni → Qəbul edildi → Hazırlanır → Hazırdır
Müştəri statusu canlı izləyir; «Hazırdır» olanda brauzer bildirişi gəlir
        ↓
Müştəri gəlir, kassada 4 rəqəmli götürmə kodunu deyir → «Götürüldü»
        ↓
Rəy yazılır · komissiya hesablaşmaya düşür · qəbz çap olunur
```

Server tərəfində yoxlanılır: mağaza açıqdır və təsdiqlənib, məhsul aktivdir, anbar qalığı kifayətdir,
minimum sifariş ödənilib, status keçidləri ardıcıldır, kupon bütün şərtlərə uyğundur.
Ləğvdə: anbar geri qaytarılır, kupon limiti azad olunur, ödəniş refund edilir.

---

## 🧱 Layihə strukturu

```
gotur/
├─ baslat.cmd                  # Windows üçün bir kliklə başlatma
├─ package.json                # yalnız skriptlər — asılılıq YOXDUR
├─ Dockerfile · render.yaml · fly.toml   # pulsuz serverə yerləşdirmə
├─ QURASDIRMA.md               # addım-addım quraşdırma təlimatı (Render/Fly/Docker/tunnel)
├─ i18n/{az,en,ru}.json        # tərcümə mənbələri (932 açar × 3 dil)
├─ apk/                        # 📱 telefon tətbiqi (WebView launcher)
│  ├─ build.mjs                # APK yığan skript (Gradle tələb etmir)
│  ├─ qur.cmd                  # iki kliklə APK yığımı
│  ├─ src/az/gotur/app/MainActivity.java   # 3 panelli tətbiq
│  ├─ AndroidManifest.xml · res/           # manifest, ikonlar, mətnlər
│  └─ out/gotur.apk            # hazır APK (imzalanmış)
├─ server/
│  ├─ index.js                 # HTTP server, statik fayllar, MIME, xəta formatı
│  ├─ api.js                   # ~70 REST endpoint, rollar üzrə icazə
│  ├─ db.js                    # SQLite sxemi + versiyalı miqrasiyalar (v1–v7) + seed
│  ├─ geo.js                   # Haversine məsafə + yerimə/avtomobil vaxtı
│  ├─ seed-data.js             # 12 mağaza, ~85 məhsul, kuponlar, rəylər, demo sifarişlər
│  ├─ payments.js              # ödəniş provayderləri (simulyasiya + Stripe REST)
│  ├─ settlements.js           # komissiya hesablanması və hesablaşma hesabatları
│  ├─ reviews.js               # rəy/reytinq + moderasiya
│  ├─ coupons.js               # kupon validasiyası və idarəsi
│  ├─ events.js                # SSE hadisə şini (filtrli yayım)
│  ├─ session.js               # cookie sessiyaları (HttpOnly, SameSite=Lax)
│  ├─ util.js                  # scrypt, validasiya, kodlu xətalar (HttpError)
│  └─ cli.js                   # seed | reset | stats | cleanup
├─ public/
│  ├─ index.html · satis.html · admin.html · odenis.html · offline.html
│  ├─ manifest.webmanifest · manifest-satis.webmanifest · manifest-admin.webmanifest · sw.js
│  └─ assets/
│     ├─ app.css               # dizayn sistemi (responsiv, 58mm çap stili)
│     ├─ common.js             # fetch, `h` şablonu, i18n, səbət, toast, modal, qəbz
│     ├─ i18n.js               # AVTOMATİK YARADILIR (build-i18n.mjs)
│     ├─ customer.js · vendor.js · admin.js · odenis.js
│     └─ icons/                # PWA ikonları (make-icons.py ilə yaradılır)
├─ tests/                      # 229 test (12 fayl)
└─ tools/                      # i18n build/merge/lint/codemod, static-check, live-check, ui-check, ikonlar
```

---

## 🔌 API xülasəsi (~70 endpoint)

| Qrup | Yollar |
|---|---|
| Sağlamlıq | `GET /api/health` (yerləşdirmə/monitorinq üçün) |
| Auth | `POST /api/auth/register` · `/login` · `/logout` · `GET /api/auth/me` |
| Kataloq | `GET /api/categories` · `/api/vendors` (`?lat&lng&sort=nearby`) · `/api/vendors/:slug` (+ `/reviews`, `/coupons`) · **`GET /api/nearby`** (qruplaşdırılmış yaxınlıq) |
| Sifariş (müştəri) | `POST /api/orders` · `GET /api/orders` · `/api/orders/:code` · `POST /api/orders/:id/cancel` · `/api/orders/:id/review` |
| Ödəniş | `GET /api/payments/:token` · `POST …/pay` · `…/decline` · `GET /api/payments/stripe/confirm` · `POST /api/payments/stripe/webhook` |
| Real vaxt | `GET /api/events?scope=vendor\|admin` · `GET /api/events?orders=GT-1001` · `GET /api/events/stats` |
| Satıcı | `GET/PATCH /api/vendor/me` · `/stats` · `/settlement` · `/orders` (+`/status`, `/collect`) · `/products` CRUD · `/coupons` CRUD · `/reviews` (+`/reply`) |
| Admin | `/api/admin/stats` · `/vendors` (**POST** = mağaza yarat) · `/categories` (**GET/POST/PATCH/DELETE**) · `/orders` · `/payments` · `/coupons` · `/reviews` · `/users` · `/settlements` · `/settings` |
| Kupon | `POST /api/coupons/validate` |

---

## 🧪 Testlər və yoxlamalar

```powershell
node tests/run-all.mjs        # 229 test: API, ödəniş, SSE, rəy/kupon, hesablaşma, admin, geo, escape, mobil, i18n, frontend
node tools/static-check.mjs   # frontend ↔ backend müqaviləsi (API yolları, selektorlar, #id-lər)
node tools/mobile-check.mjs   # mobil uyğunluq auditi (viewport, gizli təbəqələr, toxunuş, safe-area)
node tools/escape-check.mjs   # HTML escape auditi (raw() ilə sarılmayan interpolyasiyalar)
node tools/i18n-lint.mjs      # tərcümü olunmamış istifadəçi mətni varmı
node tools/live-check.mjs     # işləyən serverə qarşı canlı yoxlama (server açıq olmalıdır)
node tools/build-i18n.mjs     # i18n.js-i lüğətlərdən yenidən yığır
node server/cli.js stats      # baza statistikası
node server/cli.js vendors    # bütün mağazalar (növ, təsdiq, komissiya, məhsul/sifariş, telefon)
node server/cli.js cleanup    # yoxlama/test sifarişlərini təmizləyir
```

Test faylları (12 fayl, 229 test): `api` (31), `payments` (18), `realtime` (15), `reviews-coupons` (28),
`settlements` (14), `admin-manage` (20 — mağaza yaratma və kateqoriya idarəsi), `geo` (16 — məsafə,
yerimə/avtomobil vaxtı, `/api/nearby`), `escape` (3 — HTML escape reqressiyası), `mobile` (21 — klik baqları, viewport, off-canvas menyu, tabbar,
məsafə UI-ı), `i18n` (17), `ui-helpers` (19), `frontend-load` (11).

`tools/ui-check.mjs` — real Chrome-u CDP ilə idarə edib 15 ekran görüntüsü çıxaran tam brauzer ssenarisi:

```powershell
& "C:\Program Files\Google\Chrome\Application\chrome.exe" --headless=new --remote-debugging-port=9333 --user-data-dir="$env:TEMP\gotur-chrome" about:blank
node tools/ui-check.mjs
```

---

## ⚙️ Konfiqurasiya

| Dəyişən | Default | İzah |
|---|---|---|
| `PORT` | `4173` | HTTP portu |
| `HOST` | `127.0.0.1` | Yalnız lokal. Şəbəkəyə açmaq üçün `0.0.0.0` |
| `GOTUR_DB` | `data/gotur.db` | Baza faylının yolu |
| `GOTUR_LOG` | açıq | `0` → API loqlarını söndürür |
| `GOTUR_SEED` | — | `1` → baza boşdursa (buludda sıfırlananda) demo data avtomatik qurulur |
| `STRIPE_SECRET_KEY` | — | Verildikdə onlayn ödənişlər Stripe ilə işləyir |
| `STRIPE_WEBHOOK_SECRET` | — | Webhook imzasını yoxlamaq üçün |
| `STRIPE_CURRENCY` | `azn` | Stripe valyutası |
| `PUBLIC_URL` | `http://HOST:PORT` | Stripe success/cancel ünvanları üçün |

---

## 📱 Telefonda quraşdırma (APK + PWA)

### A) APK — bir tətbiq, üç giriş (tövsiyə olunur)

APK **WebView launcher**-dir: içində müştəri tətbiqi, satıcı paneli və admin paneli üçün üç düymə,
server ünvanı sahəsi və brauzer alətləri (geri / yenilə / ana ekran) var. Ayrıca Android layihəsi,
Gradle və ya internet lazım deyil — yalnız Android SDK + JDK.

```powershell
node apk/build.mjs                                  # cari LAN IP avtomatik yazılır
node apk/build.mjs --server http://192.168.1.50:4173   # və ya əl ilə ünvan
# Windows-da iki kliklə: apk\qur.cmd
```

Nəticə: **`apk/out/gotur.apk`** (~41 KB, imzalanmış).

Quraşdırma:
1. `apk/out/gotur.apk`-ı telefona köçürün (USB kabel, Telegram «Özünə göndər», e-poçt, Google Drive).
2. Telefonda faylı açın → Android «Naməlum mənbələrə icazə ver» soruşacaq → **Quraşdır**.
3. Kompüterdə serveri şəbəkəyə açın: `$env:HOST='0.0.0.0'; node server/index.js`
4. Tətbiqdə ünvanı yoxlayın (məsələn `http://192.168.100.133:4173`) və rolu seçin.

> Telefon və kompüter **eyni Wi-Fi**-da olmalıdır. Windows Firewall ilk dəfə soruşanda «İcazə ver» seçin.
> IP dəyişərsə tətbiqdəki ünvanı yeniləyib «Ünvanı yadda saxla» basın.
> Debug açarla imzalanıb — Google Play üçün öz açarınızla imzalayın (`--ks` parametri).

### B) PWA — hər panel ayrı ikon kimi

Hər panelin öz manifesti var, ona görə ayrı-ayrı tətbiqlər kimi quraşdırılır:

| Panel | Manifest | Quraşdırıldıqda ad |
|---|---|---|
| Müştəri | `/manifest.webmanifest` | Götür |
| Satıcı | `/manifest-satis.webmanifest` | Götür Satıcı |
| Admin | `/manifest-admin.webmanifest` | Götür Admin |

Android Chrome-da: səhifəni açın → ⋮ menyu → **«Tətbiqi quraşdır» / «Ana ekrana əlavə et»**.

> ⚠️ PWA quraşdırma və service worker yalnız **HTTPS** (və ya `localhost`) üzərində işləyir.
> `http://192.168.x.x` üzərində sayt açılır, amma quraşdırma düyməsi çıxmır — bunun üçün ya APK-dan
> istifadə edin, ya da aşağıdaki tunnel ilə HTTPS ünvan alın.

---

## ☁️ Pulsuz serverə yerləşdirmə

Layihədə hazır konfiqurasiyalar var: `Dockerfile`, `render.yaml`, `fly.toml` — addım-addım təlimat: **[QURASDIRMA.md](QURASDIRMA.md)**.

### 1) Müvəqqəti HTTPS ünvan (ən sürətli — hesab lazım deyil)

Kompüterinizdə server işləyərkən, ayrı terminalda:

```powershell
# cloudflared (bir dəfə endirilir): https://github.com/cloudflare/cloudflared/releases
cloudflared tunnel --url http://localhost:4173
```

Çıxan `https://…trycloudflare.com` ünvanı telefonda açın — **HTTPS** olduğu üçün PWA quraşdırma da işləyəcək.
Ünvan kompüter sönənə qədər yaşayır (müvəqqəti demodur).

### 2) Render.com (pulsuz plan)

1. Kodu GitHub-a push edin.
2. render.com → **New → Blueprint** → reponu seçin ( `render.yaml` oxunacaq).
3. Hazır — Render Docker obrazını qurub `https://<ad>.onrender.com` ünvanında işlədəcək.

> Pulsuz planda **disk yoxdur**: konteyner yenidən başlayanda baza sıfırlanır. `GOTUR_SEED=1` sayəsində
> baza avtomatik demo datayla doldurulur. Daimi data üçün planı yüksəldib `render.yaml`-daki `disk` blokunu açın
> (və ya Fly.io işlədin — orada volume var).

### 3) Fly.io (pulsuz kvota + daimi disk)

```powershell
fly launch --no-deploy
fly volumes create gotur_data --size 1
fly deploy
```

### 4) Docker ilə hər hansı hostda

```powershell
docker build -t gotur .
docker run -p 4173:4173 -v gotur-data:/data gotur
```

> **Qeyd:** bu layihə `node:sqlite` (daxili SQLite) istifadə edir — Vercel/Netlify kimi **serverless**
> platformalar uyğun deyil (orada fayl sistemi daimi deyil). Docker/VPS/Render/Fly düzgün seçimdir.
> İstehsalda PostgreSQL-ə keçid tövsiyə olunur.

---

## 🆚 Wolt-dan fərqi

**Var:** çox-satıcı marketplace, kateqoriya/axtarış, menyu bölmələri, səbət, minimum sifariş, anbar qalığı,
kuponlar, rəy/reytinq, onlayn ödəniş + refund, kassada ödəniş, canlı status axını, götürmə kodu, qəbz çapı,
satıcı paneli (canlı sifarişlər, menyu, kampaniya, rəy, hesablaşma), admin paneli (mağaza yaratma,
kateqoriya idarəsi, təsdiq, ödəniş, moderasiya, komissiya), komissiya modeli, 3 dildə interfeys,
PWA (oflayn + bildirişlər), telefon üçün APK.

**Yoxdur (qəsdən):** kuryer tətbiqi, ünvan/xəritə məntiqi, çatdırılma haqqı, canlı kuryer izləmə, çatdırılma zonası/ETA.
Çünki model "self-pickup"-dır — bu, platformanın məqsədli sadələşməsidir.

---

## 🔐 Təhlükəsizlik

- Şifrələr `scrypt` + təsadüfi salt (`node:crypto`), müqayisə `timingSafeEqual`.
- Sessiya cookie-si `HttpOnly` + `SameSite=Lax`, 30 gün, serverdə token cədvəli.
- Bütün interpolyasiya escape olunur (`h` şablonu; `esc()` idempotentdir — ikiqat escape olmur).
- Statik fayl serveri path traversal cəhdlərini bloklayır.
- Hər endpoint rol + sahiblik yoxlaması ilə qorunur; qonaq sifarişini yalnız kodunu bilən ləğv edə bilər.
- Stripe webhook imzası HMAC-SHA256 + timestamp tolerantlığı ilə yoxlanılır.
- **İstehsala çıxmazdan əvvəl:** HTTPS, CSRF token, rate limiting, şifrə bərpası (SMS), PostgreSQL-ə keçid,
  Stripe canlı açarları və webhook secret-ı.

---

## 🗺️ Növbəti addımlar (təklif)

1. **Web Push** (VAPID açarları ilə) — brauzer bağlı olanda da bildiriş.
2. **Kuryer modulu** — əgər çatdırılma əlavə olunacaqsa: ünvan kitabçası, zona, ETA, kuryer tətbiqi.
3. **Ödəniş genişlənməsi** — yerli provayderlər (MilliÖN, Kapital Bank), hissə-hissə ödəniş.
4. **PDF/Excel hesabatlar** — hesablaşma və satış hesabatlarının ixracı.
5. **Çoxşaxəli filiallar** — bir satıcının bir neçə nöqtəsi, hər nöqtə üçün ayrı anbar.
6. **Müştəri loyallığı** — bonus balansı, səviyyələr, dəvət kodları.
7. **A/B test və analitika** — çevrilmə, səbət tərk etmə, saatlıq yük.
8. **Docker + CI** — konteynerləşdirmə və avtomatik test boru xətti.

---

*Demo layihə · Bütün qiymətlər AZN ilədir · Məlumatlar yerli SQLite faylındadır, internet tələb olunmur.*
