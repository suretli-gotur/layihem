/**
 * Götür — telefon üçün APK yığan skript (Gradle TƏLƏB ETMİR).
 *
 *   node apk/build.mjs
 *   node apk/build.mjs --server http://192.168.1.50:4173
 *
 * Yalnız Android SDK (aapt2, d8, zipalign, apksigner) + JDK kifayətdir.
 * Nəticə: apk/out/gotur.apk — imzalanmış, quraşdırmaya hazır.
 */
import { spawnSync } from 'node:child_process';
import { copyFileSync, cpSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { networkInterfaces, tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..');

const argServer = (() => {
  const idx = process.argv.indexOf('--server');
  return idx >= 0 ? process.argv[idx + 1] : null;
})();

const log = {
  step: (t) => console.log(`  → ${t}`),
  ok: (t) => console.log(`  ✔ ${t}`),
  info: (t) => console.log(`    ${t}`),
};

/* ------------------------------------------------------------------ *
 * 1. Alətləri tap
 * ------------------------------------------------------------------ */
const sdk = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT
  || join(process.env.LOCALAPPDATA ?? '', 'Android', 'Sdk');
if (!existsSync(sdk)) fail(`Android SDK tapılmadı: ${sdk}\n    ANDROID_HOME təyin edin.`);
log.info(`SDK: ${sdk}`);

const buildToolsRoot = join(sdk, 'build-tools');
if (!existsSync(buildToolsRoot)) fail('build-tools qovluğu yoxdur');
const buildToolsName = readdirSync(buildToolsRoot)
  .filter((d) => /^\d+(\.\d+)*$/.test(d))
  .sort((a, b) => parseInt(b, 10) - parseInt(a, 10) || b.localeCompare(a))[0];
if (!buildToolsName) fail('build-tools versiyası tapılmadı');
const buildTools = join(buildToolsRoot, buildToolsName);
log.info(`build-tools: ${buildToolsName}`);

const platformsRoot = join(sdk, 'platforms');
const androidJar = (existsSync(platformsRoot) ? readdirSync(platformsRoot) : [])
  .map((p) => join(platformsRoot, p, 'android.jar'))
  .filter((p) => existsSync(p))
  .sort()
  .pop();
if (!androidJar) fail('android.jar tapılmadı (platforms/*)');
log.info(`android.jar: ${androidJar}`);

const jdkCandidates = [
  process.env.JAVA_HOME,
  join(process.env.ProgramFiles ?? '', 'Android', 'Android Studio', 'jbr'),
  join(process.env.LOCALAPPDATA ?? '', 'Programs', 'Android Studio', 'jbr'),
  join(process.env.ProgramFiles ?? '', 'Eclipse Adoptium', 'jdk-21'),
].filter(Boolean);
const jdk = jdkCandidates.find((p) => existsSync(join(p, 'bin', 'javac.exe')));
if (!jdk) fail('JDK tapılmadı (javac.exe). JAVA_HOME təyin edin.');
log.info(`JDK: ${jdk}`);

const exe = (name) => join(buildTools, name);
const paths = {
  aapt2: exe('aapt2.exe'),
  aapt: exe('aapt.exe'),
  zipalign: exe('zipalign.exe'),
  apksignerJar: join(buildTools, 'lib', 'apksigner.jar'),
  d8jar: join(buildTools, 'lib', 'd8.jar'),
  java: join(jdk, 'bin', 'java.exe'),
  javac: join(jdk, 'bin', 'javac.exe'),
  keytool: join(jdk, 'bin', 'keytool.exe'),
};
for (const [name, p] of Object.entries(paths)) {
  if (!existsSync(p)) fail(`alət tapılmadı (${name}): ${p}`);
}

/* .bat fayllarını birbaşa çağırmaq Node-da bloklanır (EINVAL) →
   apksigner-i jar vasitəsilə Java ilə işlədirik. */
const apksignerArgs = (args) => ['-jar', paths.apksignerJar, ...args];

const MIN_SDK = 24;
const TARGET_SDK = 36;

/* ------------------------------------------------------------------ *
 * 2. Server ünvanı (default: cari LAN IP)
 * ------------------------------------------------------------------ */
const lanIp = (() => {
  for (const list of Object.values(networkInterfaces())) {
    for (const net of list ?? []) {
      if (net.family === 'IPv4' && !net.internal && !net.address.startsWith('169.254.')) return net.address;
    }
  }
  return '192.168.1.10';
})();
const server = argServer || `http://${lanIp}:4173`;

console.log('\n── Götür APK yığımı ──');
log.info(`Server ünvanı (APK-ya yazılır): ${server}`);
log.info(`Android: minSdk ${MIN_SDK}, targetSdk ${TARGET_SDK}\n`);

/* ------------------------------------------------------------------ *
 * 3. İş qovluğu + mənbələr (placeholder əvəzlənir)
 * ------------------------------------------------------------------ */
const work = join(tmpdir(), 'gotur-apk-build');
rmSync(work, { recursive: true, force: true });
mkdirSync(work, { recursive: true });
for (const item of ['AndroidManifest.xml', 'res', 'src']) {
  cpSync(join(here, item), join(work, item), { recursive: true });
}
const javaPath = join(work, 'src', 'az', 'gotur', 'app', 'MainActivity.java');
writeFileSync(javaPath, readFileSync(javaPath, 'utf8').replace('__GOTUR_SERVER__', server), 'utf8');
log.step('mənbələr hazırlandı');

/* ------------------------------------------------------------------ *
 * 4-10. Yığım addımları
 * ------------------------------------------------------------------ */
function run(command, args, options = {}) {
  const result = spawnSync(command, args, { stdio: 'inherit', ...options });
  if (result.error) fail(`${command} işə salına bilmədi: ${result.error.message}`);
  if (result.status !== 0) fail(`${command} xəta ilə bitdi (kod ${result.status})`);
}

const resZip = join(work, 'res.zip');
run(paths.aapt2, ['compile', '--dir', join(work, 'res'), '-o', resZip]);
log.ok('resurslar kompilyasiya olundu (aapt2 compile)');

const genDir = join(work, 'gen');
const baseApk = join(work, 'base.apk');
mkdirSync(genDir, { recursive: true });
run(paths.aapt2, [
  'link', '-o', baseApk, '-I', androidJar,
  '--manifest', join(work, 'AndroidManifest.xml'),
  '-R', resZip, '--java', genDir,
  '--min-sdk-version', String(MIN_SDK),
  '--target-sdk-version', String(TARGET_SDK),
  '--auto-add-overlay',
]);
log.ok('APK skeleti hazır (aapt2 link + R.java)');

const listFiles = (dir, ext) => {
  const out = [];
  const walk = (d) => {
    for (const entry of readdirSync(d, { withFileTypes: true })) {
      const full = join(d, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (entry.name.endsWith(ext)) out.push(full);
    }
  };
  walk(dir);
  return out;
};

const classesDir = join(work, 'classes');
mkdirSync(classesDir, { recursive: true });
const javaSources = [...listFiles(join(work, 'src'), '.java'), ...listFiles(genDir, '.java')];
run(paths.javac, [
  '-nowarn', '-Xlint:none', '-source', '17', '-target', '17',
  '-classpath', androidJar, '-d', classesDir, ...javaSources,
]);
log.ok(`Java kodu derləndi (${listFiles(classesDir, '.class').length} klas faylı)`);

const dexDir = join(work, 'dex');
mkdirSync(dexDir, { recursive: true });
run(paths.java, [
  '-cp', paths.d8jar, 'com.android.tools.r8.D8',
  '--lib', androidJar, '--min-api', String(MIN_SDK), '--output', dexDir,
  ...listFiles(classesDir, '.class'),
]);
const dexFile = join(dexDir, 'classes.dex');
if (!existsSync(dexFile)) fail('classes.dex yaradılmadı');
log.ok(`classes.dex yaradıldı (${Math.round(statSync(dexFile).size / 1024)} KB)`);

run(paths.aapt, ['add', baseApk, 'classes.dex'], { cwd: dexDir });
log.ok('dex APK-ya əlavə olundu');

const outDir = join(here, 'out');
mkdirSync(outDir, { recursive: true });
const aligned = join(work, 'aligned.apk');
run(paths.zipalign, ['-p', '-f', '4', baseApk, aligned]);
log.ok('APK hizalandı (zipalign)');

const keystore = join(here, 'debug.keystore');
if (!existsSync(keystore)) {
  run(paths.keytool, [
    '-genkeypair', '-v', '-keystore', keystore, '-storepass', 'android', '-keypass', 'android',
    '-alias', 'gotur', '-keyalg', 'RSA', '-keysize', '2048', '-validity', '10000',
    '-dname', 'CN=Gotur Demo, O=Gotur, C=AZ',
  ]);
  log.ok('imzalama açarı yaradıldı (apk/debug.keystore)');
}

const apk = join(outDir, 'gotur.apk');
rmSync(apk, { force: true });
run(paths.java, apksignerArgs([
  'sign', '--ks', keystore, '--ks-pass', 'pass:android', '--key-pass', 'pass:android',
  '--ks-key-alias', 'gotur', '--out', apk, aligned,
]));
log.ok('APK imzalandı (apksigner)');

const verify = spawnSync(paths.java, apksignerArgs(['verify', '--print-certs', apk]), { encoding: 'utf8' });
const size = Math.round(statSync(apk).size / 1024);

console.log(`\n  ✅ Hazır: ${apk} (${size} KB)`);
console.log(`     Server ünvanı: ${server}`);
if (verify.status === 0) {
  const dn = (verify.stdout.match(/Signer #1 certificate DN: (.+)/) ?? [])[1];
  console.log(`     İmza: ${dn ?? 'doğrulandı'}`);
}
console.log('\n  Telefona quraşdırma:');
console.log('    1) apk/out/gotur.apk faylını telefona köçürün (USB / Telegram / e-poçt)');
console.log('    2) Telefonda faylı açın → «Naməlum mənbələrə icazə ver» → Quraşdır');
console.log("    3) Kompüterdə:  $env:HOST='0.0.0.0'; node server/index.js");
console.log('    4) Tətbiqdə ünvanı yoxlayın (kompüterin IP-si) və rol seçin\n');

function fail(message) {
  console.error(`\n  ✖ ${message}\n`);
  process.exit(1);
}
