<#
    Götür — telefon üçün APK yığan skript (Gradle tələb etmir).

    İstifadə:
        pwsh -File apk/build.ps1
        pwsh -File apk/build.ps1 -Server "http://192.168.1.50:4173"

    Nəticə: apk/out/gotur.apk  (imzalanmış, quraşdırmağa hazır)

    Yalnız Android SDK + JDK kifayətdir: aapt2, d8, zipalign, apksigner.
#>
[CmdletBinding()]
param(
    [string]$Server = '',
    [string]$OutDir = ''
)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $here
if (-not $OutDir) { $OutDir = Join-Path $here 'out' }

function Write-Step($text) { Write-Host "  → $text" -ForegroundColor Cyan }
function Write-Ok($text) { Write-Host "  ✔ $text" -ForegroundColor Green }

# ------------------------------------------------------------------ #
# 1. Alətləri tap
# ------------------------------------------------------------------ #
$sdk = $env:ANDROID_HOME
if (-not $sdk) { $sdk = $env:ANDROID_SDK_ROOT }
if (-not $sdk) { $sdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
if (-not (Test-Path $sdk)) { throw "Android SDK tapılmadı. ANDROID_HOME təyin edin." }

$buildTools = Get-ChildItem (Join-Path $sdk 'build-tools') -Directory -ErrorAction SilentlyContinue |
    Sort-Object { [version]$_.Name } -Descending | Select-Object -First 1
if (-not $buildTools) { throw "build-tools tapılmadı ($sdk\build-tools)" }

$platforms = Get-ChildItem (Join-Path $sdk 'platforms') -Directory -ErrorAction SilentlyContinue |
    Sort-Object Name -Descending
$androidJar = $null
foreach ($p in $platforms) {
    $jar = Join-Path $p.FullName 'android.jar'
    if (Test-Path $jar) { $androidJar = $jar; break }
}
if (-not $androidJar) { throw "android.jar tapılmadı ($sdk\platforms)" }

$jdk = $env:JAVA_HOME
if (-not $jdk -or -not (Test-Path (Join-Path $jdk 'bin\javac.exe'))) {
    $candidates = @(
        (Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Android Studio\jbr'),
        (Join-Path $env:ProgramFiles 'Eclipse Adoptium\jdk-21'),
        (Join-Path $env:ProgramFiles 'Java\jdk-21')
    )
    $jdk = $candidates | Where-Object { Test-Path (Join-Path $_ 'bin\javac.exe') } | Select-Object -First 1
}
if (-not $jdk) { throw "JDK tapılmadı (javac.exe). JAVA_HOME təyin edin." }

$javac = Join-Path $jdk 'bin\javac.exe'
$keytool = Join-Path $jdk 'bin\keytool.exe'
$aapt2 = Join-Path $buildTools.FullName 'aapt2.exe'
$aapt = Join-Path $buildTools.FullName 'aapt.exe'
$zipalign = Join-Path $buildTools.FullName 'zipalign.exe'
$apksigner = Join-Path $buildTools.FullName 'apksigner.bat'
$d8jar = Join-Path $buildTools.FullName 'lib\d8.jar'
$env:JAVA_HOME = $jdk

$minSdk = 24
$targetSdk = 36

Write-Host "`n── Götür APK yığımı ──" -ForegroundColor White
Write-Host "  SDK:          $sdk"
Write-Host "  build-tools:  $($buildTools.Name)"
Write-Host "  android.jar:  $androidJar"
Write-Host "  JDK:          $jdk"

# ------------------------------------------------------------------ #
# 2. Server ünvanı (default olaraq cari LAN IP)
# ------------------------------------------------------------------ #
if (-not $Server) {
    $ip = (ipconfig | Select-String -Pattern 'IPv4' |
        ForEach-Object { ($_ -split ':')[-1].Trim() } |
        Where-Object { $_ -notlike '127.*' -and $_ -notlike '169.254.*' } |
        Select-Object -First 1)
    if (-not $ip) { $ip = '192.168.1.10' }
    $Server = "http://$ip`:4173"
}
Write-Host "  Server ünvanı: $Server`n"

# ------------------------------------------------------------------ #
# 3. Təmiz iş qovluğu + mənbələri kopyala (placeholder əvəzlənir)
# ------------------------------------------------------------------ #
$work = Join-Path $env:TEMP "gotur-apk-build"
if (Test-Path $work) { Remove-Item $work -Recurse -Force }
New-Item -ItemType Directory -Path $work -Force | Out-Null
foreach ($item in @('AndroidManifest.xml', 'res', 'src')) {
    Copy-Item (Join-Path $here $item) (Join-Path $work $item) -Recurse -Force
}
$javaFile = Join-Path $work 'src\az\gotur\app\MainActivity.java'
(Get-Content $javaFile -Raw).Replace('__GOTUR_SERVER__', $Server) |
    Set-Content $javaFile -NoNewline -Encoding utf8
Write-Step "mənbələr hazırlandı ($work)"

# ------------------------------------------------------------------ #
# 4. Resursları kompilyasiya et (aapt2)
# ------------------------------------------------------------------ #
$resZip = Join-Path $work 'res.zip'
& $aapt2 compile --dir (Join-Path $work 'res') -o $resZip
if ($LASTEXITCODE -ne 0) { throw "aapt2 compile alınmadı" }
Write-Ok "resurslar kompilyasiya olundu"

# ------------------------------------------------------------------ #
# 5. Resursları linkləşdir (APK skeleti + R.java)
# ------------------------------------------------------------------ #
$genDir = Join-Path $work 'gen'
New-Item -ItemType Directory -Path $genDir -Force | Out-Null
$baseApk = Join-Path $work 'base.apk'
& $aapt2 link -o $baseApk -I $androidJar --manifest (Join-Path $work 'AndroidManifest.xml') `
    -R $resZip --java $genDir --min-sdk-version $minSdk --target-sdk-version $targetSdk `
    --no-version-vectors --auto-add-overlay
if ($LASTEXITCODE -ne 0) { throw "aapt2 link alınmadı" }
Write-Ok "APK skeleti hazır (R.java yaradıldı)"

# ------------------------------------------------------------------ #
# 6. Java kodu derlə (javac)
# ------------------------------------------------------------------ #
$classesDir = Join-Path $work 'classes'
New-Item -ItemType Directory -Path $classesDir -Force | Out-Null
$sources = Get-ChildItem (Join-Path $work 'src') -Recurse -Filter *.java | ForEach-Object { $_.FullName }
$rJava = Get-ChildItem $genDir -Recurse -Filter R.java | ForEach-Object { $_.FullName }
& $javac -nowarn -Xlint:none -source 17 -target 17 -classpath $androidJar `
    -d $classesDir @sources @rJava 2>&1 | Where-Object { $_ -notmatch 'bootstrap class path|warnings?$|^Note:' }
if ($LASTEXITCODE -ne 0) {
    # Bəzi JDK-lərdə -source 17 dəstəklənmirsə, default ilə yoxla
    & $javac -nowarn -classpath $androidJar -d $classesDir @sources @rJava
    if ($LASTEXITCODE -ne 0) { throw "javac alınmadı" }
}
$classCount = (Get-ChildItem $classesDir -Recurse -Filter *.class).Count
Write-Ok "Java kodu derləndi ($classCount klas faylı)"

# ------------------------------------------------------------------ #
# 7. Dex yarat (d8)
# ------------------------------------------------------------------ #
$dexDir = Join-Path $work 'dex'
New-Item -ItemType Directory -Path $dexDir -Force | Out-Null
$classFiles = Get-ChildItem $classesDir -Recurse -Filter *.class | ForEach-Object { $_.FullName }
& (Join-Path $jdk 'bin\java.exe') -cp $d8jar com.android.tools.r8.D8 `
    --lib $androidJar --min-api $minSdk --output $dexDir @classFiles
if ($LASTEXITCODE -ne 0) { throw "d8 alınmadı" }
if (-not (Test-Path (Join-Path $dexDir 'classes.dex'))) { throw "classes.dex yaradılmadı" }
Write-Ok "classes.dex yaradıldı ($([math]::Round((Get-Item (Join-Path $dexDir 'classes.dex')).Length/1KB,1)) KB)"

# ------------------------------------------------------------------ #
# 8. Dex-i APK-ya əlavə et
# ------------------------------------------------------------------ #
Push-Location $dexDir
try {
    & $aapt add $baseApk 'classes.dex'
    if ($LASTEXITCODE -ne 0) { throw "classes.dex APK-ya əlavə olunmadı" }
} finally { Pop-Location }
Write-Ok "dex APK-ya əlavə olundu"

# ------------------------------------------------------------------ #
# 9. Hizala + imzala
# ------------------------------------------------------------------ #
New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
$aligned = Join-Path $work 'aligned.apk'
& $zipalign -p -f 4 $baseApk $aligned
if ($LASTEXITCODE -ne 0) { throw "zipalign alınmadı" }

$keystore = Join-Path $here 'debug.keystore'
if (-not (Test-Path $keystore)) {
    & $keytool -genkeypair -v -keystore $keystore -storepass android -keypass android `
        -alias gotur -keyalg RSA -keysize 2048 -validity 10000 `
        -dname "CN=Gotur Demo, O=Gotur, C=AZ" 2>&1 | Out-Null
    Write-Ok "debug açar anbarı yaradıldı"
}

$apk = Join-Path $OutDir 'gotur.apk'
if (Test-Path $apk) { Remove-Item $apk -Force }
& $apksigner sign --ks $keystore --ks-pass pass:android --key-pass pass:android `
    --ks-key-alias gotur --out $apk $aligned
if ($LASTEXITCODE -ne 0) { throw "apksigner alınmadı" }
Write-Ok "APK imzalandı"

# ------------------------------------------------------------------ #
# 10. Yoxlama
# ------------------------------------------------------------------ #
$verify = & $apksigner verify --print-certs $apk 2>&1
$size = [math]::Round((Get-Item $apk).Length / 1KB, 1)
Write-Host "`n  ✅ Hazır: $apk ($size KB)" -ForegroundColor Green
Write-Host "     Server ünvanı: $Server"
Write-Host "     İmza: $(($verify | Select-String 'Signer #1 certificate DN' | Select-Object -First 1) -replace '.*: ', '')"
Write-Host ""
Write-Host "  Telefona quraşdırmaq üçün:" -ForegroundColor White
Write-Host "    1) APK faylını telefona köçürün (USB, Telegram, e-poçt)"
Write-Host "    2) Telefonda faylı açın → «Naməlum mənbələrə icazə ver» → Quraşdır"
Write-Host "    3) Kompüterdə serveri işə salın:  `$env:HOST='0.0.0.0'; node server/index.js"
Write-Host "    4) Tətbiqdə ünvanı yoxlayın və rol seçin`n"

# iş qovluğunu saxlayırıq (debug üçün); təmizləmək üçün:
# Remove-Item $work -Recurse -Force
