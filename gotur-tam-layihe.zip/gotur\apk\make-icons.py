"""Götür APK — launcher ikonlarını PWA ikonundan hazırlayır.

İstifadə: python apk/make-icons.py
"""
from pathlib import Path
import sys

from PIL import Image

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / "public" / "assets" / "icons" / "icon-512.png"
RES = ROOT / "apk" / "res"

# Android sıxlıq qovluqları → ikon ölçüləri
DENSITIES = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}


def main() -> None:
    if not SOURCE.exists():
        raise SystemExit(f"mənbə ikon tapılmadı: {SOURCE}")
    base = Image.open(SOURCE).convert("RGBA")
    for folder, size in DENSITIES.items():
        target = RES / folder
        target.mkdir(parents=True, exist_ok=True)
        img = base.resize((size, size), Image.LANCZOS)
        path = target / "ic_launcher.png"
        img.save(path, "PNG", optimize=True)
        print(f"  ✔ {path.relative_to(ROOT)} ({size}x{size})")

    # Foreground (adaptive icon) — eyni şəkil, bir az kiçildilmiş
    fg = RES / "mipmap-xxhdpi"
    fg.mkdir(parents=True, exist_ok=True)
    canvas = Image.new("RGBA", (144, 144), (0, 0, 0, 0))
    inner = base.resize((104, 104), Image.LANCZOS)
    canvas.paste(inner, (20, 20), inner)
    canvas.save(fg / "ic_launcher_foreground.png", "PNG", optimize=True)
    print(f"  ✔ {(fg / 'ic_launcher_foreground.png').relative_to(ROOT)} (144x144)")


if __name__ == "__main__":
    main()
