@echo off
chcp 65001 >nul
title Götür — APK yığımı
cd /d "%~dp0.."

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   XƏTA: Node.js tapılmadı. https://nodejs.org-dan quraşdırın.
  echo.
  pause
  exit /b 1
)

echo.
echo   Götür APK yığılır...
echo.
node apk\build.mjs %*
set RESULT=%ERRORLEVEL%

echo.
if %RESULT%==0 (
  echo   Hazır APK: %CD%\apk\out\gotur.apk
  echo.
  echo   Faylı telefona köçürüb quraşdıra bilərsiniz.
) else (
  echo   Yığım alınmadı - yuxarıdaki xətanı yoxlayın.
)
echo.
pause
exit /b %RESULT%
