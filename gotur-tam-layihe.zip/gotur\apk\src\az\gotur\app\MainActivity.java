package az.gotur.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Götür — telefon üçün nazik tətbiq (WebView launcher).
 *
 * Bir APK, üç giriş: Müştəri tətbiqi · Satıcı paneli · Admin paneli.
 * Server ünvanı yadda saxlanılır və dəyişdirilə bilər (məsələn kompüterin yerli IP-si).
 */
public class MainActivity extends Activity {

    /** Build zamanı cari LAN IP ilə əvəz olunur (build.ps1). */
    private static final String DEFAULT_SERVER = "__GOTUR_SERVER__";

    private static final String PREFS = "gotur";
    private static final String KEY_SERVER = "server";

    private static final int ROLE_CUSTOMER = 0;
    private static final int ROLE_VENDOR = 1;
    private static final int ROLE_ADMIN = 2;

    private SharedPreferences prefs;
    private FrameLayout root;
    private LinearLayout homeScreen;
    private LinearLayout webScreen;
    private WebView web;
    private TextView statusText;
    private EditText serverInput;
    private String serverUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        serverUrl = prefs.getString(KEY_SERVER, DEFAULT_SERVER);

        Window window = getWindow();
        window.setStatusBarColor(Color.parseColor("#0E1726"));
        window.setNavigationBarColor(Color.parseColor("#0E1726"));

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0E1726"));
        setContentView(root);

        buildHomeScreen();
        showHome();
    }

    /* ------------------------------------------------------------------ *
     * Ana ekran (rol seçimi + server ünvanı)
     * ------------------------------------------------------------------ */
    private void buildHomeScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#F6F8FB"));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(38), dp(22), dp(28));
        scroll.addView(box);

        TextView logo = new TextView(this);
        logo.setText("🛍️  Götür");
        logo.setTextSize(30f);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setTextColor(Color.parseColor("#0E1726"));
        box.addView(logo);

        TextView sub = new TextView(this);
        sub.setText("Sifariş et · özün götür");
        sub.setTextSize(14f);
        sub.setTextColor(Color.parseColor("#5B6B7C"));
        sub.setPadding(0, dp(4), 0, dp(22));
        box.addView(sub);

        box.addView(label("Server ünvanı (kompüterin IP-si)"));
        serverInput = new EditText(this);
        serverInput.setText(serverUrl);
        serverInput.setTextSize(15f);
        serverInput.setSingleLine(true);
        serverInput.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        serverInput.setHint("http://192.168.1.10:4173");
        box.addView(serverInput);

        statusText = new TextView(this);
        statusText.setTextSize(12.5f);
        statusText.setTextColor(Color.parseColor("#5B6B7C"));
        statusText.setPadding(0, dp(6), 0, dp(18));
        statusText.setText("Telefon və kompüter eyni Wi-Fi şəbəkəsində olmalıdır.");
        box.addView(statusText);

        box.addView(roleButton("🛍️  Müştəri tətbiqi", "Restoran və marketlərdən sifariş", ROLE_CUSTOMER));
        box.addView(roleButton("🏪  Satıcı paneli", "Mağaza sahibləri üçün", ROLE_VENDOR));
        box.addView(roleButton("🛠  Admin paneli", "Platforma idarəsi", ROLE_ADMIN));

        Button save = new Button(this);
        save.setText("Ünvanı yadda saxla");
        save.setAllCaps(false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = dp(14);
        save.setLayoutParams(sp);
        save.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { saveServer(); }
        });
        box.addView(save);

        TextView help = new TextView(this);
        help.setTextSize(12.5f);
        help.setTextColor(Color.parseColor("#5B6B7C"));
        help.setPadding(0, dp(20), 0, 0);
        help.setText("Kompüterdə serveri belə işə salın:\n"
                + "$env:HOST='0.0.0.0'; node server/index.js\n\n"
                + "Sonra brauzerdə/telefonda: http://<kompüterin-IP>:4173\n"
                + "Windows Firewall soruşanda «İcazə ver» seçin.");
        box.addView(help);

        homeScreen = new LinearLayout(this);
        homeScreen.setOrientation(LinearLayout.VERTICAL);
        homeScreen.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        root.addView(homeScreen, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private TextView label(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(13f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextColor(Color.parseColor("#5B6B7C"));
        tv.setPadding(0, dp(8), 0, dp(4));
        return tv;
    }

    private Button roleButton(String title, String subtitle, final int role) {
        Button b = new Button(this);
        b.setText(title + "\n" + subtitle);
        b.setAllCaps(false);
        b.setTextSize(16f);
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        b.setPadding(dp(18), dp(14), dp(18), dp(14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(10);
        b.setLayoutParams(lp);
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { saveServer(); openRole(role); }
        });
        return b;
    }

    private void saveServer() {
        String value = serverInput.getText().toString().trim();
        if (value.isEmpty()) {
            value = DEFAULT_SERVER;
        }
        if (!value.startsWith("http://") && !value.startsWith("https://")) {
            value = "http://" + value;
        }
        while (value.endsWith("/")) {
            value = value.substring(0, value.length() - 1);
        }
        serverUrl = value;
        serverInput.setText(value);
        prefs.edit().putString(KEY_SERVER, value).apply();
    }

    /* ------------------------------------------------------------------ *
     * WebView ekranı
     * ------------------------------------------------------------------ */
    private void buildWebScreen() {
        webScreen = new LinearLayout(this);
        webScreen.setOrientation(LinearLayout.VERTICAL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(Color.parseColor("#0E1726"));
        bar.setPadding(dp(6), dp(6), dp(6), dp(6));

        bar.addView(barButton("←", new View.OnClickListener() {
            @Override public void onClick(View v) { showHome(); }
        }));
        bar.addView(barButton("⟳", new View.OnClickListener() {
            @Override public void onClick(View v) { if (web != null) web.reload(); }
        }));
        bar.addView(barButton("⌂", new View.OnClickListener() {
            @Override public void onClick(View v) { goBackInWeb(); }
        }));

        final TextView title = new TextView(this);
        title.setText("Götür");
        title.setTextColor(Color.WHITE);
        title.setTextSize(14f);
        title.setSingleLine(true);
        title.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        tp.leftMargin = dp(8);
        title.setLayoutParams(tp);
        bar.addView(title);
        this.webTitle = title;

        webScreen.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " GoturApp/1.0");
        web.setWebViewClient(new WebViewClient());
        // Başlıq açılan səhifəyə uyğunlaşsın (müştəri/satıcı/admin)
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onReceivedTitle(WebView view, String title) {
                if (title != null && !title.isEmpty() && webTitle != null) {
                    webTitle.setText(title);
                }
            }
        });
        web.setBackgroundColor(Color.parseColor("#F6F8FB"));

        webScreen.addView(web, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(webScreen, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private TextView webTitle;

    private Button barButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16f);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(10), 0, dp(10), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.rightMargin = dp(4);
        b.setLayoutParams(lp);
        b.setOnClickListener(listener);
        return b;
    }

    private void openRole(int role) {
        if (webScreen == null) buildWebScreen();
        String path = "";
        String name = "Götür";
        if (role == ROLE_VENDOR) { path = "/satis.html"; name = "Satıcı paneli"; }
        else if (role == ROLE_ADMIN) { path = "/admin.html"; name = "Admin paneli"; }
        else { name = "Müştəri tətbiqi"; }

        if (webTitle != null) webTitle.setText(name);
        webScreen.setVisibility(View.VISIBLE);
        homeScreen.setVisibility(View.GONE);
        web.loadUrl(serverUrl + path);
    }

    private void showHome() {
        if (homeScreen == null) return;
        homeScreen.setVisibility(View.VISIBLE);
        if (webScreen != null) webScreen.setVisibility(View.GONE);
    }

    private void goBackInWeb() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            showHome();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (webScreen != null && webScreen.getVisibility() == View.VISIBLE) {
                goBackInWeb();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
