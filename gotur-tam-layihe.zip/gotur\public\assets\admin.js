/* ==================================================================
   Götür — platforma admin paneli
   Bölmələr: #icmal | #saticalar | #sifarisler | #istifadeciler
   ================================================================== */
import * as U from './common.js';
const { h, raw } = U;

const main = U.qs('#panel-main');
const sidebar = U.qs('#sidebar');

const state = {
  section: 'icmal',
  stats: null,
  vendors: [],
  orders: [],
  users: [],
  payments: [],
  reviews: [],
  coupons: [],
  orderFilter: 'all',
  vendorFilter: 'all',
  paymentFilter: 'all',
  reviewFilter: 'all',
  setRange: 'month',
  setCustom: {},
  settlement: null,
  q: '',
  poller: null,
  live: null,
};

/* ------------------------------------------------------------------ *
 * Başlanğıc
 * ------------------------------------------------------------------ */
(async function boot() {
  const { ok } = await U.requireRole('admin');
  if (!ok) return renderLogin();

  renderSidebar();
  bindDelegates();
  U.initPanelMenu('#sidebar');
  const hint = document.getElementById('ptb-hint');
  if (hint) hint.textContent = U.t('a.scopePlatform');

  const initial = location.hash.replace(/^#\/?/, '');
  if (SECTIONS.includes(initial)) state.section = initial;

  window.addEventListener('hashchange', () => {
    const hash = location.hash.replace(/^#\/?/, '');
    if (SECTIONS.includes(hash)) {
      state.section = hash;
      renderSidebar();
      paint();
    }
  });
  paint();
})();

const SECTIONS = ['icmal', 'saticalar', 'kateqoriyalar', 'sifarisler', 'odenisler', 'kampaniyalar', 'reyler', 'hesablasma', 'istifadeciler'];

function renderLogin() {
  document.body.classList.add('no-menu'); // girişsiz: üst zolaq gizlədilir
  sidebar.style.display = 'none';
  main.innerHTML = h`
    <div style="max-width:480px;margin:40px auto">
      <div class="card card-pad">
        <h1 style="font-size:24px">⚙️ ${U.t('nav.adminPanel')}</h1>
        <p class="muted mt-1">${U.t('a.panelSubtitle')}</p>
        <div class="col mt-3">
          <div class="field"><label>${U.t('common.phone')}</label><input class="input" name="phone" placeholder="0500000000"></div>
          <div class="field"><label>${U.t('auth.password')}</label><input class="input" type="password" name="password"></div>
          <button class="btn btn-dark btn-lg btn-block" data-act="login">${U.t('nav.login')}</button>
        </div>
        <p class="small muted mt-3">${U.t('a.demoAccount')}: <b>0500000000</b> / admin123</p>
        <p class="small muted"><a href="/">← ${U.t('nav.customerApp')}</a> · <a href="/satis.html">${U.t('nav.vendorPanel')}</a></p>
      </div>
    </div>`;
  U.qs('[data-act="login"]', main).addEventListener('click', async (e) => {
    const val = (n) => main.querySelector(`[name="${n}"]`).value.trim();
    e.target.disabled = true;
    try {
      const data = await U.login(val('phone'), val('password'));
      if (data.user.role !== 'admin') { U.toast(U.t('a.notAdmin'), 'err'); e.target.disabled = false; return; }
      location.reload();
    } catch (err) { U.toast(err.message, 'err'); e.target.disabled = false; }
  });
}

function renderSidebar() {
  const item = (key, icon, label, badge) => `
    <a href="#${key}" class="${state.section === key ? 'active' : ''}">
      <span>${icon} ${label}</span>${badge ? `<span class="badge ${badge.cls}">${badge.text}</span>` : ''}
    </a>`;
  const pending = state.stats?.totals.pendingVendors;

  sidebar.innerHTML = h`
    <div class="brand"><span class="mark">⚙️</span> ${U.t('app.name')}<small style="font-weight:500;opacity:.7"> admin</small></div>
    ${raw(item('icmal', '📊', U.t('a.sidebarOverview'), null))}
    ${raw(item('saticalar', '🏪', U.t('a.sidebarVendors'), pending ? { text: pending, cls: 'badge-warn' } : null))}
    ${raw(item('kateqoriyalar', '🗂️', U.t('a.sidebarCategories'), null))}
    ${raw(item('sifarisler', '🧾', U.t('a.sidebarOrders'), null))}
    ${raw(item('odenisler', '💳', U.t('a.sidebarPayments'), null))}
    ${raw(item('kampaniyalar', '🎁', U.t('a.sidebarCoupons'), null))}
    ${raw(item('reyler', '⭐', U.t('a.sidebarReviews'), null))}
    ${raw(item('hesablasma', '💰', U.t('a.sidebarSettlements'), null))}
    ${raw(item('istifadeciler', '👥', U.t('a.sidebarUsers'), null))}
    <div class="spacer"></div>
    <div class="who">
      ${U.t('a.platformAdmin')}<br>
      <a href="/" style="color:#7fd6ea">${U.t('nav.toCustomer')}</a> ·
      <a href="/satis.html" style="color:#7fd6ea">${U.t('nav.vendorPanel')} →</a>
    </div>
    <button class="btn btn-sm btn-outline" data-act="logout" style="margin:8px 4px">${U.t('nav.logout')}</button>`;

  sidebar.querySelector('[data-act="logout"]')?.addEventListener('click', async () => {
    await U.logout();
    location.href = '/';
  });
}

async function paint() {
  state.poller?.stop();
  state.live?.close();
  state.live = null;
  if (state.section === 'icmal') return paintOverview();
  if (state.section === 'saticalar') return paintVendors();
  if (state.section === 'kateqoriyalar') return paintCategories();
  if (state.section === 'sifarisler') return paintOrders();
  if (state.section === 'odenisler') return paintPayments();
  if (state.section === 'kampaniyalar') return paintAdminCoupons();
  if (state.section === 'reyler') return paintAdminReviews();
  if (state.section === 'hesablasma') return paintSettlements();
  if (state.section === 'istifadeciler') return paintUsers();
}

const SET_RANGES = [
  { key: 'month', labelKey: 'a.setThisMonth' },
  { key: 'last', labelKey: 'a.setLastMonth' },
  { key: 'year', labelKey: 'a.setThisYear' },
  { key: 'custom', labelKey: 'a.setCustom' },
];

const setRangeParams = (key, custom = {}) => {
  const now = new Date();
  const iso = (d) => d.toISOString();
  if (key === 'month') return { from: iso(new Date(now.getFullYear(), now.getMonth(), 1)), to: iso(now) };
  if (key === 'last') {
    return {
      from: iso(new Date(now.getFullYear(), now.getMonth() - 1, 1)),
      to: iso(new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59)),
    };
  }
  if (key === 'year') return { from: iso(new Date(now.getFullYear(), 0, 1)), to: iso(now) };
  return { from: custom.from || undefined, to: custom.to || undefined };
};

async function paintSettlements() {
  state.setRange = state.setRange ?? 'month';
  const range = setRangeParams(state.setRange, state.setCustom ?? {});
  const params = new URLSearchParams();
  if (range.from) params.set('from', range.from);
  if (range.to) params.set('to', range.to);

  main.innerHTML = h`
    <div class="panel-head">
      <div><h1>${U.t('a.setTitle')}</h1><p class="muted small mt-1">${U.t('a.setSubtitle')}</p></div>
      <div class="tabs">
        ${raw(SET_RANGES.map((r) => `<button data-set-range="${r.key}"
          class="${state.setRange === r.key ? 'active' : ''}">${U.t(r.labelKey)}</button>`).join(''))}
      </div>
    </div>
    ${state.setRange === 'custom'
      ? raw(`<div class="row wrap-row mb-3" style="gap:10px">
          <div class="field"><label>${U.t('a.setFrom')}</label>
            <input class="input input-sm" type="date" data-set-from value="${U.esc((state.setCustom?.from ?? '').slice(0, 10))}"></div>
          <div class="field"><label>${U.t('a.setTo')}</label>
            <input class="input input-sm" type="date" data-set-to value="${U.esc((state.setCustom?.to ?? '').slice(0, 10))}"></div>
          <button class="btn btn-dark btn-sm" data-act="apply-set-range" style="align-self:end">${U.t('actions.apply')}</button>
        </div>`)
      : ''}
    <div id="settlements-area"><div class="skeleton" style="height:260px"></div></div>`;

  let data;
  try {
    data = await U.api(`/api/admin/settlements?${params}`);
  } catch (err) {
    U.qs('#settlements-area').innerHTML = h`<div class="card card-pad">${U.errText(err)}</div>`;
    return;
  }
  state.settlement = data;
  renderSettlements(data);
}

function renderSettlements(data) {
  const t = data.totals;
  const host = U.qs('#settlements-area');

  host.innerHTML = h`
    <div class="card card-pad mb-3">
      <div class="row-between wrap-row">
        <div>
          <h3>${U.t('a.setCommissionTitle')}</h3>
          <p class="small muted mt-1">${U.t('a.setCommissionHint')}</p>
        </div>
        <div class="row" style="gap:8px">
          <div class="field"><label>${U.t('a.setDefaultCommission')}</label>
            <input class="input input-sm" type="number" min="0" max="40" step="0.5"
                   data-default-commission value="${data.settings.defaultCommission}"></div>
          <button class="btn btn-primary btn-sm" data-act="save-commission" style="align-self:end">
            ${U.t('actions.save')}</button>
        </div>
      </div>
    </div>

    <div class="stat-grid mb-3">
      <div class="card stat"><span>${U.t('a.setGross')}</span><b>${U.azn(t.gross)}</b>
        <span class="tiny muted">${t.orders} ${U.t('common.orders')} · ${t.vendors} ${U.t('a.setVendors')}</span></div>
      <div class="card stat"><span>${U.t('a.setCommission')}</span><b>${U.azn(t.commission)}</b>
        <span class="tiny muted">${U.t('a.setPlatformRevenue')}: ${U.azn(t.platformRevenue)}</span></div>
      <div class="card stat"><span>${U.t('a.setDiscount')}</span><b>${U.azn(t.discount)}</b>
        <span class="tiny muted">${U.t('a.setDiscountHint')}</span></div>
      <div class="card stat"><span>${U.t('a.setOnline')} / ${U.t('a.setCounter')}</span>
        <b style="font-size:19px">${U.azn(t.online)} <span class="muted">/</span> ${U.azn(t.counter)}</b>
        <span class="tiny muted">${U.t('a.setCollectedHint')}</span></div>
      <div class="card stat"><span>${U.t('a.setPayoutTotal')}</span><b>${U.azn(t.payout)}</b>
        <span class="tiny muted">${U.t('a.setPayoutHint')}</span></div>
      <div class="card stat"><span>${U.t('a.setDueTotal')}</span><b>${U.azn(t.due)}</b>
        <span class="tiny muted">${U.t('a.setDueHint')}</span></div>
    </div>

    <div class="card mb-3">
      <div class="card-pad" style="border-bottom:1px solid var(--line)">
        <h3>${U.t('a.setByVendor')}</h3>
        <p class="small muted mt-1">${U.t('a.setPeriod')}: ${U.dateTime(data.period.from)} — ${U.dateTime(data.period.to)}</p>
      </div>
      <div class="table-wrap"><table class="table">
        <thead><tr>
          <th>${U.t('a.setVendor')}</th><th>${U.t('a.setRate')}</th><th>${U.t('a.setOrders')}</th>
          <th>${U.t('a.setGross')}</th><th>${U.t('a.setCommission')}</th><th>${U.t('a.setDiscount')}</th>
          <th>${U.t('a.setPayout')}</th><th>${U.t('a.setDue')}</th><th>${U.t('a.setNet')}</th><th></th>
        </tr></thead>
        <tbody>${raw(data.vendors.map((v) => `<tr>
          <td><a href="/#/v/${U.esc(v.slug)}" target="_blank"><b>${U.esc(v.name)}</b> ↗</a></td>
          <td class="nowrap">
            <input class="input input-sm" style="width:80px" type="number" min="0" max="40" step="0.5"
                   data-vendor-rate="${v.vendorId}" value="${v.ownCommissionPercent}"
                   title="${U.t('a.setOwnHint')}">
            <div class="tiny muted">${v.ownCommissionPercent ? U.t('a.setOwn') : `${U.t('a.setDefault')} ${v.commissionPercent}%`}</div>
          </td>
          <td>${v.orders}</td>
          <td>${U.azn(v.gross)}</td>
          <td><b>${U.azn(v.commission)}</b></td>
          <td>${v.discount ? `−${U.azn(v.discount)}` : '—'}</td>
          <td>${U.azn(v.payout)}</td>
          <td>${U.azn(v.due)}</td>
          <td><b style="color:${v.net >= 0 ? '#0b7a45' : '#8a5200'}">${U.azn(v.net)}</b></td>
          <td class="right nowrap">
            <button class="btn btn-sm btn-outline" data-set-create="${v.vendorId}"
              ${v.orders ? '' : 'disabled'}>${U.t('a.setCreate')}</button>
          </td>
        </tr>`).join(''))}</tbody>
      </table></div>
    </div>

    <div class="card">
      <div class="card-pad" style="border-bottom:1px solid var(--line)">
        <h3>${U.t('a.setHistoryTitle')}</h3>
      </div>
      ${data.history?.length
    ? raw(`<div class="table-wrap"><table class="table">
          <thead><tr><th>${U.t('a.setVendor')}</th><th>${U.t('a.setPeriod')}</th><th>${U.t('a.setOrders')}</th>
            <th>${U.t('a.setCommission')}</th><th>${U.t('a.setPayout')}</th><th>${U.t('common.status')}</th><th></th></tr></thead>
          <tbody>${data.history.map((s) => `<tr>
            <td><b>${U.esc(s.vendorName ?? '')}</b><div class="tiny muted">${U.esc(s.note || '')}</div></td>
            <td class="small nowrap">${U.dateTime(s.periodStart)} — ${U.dateTime(s.periodEnd)}</td>
            <td>${s.ordersCount}</td>
            <td>${U.azn(s.commission)}</td>
            <td><b>${U.azn(s.payout)}</b></td>
            <td>${s.status === 'paid'
    ? `<span class="badge badge-open">${U.t('a.setPaid')}</span><div class="tiny muted">${U.dateTime(s.paidAt)}</div>`
    : `<span class="badge badge-warn">${U.t('v.setStatusPending')}</span>`}</td>
            <td class="right nowrap">
              ${s.status === 'paid' ? '' : `<button class="btn btn-sm btn-ok" data-set-pay="${s.id}">${U.t('a.setMarkPaid')}</button>`}
              <button class="btn btn-sm btn-danger" data-set-del="${s.id}">${U.t('actions.delete')}</button>
            </td>
          </tr>`).join('')}</tbody>
        </table></div>`)
    : raw(`<div class="empty">${U.t('a.setNoHistory')}</div>`)}
    </div>`;
}

/* ------------------------------------------------------------------ *
 * Yeni mağaza yaratmaq (admin birbaşa yaradır)
 * ------------------------------------------------------------------ */
async function newVendorModal() {
  const { categories } = await U.api('/api/admin/categories');
  state.categories = categories;
  const catsFor = (kind, selected) => categories
    .filter((c) => c.kind === kind)
    .map((c) => `<option value="${U.esc(c.slug)}" ${selected === c.slug ? 'selected' : ''}>
      ${U.esc(c.icon)} ${U.esc(c.name)}</option>`).join('');

  const m = U.modal({
    title: U.t('a.newVendorTitle'),
    body: h`
      <p class="small muted mb-2">${U.t('a.newVendorHint')}</p>
      <div class="form-grid">
        <div class="field"><label>${U.t('a.ownerName')} *</label>
          <input class="input" name="ownerName" placeholder="${U.t('a.ownerNamePlaceholder')}"></div>
        <div class="field"><label>${U.t('auth.vendorName')} *</label>
          <input class="input" name="vendorName" placeholder="${U.t('a.vendorNamePlaceholder')}"></div>
        <div class="field"><label>${U.t('common.phone')} *</label>
          <input class="input" name="phone" placeholder="050 123 45 67">
          <span class="hint">${U.t('a.ownerPhoneHint')}</span></div>
        <div class="field"><label>${U.t('auth.password')}</label>
          <input class="input" name="password" placeholder="${U.t('a.passwordAutoPlaceholder')}">
          <span class="hint">${U.t('a.passwordAutoHint')}</span></div>
        <div class="field"><label>${U.t('auth.vendorKind')}</label>
          <select class="select" name="kind" data-kind>
            <option value="restaurant">${U.t('auth.restaurantKind')}</option>
            <option value="market">${U.t('auth.marketKind')}</option>
          </select></div>
        <div class="field"><label>${U.t('v.storeCategory')}</label>
          <select class="select" name="category" data-category>${raw(catsFor('restaurant'))}</select></div>
        <div class="field"><label>${U.t('customer.addressPlaceholder')}</label>
          <input class="input" name="address" placeholder="${U.t('customer.addressPlaceholder')}"></div>
        <div class="field"><label>${U.t('v.storePhone')}</label>
          <input class="input" name="vendorPhone" placeholder="+994 12 000 00 00"></div>
        <div class="field"><label>${U.t('v.storeLogo')}</label>
          <input class="input" name="logo" value="🍽️" placeholder="🍰"></div>
        <div class="field"><label>${U.t('v.storePrepTime')}</label>
          <input class="input" type="number" min="1" max="240" name="prepTime" value="20"></div>
        <div class="field"><label>${U.t('v.storeMinOrder')}</label>
          <input class="input" type="number" min="0" step="0.5" name="minOrder" value="0"></div>
        <div class="field"><label>${U.t('a.setRate')}</label>
          <input class="input" type="number" min="0" max="40" step="0.5" name="commissionPercent" value="0">
          <span class="hint">${U.t('a.setOwnHint')}</span></div>
        <div class="field" style="grid-column:1/-1"><label>${U.t('v.storeTagline')}</label>
          <input class="input" name="tagline" placeholder="${U.t('a.taglinePlaceholder')}"></div>
      </div>`,
    footer: `<button class="btn btn-outline" data-close>${U.t('actions.cancel')}</button>
             <button class="btn btn-primary" data-create>${U.t('a.createVendor')}</button>`,
  });

  const kindEl = m.root.querySelector('[data-kind]');
  const catEl = m.root.querySelector('[data-category]');
  const logoEl = m.root.querySelector('[name="logo"]');
  kindEl.addEventListener('change', () => {
    catEl.innerHTML = catsFor(kindEl.value);
    logoEl.value = kindEl.value === 'market' ? '🛒' : '🍽️';
  });

  m.root.querySelector('[data-create]').addEventListener('click', async (e) => {
    const val = (n) => m.root.querySelector(`[name="${n}"]`)?.value.trim() ?? '';
    const body = {
      ownerName: val('ownerName'),
      vendorName: val('vendorName'),
      phone: val('phone'),
      password: val('password') || null,
      kind: val('kind'),
      category: val('category'),
      address: val('address'),
      vendorPhone: val('vendorPhone'),
      logo: val('logo'),
      tagline: val('tagline'),
      prepTime: Number(val('prepTime')) || 20,
      minOrder: Number(val('minOrder')) || 0,
      commissionPercent: Number(val('commissionPercent')) || 0,
      approved: true,
    };
    if (!body.ownerName) return U.toast(U.t('a.ownerNameRequired'), 'err');
    if (!body.vendorName) return U.toast(U.t('a.vendorNameRequired'), 'err');
    if (!body.phone) return U.toast(U.t('a.phoneRequired'), 'err');

    e.target.disabled = true;
    try {
      const res = await U.api('/api/admin/vendors', { method: 'POST', body });
      m.close();
      U.toast(U.t('a.vendorCreated', { name: body.vendorName }), 'ok', 5000);
      await paintVendors();
      credentialModal(res);
    } catch (err) {
      U.toast(U.errText(err), 'err', 6000);
      e.target.disabled = false;
    }
  });
}

/** Yeni mağaza sahibinə veriləcək giriş məlumatları */
function credentialModal(res) {
  const { owner, credentials, vendor } = res;
  const text = `${U.t('a.credTitle')}
${U.t('auth.vendorName')}: ${vendor.name}
${U.t('nav.login')}: ${globalThis.location?.origin ?? ''}/satis.html
${U.t('common.phone')}: ${credentials.phone}
${U.t('auth.password')}: ${credentials.password}`;

  const m = U.modal({
    title: U.t('a.credTitle'),
    body: h`
      <p class="small muted">${U.t('a.credHint', { name: owner.name })}</p>
      <div class="card card-pad mt-2" style="background:var(--brand-soft);border:none">
        <div class="row-between"><span class="muted small">${U.t('auth.vendorName')}</span><b>${U.esc(vendor.name)}</b></div>
        <div class="row-between mt-1"><span class="muted small">${U.t('common.phone')}</span><b>${U.esc(credentials.phone)}</b></div>
        <div class="row-between mt-1"><span class="muted small">${U.t('auth.password')}</span>
          <b style="letter-spacing:.08em">${U.esc(credentials.password)}</b></div>
        ${credentials.generated
    ? raw(`<p class="tiny mt-2">${U.t('a.credGenerated')}</p>`)
    : raw(`<p class="tiny mt-2">${U.t('a.credManual')}</p>`)}
      </div>
      <p class="small mt-2">${U.t('a.credSendHint')}</p>`,
    footer: `<button class="btn btn-outline" data-copy>${U.t('actions.copy')}</button>
             <button class="btn btn-primary" data-close>${U.t('nav.close')}</button>`,
  });

  m.root.querySelector('[data-copy]').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(text);
      U.toast(U.t('actions.copied'), 'ok');
    } catch {
      U.toast(text, '', 8000);
    }
  });
}

/* ------------------------------------------------------------------ *
 * Kateqoriyalar
 * ------------------------------------------------------------------ */
async function paintCategories() {
  main.innerHTML = h`
    <div class="panel-head">
      <div><h1>${U.t('a.catTitle')}</h1><p class="muted small mt-1">${U.t('a.catSubtitle')}</p></div>
      <button class="btn btn-primary" data-act="new-category">${U.t('a.newCategory')}</button>
    </div>
    <div id="categories-area"><div class="skeleton" style="height:240px"></div></div>`;

  U.qs('[data-act="new-category"]', main).addEventListener('click', () => categoryModal(null));
  await loadCategories();
}

async function loadCategories() {
  const { categories } = await U.api('/api/admin/categories');
  state.categories = categories;
  const kinds = { restaurant: U.t('a.kindRestaurant'), market: U.t('a.kindMarket') };
  const host = U.qs('#categories-area');
  host.innerHTML = h`<div class="card"><div class="table-wrap"><table class="table">
    <thead><tr><th>${U.t('v.storeLogo')}</th><th>${U.t('v.storeName')}</th><th>${U.t('a.catSlug')}</th>
      <th>${U.t('auth.vendorKind')}</th><th>${U.t('a.catSort')}</th><th>${U.t('a.setVendors')}</th>
      <th>${U.t('a.tableProducts')}</th><th></th></tr></thead>
    <tbody>${raw(categories.map((c) => `<tr>
      <td style="font-size:20px">${U.esc(c.icon)}</td>
      <td><b>${U.esc(c.name)}</b></td>
      <td class="small muted">${U.esc(c.slug)}</td>
      <td><span class="badge ${c.kind === 'market' ? 'badge-info' : 'badge-brand'}">${U.esc(kinds[c.kind] ?? c.kind)}</span></td>
      <td>${c.sort}</td>
      <td>${c.vendorCount}</td>
      <td>${c.productCount}</td>
      <td class="right nowrap">
        <button class="btn btn-sm btn-outline" data-cat-edit="${c.id}">${U.t('actions.edit')}</button>
        <button class="btn btn-sm btn-danger" data-cat-del="${c.id}">${U.t('actions.delete')}</button>
      </td>
    </tr>`).join(''))}</tbody>
  </table></div></div>`;
}

function categoryModal(category) {
  const isNew = !category;
  const m = U.modal({
    title: isNew ? U.t('a.newCategoryTitle') : U.t('a.catEditTitle', { name: category.name }),
    body: h`
      <div class="form-grid">
        <div class="field"><label>${U.t('v.storeName')} *</label>
          <input class="input" name="name" value="${U.esc(category?.name ?? '')}" placeholder="${U.t('a.catNamePlaceholder')}"></div>
        <div class="field"><label>${U.t('v.storeLogo')}</label>
          <input class="input" name="icon" value="${U.esc(category?.icon ?? '🛒')}" placeholder="🏥"></div>
        <div class="field"><label>${U.t('auth.vendorKind')}</label>
          <select class="select" name="kind">
            <option value="restaurant" ${category?.kind === 'restaurant' ? 'selected' : ''}>${U.t('auth.restaurantKind')}</option>
            <option value="market" ${category?.kind !== 'restaurant' ? 'selected' : ''}>${U.t('auth.marketKind')}</option>
          </select>
          <span class="hint">${U.t('a.catKindHint')}</span></div>
        <div class="field"><label>${U.t('a.catSlug')}</label>
          <input class="input" name="slug" value="${U.esc(category?.slug ?? '')}" placeholder="${U.t('a.catSlugPlaceholder')}">
          <span class="hint">${U.t('a.catSlugHint')}</span></div>
        <div class="field"><label>${U.t('a.catSort')}</label>
          <input class="input" type="number" name="sort" value="${category?.sort ?? ''}" placeholder="20">
          <span class="hint">${U.t('a.catSortHint')}</span></div>
      </div>`,
    footer: `<button class="btn btn-outline" data-close>${U.t('actions.cancel')}</button>
             <button class="btn btn-primary" data-save>${isNew ? U.t('actions.create') : U.t('actions.save')}</button>`,
  });

  m.root.querySelector('[data-save]').addEventListener('click', async (e) => {
    const val = (n) => m.root.querySelector(`[name="${n}"]`)?.value.trim() ?? '';
    const body = {
      name: val('name'),
      icon: val('icon'),
      kind: val('kind'),
      slug: val('slug') || undefined,
      sort: val('sort') === '' ? undefined : Number(val('sort')),
    };
    if (!body.name) return U.toast(U.t('a.catNameRequired'), 'err');
    e.target.disabled = true;
    try {
      if (isNew) await U.api('/api/admin/categories', { method: 'POST', body });
      else await U.api(`/api/admin/categories/${category.id}`, { method: 'PATCH', body });
      m.close();
      U.toast(isNew ? U.t('a.catCreated') : U.t('a.catUpdated'), 'ok');
      await loadCategories();
    } catch (err) {
      U.toast(U.errText(err), 'err', 5000);
      e.target.disabled = false;
    }
  });
}

/* ------------------------------------------------------------------ *
 * Kampaniyalar (bütün platforma)
 * ------------------------------------------------------------------ */
async function paintAdminCoupons() {
  main.innerHTML = h`
    <div class="panel-head">
      <div><h1>${U.t('vendorPage.promotions')}</h1>
        <p class="muted small mt-1">${U.t('a.couponsSubtitle')}</p></div>
      <button class="btn btn-primary" data-act="new-coupon">${U.t('v.newCoupon')}</button>
    </div>
    <div id="coupons-admin-area"><div class="skeleton" style="height:220px"></div></div>`;

  U.qs('[data-act="new-coupon"]', main).addEventListener('click', () => adminCouponModal(null));
  if (!state.vendors.length) {
    const { vendors } = await U.api('/api/admin/vendors');
    state.vendors = vendors;
  }
  await loadAdminCoupons();
}

async function loadAdminCoupons() {
  const { coupons } = await U.api('/api/admin/coupons');
  state.coupons = coupons;
  const host = U.qs('#coupons-admin-area');
  if (!coupons.length) {
    host.innerHTML = h`<div class="card"><div class="empty"><div class="big">🎁</div>
      <h3>${U.t('v.couponsEmpty')}</h3><p class="muted mt-1">${U.t('a.couponsEmptyHint')}</p></div></div>`;
    return;
  }
  host.innerHTML = h`<div class="card"><div class="table-wrap"><table class="table">
    <thead><tr><th>${U.t('v.tableCode')}</th><th>${U.t('a.coverage')}</th><th>${U.t('common.discount')}</th><th>${U.t('v.tableConditions')}</th><th>${U.t('v.tableUsage')}</th><th>${U.t('a.tablePeriod')}</th><th>${U.t('common.status')}</th><th></th></tr></thead>
    <tbody>${raw(coupons.map((c) => `<tr>
      <td><b style="letter-spacing:.06em">${U.esc(c.code)}</b>
        ${c.description ? `<div class="tiny muted">${U.esc(c.description)}</div>` : ''}</td>
      <td>${c.scope === 'platform'
        ? `<span class="badge badge-brand">${U.t('a.scopePlatform')}</span>`
        : `<a href="/#/v/${U.esc(c.vendorSlug)}" target="_blank">${U.esc(c.vendorName)} ↗</a>`}</td>
      <td><b>${c.kind === 'percent' ? `${c.value}%` : U.azn(c.value)}</b>
        ${c.maxDiscount ? `<div class="tiny muted">${U.t('v.maxDiscountShort', { amount: U.azn(c.maxDiscount) })}</div>` : ''}</td>
      <td class="small muted">${c.minOrder ? `${U.t('a.minShort', { amount: U.azn(c.minOrder) })}<br>` : ''}
        ${c.usageLimit ? U.t('a.limitShort', { count: c.usageLimit }) : U.t('v.unlimited')} · ${U.t('a.perUserShort', { count: c.perUserLimit })}</td>
      <td>${c.stats?.orders ?? 0}
        <div class="tiny muted">−${U.azn(c.stats?.discounted ?? 0)}</div></td>
      <td class="small muted nowrap">${c.startsAt ? `${U.t('a.startsShort', { date: U.dateTime(c.startsAt) })}<br>` : ''}
        ${c.expiresAt ? U.t('a.expiresShort', { date: U.dateTime(c.expiresAt) }) : U.t('v.noExpiry')}</td>
      <td>${c.active ? `<span class="badge badge-open">${U.t('v.active')}</span>` : `<span class="badge">${U.t('v.inactive')}</span>`}</td>
      <td class="right nowrap">
        <button class="btn btn-sm btn-outline" data-coupon-edit="${c.id}">${U.t('actions.edit')}</button>
        <button class="btn btn-sm btn-danger" data-coupon-del="${c.id}">${U.t('actions.delete')}</button>
      </td></tr>`).join(''))}</tbody>
  </table></div></div>`;
}

function adminCouponModal(coupon) {
  const isNew = !coupon;
  const vendorOptions = state.vendors
    .map((v) => `<option value="${v.id}" ${coupon?.vendorId === v.id ? 'selected' : ''}>${U.esc(v.name)}</option>`)
    .join('');

  const m = U.modal({
    title: isNew ? U.t('v.couponCreatedTitle') : `${U.t('actions.edit')}: ${coupon.code}`,
    body: h`
      <div class="form-grid">
        <div class="field"><label>${U.t('v.couponCode')}</label>
          <input class="input" name="code" value="${coupon?.code ?? ''}" placeholder="GOTUR10" style="text-transform:uppercase"></div>
        <div class="field"><label>${U.t('a.coverage')}</label>
          <select class="select" name="vendorId">
            <option value="" ${coupon?.vendorId ? '' : 'selected'}>${U.t('a.scopePlatformFull')}</option>
            ${raw(vendorOptions)}
          </select></div>
        <div class="field"><label>${U.t('v.couponKind')}</label>
          <select class="select" name="kind">
            <option value="percent" ${coupon?.kind !== 'fixed' ? 'selected' : ''}>${U.t('v.couponKindPercent')}</option>
            <option value="fixed" ${coupon?.kind === 'fixed' ? 'selected' : ''}>${U.t('v.couponKindFixed')}</option>
          </select></div>
        <div class="field"><label data-value-label>${U.t('v.couponPercent')}</label>
          <input class="input" name="value" type="number" step="1" min="1"
                 value="${coupon ? (coupon.kind === 'percent' ? coupon.value : (coupon.value / 100).toFixed(2)) : ''}"></div>
        <div class="field"><label>${U.t('v.couponMaxDiscount')}</label>
          <input class="input" name="maxDiscount" type="number" step="0.5" min="0"
                 value="${coupon ? (coupon.maxDiscount / 100).toFixed(2) : '0'}"></div>
        <div class="field"><label>${U.t('v.couponMinOrder')}</label>
          <input class="input" name="minOrder" type="number" step="0.5" min="0"
                 value="${coupon ? (coupon.minOrder / 100).toFixed(2) : '0'}"></div>
        <div class="field"><label>${U.t('v.couponUsageLimit')}</label>
          <input class="input" name="usageLimit" type="number" min="0" value="${coupon?.usageLimit ?? 0}"></div>
        <div class="field"><label>${U.t('a.couponPerUser')}</label>
          <input class="input" name="perUserLimit" type="number" min="0" value="${coupon?.perUserLimit ?? 1}"></div>
        <div class="field"><label>${U.t('v.couponStarts')}</label>
          <input class="input" name="startsAt" type="date" value="${coupon?.startsAt ? coupon.startsAt.slice(0, 10) : ''}"></div>
        <div class="field"><label>${U.t('v.couponExpires')}</label>
          <input class="input" name="expiresAt" type="date" value="${coupon?.expiresAt ? coupon.expiresAt.slice(0, 10) : ''}"></div>
        <div class="field" style="grid-column:1/-1"><label>${U.t('v.fieldDescription')}</label>
          <input class="input" name="description" value="${coupon?.description ?? ''}"
                 placeholder="${U.t('a.couponDescriptionPlaceholder')}"></div>
        <div class="field"><label>${U.t('common.status')}</label>
          <label class="switch" style="padding-top:6px">
            <input type="checkbox" name="active" ${coupon?.active === false ? '' : 'checked'}>
            <span class="track"></span><span class="small">${U.t('v.tabActive')}</span></label></div>
      </div>`,
    footer: `<button class="btn btn-outline" data-close>${U.t('actions.cancel')}</button>
             <button class="btn btn-primary" data-save>${isNew ? U.t('actions.create') : U.t('actions.save')}</button>`,
  });

  const kindEl = m.root.querySelector('[name="kind"]');
  const valueLabel = m.root.querySelector('[data-value-label]');
  const syncKind = () => {
    valueLabel.textContent = kindEl.value === 'percent' ? U.t('v.couponPercent') : U.t('v.couponAmount');
  };
  kindEl.addEventListener('change', syncKind);
  syncKind();

  m.root.querySelector('[data-save]').addEventListener('click', async (e) => {
    const val = (n) => m.root.querySelector(`[name="${n}"]`)?.value.trim() ?? '';
    const body = {
      code: val('code'),
      vendorId: val('vendorId') ? Number(val('vendorId')) : null,
      kind: val('kind'),
      value: Number(val('value').replace(',', '.')),
      minOrder: Number(val('minOrder').replace(',', '.')) || 0,
      maxDiscount: Number(val('maxDiscount').replace(',', '.')) || 0,
      usageLimit: Number(val('usageLimit')) || 0,
      perUserLimit: Number(val('perUserLimit')) || 0,
      startsAt: val('startsAt') || null,
      expiresAt: val('expiresAt') || null,
      description: val('description'),
      active: m.root.querySelector('[name="active"]').checked,
    };
    e.target.disabled = true;
    try {
      if (isNew) await U.api('/api/admin/coupons', { method: 'POST', body });
      else await U.api(`/api/admin/coupons/${coupon.id}`, { method: 'PATCH', body });
      m.close();
      U.toast(isNew ? U.t('a.couponCreated') : U.t('v.couponUpdated'), 'ok');
      await loadAdminCoupons();
    } catch (err) {
      U.toast(err.message, 'err', 5000);
      e.target.disabled = false;
    }
  });
}

/* ------------------------------------------------------------------ *
 * Rəylər (moderasiya)
 * ------------------------------------------------------------------ */
async function paintAdminReviews() {
  main.innerHTML = h`
    <div class="panel-head">
      <div><h1>${U.t('common.reviews')}</h1><p class="muted small mt-1">${U.t('a.reviewsSubtitle')}</p></div>
      <div class="tabs">
        <button data-rfilter="all" class="${state.reviewFilter === 'all' ? 'active' : ''}">${U.t('nav.all')}</button>
        <button data-rfilter="visible" class="${state.reviewFilter === 'visible' ? 'active' : ''}">${U.t('a.reviewsFilterVisible')}</button>
        <button data-rfilter="hidden" class="${state.reviewFilter === 'hidden' ? 'active' : ''}">${U.t('a.reviewsFilterHidden')}</button>
      </div>
    </div>
    <div id="reviews-admin-area"><div class="skeleton" style="height:240px"></div></div>`;

  await loadAdminReviews();
}

async function loadAdminReviews() {
  const params = new URLSearchParams();
  if (state.reviewFilter === 'hidden') params.set('hidden', '1');
  if (state.reviewFilter === 'visible') params.set('hidden', '0');
  const { reviews } = await U.api(`/api/admin/reviews?${params}`);
  state.reviews = reviews;

  const host = U.qs('#reviews-admin-area');
  if (!reviews.length) {
    host.innerHTML = h`<div class="card"><div class="empty"><div class="big">⭐</div>
      <h3>${U.t('a.reviewsEmpty')}</h3></div></div>`;
    return;
  }

  host.innerHTML = h`<div class="col">${raw(reviews.map((r) => `
    <div class="card card-pad">
      <div class="row-between wrap-row">
        <div>
          <div class="row" style="gap:8px">
            <b>${U.esc(r.authorName)}</b>
            ${U.starsHtml(r.rating, 14)}
            ${r.hidden ? `<span class="badge badge-closed">${U.t('a.reviewHiddenBadge')}</span>` : ''}
          </div>
          <span class="tiny muted">
            <a href="/#/v/${U.esc(r.vendorSlug)}" target="_blank">${U.esc(r.vendorName)} ↗</a>
            · ${U.t('a.reviewOrderRef', { id: r.orderId })} · ${U.dateTime(r.createdAt)}
          </span>
        </div>
        <button class="btn btn-sm ${r.hidden ? 'btn-ok' : 'btn-danger'}" data-hide="${r.id}" data-value="${r.hidden ? 0 : 1}">
          ${r.hidden ? U.t('a.unhide') : U.t('a.hide')}</button>
      </div>
      ${r.comment ? `<p class="mt-2">${U.esc(r.comment)}</p>` : `<p class="muted small mt-2">${U.t('v.noComment')}</p>`}
      ${r.reply ? `<div class="card card-pad mt-2" style="background:var(--brand-soft);border:none">
        <b class="small">${U.t('review.storeReply')}</b><p class="small mt-1">${U.esc(r.reply)}</p></div>` : ''}
    </div>`).join(''))}</div>`;
}

/* ------------------------------------------------------------------ *
 * Ödənişlər
 * ------------------------------------------------------------------ */
const PAYMENT_TABS = [
  { key: 'all', label: U.t('nav.all') },
  { key: 'paid', label: U.t('paymentStatus.paid') },
  { key: 'requires_action', label: U.t('a.pending') },
  { key: 'failed', label: U.t('a.tabFailed') },
  { key: 'refunded', label: U.t('paymentStatus.refunded') },
];

async function paintPayments() {
  main.innerHTML = h`
    <div class="panel-head">
      <div><h1>${U.t('a.sidebarPayments')}</h1>
        <p class="muted small mt-1">${U.t('a.paymentsSubtitle', { stripe: state.stats?.totals.stripeActive ? U.t('a.stripeOn') : U.t('a.stripeOff') })}</p></div>
    </div>
    <div id="pay-totals" class="stat-grid mb-3"></div>
    <div class="tabs mb-3">
      ${raw(PAYMENT_TABS.map((t) => `<button data-pfilter="${U.esc(t.key)}"
        class="${state.paymentFilter === t.key ? 'active' : ''}">${U.esc(t.label)}</button>`).join(''))}
    </div>
    <div class="search mb-3"><input class="input" data-psearch placeholder="${U.t('a.searchPayments')}"></div>
    <div id="payments-area"><div class="skeleton" style="height:260px"></div></div>`;

  U.qs('[data-psearch]', main).addEventListener('input', U.debounce(() => loadPayments(), 260));
  await loadPayments();
}

async function loadPayments() {
  const params = new URLSearchParams();
  if (state.paymentFilter && state.paymentFilter !== 'all') params.set('status', state.paymentFilter);
  const q = U.qs('[data-psearch]', main)?.value.trim();
  if (q) params.set('q', q);

  const { payments, totals } = await U.api(`/api/admin/payments?${params}`);
  state.payments = payments;

  U.qs('#pay-totals', main).innerHTML = h`
    <div class="card stat"><span>${U.t('a.statPaidTotal')}</span><b>${U.azn(totals.paid)}</b></div>
    <div class="card stat"><span>${U.t('a.statPending')}</span><b>${U.azn(totals.pending)}</b></div>
    <div class="card stat"><span>${U.t('a.statFailed')}</span><b>${U.azn(totals.failed)}</b></div>
    <div class="card stat"><span>${U.t('v.statsRefunded')}</span><b>${U.azn(totals.refunded)}</b></div>`;

  const host = U.qs('#payments-area');
  if (!payments.length) {
    host.innerHTML = h`<div class="card"><div class="empty"><div class="big">💳</div>
      <h3>${U.t('a.paymentsEmpty')}</h3><p class="muted mt-1">${U.t('a.paymentsEmptyHint')}</p>
    </div></div>`;
    return;
  }

  const PROVIDER = { simulated: U.t('payment.simulated'), stripe: U.t('payment.stripe'), counter: U.t('payment.counter') };
  host.innerHTML = h`<div class="card"><div class="table-wrap"><table class="table">
    <thead><tr><th>${U.t('orders.orderCode')}</th><th>${U.t('v.sidebarStore')}</th><th>${U.t('auth.customer')}</th><th>${U.t('a.tableMethod')}</th><th>${U.t('a.tableProvider')}</th><th>${U.t('a.tableAmount')}</th><th>${U.t('common.status')}</th><th>${U.t('receipt.date')}</th></tr></thead>
    <tbody>${raw(payments.map((p) => `<tr>
      <td><b>${U.esc(p.orderCode)}</b>${p.cardLast4 ? `<div class="tiny muted">•••• ${U.esc(p.cardLast4)}</div>` : ''}</td>
      <td>${U.esc(p.vendorName)}</td>
      <td>${U.esc(p.customerName)}</td>
      <td class="small">${U.esc(U.paymentLabel(p.method))}</td>
      <td class="small">${U.esc(PROVIDER[p.provider] ?? p.provider)}</td>
      <td><b>${U.azn(p.amount)}</b></td>
      <td>${U.paymentBadgeHtml(p.status)}
        ${p.error ? `<div class="tiny" style="color:#a5181c">${U.esc(p.error)}</div>` : ''}</td>
      <td class="small muted nowrap">${U.dateTime(p.paidAt ?? p.createdAt)}</td>
    </tr>`).join(''))}</tbody>
  </table></div></div>`;
}

/* ------------------------------------------------------------------ *
 * İcmal
 * ------------------------------------------------------------------ */
async function paintOverview() {
  main.innerHTML = h`<div class="skeleton" style="height:110px"></div>
    <div class="skeleton mt-2" style="height:260px"></div>`;
  const stats = await U.api('/api/admin/stats');
  state.stats = stats;
  renderSidebar();

  const t = stats.totals;
  const max = Math.max(1, ...stats.daily.map((d) => d.revenue));

  main.innerHTML = h`
    <div class="panel-head">
      <div><h1>${U.t('a.overviewTitle')}</h1>
        <p class="muted small mt-1">${U.t('a.overviewSubtitle')}</p></div>
      <span class="badge badge-brand">${U.t('v.live')}</span>
    </div>

    <div class="stat-grid mb-3">
      <div class="card stat"><span>${U.t('v.statsTodayOrders')}</span><b>${t.ordersToday}</b>
        <span class="tiny muted">${U.t('a.statTotal', { count: t.orders })}</span></div>
      <div class="card stat"><span>${U.t('a.statTodayGmv')}</span><b>${U.azn(t.gmvToday)}</b>
        <span class="tiny muted">${U.t('a.statTotal', { count: U.azn(t.gmvTotal) })}</span></div>
      <div class="card stat"><span>${U.t('a.statAvgBasket')}</span><b>${U.azn(t.avgBasket)}</b>
        <span class="tiny muted">${U.t('a.statAvgBasketHint')}</span></div>
      <div class="card stat"><span>${U.t('a.statVendors')}</span><b>${t.vendors}</b>
        <span class="tiny muted">${U.t('a.statPendingVendors', { count: t.pendingVendors })}</span></div>
      <div class="card stat"><span>${U.t('a.sidebarUsers')}</span><b>${t.users}</b>
        <span class="tiny muted">${U.t('a.statCustomers', { count: t.customers })}</span></div>
      <div class="card stat"><span>${U.t('a.statProducts')}</span><b>${t.products}</b>
        <span class="tiny muted">${U.t('a.statProductsHint')}</span></div>
    </div>

    <div class="stat-grid mb-3">
      <div class="card stat"><span>${U.t('a.statOnlineToday')}</span><b>${U.azn(t.onlinePaidToday)}</b>
        <span class="tiny muted">${t.stripeActive ? U.t('a.statStripeActive') : U.t('a.statSimulated')}</span></div>
      <div class="card stat"><span>${U.t('a.statCounterToday')}</span><b>${U.azn(t.counterPaidToday)}</b>
        <span class="tiny muted">${U.t('a.statCashCard')}</span></div>
      <div class="card stat"><span>${U.t('a.statUnpaid')}</span><b>${U.azn(t.unpaidTotal)}</b>
        <span class="tiny muted">${U.t('a.statUnpaidHint')}</span></div>
      <div class="card stat"><span>${U.t('v.statsRefunded')}</span><b>${U.azn(t.refundedTotal)}</b>
        <span class="tiny muted">${U.t('v.statsRefundedHint')}</span></div>
    </div>

    <div class="stat-grid mb-3">
      <div class="card stat"><span>${U.t('common.reviews')}</span><b>${t.reviews}</b>
        <span class="tiny muted">${U.t('a.statReviewsAvg', { value: Number(t.newRatingAvg || 0).toFixed(1) })}</span></div>
      <div class="card stat"><span>${U.t('a.statHiddenReviews')}</span><b>${t.hiddenReviews}</b>
        <span class="tiny muted">${U.t('a.statHiddenReviewsHint')}</span></div>
      <div class="card stat"><span>${U.t('a.statActiveCoupons')}</span><b>${t.activeCoupons}</b>
        <span class="tiny muted">${U.t('a.statCouponOrders', { count: t.couponOrders })}</span></div>
      <div class="card stat"><span>${U.t('a.statCouponDiscount')}</span><b>${U.azn(t.couponDiscount)}</b>
        <span class="tiny muted">${U.t('a.statAvgBasketHint')}</span></div>
    </div>

    <div class="stat-grid mb-3">
      <div class="card stat"><span>${U.t('a.statCommission')}</span><b>${U.azn(t.commissionTotal)}</b>
        <span class="tiny muted">${U.t('a.statCommissionHint')} ${U.azn(t.commissionToday)}</span></div>
      <div class="card stat"><span>${U.t('a.statPayoutPending')}</span><b>${U.azn(t.payoutOnline)}</b>
        <span class="tiny muted">${U.t('a.statPayoutPendingHint')}</span></div>
      <div class="card stat"><span>${U.t('a.statCommissionCounter')}</span><b>${U.azn(t.commissionCounter)}</b>
        <span class="tiny muted">${U.t('a.statCommissionCounterHint')}</span></div>
      <div class="card stat"><span>${U.t('a.statPlatformRevenue')}</span>
        <b>${U.azn(t.commissionTotal - t.couponDiscount)}</b>
        <span class="tiny muted">${U.t('a.statPlatformRevenueHint')}</span></div>
    </div>

    <div class="card card-pad mb-3">
      <h3>${U.t('a.dailyTitle')}</h3>
      <div class="row" style="align-items:flex-end;gap:10px;height:150px;margin-top:16px">
        ${raw(stats.daily.map((d) => `
          <div style="flex:1;text-align:center">
            <div class="tiny muted">${U.azn(d.revenue)}</div>
            <div style="height:${Math.max(4, Math.round((d.revenue / max) * 100))}px;background:var(--brand);
                 border-radius:8px 8px 0 0;margin:4px auto 6px;width:64%"></div>
            <div class="tiny muted">${d.day.slice(8)}.${d.day.slice(5, 7)} · ${d.orders}</div>
          </div>`).join(''))}
      </div>
    </div>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px">
      <div class="card">
        <div class="card-pad" style="border-bottom:1px solid var(--line)"><h3>${U.t('a.statusBreakdown')}</h3></div>
        <div class="card-pad">
          ${raw(stats.byStatus.map((s) => h`
            <div class="row-between" style="padding:6px 0">
              <span>${U.statusBadge(s.status)}</span><b>${s.count}</b>
            </div>`).join(''))}
        </div>
      </div>

      <div class="card">
        <div class="card-pad" style="border-bottom:1px solid var(--line)"><h3>${U.t('a.topVendors')}</h3></div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>${U.t('v.sidebarStore')}</th><th>${U.t('orders.orderCode')}</th><th>${U.t('a.tableRevenue')}</th></tr></thead>
            <tbody>${raw(stats.topVendors.map((v) => `<tr>
              <td><a href="/#/v/${U.esc(v.slug)}" target="_blank"><b>${U.esc(v.name)}</b> ↗</a></td>
              <td>${v.orders}</td><td>${U.azn(v.revenue)}</td></tr>`).join(''))}</tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="card card-pad mt-3" style="background:var(--brand-soft);border-color:#bfeaf5">
      <b>${U.t('a.noCourierTitle')}</b>
      <p class="small mt-1">${U.t('a.noCourierText')}</p>
    </div>`;
}

/* ------------------------------------------------------------------ *
 * Satıcılar
 * ------------------------------------------------------------------ */
async function paintVendors() {
  main.innerHTML = h`
    <div class="panel-head">
      <div><h1>${U.t('a.sidebarVendors')}</h1><p class="muted small mt-1">${U.t('a.vendorsSubtitle')}</p></div>
      <div class="row wrap-row" style="gap:8px">
        <button class="btn btn-primary" data-act="new-vendor">${U.t('a.newVendor')}</button>
        <div class="tabs">
          <button data-vfilter="all" class="${state.vendorFilter === 'all' ? 'active' : ''}">${U.t('nav.all')}</button>
          <button data-vfilter="pending" class="${state.vendorFilter === 'pending' ? 'active' : ''}">${U.t('a.filterPending')}</button>
          <button data-vfilter="open" class="${state.vendorFilter === 'open' ? 'active' : ''}">${U.t('common.open')}</button>
        </div>
      </div>
    </div>
    <div class="search mb-3"><input class="input" data-vsearch placeholder="${U.t('a.searchVendors')}" value="${state.q}"></div>
    <div id="vendors-area"><div class="skeleton" style="height:240px"></div></div>`;

  U.qs('[data-act="new-vendor"]', main).addEventListener('click', () => newVendorModal());
  const search = U.qs('[data-vsearch]', main);
  search.addEventListener('input', U.debounce((e) => { state.q = e.target.value.trim(); paintVendorTable(); }, 250));

  const { vendors } = await U.api('/api/admin/vendors');
  state.vendors = vendors;
  paintVendorTable();
}

function paintVendorTable() {
  const host = U.qs('#vendors-area');
  const q = state.q.toLowerCase();
  let rows = state.vendors;
  if (state.vendorFilter === 'pending') rows = rows.filter((v) => !v.approved);
  if (state.vendorFilter === 'open') rows = rows.filter((v) => v.open);
  if (q) {
    rows = rows.filter((v) => [v.name, v.owner?.name, v.owner?.phone, v.address]
      .some((f) => String(f ?? '').toLowerCase().includes(q)));
  }

  if (!rows.length) {
    host.innerHTML = h`<div class="card"><div class="empty"><div class="big">🏪</div>
      <h3>${U.t('vendorPage.storeNotFound')}</h3></div></div>`;
    return;
  }

  host.innerHTML = h`<div class="card"><div class="table-wrap"><table class="table">
    <thead><tr><th>${U.t('v.sidebarStore')}</th><th>${U.t('a.tableOwner')}</th><th>${U.t('a.tableProducts')}</th><th>${U.t('orders.orderCode')}</th><th>${U.t('a.tableRevenue')}</th><th>${U.t('common.status')}</th><th></th></tr></thead>
    <tbody>
      ${raw(rows.map((v) => `
        <tr>
          <td>
            <div class="row" style="gap:10px">
              ${U.thumbHtml(v.logo)}
              <div>
                <b>${U.esc(v.name)}</b>
                <div class="tiny muted">${U.esc(v.kind === 'market' ? `🏪 ${U.t('a.kindMarket')}` : `🍽️ ${U.t('a.kindRestaurant')}`)} · ${U.esc(v.category?.name ?? '—')}</div>
                <div class="tiny muted">${U.esc(v.address)}</div>
              </div>
            </div>
          </td>
          <td>${U.esc(v.owner?.name ?? '—')}<div class="tiny muted">${U.esc(v.owner?.phone ?? '')}</div></td>
          <td>${v.productCount}</td>
          <td>${v.orderCount}</td>
          <td>${U.azn(v.revenue)}</td>
          <td>
            ${v.approved ? `<span class="badge badge-open">${U.t('a.approved')}</span>` : `<span class="badge badge-warn">${U.t('a.pending')}</span>`}
            <div class="tiny muted mt-1">${v.open ? U.t('a.open') : U.t('a.closed')}</div>
          </td>
          <td class="right nowrap">
            ${v.approved
              ? `<button class="btn btn-sm btn-outline" data-vopen="${v.id}" data-value="${v.open ? 0 : 1}">${v.open ? U.t('a.close') : U.t('a.openAction')}</button>
                 <button class="btn btn-sm btn-danger" data-vapprove="${v.id}" data-value="0">${U.t('a.revoke')}</button>`
              : `<button class="btn btn-sm btn-ok" data-vapprove="${v.id}" data-value="1">${U.t('a.approve')}</button>`}
            <a class="btn btn-sm btn-ghost" href="/#/v/${U.esc(v.slug)}" target="_blank">${U.t('nav.openStore')}</a>
          </td>
        </tr>`).join(''))}
    </tbody></table></div></div>`;
}

/* ------------------------------------------------------------------ *
 * Sifarişlər
 * ------------------------------------------------------------------ */
const ORDER_TABS = [
  { key: 'all', label: U.t('nav.all') },
  { key: 'pending', label: U.t('v.tabNew') },
  { key: 'accepted,preparing', label: U.t('status.preparing') },
  { key: 'ready', label: U.t('v.tabReady') },
  { key: 'picked_up', label: U.t('status.picked_up') },
  { key: 'cancelled', label: U.t('a.tabCancelled') },
];

async function paintOrders() {
  main.innerHTML = h`
    <div class="panel-head">
      <div><h1>${U.t('v.sidebarOrders')}</h1><p class="muted small mt-1">${U.t('a.ordersSubtitle')}</p></div>
    </div>
    <div class="tabs mb-3">
      ${raw(ORDER_TABS.map((t) => `<button data-ofilter="${U.esc(t.key)}"
        class="${state.orderFilter === t.key ? 'active' : ''}">${U.esc(t.label)}</button>`).join(''))}
    </div>
    <div class="search mb-3"><input class="input" data-osearch placeholder="${U.t('a.searchOrders')}"></div>
    <div id="orders-area"><div class="skeleton" style="height:260px"></div></div>`;

  U.qs('[data-osearch]', main).addEventListener('input', U.debounce(() => loadAdminOrders(), 260));
  await loadAdminOrders();

  // Yeni sifariş/status hadisələrində cədvəl avtomatik yenilənir
  state.live = U.subscribeEvents({ scope: 'admin' }, {
    onCreated: () => loadAdminOrders(),
    onStatusChange: () => loadAdminOrders(),
    onPayment: () => loadAdminOrders(),
  });
}

async function loadAdminOrders() {
  const params = new URLSearchParams();
  if (state.orderFilter !== 'all') params.set('status', state.orderFilter);
  const q = U.qs('[data-osearch]', main)?.value.trim();
  if (q) params.set('q', q);
  const { orders } = await U.api(`/api/admin/orders?${params}`);
  state.orders = orders;

  const host = U.qs('#orders-area');
  if (!orders.length) {
    host.innerHTML = h`<div class="card"><div class="empty"><div class="big">🧾</div><h3>${U.t('v.noOrders')}</h3></div></div>`;
    return;
  }
  host.innerHTML = h`<div class="card"><div class="table-wrap"><table class="table">
    <thead><tr><th>${U.t('v.tableCode')}</th><th>${U.t('v.sidebarStore')}</th><th>${U.t('auth.customer')}</th><th>${U.t('a.tableContent')}</th><th>${U.t('common.payment')}</th><th>${U.t('a.tablePaymentStatus')}</th><th>${U.t('a.tableAmount')}</th><th>${U.t('common.status')}</th><th>${U.t('receipt.date')}</th></tr></thead>
    <tbody>${raw(orders.map((o) => `<tr style="cursor:pointer" data-order-row="${U.esc(o.code)}">
      <td><b>${U.esc(o.code)}</b><div class="tiny muted">${U.t('orders.pickupCodeShort')} ${U.esc(o.pickupCode)}</div></td>
      <td>${U.esc(o.vendorName)}</td>
      <td>${U.esc(o.customerName)}<div class="tiny muted">${U.esc(o.customerPhone)}</div></td>
      <td>${(o.items ?? []).slice(0, 3).map((i) => `${i.qty}× ${U.esc(i.name)}`).join('<br>') || '—'}</td>
      <td class="small">${U.esc(U.paymentLabel(o.payment))}</td>
      <td>${U.paymentBadgeHtml(o.paymentStatus)}</td>
      <td><b>${U.azn(o.total)}</b></td>
      <td>${U.statusBadgeHtml(o.status)}</td>
      <td class="small muted nowrap">${U.dateTime(o.createdAt)}</td>
    </tr>`).join(''))}</tbody>
  </table></div></div>`;
}

/* ------------------------------------------------------------------ *
 * İstifadəçilər
 * ------------------------------------------------------------------ */
async function paintUsers() {
  main.innerHTML = h`
    <div class="panel-head"><div><h1>${U.t('a.sidebarUsers')}</h1>
      <p class="muted small mt-1">${U.t('a.usersSubtitle')}</p></div></div>
    <div class="search mb-3"><input class="input" data-usearch placeholder="${U.t('a.searchUsers')}"></div>
    <div id="users-area"><div class="skeleton" style="height:240px"></div></div>`;

  U.qs('[data-usearch]', main).addEventListener('input', U.debounce((e) => {
    state.q = e.target.value.trim().toLowerCase();
    paintUserTable();
  }, 250));

  const { users } = await U.api('/api/admin/users');
  state.users = users;
  paintUserTable();
}

function paintUserTable() {
  const host = U.qs('#users-area');
  let rows = state.users;
  if (state.q) {
    rows = rows.filter((u) => [u.name, u.phone].some((f) => String(f).toLowerCase().includes(state.q)));
  }
  const ROLE = { customer: U.t('auth.customer'), vendor: U.t('a.roleVendor'), admin: U.t('a.roleAdmin') };
  host.innerHTML = h`<div class="card"><div class="table-wrap"><table class="table">
    <thead><tr><th>${U.t('v.tableName')}</th><th>${U.t('a.role')}</th><th>${U.t('common.phone')}</th><th>${U.t('orders.orderCode')}</th><th>${U.t('a.tableSpent')}</th><th>${U.t('auth.register')}</th><th></th></tr></thead>
    <tbody>${raw(rows.map((u) => `<tr>
      <td><b>${U.esc(u.name)}</b>${u.blocked ? ` <span class="badge badge-closed">${U.t('a.blocked')}</span>` : ''}</td>
      <td><span class="badge ${u.role === 'admin' ? 'badge-brand' : u.role === 'vendor' ? 'badge-info' : ''}">
        ${U.esc(ROLE[u.role] ?? u.role)}</span></td>
      <td>${U.esc(u.phone)}</td>
      <td>${u.orderCount}</td>
      <td>${U.azn(u.spent)}</td>
      <td class="small muted nowrap">${U.dateTime(u.createdAt)}</td>
      <td class="right">${u.role === 'admin' ? '' : `<button class="btn btn-sm ${u.blocked ? 'btn-ok' : 'btn-danger'}"
        data-block="${u.id}" data-value="${u.blocked ? 0 : 1}">${u.blocked ? U.t('a.unblock') : U.t('a.block')}</button>`}</td>
    </tr>`).join(''))}</tbody>
  </table></div></div>`;
}

/* ------------------------------------------------------------------ *
 * Hadisələr
 * ------------------------------------------------------------------ */
function bindDelegates() {
  U.on(main, 'click', '[data-vfilter]', async (e, el) => {
    state.vendorFilter = el.dataset.vfilter;
    U.qsa('[data-vfilter]', main).forEach((b) => b.classList.toggle('active', b === el));
    paintVendorTable();
  });

  U.on(main, 'click', '[data-vapprove]', async (e, el) => {
    const approved = el.dataset.value === '1';
    try {
      await U.api(`/api/admin/vendors/${el.dataset.vapprove}`, {
        method: 'PATCH', body: { approved, open: approved },
      });
      U.toast(approved ? U.t('a.vendorApprovedToast') : U.t('a.vendorRevokedToast'), approved ? 'ok' : 'warn');
      await paintVendors();
    } catch (err) { U.toast(err.message, 'err'); }
  });

  U.on(main, 'click', '[data-vopen]', async (e, el) => {
    try {
      await U.api(`/api/admin/vendors/${el.dataset.vopen}`, {
        method: 'PATCH', body: { open: el.dataset.value === '1' },
      });
      U.toast(U.t('a.statusChanged'), 'ok', 1600);
      await paintVendors();
    } catch (err) { U.toast(err.message, 'err'); }
  });

  U.on(main, 'click', '[data-ofilter]', async (e, el) => {
    state.orderFilter = el.dataset.ofilter;
    U.qsa('[data-ofilter]', main).forEach((b) => b.classList.toggle('active', b === el));
    await loadAdminOrders();
  });

  U.on(main, 'click', '[data-pfilter]', async (e, el) => {
    state.paymentFilter = el.dataset.pfilter;
    U.qsa('[data-pfilter]', main).forEach((b) => b.classList.toggle('active', b === el));
    await loadPayments();
  });

  U.on(main, 'click', '[data-rfilter]', async (e, el) => {
    state.reviewFilter = el.dataset.rfilter;
    U.qsa('[data-rfilter]', main).forEach((b) => b.classList.toggle('active', b === el));
    await loadAdminReviews();
  });

  U.on(main, 'click', '[data-coupon-edit]', (e, el) =>
    adminCouponModal(state.coupons.find((c) => c.id === Number(el.dataset.couponEdit))));

  U.on(main, 'click', '[data-coupon-del]', async (e, el) => {
    const coupon = state.coupons.find((c) => c.id === Number(el.dataset.couponDel));
    if (!coupon) return;
    const yes = await U.confirmDialog({
      title: U.t('v.deleteCouponTitle'),
      text: U.t('a.deleteCouponText', { code: coupon.code }),
      okText: U.t('actions.delete'), danger: true,
    });
    if (!yes) return;
    try {
      await U.api(`/api/admin/coupons/${coupon.id}`, { method: 'DELETE' });
      U.toast(U.t('v.couponDeleted'), 'ok');
      await loadAdminCoupons();
    } catch (err) { U.toast(err.message, 'err'); }
  });

  U.on(main, 'click', '[data-hide]', async (e, el) => {
    const hidden = el.dataset.value === '1';
    try {
      await U.api(`/api/admin/reviews/${el.dataset.hide}`, { method: 'PATCH', body: { hidden } });
      U.toast(hidden ? U.t('a.reviewHiddenToast') : U.t('a.reviewShownToast'),
        hidden ? 'warn' : 'ok');
      await loadAdminReviews();
    } catch (err) { U.toast(err.message, 'err'); }
  });

  U.on(main, 'click', '[data-order-row]', async (e, el) => {
    const code = el.dataset.orderRow;
    try {
      const { order } = await U.api(`/api/orders/${encodeURIComponent(code)}`);
      U.modal({
        title: `${order.code} · ${order.vendorName}`,
        body: h`
          <div class="row-between"><b>${order.customerName}</b>${U.statusBadge(order.status)}</div>
          <p class="small muted">☎ ${order.customerPhone} · ${U.paymentLabel(order.payment)} · ${U.dateTime(order.createdAt)}</p>
          <div class="row mt-2">${U.paymentBadge(order.paymentStatus)}
            <span class="small muted">${U.azn(order.total)}</span></div>
          <p class="mt-2">${U.t('orders.pickupCode')}: <b style="letter-spacing:.12em">${order.pickupCode}</b></p>
          <div class="mt-2">${raw(order.items.map((i) => h`<div class="row-between small" style="padding:6px 0;border-bottom:1px solid var(--line)">
            <span>${i.qty} × ${i.name}</span><b>${U.azn(i.lineTotal)}</b></div>`).join(''))}</div>
          <div class="row-between total mt-2"><b>${U.t('common.total')}</b><b>${U.azn(order.total)}</b></div>
          <h4 class="mt-3">${U.t('track.history')}</h4>
          ${raw(order.events.map((ev) => h`<div class="row-between small">
            <span>${U.statusLabel(ev.status)}${ev.note ? ` — ${ev.note}` : ''}</span>
            <span class="muted">${U.dateTime(ev.at)}</span></div>`).join(''))}`,
        footer: `<button class="btn btn-ghost" data-print-order="${U.esc(order.code)}">🖨 ${U.t('actions.print')}</button>
                 <button class="btn btn-outline" data-close>${U.t('nav.close')}</button>`,
      });
    } catch (err) { U.toast(err.message, 'err'); }
  });

  U.on(main, 'click', '[data-print-order]', async (e, el) => {
    try {
      const { order } = await U.api(`/api/orders/${encodeURIComponent(el.dataset.printOrder)}`);
      U.printReceipt(order, {
        name: order.vendorName, address: order.vendorAddress, phone: order.vendorPhone,
      });
      U.toast(U.t('receipt.reprint'), 'ok', 2200);
    } catch (err) { U.toast(U.errText(err), 'err'); }
  });

  U.on(main, 'click', '[data-block]', async (e, el) => {
    const blocked = el.dataset.value === '1';
    try {
      await U.api(`/api/admin/users/${el.dataset.block}`, { method: 'PATCH', body: { blocked } });
      U.toast(blocked ? U.t('a.userBlocked') : U.t('a.userUnblocked'), blocked ? 'warn' : 'ok');
      const { users } = await U.api('/api/admin/users');
      state.users = users;
      paintUserTable();
    } catch (err) { U.toast(U.errText(err), 'err'); }
  });

  /* --- Kateqoriyalar --- */
  U.on(main, 'click', '[data-cat-edit]', (e, el) => {
    const cat = state.categories.find((c) => c.id === Number(el.dataset.catEdit));
    if (cat) categoryModal(cat);
  });

  U.on(main, 'click', '[data-cat-del]', async (e, el) => {
    const id = Number(el.dataset.catDel);
    const cat = state.categories.find((c) => c.id === id);
    if (!cat) return;
    const yes = await U.confirmDialog({
      title: U.t('a.catDeleteTitle'),
      text: U.t('a.catDeleteText', { name: cat.name, count: cat.vendorCount }),
      okText: U.t('actions.delete'),
      danger: true,
    });
    if (!yes) return;
    try {
      await U.api(`/api/admin/categories/${id}`, { method: 'DELETE' });
      U.toast(U.t('a.catDeleted'), 'ok');
    } catch (err) {
      if (err.code === 'category_in_use') {
        const force = await U.confirmDialog({
          title: U.t('a.catForceTitle'),
          text: U.t('a.catForceText', { count: cat.vendorCount }),
          okText: U.t('a.catForceOk'),
          danger: true,
        });
        if (!force) return;
        try {
          await U.api(`/api/admin/categories/${id}?force=1`, { method: 'DELETE' });
          U.toast(U.t('a.catDeletedMoved', { count: cat.vendorCount }), 'warn', 5000);
        } catch (forceErr) {
          U.toast(U.errText(forceErr), 'err');
          return;
        }
      } else {
        U.toast(U.errText(err), 'err');
        return;
      }
    }
    await loadCategories();
  });

  /* --- Hesablaşma və komissiya --- */
  U.on(main, 'click', '[data-set-range]', async (e, el) => {
    state.setRange = el.dataset.setRange;
    if (state.setRange !== 'custom') state.setCustom = {};
    await paintSettlements();
  });

  U.on(main, 'click', '[data-act="apply-set-range"]', async () => {
    state.setCustom = {
      from: U.qs('[data-set-from]', main)?.value ?? '',
      to: U.qs('[data-set-to]', main)?.value ?? '',
    };
    await paintSettlements();
  });

  U.on(main, 'click', '[data-act="save-commission"]', async (e, el) => {
    const value = Number(U.qs('[data-default-commission]', main)?.value ?? 0);
    el.disabled = true;
    try {
      await U.api('/api/admin/settings', { method: 'PATCH', body: { defaultCommission: value } });
      U.toast(U.t('a.setCommissionSaved'), 'ok');
      await paintSettlements();
    } catch (err) {
      U.toast(U.errText(err), 'err');
      el.disabled = false;
    }
  });

  U.on(main, 'change', '[data-vendor-rate]', async (e, el) => {
    const vendorId = Number(el.dataset.vendorRate);
    const value = Number(el.value);
    try {
      await U.api(`/api/admin/vendors/${vendorId}`, { method: 'PATCH', body: { commissionPercent: value } });
      U.toast(value > 0
        ? U.t('a.setVendorRateSaved', { percent: value })
        : U.t('a.setVendorRateDefault'), 'ok');
      await paintSettlements();
    } catch (err) {
      U.toast(U.errText(err), 'err');
      await paintSettlements();
    }
  });

  U.on(main, 'click', '[data-set-create]', async (e, el) => {
    const vendorId = Number(el.dataset.setCreate);
    const vendor = state.settlement?.vendors.find((v) => v.vendorId === vendorId);
    const yes = await U.confirmDialog({
      title: U.t('a.setCreateTitle'),
      text: U.t('a.setCreateText', { name: vendor?.name ?? '', amount: U.azn(vendor?.net ?? 0) }),
      okText: U.t('a.setCreate'),
    });
    if (!yes) return;
    el.disabled = true;
    try {
      await U.api('/api/admin/settlements', {
        method: 'POST',
        body: {
          vendorId,
          from: state.settlement?.period.from,
          to: state.settlement?.period.to,
        },
      });
      U.toast(U.t('a.setCreated'), 'ok');
      await paintSettlements();
    } catch (err) {
      U.toast(U.errText(err), 'err');
      el.disabled = false;
    }
  });

  U.on(main, 'click', '[data-set-pay]', async (e, el) => {
    const yes = await U.confirmDialog({
      title: U.t('a.setMarkPaidTitle'),
      text: U.t('a.setMarkPaidText'),
      okText: U.t('a.setMarkPaid'),
    });
    if (!yes) return;
    el.disabled = true;
    try {
      await U.api(`/api/admin/settlements/${el.dataset.setPay}`, { method: 'PATCH', body: {} });
      U.toast(U.t('a.setPaidToast'), 'ok');
      await paintSettlements();
    } catch (err) {
      U.toast(U.errText(err), 'err');
      el.disabled = false;
    }
  });

  U.on(main, 'click', '[data-set-del]', async (e, el) => {
    const yes = await U.confirmDialog({
      title: U.t('a.setDeleteTitle'),
      text: U.t('a.setDeleteText'),
      okText: U.t('actions.delete'),
      danger: true,
    });
    if (!yes) return;
    try {
      await U.api(`/api/admin/settlements/${el.dataset.setDel}`, { method: 'DELETE' });
      U.toast(U.t('a.setDeleted'), 'ok');
      await paintSettlements();
    } catch (err) { U.toast(U.errText(err), 'err'); }
  });
}
