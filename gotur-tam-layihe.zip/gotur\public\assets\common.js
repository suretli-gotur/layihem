/* ==================================================================
   Götür — ortaq frontend kitabxanası (fetch, format, UI, səbət, i18n)
   ================================================================== */
import {
  LANGS, DEFAULT_LANG, LANG_LABELS, LANG_NAMES, detectLang, isSupported, translate,
} from './i18n.js';

/* ---------------- Dil (i18n) ---------------- */
const LANG_KEY = 'gotur.lang';

const readStoredLang = () => {
  try { return globalThis.localStorage?.getItem(LANG_KEY) ?? null; } catch { return null; }
};
const urlLang = () => {
  try { return new URLSearchParams(globalThis.location?.search ?? '').get('lang'); } catch { return null; }
};
const browserLanguages = () => {
  const nav = globalThis.navigator;
  if (!nav) return [];
  return Array.isArray(nav.languages) && nav.languages.length ? [...nav.languages] : [nav.language];
};

let currentLang = (() => {
  const stored = readStoredLang();
  if (stored && isSupported(stored)) return stored;
  const fromUrl = urlLang();
  if (fromUrl && isSupported(fromUrl)) return fromUrl;
  return detectLang(browserLanguages());
})();

export const lang = () => currentLang;
export const availableLangs = () => LANGS;
export const langNames = () => LANG_NAMES;

export function setLang(next, { persist = true } = {}) {
  if (!isSupported(next)) return currentLang;
  currentLang = next;
  if (persist) {
    try { globalThis.localStorage?.setItem(LANG_KEY, next); } catch { /* private mode */ }
  }
  if (globalThis.document?.documentElement) globalThis.document.documentElement.lang = next;
  return currentLang;
}
setLang(currentLang, { persist: false });

/** Tərcümə: t('nav.cart') və ya t('checkout.accepted', { code: 'GT-1001' }) */
export const t = (key, params) => translate(currentLang, key, params);

export const langSwitcherHtml = (extraClass = '') =>
  `<span class="lang-switch ${esc(extraClass)}">${LANGS.map((code) =>
    `<button type="button" data-lang="${code}" class="${code === currentLang ? 'on' : ''}"
       title="${esc(LANG_NAMES[code])}" aria-label="${esc(LANG_NAMES[code])}">${LANG_LABELS[code]}</button>`).join('')}</span>`;

/* ---------------- HTML şablonu (avtomatik escape ilə) ---------------- */
const RAW = Symbol('raw');
const ESCAPED = Symbol('escaped');

const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (c) =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/**
 * HTML üçün təhlükəsiz mətn.
 * Qaytarılan dəyər "artıq escape olunmuş" kimi işarələnir: `h` şablonu onu
 * ikinci dəfə escape etmir. Beləliklə həm düz şablonlarda (`${esc(x)}`),
 * həm də `h` şablonlarında təhlükəsizdir.
 */
export function esc(value) {
  const marked = new String(escapeHtml(value)); // eslint-disable-line no-new-wrappers
  marked[ESCAPED] = true;
  return marked;
}

/** Daxili: `h` interpolyasiyasını HTML-ə çevirir. */
function stringify(value) {
  if (value && value[RAW] !== undefined) return value[RAW];
  if (value && value[ESCAPED]) return String(value);
  return escapeHtml(value);
}

export function h(strings, ...values) {
  let out = strings[0];
  for (let i = 0; i < values.length; i++) {
    const v = values[i];
    const inner = Array.isArray(v) ? v.map(stringify).join('') : stringify(v);
    out += inner + strings[i + 1];
  }
  return out;
}

/* ---------------- API klienti ---------------- */
export const raw = (value) => ({ [RAW]: String(value ?? '') });

export class ApiError extends Error {
  constructor(message, status, code = null, params = null) {
    super(message);
    this.status = status;
    this.code = code;
    this.params = params;
  }
}

export async function api(path, options = {}) {
  const { method = 'GET', body, signal } = options;
  let res;
  try {
    res = await fetch(path, {
      method,
      headers: body ? { 'content-type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
      credentials: 'same-origin',
      signal,
    });
  } catch (err) {
    throw new ApiError(t('errors.network'), 0, 'network');
  }
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = { error: text }; }
  if (!res.ok) {
    throw new ApiError(
      data?.error || t('errors.generic'),
      res.status,
      data?.code ?? null,
      data?.params ?? null,
    );
  }
  return data;
}

/** Xəta mətnini cari dilə çevirir (server kodu varsa lüğətdən oxuyur). */
export function errText(err) {
  if (err?.code) {
    const key = `errors.${err.code}`;
    const text = translate(currentLang, key, err.params ?? undefined);
    if (text !== key) return text;
  }
  return err?.message || t('errors.generic');
}

/* ---------------- Formatlaşdırma ---------------- */
const LOCALES = { az: 'az-AZ', en: 'en-GB', ru: 'ru-RU' };
export const locale = () => LOCALES[currentLang] ?? 'az-AZ';

export const azn = (qepik) =>
  `${(Number(qepik || 0) / 100).toFixed(2).replace('.', ',')} \u20BC`;

export const pct = (v) => `${Math.round(Number(v || 0))}%`;

export function dateTime(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleString(locale(), { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

export function timeOnly(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleTimeString(locale(), { hour: '2-digit', minute: '2-digit' });
}

export function timeAgo(iso) {
  if (!iso) return '';
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60) return t('units.now');
  if (diff < 3600) return t('units.minutesAgo', { count: Math.floor(diff / 60) });
  if (diff < 86400) return t('units.hoursAgo', { count: Math.floor(diff / 3600) });
  return t('units.daysAgo', { count: Math.floor(diff / 86400) });
}

export const minutesLabel = (m) => (m >= 60
  ? t('units.hoursMinutes', { hours: Math.floor(m / 60), minutes: m % 60 })
  : t('units.minutesShort', { count: m }));

/* ---------------- Statuslar (tərcümə olunur) ---------------- */
export const statusLabel = (status) => t(`status.${status}`);

export const statusBadgeHtml = (status) =>
  `<span class="status status-${esc(status)}">${esc(statusLabel(status))}</span>`;

export const statusBadge = (status) => raw(statusBadgeHtml(status));

export const paymentLabel = (method) => t(`payment.${method}`);
export const paymentStatusLabel = (status) => t(`paymentStatus.${status}`);

const PAYMENT_BADGE_CLASS = {
  paid: 'badge-open',
  unpaid: 'badge-warn',
  refunded: 'badge-closed',
  failed: 'badge-closed',
};

export const paymentBadgeHtml = (status) =>
  `<span class="badge ${PAYMENT_BADGE_CLASS[status] ?? 'badge'}">${esc(status ? paymentStatusLabel(status) : '—')}</span>`;

export const paymentBadge = (status) => raw(paymentBadgeHtml(status));

export const isImage = (v) => typeof v === 'string' && /^(https?:|data:|\/)/.test(v);

/** Şəkil/emoji tile-ını HTML sətri kimi qaytarır (düz şablonlarda istifadə üçün). */
export const thumbHtml = (image, cls = 'tile tile-56') =>
  isImage(image)
    ? `<span class="${cls}" style="overflow:hidden"><img src="${esc(image)}" alt="" style="width:100%;height:100%;object-fit:cover"></span>`
    : `<span class="${cls}">${esc(image || '🍽️')}</span>`;

/** Eyni şey, lakin `h` şablonu içərisində istifadə üçün. */
export const thumb = (image, cls = 'tile tile-56') => raw(thumbHtml(image, cls));

export const initials = (name) => String(name || '?').trim().split(/\s+/).slice(0, 2)
  .map((w) => w[0]?.toUpperCase() ?? '').join('');

/* ---------------- Reytinq ---------------- */
export const starsHtml = (rating, size = 14) => {
  const full = Math.max(0, Math.min(5, Math.round(Number(rating) || 0)));
  return `<span style="color:#f5b60a;letter-spacing:1px;font-size:${size}px">${'★'.repeat(full)}${'☆'.repeat(5 - full)}</span>`;
};
export const stars = (rating, size) => raw(starsHtml(rating, size));

/** Mağaza reytinqi: rəy yoxdursa «Yeni» göstərilir. */
export const ratingHtml = (vendor) => {
  if (!vendor || !vendor.ratingCount) return `<span class="badge">🌱 ${esc(t('common.newStore'))}</span>`;
  return `<span class="badge badge-brand">⭐ ${Number(vendor.rating).toFixed(1)} · ${esc(t('common.rating'))} ${vendor.ratingCount}</span>`;
};
export const ratingBadge = (vendor) => raw(ratingHtml(vendor));

export const discountLabel = (coupon) => (coupon?.kind === 'percent'
  ? `${coupon.value}% ${t('common.discount').toLowerCase()}`
  : `${azn(coupon?.value ?? 0)} ${t('common.discount').toLowerCase()}`);

/* ---------------- Toast ---------------- */
let toastHost;
export function toast(message, type = '', ms = 3200) {
  if (!toastHost) {
    toastHost = document.createElement('div');
    toastHost.className = 'toast-host';
    document.body.appendChild(toastHost);
  }
  const node = document.createElement('div');
  node.className = `toast ${type}`;
  node.textContent = message;
  toastHost.appendChild(node);
  setTimeout(() => node.remove(), ms);
}

/* ---------------- Modal ---------------- */
export function modal({ title, body, footer = '', size, onClose }) {
  const backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';
  backdrop.innerHTML = h`
    <div class="modal" role="dialog" aria-modal="true" ${size ? raw(`style="width:min(${esc(size)},100%)"`) : ''}>
      <header>
        <h3>${raw(title)}</h3>
        <button class="btn btn-ghost btn-icon" data-close title="Bağla">✕</button>
      </header>
      <div class="body">${raw(body)}</div>
      ${footer ? raw(`<footer>${footer}</footer>`) : ''}
    </div>`;
  const close = () => {
    backdrop.remove();
    document.removeEventListener('keydown', onKey);
    onClose?.();
  };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop || e.target.closest('[data-close]')) close();
  });
  document.addEventListener('keydown', onKey);
  document.body.appendChild(backdrop);
  return { root: backdrop, close };
}

export function confirmDialog({ title = null, text = '', okText = null, danger = false }) {
  return new Promise((resolve) => {
    const m = modal({
      title: title ?? t('common.confirmTitle'),
      body: `<p class="muted">${esc(text)}</p>`,
      footer: `<button class="btn btn-outline" data-close>${esc(t('actions.cancel'))}</button>
               <button class="btn ${danger ? 'btn-danger' : 'btn-dark'}" data-ok>${esc(okText ?? t('actions.confirm'))}</button>`,
      onClose: () => resolve(false),
    });
    m.root.querySelector('[data-ok]').addEventListener('click', () => { resolve(true); m.close(); });
  });
}

/* ---------------- Səbət (localStorage) ---------------- */
const CART_KEY = 'gotur.cart.v1';

const emptyCart = () => ({ vendorId: null, vendorSlug: '', vendorName: '', minOrder: 0, logo: '🍽️', items: [] });

function readCart() {
  try {
    const parsed = JSON.parse(localStorage.getItem(CART_KEY) || 'null');
    if (!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.items)) return emptyCart();
    return { ...emptyCart(), ...parsed };
  } catch { return emptyCart(); }
}

const listeners = new Set();

export const cart = {
  get: readCart,
  items: () => readCart().items,
  count: () => readCart().items.reduce((s, i) => s + i.qty, 0),
  subtotal: () => readCart().items.reduce((s, i) => s + i.price * i.qty, 0),
  qty: (productId) => readCart().items.find((i) => i.productId === productId)?.qty ?? 0,
  vendorId: () => readCart().vendorId,
  isEmpty: () => readCart().items.length === 0,

  save(next) {
    localStorage.setItem(CART_KEY, JSON.stringify(next));
    listeners.forEach((fn) => fn(next));
    return next;
  },

  onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); },

  /** Məhsul əlavə edir. Başqa mağazadan əlavə olunursa səbət sıfırlanır. */
  add(vendor, product, qty = 1) {
    let c = readCart();
    if (c.vendorId && c.vendorId !== vendor.id) c = emptyCart();
    c.vendorId = vendor.id;
    c.vendorSlug = vendor.slug;
    c.vendorName = vendor.name;
    c.minOrder = vendor.minOrder ?? 0;
    c.logo = vendor.logo ?? '🍽️';
    const found = c.items.find((i) => i.productId === product.id);
    if (found) found.qty = Math.min(found.qty + qty, product.stock ?? 99);
    else c.items.push({
      productId: product.id,
      name: product.name,
      price: product.price,
      unit: product.unit,
      image: product.image,
      qty: Math.min(qty, product.stock ?? 99),
    });
    return this.save(c);
  },

  setQty(productId, qty) {
    const c = readCart();
    const item = c.items.find((i) => i.productId === productId);
    if (!item) return c;
    item.qty = qty;
    if (item.qty <= 0) c.items = c.items.filter((i) => i.productId !== productId);
    if (!c.items.length) return this.save(emptyCart());
    return this.save(c);
  },

  clear() { return this.save(emptyCart()); },

  /** Səbətdən sifariş payload-u */
  payload() {
    const c = readCart();
    return { vendorId: c.vendorId, items: c.items.map((i) => ({ productId: i.productId, qty: i.qty })) };
  },
};

/* ---------------- Sessiya ---------------- */
let session = { user: null, vendor: null, loaded: false };

export async function loadSession(force = false) {
  if (session.loaded && !force) return session;
  try {
    const data = await api('/api/auth/me');
    session = { ...data, loaded: true };
  } catch {
    session = { user: null, vendor: null, loaded: true };
  }
  return session;
}

export const getUser = () => session.user;

export async function login(phone, password) {
  const data = await api('/api/auth/login', { method: 'POST', body: { phone, password } });
  session = { user: data.user, vendor: data.vendor, loaded: true };
  return data;
}

export async function register(payload) {
  const data = await api('/api/auth/register', { method: 'POST', body: payload });
  session = { user: data.user, vendor: data.vendor, loaded: true };
  return data;
}

export async function logout() {
  await api('/api/auth/logout', { method: 'POST' });
  session = { user: null, vendor: null, loaded: true };
}

/** Səhifə üçün rol qoruyucusu — uyğun deyilsə giriş ekranına yönləndirir. */
export async function requireRole(role) {
  const s = await loadSession(true);
  if (!s.user || s.user.role !== role) return { ok: false, session: s };
  return { ok: true, session: s };
}

/* ---------------- Real vaxt (Server-Sent Events) ---------------- */
/**
 * Server hadisələrinə abunə olur.
 * @param {{scope?:string, orders?:string}} params
 * @param {{onReady?:Function,onCreated?:Function,onStatusChange?:Function,onPayment?:Function,onReview?:Function,onState?:Function}} handlers
 */
export function subscribeEvents(params = {}, handlers = {}) {
  if (typeof EventSource === 'undefined') {
    handlers.onState?.('unsupported');
    return { close() {} };
  }
  const query = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== '') query.set(key, value);
  }

  let source = null;
  let closed = false;
  let errors = 0;

  const open = () => {
    if (closed) return;
    source = new EventSource(`/api/events?${query}`);
    source.addEventListener('ready', (e) => {
      errors = 0;
      handlers.onState?.('online');
      try { handlers.onReady?.(JSON.parse(e.data)); } catch { /* boş */ }
    });
    const pipe = (name, fn) => source.addEventListener(name, (e) => {
      try { fn?.(JSON.parse(e.data)); } catch (err) { console.warn('[gotur] hadisə oxunmadı', name, err); }
    });
    pipe('order.created', handlers.onCreated);
    pipe('order.status', handlers.onStatusChange);
    pipe('order.payment', handlers.onPayment);
    pipe('review.created', handlers.onReview);
    source.onerror = () => {
      errors++;
      handlers.onState?.(navigator.onLine === false ? 'offline' : 'reconnecting');
      if (errors > 8) {
        // EventSource özü yenidən qoşulur; sonsuz cəhdin qarşısını alırıq
        source.close();
        handlers.onState?.('failed');
        setTimeout(() => { errors = 0; open(); }, 30000);
      }
    };
  };

  open();
  return {
    close() { closed = true; source?.close(); },
    get state() { return source?.readyState ?? 2; },
  };
}

/* ---------------- Bildirişlər ---------------- */
export const notificationsSupported = () => typeof Notification !== 'undefined';
export const notificationPermission = () =>
  (notificationsSupported() ? Notification.permission : 'unsupported');

export async function requestNotificationPermission() {
  if (!notificationsSupported()) return 'unsupported';
  try { return await Notification.requestPermission(); } catch { return 'denied'; }
}

export async function notify(title, body, { tag, url = '/', requireInteraction = false } = {}) {
  if (!notificationsSupported() || Notification.permission !== 'granted') return false;
  const options = {
    body,
    tag,
    icon: '/assets/icons/icon-192.png',
    badge: '/assets/icons/icon-192.png',
    lang: 'az',
    requireInteraction,
    data: { url },
  };
  try {
    const reg = await navigator.serviceWorker?.getRegistration?.();
    if (reg?.showNotification) {
      await reg.showNotification(title, options);
      return true;
    }
  } catch { /* service worker yoxdur */ }
  try {
    const n = new Notification(title, options);
    n.onclick = () => { globalThis.focus?.(); location.href = url; };
    return true;
  } catch { return false; }
}

/* ---------------- PWA: service worker + quraşdırma ---------------- */
export async function registerServiceWorker() {
  if (!globalThis.navigator?.serviceWorker) return null;
  try {
    return await navigator.serviceWorker.register('/sw.js', { scope: '/' });
  } catch (err) {
    console.warn('[gotur] service worker qeydiyyatı alınmadı:', err.message);
    return null;
  }
}

let deferredInstall = null;
const installListeners = new Set();
globalThis.addEventListener?.('beforeinstallprompt', (event) => {
  event.preventDefault();
  deferredInstall = event;
  installListeners.forEach((fn) => fn(true));
});
globalThis.addEventListener?.('appinstalled', () => {
  deferredInstall = null;
  installListeners.forEach((fn) => fn(false));
});

export const installAvailable = () => Boolean(deferredInstall);
export function onInstallAvailable(fn) {
  installListeners.add(fn);
  fn(installAvailable());
  return () => installListeners.delete(fn);
}
export async function promptInstall() {
  if (!deferredInstall) return false;
  deferredInstall.prompt();
  const choice = await deferredInstall.userChoice.catch(() => ({ outcome: 'dismissed' }));
  deferredInstall = null;
  installListeners.forEach((fn) => fn(false));
  return choice?.outcome === 'accepted';
}

export const isStandalone = () =>
  globalThis.matchMedia?.('(display-mode: standalone)')?.matches === true
  || globalThis.navigator?.standalone === true;

export const isOnline = () => globalThis.navigator?.onLine !== false;

/* Service worker-i avtomatik qeydiyyatdan keçir (yalnız brauzerdə) */
if (globalThis.navigator?.serviceWorker) {
  globalThis.addEventListener?.('load', () => { registerServiceWorker(); });
}

/* ---------------- Dil dəyişdirici + səhifə başlığı ---------------- */
function mountLangSwitcher() {
  const doc = globalThis.document;
  if (!doc) return;

  // Səhifə başlığı: <body data-title-key="a.panel"> → «Götür — Admin paneli»
  const titleKey = doc.body?.dataset?.titleKey;
  if (titleKey) {
    const brand = t('app.name');
    const text = t(titleKey);
    doc.title = text.includes(brand) ? text : `${brand} — ${text}`;
  }
  doc.documentElement.lang = currentLang;

  const host = doc.querySelector?.('#lang-switch-host');
  if (!host) return;
  host.innerHTML = langSwitcherHtml();
  const label = doc.querySelector('#lang-switch-label');
  if (label) label.textContent = t('lang.label');

  host.addEventListener('click', (event) => {
    const button = event.target.closest?.('[data-lang]');
    if (!button) return;
    const next = button.dataset.lang;
    if (!isSupported(next) || next === currentLang) return;
    setLang(next);
    toast(translate(next, 'lang.changed', { name: LANG_NAMES[next] }), 'ok', 1600);
    globalThis.setTimeout?.(() => globalThis.location?.reload(), 400);
  });
}
if (globalThis.document) {
  if (globalThis.document.readyState === 'loading') {
    globalThis.document.addEventListener('DOMContentLoaded', mountLangSwitcher, { once: true });
  } else {
    mountLangSwitcher();
  }
}

/* ---------------- 58mm termal qəbz ---------------- */
/**
 * Qəbz mətnini 32 simvolluq sətirlərlə qurur (58mm printerlərin standart eni).
 * Yalnız ASCII/mətn simvolları istifadə olunur ki, termal printerlər düzgün çap etsin.
 */
const RECEIPT_WIDTH = 32;

const rLine = (char = '-') => char.repeat(RECEIPT_WIDTH);
const rLeftRight = (left, right) => {
  const l = String(left);
  const r = String(right);
  const space = RECEIPT_WIDTH - l.length - r.length;
  return space >= 1 ? l + ' '.repeat(space) + r : `${l}\n${r.padStart(RECEIPT_WIDTH)}`;
};
const rCenter = (text) => {
  const value = String(text);
  const pad = Math.max(0, Math.floor((RECEIPT_WIDTH - value.length) / 2));
  return ' '.repeat(pad) + value;
};
const rWrap = (text, indent = '') => {
  const words = String(text).split(/\s+/);
  const lines = [];
  let line = indent;
  for (const word of words) {
    if ((line + word).length > RECEIPT_WIDTH && line.trim()) {
      lines.push(line.trimEnd());
      line = `${indent}${word} `;
    } else {
      line += `${word} `;
    }
  }
  if (line.trim()) lines.push(line.trimEnd());
  return lines.join('\n');
};

/** Sifariş üçün qəbz mətnini qurur. `options.lang` ilə dil seçilə bilər. */
export function receiptText(order, vendor = {}, { lang: receiptLang = currentLang } = {}) {
  const tr = (key, params) => translate(receiptLang, key, params);
  const shortDate = (iso) => {
    const d = new Date(iso);
    return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')} `
      + `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  };
  const money = (qepik) => azn(qepik).replace(/\s?\u20BC$/, '') + ' AZN';

  const out = [];
  out.push(rCenter(tr('app.name').toUpperCase()));
  out.push(rCenter(vendor.name ?? order.vendorName ?? ''));
  if (vendor.address ?? order.vendorAddress) out.push(rWrap(vendor.address ?? order.vendorAddress, ''));
  const phone = vendor.phone ?? order.vendorPhone;
  if (phone) out.push(rCenter(`${tr('receipt.phone')}: ${phone}`));
  out.push(rLine('='));
  out.push(rLeftRight(`${tr('receipt.order')}: ${order.code}`, shortDate(order.createdAt)));
  out.push(rWrap(`${tr('receipt.customer')}: ${order.customerName}`));
  out.push(`${tr('receipt.phone')}: ${order.customerPhone}`);
  const payStatus = order.paymentStatus === 'paid' ? tr('paymentStatus.paid')
    : order.paymentStatus === 'refunded' ? tr('paymentStatus.refunded')
      : tr('paymentStatus.unpaid');
  out.push(`${tr('receipt.payment')}: ${translate(receiptLang, `payment.${order.payment}`)} (${payStatus})`);
  out.push(rLine());
  for (const item of order.items ?? []) {
    out.push(`${item.qty} x ${item.name}`);
    out.push(rLeftRight('', money(item.lineTotal)));
  }
  out.push(rLine());
  if (order.discount > 0) {
    out.push(rLeftRight(tr('common.subtotal'), money(order.subtotal)));
    out.push(rLeftRight(`${tr('common.discount')} ${order.couponCode ?? ''}`.trim(), `-${money(order.discount)}`));
  }
  out.push(rLeftRight(tr('common.total').toUpperCase(), money(order.total)));
  out.push(rLine('='));
  out.push(rCenter(`${tr('receipt.pickupCode')}: ${order.pickupCode}`));
  out.push(rLine('='));
  out.push(rCenter(tr('receipt.thanks').slice(0, RECEIPT_WIDTH)));
  out.push(rCenter(tr('receipt.footer')));
  return out.join('\n');
}

/** Qəbzi gizli iframe vasitəsilə çap edir (səhifənin görünüşü dəyişmir). */
export function printReceipt(order, vendor = {}, { text = null } = {}) {
  const body = text ?? receiptText(order, vendor);
  const html = `<!doctype html><html lang="${esc(currentLang)}"><head><meta charset="utf-8">
<title>${esc(order.code)}</title>
<style>
  @page { size: 58mm auto; margin: 3mm 2mm; }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; background: #fff; color: #000; }
  body { width: 54mm; }
  pre {
    margin: 0; white-space: pre-wrap; word-break: break-word;
    font: 11px/1.35 "Consolas", "Courier New", monospace;
  }
</style></head><body><pre>${esc(body)}</pre></body></html>`;

  const frame = document.createElement('iframe');
  frame.setAttribute('aria-hidden', 'true');
  frame.style.cssText = 'position:fixed;right:0;bottom:0;width:80mm;height:120mm;border:0;opacity:0;pointer-events:none;';
  document.body.appendChild(frame);
  const doc = frame.contentDocument ?? frame.contentWindow?.document;
  if (!doc) {
    frame.remove();
    toast(t('errors.generic'), 'err');
    return false;
  }
  doc.open();
  doc.write(html);
  doc.close();
  setTimeout(() => {
    try {
      frame.contentWindow?.focus();
      frame.contentWindow?.print();
    } catch (err) {
      console.warn('[gotur] çap alınmadı:', err);
    }
    setTimeout(() => frame.remove(), 2000);
  }, 250);
  return true;
}

/* ---------------- Kiçik köməkçilər ---------------- */
export const qs = (sel, root = document) => root.querySelector(sel);
export const qsa = (sel, root = document) => [...root.querySelectorAll(sel)];

export function on(root, event, selector, handler) {
  root.addEventListener(event, (e) => {
    const target = e.target.closest(selector);
    if (target && root.contains(target)) handler(e, target);
  });
}

/* ------------------------------------------------------------------ *
 * Yer (geolocation) və məsafə
 * ------------------------------------------------------------------ */
const LOC_KEY = 'gotur.loc.v1';

export const geo = {
  /** Yadda saxlanılmış yer (varsa). */
  cached() {
    try {
      const parsed = JSON.parse(localStorage.getItem(LOC_KEY) || 'null');
      if (parsed && Number.isFinite(parsed.lat) && Number.isFinite(parsed.lng)) return parsed;
    } catch { /* zədələnmiş yazı */ }
    return null;
  },

  has() { return !!geo.cached(); },

  /** Yer icazəsi vəziyyəti: 'granted' | 'denied' | 'prompt' | 'unsupported' */
  async permission() {
    if (!globalThis.navigator?.geolocation) return 'unsupported';
    try {
      const status = await globalThis.navigator.permissions?.query({ name: 'geolocation' });
      return status?.state ?? 'prompt';
    } catch {
      return 'prompt';
    }
  },

  /** Brauzerdən yer soruşur və yadda saxlayır. Xəta halında kodlu xəta atır. */
  async request({ timeout = 10000 } = {}) {
    const nav = globalThis.navigator;
    if (!nav?.geolocation) {
      throw Object.assign(new Error(t('nearby.unsupported')), { code: 'unsupported' });
    }
    const position = await new Promise((resolve, reject) => {
      nav.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: false, timeout, maximumAge: 120000,
      });
    }).catch((err) => {
      const code = err?.code === 1 ? 'denied' : err?.code === 3 ? 'timeout' : 'unavailable';
      throw Object.assign(new Error(t(`nearby.${code}`)), { code });
    });
    const loc = {
      lat: Number(position.coords.latitude.toFixed(6)),
      lng: Number(position.coords.longitude.toFixed(6)),
      accuracy: Math.round(position.coords.accuracy || 0),
      at: Date.now(),
    };
    try { localStorage.setItem(LOC_KEY, JSON.stringify(loc)); } catch { /* gizli rejim */ }
    return loc;
  },

  clear() { try { localStorage.removeItem(LOC_KEY); } catch { /* boş */ } },
};

/** Məsafəni oxunaqlı mətnə çevirir: 850 m / 2,4 km (dilə uyğun onluq ayırıcı). */
export function kmText(km) {
  const value = Number(km);
  if (!Number.isFinite(value)) return '';
  if (value < 1) return `${Math.max(10, Math.round((value * 1000) / 10) * 10)} m`;
  const digits = value < 10 ? 1 : 0;
  return `${value.toLocaleString(locale(), { minimumFractionDigits: digits, maximumFractionDigits: digits })} km`;
}

/** Mağaza üçün məsafə + yerimə/avtomobil vaxtı mətnləri (yoxdursa null). */
export function travel(vendor) {
  if (!vendor || vendor.distanceKm === null || vendor.distanceKm === undefined) return null;
  const distance = kmText(vendor.distanceKm);
  const walk = Number.isFinite(vendor.walkMinutes) ? t('nearby.walkMinutes', { min: vendor.walkMinutes }) : '';
  const drive = Number.isFinite(vendor.driveMinutes) ? t('nearby.driveMinutes', { min: vendor.driveMinutes }) : '';
  return { distance, walk, drive, km: vendor.distanceKm };
}

/** Kiçik nişanlar: 📍 2,4 km · 🚶 30 dəq · 🚗 8 dəq */
export function travelChipsHtml(vendor) {
  const info = travel(vendor);
  if (!info) return '';
  return `<span class="dist-chip" title="${esc(t('nearby.estimatedHint'))}">📍 ${esc(info.distance)}</span>
    <span class="dist-chip">🚶 ${esc(info.walk)}</span>
    <span class="dist-chip">🚗 ${esc(info.drive)}</span>`;
}

/** Sıralama: koordinatı olan mağazalar əvvəl, məsafəyə görə. */
export function byDistance(list) {
  return [...list].sort((a, b) => {
    const da = Number.isFinite(a?.distanceKm) ? a.distanceKm : Number.POSITIVE_INFINITY;
    const db = Number.isFinite(b?.distanceKm) ? b.distanceKm : Number.POSITIVE_INFINITY;
    if (da === db) return (b.rating ?? 0) - (a.rating ?? 0);
    return da - db;
  });
}

/* ------------------------------------------------------------------ *
 * Mobil yan panel (off-canvas menyu) — satıcı və admin panelləri
 * ------------------------------------------------------------------ */
export function initPanelMenu(sidebarSelector = '#sidebar') {
  const sidebar = typeof sidebarSelector === 'string' ? qs(sidebarSelector) : sidebarSelector;
  const backdrop = qs('.sidebar-backdrop');
  if (!sidebar || !backdrop) return;

  const setOpen = (open) => {
    sidebar.classList.toggle('open', open);
    backdrop.classList.toggle('open', open);
    document.body.classList.toggle('menu-open', open);
  };

  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-act="menu"]')) {
      e.preventDefault();
      setOpen(!sidebar.classList.contains('open'));
      return;
    }
    if (e.target.closest('[data-act="menu-close"]')) {
      setOpen(false);
      return;
    }
    // Menyu elementinə toxunanda paneli bağla (bölmə dəyişir)
    const link = e.target.closest(`${sidebarSelector} a`);
    if (link) setOpen(false);
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') setOpen(false);
  });

  // Ekran böyüdükdə menyu bağlı qalsın
  globalThis.addEventListener?.('resize', () => {
    if (globalThis.innerWidth > 980) setOpen(false);
  });

  return { open: () => setOpen(true), close: () => setOpen(false), toggle: () => setOpen(!sidebar.classList.contains('open')) };
}

export function debounce(fn, ms = 260) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

/** Sadə sorğu (polling) — dayandırmaq üçün .stop() çağırın. */
export function poll(fn, ms = 5000) {
  let stopped = false;
  let timer;
  const tick = async () => {
    if (stopped) return;
    try { await fn(); } catch (err) { if (err.status === 401) return; }
    if (!stopped) timer = setTimeout(tick, ms);
  };
  timer = setTimeout(tick, ms);
  return { stop() { stopped = true; clearTimeout(timer); } };
}

export function go(hash) { location.hash = hash; }

export function setActiveNav(root = document) {
  const here = location.pathname.split('/').pop() || 'index.html';
  qsa('[data-nav]', root).forEach((a) => {
    const target = (a.getAttribute('href') || '').split('/').pop();
    a.classList.toggle('active', target === here);
  });
}
