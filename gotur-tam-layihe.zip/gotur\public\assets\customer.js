/* ==================================================================
   Götür — müştəri tətbiqi
   Marşrutlar:  #/  |  #/v/:slug  |  #/sifarislerim  |  #/sifaris/:code  |  #/giris
   ================================================================== */
import * as U from './common.js';
const { h, raw } = U;

const app = U.qs('#app');
const state = {
  categories: [],
  vendors: [],
  kind: '',
  category: '',
  q: '',
  loading: true,
  user: null,
  loc: null,
  trackStop: null,
  trackLive: null,
};

/* ------------------------------------------------------------------ *
 * Başlanğıc
 * ------------------------------------------------------------------ */
(async function init() {
  await U.loadSession();
  state.user = U.getUser();
  renderHeader();
  renderFooter();
  renderTabbar();

  window.addEventListener('hashchange', route);
  U.cart.onChange(() => {
    renderHeader();
    renderDrawer();
    refreshSteppers();
    renderTabbar();
  });

  try {
    const { categories } = await U.api('/api/categories');
    state.categories = categories;
  } catch { /* kateqoriyalar olmadan da işləyir */ }

  // PWA: quraşdırma düyməsi + oflayn zolağı
  U.onInstallAvailable(() => {
    const btn = U.qs('[data-act="install"]');
    btn?.classList.toggle('hidden', !U.installAvailable());
  });
  const offlineBar = U.qs('#offline-bar');
  const syncNet = () => offlineBar?.classList.toggle('hidden', U.isOnline());
  globalThis.addEventListener?.('online', syncNet);
  globalThis.addEventListener?.('offline', syncNet);
  syncNet();

  await route();
})();

/* ------------------------------------------------------------------ *
 * Başlıq və ayaq
 * ------------------------------------------------------------------ */
function renderHeader() {
  const count = U.cart.count();
  const user = U.getUser();
  const kindLabel = state.kind === 'market' ? U.t('nav.markets') : U.t('nav.restaurants');
  U.qs('#header').innerHTML = h`
    <div class="inner">
      <a class="logo" href="#/">
        <span class="mark">🛍️</span>
        <span>${U.t('app.name')}<small>${U.t('app.tagline')}</small></span>
      </a>

      <nav class="nav-links">
        <a href="#/" data-nav>${U.t('nav.all')}</a>
        <a href="#/k/restaurant" data-nav>${U.t('nav.restaurants')}</a>
        <a href="#/k/market" data-nav>${U.t('nav.markets')}</a>
        <a href="#/sifarislerim" data-nav>${U.t('nav.myOrders')}</a>
      </nav>

      <span class="grow"></span>

      <button class="btn btn-outline btn-sm" data-act="search-open" title="${U.t('nav.search')}" aria-label="${U.t('nav.search')}">🔍 <span class="btn-label">${U.t('nav.search')}</span></button>
      ${U.notificationPermission() === 'granted'
        ? ''
        : raw(`<button class="btn btn-outline btn-sm" data-act="notify" title="${U.t('customer.openNotifications')}" aria-label="${U.t('customer.openNotifications')}">🔔</button>`)}
      <button class="btn btn-outline btn-sm hidden" data-act="install" title="${U.t('nav.installTitle')}">⬇ <span class="btn-label">${U.t('nav.install')}</span></button>
      <button class="btn btn-dark cart-btn" data-act="cart" aria-label="${U.t('nav.cart')}">
        🧺 <span class="btn-label">${U.t('nav.cart')}</span> ${count ? raw(`<span class="cart-count">${count}</span>`) : ''}
      </button>
      ${user
        ? raw(`<span class="row" style="gap:8px">
             <span class="avatar" title="${U.esc(user.name)}">${U.esc(U.initials(user.name))}</span>
             <button class="btn btn-ghost btn-sm" data-act="logout" aria-label="${U.t('nav.logout')}"><span class="btn-label">${U.t('nav.logout')}</span><span class="only-sm">⎋</span></button>
           </span>`)
        : raw(`<a class="btn btn-primary btn-sm" href="#/giris">${U.t('nav.login')}</a>`)}
    </div>`;

  U.qs('[data-act="install"]', U.qs('#header'))?.classList.toggle('hidden', !U.installAvailable());
}

function renderFooter() {
  U.qs('#footer').innerHTML = h`
    <div class="wrap">
      <div class="cols">
        <div>
          <div class="logo mb-2"><span class="mark">🛍️</span><span>${U.t('app.name')}</span></div>
          <p class="small muted">${U.t('app.footerNote')} ${U.t('customer.footerExtra')}</p>
        </div>
        <div>
          <h4 class="mb-1">${U.t('customer.forCustomers')}</h4>
          <p class="small muted">${U.t('customer.forCustomersText')}</p>
        </div>
        <div>
          <h4 class="mb-1">${U.t('customer.forBusiness')}</h4>
          <p class="small muted"><a href="/satis.html"><b>${U.t('nav.vendorPanel')} →</b></a><br>${U.t('customer.forBusinessText')}</p>
        </div>
        <div>
          <h4 class="mb-1">${U.t('a.scopePlatform')}</h4>
          <p class="small muted"><a href="/admin.html">${U.t('nav.adminPanel')}</a><br>${U.t('app.demoProject')}</p>
        </div>
      </div>
      <p class="tiny muted mt-3">${U.t('app.copyright', { year: new Date().getFullYear() })}</p>
    </div>`;
}

/* ------------------------------------------------------------------ *
 * Mobil alt naviqasiya (tabbar)
 * ------------------------------------------------------------------ */
function renderTabbar() {
  const host = U.qs('#tabbar');
  if (!host) return;
  document.body.classList.add('has-tabbar');

  const hash = location.hash.replace(/^#\/?/, '');
  const head = hash.split('/')[0];
  const count = U.cart.count();
  const tab = (href, icon, label, active, badge) => `
    <a href="${href}" class="${active ? 'active' : ''}">
      <span class="ico">${icon}</span>
      <span>${label}</span>
      ${badge ? `<span class="cart-count badge badge-brand">${badge}</span>` : ''}
    </a>`;

  host.innerHTML = h`
    ${raw(tab('#/', '🏠', U.t('nav.home'), !head))}
    ${raw(tab('#/k/restaurant', '🍽️', U.t('nav.restaurants'), head === 'k' && hash.includes('restaurant')))}
    ${raw(tab('#/k/market', '🏪', U.t('nav.markets'), head === 'k' && hash.includes('market')))}
    ${raw(tab('#/sifarislerim', '📦', U.t('nav.myOrders'), head === 'sifarislerim'))}
    ${raw(`<button type="button" data-act="cart" aria-label="${U.esc(U.t('nav.cart'))}">
      <span class="ico">🧺</span>
      <span>${U.t('nav.cart')}</span>
      ${count ? `<span class="cart-count badge badge-brand">${count}</span>` : ''}
    </button>`)}
  `;
}

/* ------------------------------------------------------------------ *
 * Marşrutlaşdırma
 * ------------------------------------------------------------------ */
async function route() {
  state.trackStop?.stop();
  state.trackLive?.close();
  state.trackLive = null;
  const hash = location.hash.replace(/^#\/?/, '');
  const [head, param] = hash.split('/');
  window.scrollTo({ top: 0 });
  renderTabbar();

  if (!head) return renderHome();
  if (head === 'k') { state.kind = ['restaurant', 'market'].includes(param) ? param : ''; state.category = ''; return renderHome(); }
  if (head === 'v' && param) return renderVendor(decodeURIComponent(param));
  if (head === 'sifarislerim') return renderMyOrders();
  if (head === 'sifaris' && param) return renderTrack(decodeURIComponent(param));
  if (head === 'giris') return renderAuth();
  return renderHome();
}

/* ------------------------------------------------------------------ *
 * Ana səhifə
 * ------------------------------------------------------------------ */
async function renderHome() {
  state.loading = true;
  state.loc = U.geo.cached();
  app.innerHTML = `<div id="home-page">${homeShell()}</div>`;
  bindHomeEvents();
  await Promise.all([loadVendors(), paintNearby()]);
  paintVendorSections();
}

function homeShell() {
  const chips = state.categories
    .filter((c) => !state.kind || c.kind === state.kind)
    .map((c) => `<button class="chip ${state.category === c.slug ? 'active' : ''}" data-cat="${U.esc(c.slug)}">
        <span>${U.esc(c.icon)}</span>${U.esc(c.name)}</button>`)
    .join('');

  return h`
    <section class="hero">
      <div class="wrap">
        <h1>${U.t('hero.title')} <span style="color:var(--brand)">${U.t('hero.titleAccent')}</span></h1>
        <p>${U.t('hero.text')} ${U.t('customer.heroExtra')}</p>
        <div class="search">
          <input class="input" data-act="search" placeholder="${U.t('hero.searchPlaceholder')}" value="${state.q}">
        </div>
        <div class="stats">
          <div><b>${state.kind === 'market' ? `🏪 ${U.t('nav.markets')}` : `🍽️ ${U.t('nav.restaurants')}`}</b><span>${state.kind ? U.t('hero.filterActive') : U.t('hero.allInOne')}</span></div>
          <div><b>0 ₼</b><span>${U.t('hero.statDelivery')}</span></div>
          <div><b>15–30 ${U.t('common.minutes')}</b><span>${U.t('hero.statPrep')}</span></div>
        </div>
      </div>
    </section>

    <div class="wrap">
      <div id="nearby-area" class="mt-3"></div>
    </div>

    <div class="wrap">
      <div class="section-head">
        <h2>${state.kind === 'market' ? `🏪 ${U.t('nav.markets')}` : state.kind === 'restaurant' ? `🍽️ ${U.t('nav.restaurants')}` : `🧭 ${U.t('home.categories')}`}</h2>
        ${state.category ? raw(`<button class="btn btn-sm btn-outline" data-act="clear-cat">${U.t('home.clearFilter')}</button>`) : ''}
      </div>
      <div class="chip-row">
        <button class="chip ${!state.category ? 'active' : ''}" data-cat="">${U.t('nav.all')}</button>
        ${raw(chips)}
      </div>
      <div id="vendor-area" class="mt-3">
        <div class="vendor-grid">
          ${raw(Array.from({ length: 6 }, () => '<div class="skeleton" style="height:230px"></div>').join(''))}
        </div>
      </div>
    </div>`;
}

/* ------------------------------------------------------------------ *
 * Yaxınlıqdakılar (məsafə + yol vaxtı)
 * ------------------------------------------------------------------ */
async function paintNearby() {
  const host = U.qs('#nearby-area');
  if (!host) return;
  const loc = state.loc;

  if (!loc) {
    host.innerHTML = h`
      <div class="card card-pad nearby-cta">
        <div class="row-between wrap-row">
          <div>
            <h3>📍 ${U.t('nearby.title')}</h3>
            <p class="small muted mt-1">${U.t('nearby.subtitle')}</p>
          </div>
          <button class="btn btn-primary" data-act="share-loc">📍 ${U.t('nearby.share')}</button>
        </div>
        <p class="tiny muted mt-2">${U.t('nearby.estimatedHint')}</p>
      </div>`;
    return;
  }

  host.innerHTML = h`
    <div class="card card-pad">
      <div class="row-between wrap-row">
        <div>
          <h3>📍 ${U.t('nearby.title')}</h3>
          <p class="small muted mt-1">${U.t('nearby.subtitleShared')}</p>
        </div>
        <div class="row wrap-row" style="gap:8px">
          <button class="btn btn-sm btn-outline" data-act="share-loc">🔄 ${U.t('nearby.update')}</button>
          <button class="btn btn-sm btn-ghost" data-act="clear-loc">✕</button>
        </div>
      </div>
      <div id="nearby-groups" class="mt-3">
        <div class="skeleton" style="height:150px"></div>
      </div>
    </div>`;

  let data;
  try {
    data = await U.api(`/api/nearby?lat=${loc.lat}&lng=${loc.lng}&limit=4`);
  } catch (err) {
    U.qs('#nearby-groups').innerHTML = h`<p class="small muted">${U.errText(err)}</p>`;
    return;
  }
  const groupsHost = U.qs('#nearby-groups');
  if (!groupsHost) return;

  const groups = [
    { key: 'restaurants', icon: '🍽️', labelKey: 'nearby.restaurants' },
    { key: 'markets', icon: '🏪', labelKey: 'nearby.markets' },
    { key: 'pharmacies', icon: '🏥', labelKey: 'nearby.pharmacies' },
  ].filter((g) => data.groups[g.key]?.length);

  if (!groups.length) {
    groupsHost.innerHTML = h`<p class="small muted">${U.t('nearby.none')}</p>`;
    return;
  }

  groupsHost.innerHTML = h`
    ${raw(groups.map((g) => `
      <div class="nearby-block">
        <div class="nearby-head">
          <b>${g.icon} ${U.t(g.labelKey)}</b>
          <span class="tiny muted">${U.t('nearby.count', { count: data.counts[g.key] })}</span>
        </div>
        <div class="nearby-grid">
          ${data.groups[g.key].map((v, i) => `
            <a class="nearby-card" href="#/v/${U.esc(v.slug)}">
              <span class="nc-logo">${U.esc(v.logo)}</span>
              <span class="nc-body">
                <span class="nc-name">${U.esc(v.name)}</span>
                <span class="nc-meta">
                  <span class="dist-chip strong">📍 ${U.esc(U.kmText(v.distanceKm))}</span>
                  <span class="dist-chip">🚶 ${U.esc(U.t('nearby.walkMinutes', { min: v.walkMinutes }))}</span>
                  <span class="dist-chip">🚗 ${U.esc(U.t('nearby.driveMinutes', { min: v.driveMinutes }))}</span>
                </span>
              </span>
              ${i === 0 ? `<span class="nc-badge">${U.t('nearby.nearest')}</span>` : ''}
            </a>`).join('')}
        </div>
      </div>`).join(''))}`;
}

function bindHomeEvents() {
  const page = U.qs('#home-page');
  U.on(page, 'click', '[data-cat]', async (e, el) => {
    state.category = el.dataset.cat;
    await renderHome();
  });
  U.on(page, 'click', '[data-act="clear-cat"]', async () => {
    state.category = '';
    await renderHome();
  });
  U.on(page, 'click', '[data-act="share-loc"]', async (e, el) => {
    el.disabled = true;
    const label = el.innerHTML;
    el.innerHTML = `⏳ ${U.t('nearby.locating')}`;
    try {
      state.loc = await U.geo.request();
      U.toast(U.t('nearby.shared'), 'ok');
      await Promise.all([loadVendors(), paintNearby()]);
      paintVendorSections();
    } catch (err) {
      U.toast(U.errText(err), 'err', 5000);
      el.disabled = false;
      el.innerHTML = label;
    }
  });
  U.on(page, 'click', '[data-act="clear-loc"]', async () => {
    U.geo.clear();
    state.loc = null;
    await Promise.all([loadVendors(), paintNearby()]);
    paintVendorSections();
  });
  const search = U.qs('[data-act="search"]', page);
  search?.addEventListener('input', U.debounce(async (e) => {
    state.q = e.target.value.trim();
    await loadVendors();
    paintVendorSections();
  }, 280));
}

async function loadVendors() {
  const params = new URLSearchParams();
  if (state.kind) params.set('kind', state.kind);
  if (state.category) params.set('category', state.category);
  if (state.q) params.set('q', state.q);
  const loc = state.loc ?? U.geo.cached();
  if (loc) {
    params.set('lat', loc.lat);
    params.set('lng', loc.lng);
    if (!state.q && !state.category) params.set('sort', 'nearby');
  }
  try {
    const data = await U.api(`/api/vendors?${params}`);
    state.vendors = data.vendors;
  } catch (err) {
    state.vendors = [];
    U.toast(U.errText(err), 'err');
  }
  state.loading = false;
}

function vendorCard(v) {
  const chips = U.travelChipsHtml(v);
  return h`
    <a class="card card-hover vendor-card ${v.open ? '' : 'closed'}" href="#/v/${U.esc(v.slug)}">
      <div class="cover">
        ${U.esc(v.logo)}
        <span class="status-chip">${v.open
          ? raw(`<span class="badge badge-open">${U.t('common.open')}</span>`)
          : raw(`<span class="badge badge-closed">${U.t('common.closed')}</span>`)}</span>
      </div>
      <div class="body">
        <div class="row-between">
          <h3>${v.name}</h3>
          <span class="badge badge-brand">⭐ ${Number(v.rating).toFixed(1)}</span>
        </div>
        <div class="tagline">${v.tagline || v.category?.name || ''}</div>
        ${chips ? raw(`<div class="dist-row">${chips}</div>`) : ''}
        <div class="meta">
          <span>⏱ ${U.t('units.minutesShort', { count: v.prepTime })}</span>
          ${v.minOrder ? raw(`<span>🧾 min ${U.azn(v.minOrder)}</span>`) : raw(`<span>🧾 ${U.t('common.noMinOrder')}</span>`)}
          <span>📍 ${U.esc(v.address.split(',')[0])}</span>
        </div>
      </div>
    </a>`;
}

function paintVendorSections() {
  const area = U.qs('#vendor-area');
  if (!area) return;
  if (!state.vendors.length) {
    area.innerHTML = h`
      <div class="empty">
        <div class="big">🔍</div>
        <h3>${U.t('common.noResults')}</h3>
        <p class="muted mt-1">${state.q ? U.t('home.noMatchFor', { query: state.q }) : U.t('home.noStoresInFilter')}</p>
      </div>`;
    return;
  }

  const searching = Boolean(state.q || state.category || state.kind);
  if (searching) {
    area.innerHTML = h`
      <div class="row-between mb-2">
        <h2>${state.q ? raw(U.t('home.resultsFor', { query: U.esc(state.q) })) : U.t('home.results')}</h2>
        <span class="muted small">${U.t('home.storesCount', { count: state.vendors.length })}</span>
      </div>
      <div class="vendor-grid">${raw(state.vendors.map(vendorCard).join(''))}</div>`;
    return;
  }

  const restaurants = state.vendors.filter((v) => v.kind === 'restaurant');
  const markets = state.vendors.filter((v) => v.kind === 'market');
  area.innerHTML = h`
    ${restaurants.length ? raw(`
      <div class="section-head"><h2>🍽️ ${U.t('nav.restaurants')}</h2>
        <a class="small muted" href="#/k/restaurant">${U.t('nav.seeAll')}</a></div>
      <div class="vendor-grid">${restaurants.map(vendorCard).join('')}</div>`) : ''}
    ${markets.length ? raw(`
      <div class="section-head"><h2>🏪 ${U.t('nav.markets')}</h2>
        <a class="small muted" href="#/k/market">${U.t('nav.seeAll')}</a></div>
      <div class="vendor-grid">${markets.map(vendorCard).join('')}</div>`) : ''}`;
}

/* ------------------------------------------------------------------ *
 * Mağaza səhifəsi
 * ------------------------------------------------------------------ */
async function renderVendor(slug) {
  app.innerHTML = h`<div class="wrap" style="padding-top:40px">
    <div class="skeleton" style="height:150px"></div>
    <div class="skeleton mt-3" style="height:320px"></div></div>`;

  let vendor;
  let reviews = [];
  let reviewSummary = null;
  let coupons = [];
  let travel = null;
  try {
    const loc = state.loc ?? U.geo.cached();
    state.loc = loc;
    const query = loc ? `?lat=${loc.lat}&lng=${loc.lng}` : '';
    const data = await U.api(`/api/vendors/${encodeURIComponent(slug)}${query}`);
    vendor = data.vendor;
    reviews = data.reviews ?? [];
    reviewSummary = data.reviewSummary ?? null;
    coupons = data.coupons ?? [];
    travel = U.travel(vendor);
  } catch (err) {
    app.innerHTML = h`<div class="wrap"><div class="empty"><div class="big">😕</div>
      <h3>${U.t('vendorPage.storeNotFound')}</h3><p class="muted mt-1">${err.message}</p>
      <a class="btn btn-primary mt-3" href="#/">${U.t('nav.mainPage')}</a></div></div>`;
    return;
  }

  const menu = vendor.menu ?? [];
  const navChips = menu.map((s, i) => `<a class="chip" href="#/v/${U.esc(vendor.slug)}" data-scroll="sec-${i}">${U.esc(s.section)}</a>`).join('');

  app.innerHTML = h`<div id="vendor-page">
    <section class="vendor-hero">
      <div class="wrap row wrap-row" style="gap:20px">
        <div class="logo-big">${U.esc(vendor.logo)}</div>
        <div class="grow">
          <div class="row wrap-row" style="gap:10px">
            <h1>${vendor.name}</h1>
            ${vendor.open ? raw(`<span class="badge badge-open">${U.t('common.open')}</span>`) : raw(`<span class="badge badge-closed">${U.t('common.closed')}</span>`)}
            ${U.ratingBadge(vendor)}
          </div>
          <p class="mt-1" style="color:#cfe0ea">${vendor.tagline || ''}</p>
          <div class="row wrap-row mt-2" style="gap:16px;color:#bcd0dc;font-size:13.5px">
            <span>⏱ ${U.t('common.prepTime')}: ${U.t('units.minutesShort', { count: vendor.prepTime })}</span>
            <span>🧾 ${U.t('common.minOrder')}: ${vendor.minOrder ? U.azn(vendor.minOrder) : U.t('customer.none')}</span>
            <span>📍 ${U.esc(vendor.address)}</span>
            ${vendor.phone ? raw(`<span>☎ ${U.esc(vendor.phone)}</span>`) : ''}
          </div>
          ${travel ? raw(`<div class="travel-bar mt-2">
            <span class="dist-chip strong">📍 ${U.esc(travel.distance)} ${U.t('nearby.fromYou')}</span>
            <span class="dist-chip">🚶 ${U.esc(travel.walk)}</span>
            <span class="dist-chip">🚗 ${U.esc(travel.drive)}</span>
            <span class="tiny" style="opacity:.75">${U.t('nearby.estimated')}</span>
          </div>`) : ''}
        </div>
      </div>
    </section>

    <div class="menu-nav">
      <div class="wrap row" style="gap:8px;overflow-x:auto">
        ${raw(navChips || `<span class="muted small">${U.t('vendorPage.menuEmptyShort')}</span>`)}
      </div>
    </div>

    <div class="wrap">
      <div class="menu-grid">
        <div>
          ${menu.length ? raw(menu.map((sec, i) => `
            <section class="card section-card" id="sec-${i}">
              <div class="card-pad">
                <h3>${U.esc(sec.section)}</h3>
              </div>
              ${sec.items.map((p) => itemRow(p, vendor)).join('')}
            </section>`).join(''))
            : raw(`<div class="card card-pad empty"><div class="big">🍽️</div>
                <h3>${U.t('vendorPage.menuEmpty')}</h3></div>`) }
        </div>

        <aside class="col menu-side" style="top:calc(var(--header-h) + 12px)">
          <div class="card card-pad">
            <h3>${U.t('vendorPage.howItWorks')}</h3>
            <ol class="small muted" style="padding-left:18px;margin:10px 0 0;line-height:1.8">
              <li>${U.t('vendorPage.howStep1')}</li>
              <li>${U.t('vendorPage.howStep2')}</li>
              <li>${U.t('vendorPage.howStep3')}</li>
            </ol>
            <p class="tiny muted mt-2">${U.t('vendorPage.noDeliveryNote')}</p>
          </div>
          <div class="card card-pad">
            <h3>${U.t('vendorPage.about')}</h3>
            <p class="small muted mt-1">${vendor.description || '—'}</p>
            <p class="small mt-2">📍 ${U.esc(vendor.address)}</p>
            ${vendor.phone ? raw(`<p class="small">☎ ${U.esc(vendor.phone)}</p>`) : ''}
          </div>
          ${coupons.length ? raw(`
            <div class="card card-pad">
              <h3>🎁 ${U.t('vendorPage.promotions')}</h3>
              <p class="small muted mt-1">${U.t('vendorPage.promotionsHint')}</p>
              ${coupons.map((c) => `
                <div class="row-between mt-2" style="gap:8px">
                  <div>
                    <b style="letter-spacing:.06em">${U.esc(c.code)}</b>
                    <div class="tiny muted">${U.esc(c.description || c.label)}
                      ${c.minOrder ? ` · min ${U.azn(c.minOrder)}` : ''}</div>
                  </div>
                  <button class="btn btn-sm btn-outline" data-copy="${U.esc(c.code)}">${U.t('actions.copy')}</button>
                </div>`).join('')}
            </div>`) : ''}
          <div id="cart-preview"></div>
        </aside>
      </div>

      ${reviews.length ? raw(renderReviewsBlock(reviewSummary, reviews)) : ''}
    </div>
  </div>`;

  const page = U.qs('#vendor-page');
  U.on(page, 'click', '[data-copy]', async (e, el) => {
    try {
      await navigator.clipboard.writeText(el.dataset.copy);
      U.toast(U.t('customer.couponCopied', { code: el.dataset.copy }), 'ok');
    } catch {
      U.toast(U.t('customer.couponCodeToast', { code: el.dataset.copy }), '', 6000);
    }
  });
  U.on(page, 'click', '[data-scroll]', (e, el) => {
    e.preventDefault();
    U.qs(`#${el.dataset.scroll}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
  U.on(page, 'click', '[data-add]', (e, el) => {
    const product = findProduct(vendor, Number(el.dataset.add));
    if (!product) return;
    U.cart.add(vendor, product, 1);
    U.toast(U.t('vendorPage.addedToCart', { name: product.name }), 'ok', 1800);
  });
  U.on(page, 'click', '[data-plus]', (e, el) => {
    const product = findProduct(vendor, Number(el.dataset.plus));
    U.cart.add(vendor, product, 1);
  });
  U.on(page, 'click', '[data-minus]', (e, el) => {
    const id = Number(el.dataset.minus);
    U.cart.setQty(id, U.cart.qty(id) - 1);
  });
  renderDrawer();
  refreshSteppers();
}

function findProduct(vendor, id) {
  return vendor.menu.flatMap((s) => s.items).find((p) => p.id === id);
}

/** Mağaza səhifəsindəki rəylər bloku (ulduz bölgüsü + rəy kartları). */
function renderReviewsBlock(summary, reviews) {
  const dist = summary?.distribution ?? {};
  const total = summary?.reviewCount ?? reviews.length;
  const avg = summary?.newRating ?? 0;

  return `
    <section class="mt-4" id="reyler">
      <div class="section-head">
        <h2>⭐ ${U.t('common.reviews')}</h2>
        <span class="muted small">${U.t('review.storeRating')} ${Number(summary?.rating ?? 0).toFixed(1)} · ${U.t('customer.ratingCount', { count: summary?.ratingCount ?? 0 })}</span>
      </div>
      <div class="review-grid">
        <div class="card card-pad">
          <div style="font-size:34px;font-weight:800;line-height:1">${avg ? avg.toFixed(1) : '—'}</div>
          ${U.starsHtml(avg, 16)}
          <p class="small muted mt-1">${U.t('common.basedOnReviews', { count: total })}</p>
          <div class="mt-2">
            ${[5, 4, 3, 2, 1].map((star) => {
    const count = dist[star] ?? 0;
    const percent = total ? Math.round((count / total) * 100) : 0;
    return `<div class="row" style="gap:8px;margin:4px 0">
                <span class="tiny muted" style="width:26px">${star}★</span>
                <div style="flex:1;height:7px;background:var(--surface-2);border-radius:99px;overflow:hidden">
                  <div style="width:${percent}%;height:100%;background:#f5b60a"></div></div>
                <span class="tiny muted" style="width:22px;text-align:right">${count}</span></div>`;
  }).join('')}
          </div>
        </div>
        <div class="col">
          ${reviews.map((r) => `
            <div class="card card-pad">
              <div class="row-between wrap-row">
                <div>
                  <b>${U.esc(r.authorName)}</b>
                  <div>${U.starsHtml(r.rating)}</div>
                </div>
                <span class="tiny muted">${U.dateTime(r.createdAt)}</span>
              </div>
              ${r.comment ? `<p class="small mt-2">${U.esc(r.comment)}</p>` : ''}
              ${r.reply
    ? `<div class="card card-pad mt-2" style="background:var(--brand-soft);border:none">
                     <b class="small">${U.t('review.storeReply')}</b>
                     <p class="small mt-1">${U.esc(r.reply)}</p>
                   </div>`
    : ''}
            </div>`).join('')}
        </div>
      </div>
    </section>`;
}

function itemRow(p, vendor) {
  return h`
    <div class="item-row" data-item="${p.id}">
      ${U.thumb(p.image)}
      <div class="item-info">
        <div class="bold">${p.name}</div>
        ${p.description ? raw(`<div class="small muted">${U.esc(p.description)}</div>`) : ''}
        <div class="small muted mt-1">
          <span class="item-price">${U.azn(p.price)}</span>
          <span> / ${U.esc(p.unit)}</span>
          ${p.stock !== null ? raw(` · ${U.t('vendorPage.inStock', { count: p.stock })}`) : ''}
        </div>
      </div>
      <div class="item-actions">
        ${p.inStock
          ? raw(`<button class="btn btn-dark btn-sm" data-add="${p.id}">${U.t('actions.add')}</button>
                 <div class="stepper hidden" data-stepper="${p.id}">
                   <button data-minus="${p.id}" aria-label="${U.t('customer.decrease')}">−</button>
                   <span class="qty" data-qty="${p.id}">0</span>
                   <button data-plus="${p.id}" aria-label="${U.t('customer.increase')}">+</button>
                 </div>`)
          : raw(`<span class="badge badge-closed">${U.t('vendorPage.outOfStock')}</span>`)}
      </div>
    </div>`;
}

/** Səbətdəki məhsulların stepperlərini yeniləyir */
function refreshSteppers() {
  U.qsa('[data-item]').forEach((row) => {
    const id = Number(row.dataset.item);
    const qty = U.cart.qty(id);
    const stepper = U.qs(`[data-stepper="${id}"]`, row);
    const addBtn = U.qs(`[data-add="${id}"]`, row);
    if (stepper) stepper.classList.toggle('hidden', qty <= 0);
    if (addBtn) addBtn.classList.toggle('hidden', qty > 0);
    const qtyEl = U.qs(`[data-qty="${id}"]`, row);
    if (qtyEl) qtyEl.textContent = qty;
  });
  renderCartPreview();
}

function renderCartPreview() {
  const host = U.qs('#cart-preview');
  if (!host) return;
  const c = U.cart.get();
  if (!c.items.length) {
    host.innerHTML = '';
    return;
  }
  host.innerHTML = h`
    <div class="card card-pad">
      <div class="row-between">
        <h3>🧺 ${U.t('cart.yourCart')}</h3>
        <span class="badge badge-brand">${U.cart.count()} ${U.t('common.items')}</span>
      </div>
      <p class="small muted mt-1">${c.vendorName}</p>
      <div class="row-between mt-2"><span class="muted small">${U.t('common.subtotal')}</span><b>${U.azn(U.cart.subtotal())}</b></div>
      <button class="btn btn-primary btn-block mt-2" data-act="cart">${U.t('cart.viewCart')}</button>
    </div>`;
}

/* ------------------------------------------------------------------ *
 * Səbət paneli
 * ------------------------------------------------------------------ */
function renderDrawer(forceOpen) {
  const host = U.qs('#drawer-root');
  const isOpen = forceOpen ?? (U.qs('.drawer', host)?.classList.contains('open') ?? false);
  const c = U.cart.get();
  const subtotal = U.cart.subtotal();
  const belowMin = subtotal < (c.minOrder ?? 0);

  if (!c.items.length) {
    host.innerHTML = '';
    return;
  }

  // Backdrop YALNIZ açıq halda DOM-a əlavə olunur — gizli təbəqə klikləri bloklamasın
  host.innerHTML = h`
    ${isOpen ? raw('<div class="drawer-backdrop open" data-act="close-cart"></div>') : ''}
    <aside class="drawer ${isOpen ? 'open' : ''}">
      <header>
        <div>
          <h3>🧺 ${U.t('nav.cart')}</h3>
          <p class="small muted">${c.vendorName}</p>
        </div>
        <button class="btn btn-ghost btn-icon" data-act="close-cart">✕</button>
      </header>
      <div class="content">
        ${raw(c.items.map((i) => `
          <div class="cart-line">
            ${U.thumbHtml(i.image)}
            <div class="grow">
              <div class="bold">${U.esc(i.name)}</div>
              <div class="small muted">${U.azn(i.price)} / ${U.esc(i.unit)}</div>
              <div class="row-between mt-1">
                <span class="stepper">
                  <button data-minus="${i.productId}">−</button>
                  <span class="qty">${i.qty}</span>
                  <button data-plus="${i.productId}">+</button>
                </span>
                <b>${U.azn(i.price * i.qty)}</b>
              </div>
            </div>
          </div>`).join(''))}
        <button class="btn btn-ghost btn-sm mt-2" data-act="clear-cart">🗑 ${U.t('cart.clear')}</button>
      </div>
      <footer>
        <div class="totals">
          <div class="row-between"><span class="muted">${U.t('common.subtotal')}</span><span>${U.azn(subtotal)}</span></div>
          <div class="row-between"><span class="muted">${U.t('common.delivery')}</span><span class="badge badge-open">${U.t('common.noDelivery')}</span></div>
          <div class="row-between total"><span>${U.t('common.total')}</span><span>${U.azn(subtotal)}</span></div>
        </div>
        ${belowMin
          ? raw(`<p class="small" style="color:#8a5200">${U.t('cart.belowMin', { min: U.azn(c.minOrder), missing: U.azn(c.minOrder - subtotal) })}</p>
                 <button class="btn btn-block mt-2" disabled>${U.t('cart.checkout')}</button>`)
          : raw(`<button class="btn btn-primary btn-block btn-lg" data-act="checkout">${U.t('cart.checkout')} →</button>`)}
      </footer>
    </aside>`;
}

function openCart() {
  if (!U.cart.items().length) return U.toast(U.t('cart.empty'));
  renderDrawer(false);
  const host = U.qs('#drawer-root');
  if (!U.qs('.drawer-backdrop', host)) {
    host.insertAdjacentHTML('afterbegin', '<div class="drawer-backdrop" data-act="close-cart"></div>');
  }
  requestAnimationFrame(() => {
    U.qs('#drawer-root .drawer')?.classList.add('open');
    U.qs('#drawer-root .drawer-backdrop')?.classList.add('open');
  });
}

function closeCart() {
  U.qs('#drawer-root .drawer')?.classList.remove('open');
  U.qs('#drawer-root .drawer-backdrop')?.classList.remove('open');
}

/* ------------------------------------------------------------------ *
 * Ödəniş (checkout)
 * ------------------------------------------------------------------ */
function checkoutModal() {
  const user = U.getUser();
  const subtotal = U.cart.subtotal();
  const c = U.cart.get();

  const m = U.modal({
    title: U.t('cart.checkout'),
    body: h`
      <div class="card card-pad mb-2" style="background:var(--brand-soft);border-color:#bfeaf5">
        <div class="row-between"><b>${c.vendorName}</b><span class="badge badge-brand">${U.cart.count()} ${U.t('common.items')}</span></div>
        <p class="small mt-1">${U.t('checkout.pickupNote')}</p>
      </div>
      <div class="form-grid">
        <div class="field">
          <label>${U.t('checkout.name')}</label>
          <input class="input" name="name" value="${user?.name ?? ''}" placeholder="${U.t('checkout.namePlaceholder')}">
        </div>
        <div class="field">
          <label>${U.t('common.phone')}</label>
          <input class="input" name="phone" value="${user?.phone ?? ''}" placeholder="${U.t('checkout.phonePlaceholder')}">
        </div>
      </div>
      <div class="field mt-2">
        <label>${U.t('checkout.paymentMethod')}</label>
        <select class="select" name="payment">
          <option value="cash">${U.t('payment.cash')}</option>
          <option value="card">${U.t('payment.card')}</option>
          <option value="online">${U.t('customer.onlinePaymentOption')}</option>
        </select>
        <span class="hint">${U.t('checkout.paymentHint')}</span>
      </div>
      <div class="field mt-2">
        <label>${U.t('checkout.coupon')}</label>
        <div class="row">
          <input class="input" name="coupon" placeholder="GOTUR10" style="text-transform:uppercase">
          <button class="btn btn-outline" data-coupon-apply>${U.t('actions.apply')}</button>
        </div>
        <span class="hint" data-coupon-hint>${U.t('checkout.couponHint')}</span>
      </div>
      <div class="field mt-2">
        <label>${U.t('checkout.note')}</label>
        <textarea class="textarea" name="note" placeholder="${U.t('checkout.notePlaceholder')}"></textarea>
      </div>
      <div class="totals mt-3" data-totals>
        <div class="row-between"><span class="muted">${U.t('common.subtotal')}</span><span data-line-subtotal>${U.azn(subtotal)}</span></div>
        <div class="row-between hidden" data-line-discount><span class="muted">${U.t('common.discount')} <span data-discount-code></span></span>
          <span style="color:#0b7a45" data-discount-value>—</span></div>
        <div class="row-between total"><span>${U.t('common.total')}</span><span data-line-total>${U.azn(subtotal)}</span></div>
      </div>`,
    footer: `<button class="btn btn-outline" data-close>${U.t('actions.cancel')}</button>
             <button class="btn btn-primary btn-lg" data-submit>${U.t('checkout.submit')}</button>`,
  });

  // Kupon: serverdə yoxlanılır, endirim dərhal göstərilir
  let appliedCoupon = null;
  const hint = U.qs('[data-coupon-hint]', m.root);
  const discountRow = U.qs('[data-line-discount]', m.root);
  const totalEl = U.qs('[data-line-total]', m.root);

  const refreshTotals = () => {
    const discount = appliedCoupon?.discount ?? 0;
    discountRow.classList.toggle('hidden', discount <= 0);
    U.qs('[data-discount-code]', m.root).textContent = appliedCoupon ? `(${appliedCoupon.code})` : '';
    U.qs('[data-discount-value]', m.root).textContent = discount > 0 ? `−${U.azn(discount)}` : '—';
    totalEl.textContent = U.azn(Math.max(0, subtotal - discount));
  };

  m.root.querySelector('[data-coupon-apply]').addEventListener('click', async (e) => {
    const code = m.root.querySelector('[name="coupon"]').value.trim().toUpperCase();
    if (!code) {
      appliedCoupon = null;
      hint.textContent = U.t('checkout.couponHint');
      hint.style.color = '';
      refreshTotals();
      return;
    }
    e.target.disabled = true;
    try {
      const res = await U.api('/api/coupons/validate', {
        method: 'POST',
        body: { code, vendorId: c.vendorId, subtotal, phone: U.qs('[name="phone"]', m.root).value.trim() },
      });
      if (!res.valid) throw new Error(res.error || U.t('customer.couponNotApplicable'));
      appliedCoupon = res;
      hint.textContent = U.t('checkout.couponApplied', { description: `✅ ${res.description || U.t('customer.couponAppliedCode', { code: res.code })}`, amount: U.azn(res.discount) });
      hint.style.color = '#0b7a45';
      U.toast(U.t('checkout.couponAppliedShort', { amount: U.azn(res.discount) }), 'ok');
      refreshTotals();
    } catch (err) {
      appliedCoupon = null;
      hint.textContent = `❌ ${err.message}`;
      hint.style.color = '#a5181c';
      refreshTotals();
    } finally {
      e.target.disabled = false;
    }
  });

  m.root.querySelector('[data-submit]').addEventListener('click', async (e) => {
    const btn = e.target;
    const val = (name) => m.root.querySelector(`[name="${name}"]`)?.value.trim() ?? '';
    const payload = {
      ...U.cart.payload(),
      name: val('name'),
      phone: val('phone'),
      payment: val('payment') || 'cash',
      note: val('note'),
      coupon: appliedCoupon?.code ?? null,
    };
    if (!payload.name) return U.toast(U.t('checkout.nameRequired'), 'err');
    btn.disabled = true;
    btn.textContent = U.t('common.sending');
    try {
      const data = await U.api('/api/orders', { method: 'POST', body: payload });
      U.cart.clear();
      m.close();
      U.toast(U.t('checkout.accepted', { code: data.order.pickupCode }), 'ok', 6000);
      if (data.payment?.redirectUrl) {
        location.href = data.payment.redirectUrl;
      } else {
        location.hash = `#/sifaris/${data.order.code}`;
      }
    } catch (err) {
      U.toast(err.message, 'err', 5000);
      btn.disabled = false;
      btn.textContent = U.t('checkout.submit');
    }
  });
}

/* ------------------------------------------------------------------ *
 * Sifarişlərim
 * ------------------------------------------------------------------ */
async function renderMyOrders() {
  const user = U.getUser();
  if (!user) {
    app.innerHTML = h`<div class="wrap"><div class="empty">
      <div class="big">🔐</div><h3>${U.t('orders.loginRequired')}</h3>
      <p class="muted mt-1">${U.t('orders.loginHint')}</p>
      <a class="btn btn-primary mt-3" href="#/giris">${U.t('nav.login')} / ${U.t('auth.register')}</a>
      <div class="mt-2"><a class="small muted" href="#/">${U.t('customer.trackByCodeLink')}</a></div>
    </div></div>`;
    return;
  }

  app.innerHTML = h`<div id="orders-page"><div class="wrap"><div class="section-head"><h2>📦 ${U.t('nav.myOrders')}</h2></div>
    <div id="orders-area"><div class="skeleton" style="height:120px"></div></div>
    <div class="card card-pad mt-3">
      <h3>${U.t('orders.trackByCode')}</h3>
      <div class="row mt-2">
        <input class="input" placeholder="${U.t('orders.trackPlaceholder')}" data-act="code">
        <button class="btn btn-dark" data-act="code-go">${U.t('actions.track')}</button>
      </div>
    </div></div></div>`;

  const page = U.qs('#orders-page');
  U.on(page, 'click', '[data-act="code-go"]', () => {
    const code = U.qs('[data-act="code"]', page).value.trim().toUpperCase();
    if (code) location.hash = `#/sifaris/${encodeURIComponent(code)}`;
  });

  try {
    const { orders } = await U.api('/api/orders');
    const area = U.qs('#orders-area');
    if (!orders.length) {
      area.innerHTML = h`<div class="card"><div class="empty"><div class="big">🧺</div>
        <h3>${U.t('orders.empty')}</h3><p class="muted mt-1">${U.t('orders.emptyHint')}</p>
        <a class="btn btn-primary mt-3" href="#/">${U.t('orders.browseStores')}</a></div></div>`;
      return;
    }
    area.innerHTML = h`<div class="col">${raw(orders.map(orderListRow).join(''))}</div>`;
  } catch (err) {
    U.qs('#orders-area').innerHTML = h`<div class="card card-pad">${err.message}</div>`;
  }
}

function orderListRow(o) {
  return h`
    <a class="card card-pad row-between" href="#/sifaris/${U.esc(o.code)}" style="gap:16px">
      <div class="grow">
        <div class="row" style="gap:10px">
          <b>${o.vendorName}</b>
          ${U.statusBadge(o.status)}
        </div>
        <p class="small muted mt-1">${o.code} · ${U.dateTime(o.createdAt)} · ${o.itemCount ?? ''} ${U.t('common.items')} · ${U.esc(o.vendorAddress)}</p>
      </div>
      <div class="right">
        <b style="font-size:17px">${U.azn(o.total)}</b>
        <div class="tiny muted">${U.t('orders.pickupCode')} <b>${U.esc(o.pickupCode)}</b></div>
      </div>
    </a>`;
}

/* ------------------------------------------------------------------ *
 * Sifariş izləmə
 * ------------------------------------------------------------------ */
const FLOW = [
  { key: 'pending', title: U.t('track.step1Title'), text: U.t('track.step1Text') },
  { key: 'accepted', title: U.t('track.step2Title'), text: U.t('track.step2Text') },
  { key: 'preparing', title: U.t('status.preparing'), text: U.t('track.step3Text') },
  { key: 'ready', title: U.t('track.step4Title'), text: U.t('track.step4Text') },
  { key: 'picked_up', title: U.t('status.picked_up'), text: U.t('track.step5Text') },
];

async function renderTrack(code) {
  app.innerHTML = h`<div class="wrap" style="padding-top:30px">
    <a class="small muted" href="#/sifarislerim">← ${U.t('nav.myOrders')}</a>
    <div class="skeleton mt-2" style="height:200px"></div></div>`;

  const paint = async () => {
    let order;
    try {
      ({ order } = await U.api(`/api/orders/${encodeURIComponent(code)}`));
    } catch (err) {
      app.innerHTML = h`<div class="wrap"><div class="empty"><div class="big">🔎</div>
        <h3>${U.t('track.notFound')}</h3><p class="muted mt-1">${err.message}</p>
        <a class="btn btn-primary mt-3" href="#/">${U.t('nav.mainPage')}</a></div></div>`;
      return;
    }

    const stepIndex = FLOW.findIndex((s) => s.key === order.status);
    const cancelled = order.status === 'cancelled';
    const active = ['pending', 'accepted', 'preparing'].includes(order.status);
    const pendingPayment = (order.payments ?? []).find((p) => p.status === 'requires_action' && p.token);

    app.innerHTML = h`
      <div id="track-page"><div class="wrap" style="padding-top:26px">
        <a class="small muted" href="#/sifarislerim">← ${U.t('nav.myOrders')}</a>

        <div class="row-between mt-2 wrap-row">
          <div>
            <h1>${order.vendorName}</h1>
            <p class="muted">${U.t('orders.orderCode')} <b>${U.esc(order.code)}</b> · ${U.dateTime(order.createdAt)}</p>
          </div>
          ${U.statusBadge(order.status)}
        </div>

        <div class="menu-grid mt-3">
          <div class="col" style="gap:16px">
            <div class="card card-pad">
              <h3>${U.t('common.status')}</h3>
              ${cancelled
                ? raw(`<p class="mt-2"><span class="status status-cancelled">${U.t('status.cancelled')}</span></p>
                       <p class="small muted mt-1">${U.t('track.cancelledText')}</p>`)
                : raw(`<div class="timeline mt-2">
                    ${FLOW.map((s, i) => `
                      <div class="tl-step ${i < stepIndex ? 'done' : i === stepIndex ? 'current' : ''}">
                        <div class="dot-col">
                          <div class="dot">${i < stepIndex ? '✓' : i + 1}</div>
                          ${i < FLOW.length - 1 ? '<div class="line"></div>' : ''}
                        </div>
                        <div class="tl-body">
                          <b>${U.esc(s.title)}</b>
                          <span class="small muted">${U.esc(s.text)}</span>
                        </div>
                      </div>`).join('')}
                  </div>`)}
            </div>

            <div class="card card-pad">
              <h3>${U.t('customer.orderContents')}</h3>
              <div class="mt-2">
                ${raw(order.items.map((i) => h`
                  <div class="row-between" style="padding:8px 0;border-bottom:1px solid var(--line)">
                    <span>${i.qty} × ${i.name}</span>
                    <b>${U.azn(i.lineTotal)}</b>
                  </div>`).join(''))}
              </div>
              <div class="totals mt-2">
                ${order.discount > 0
    ? raw(`<div class="row-between"><span class="muted small">${U.t('common.subtotal')}</span><span class="small">${U.azn(order.subtotal)}</span></div>
                     <div class="row-between"><span class="muted small">${U.t('common.discount')} ${order.couponCode ? `(${U.esc(order.couponCode)})` : ''}</span>
                       <span class="small" style="color:#0b7a45">−${U.azn(order.discount)}</span></div>`)
    : ''}
                <div class="row-between total"><span>${U.t('common.total')}</span><span>${U.azn(order.total)}</span></div>
                <div class="row-between"><span class="muted small">${U.t('common.payment')}</span><span class="small">${U.paymentLabel(order.payment)}</span></div>
              </div>
              ${order.note ? raw(`<p class="small muted mt-2">📝 ${U.esc(order.note)}</p>`) : ''}
            </div>

            ${order.review
    ? raw(reviewCardHtml(order.review))
    : order.status === 'picked_up'
      ? raw(`
                  <div class="card card-pad" id="review-form">
                    <h3>${U.t('review.title')}</h3>
                    <p class="small muted mt-1">${U.t('review.hint')}</p>
                    <div class="star-picker mt-2" data-stars>
                      ${[1, 2, 3, 4, 5].map((n) => `<button data-star="${n}" aria-label="${n} ${U.t('common.star')}">★</button>`).join('')}
                    </div>
                    <textarea class="textarea mt-2" data-review-comment placeholder="${U.t('review.commentPlaceholder')}"></textarea>
                    <button class="btn btn-primary btn-block mt-2" data-review-submit>${U.t('review.submit')}</button>
                  </div>`)
      : order.status === 'cancelled'
        ? ''
        : raw(`<div class="card card-pad small muted" id="review-hint">
                 ${U.t('review.afterPickup')}
               </div>`)}
          </div>

          <aside class="col" style="gap:16px">
            <div class="pickup-box">
              <p class="small" style="color:#a9cbd9">${U.t('track.pickupCodeLabel')}</p>
              <div class="code">${U.esc(order.pickupCode)}</div>
              <p class="small mt-1" style="color:#a9cbd9">${U.t('track.pickupCodeHint')}</p>
            </div>

            <div class="card card-pad">
              <div class="row-between">
                <h3>${U.t('common.payment')}</h3>
                ${U.paymentBadge(order.paymentStatus)}
              </div>
              <p class="small muted mt-1">${U.paymentLabel(order.payment)}
                · ${U.azn(order.total)}</p>
              ${pendingPayment
                ? raw(`<a class="btn btn-primary btn-block mt-2"
                     href="/odenis.html?token=${encodeURIComponent(pendingPayment.token)}">💳 ${U.t('pay.title')}</a>`)
                : ''}
              ${order.paymentStatus === 'unpaid' && !pendingPayment
                ? raw(`<p class="small muted mt-2">${U.t('customer.payAtCounter')}</p>`)
                : ''}
              ${order.paymentStatus === 'refunded'
                ? raw(`<p class="small mt-2">${U.t('customer.refundedAmount')}</p>`)
                : ''}
              ${order.paymentStatus === 'paid' && order.paidAt
                ? raw(`<p class="tiny muted mt-2">${U.t('paymentStatus.paid')}: ${U.dateTime(order.paidAt)}</p>`)
                : ''}
            </div>

            <div class="card card-pad">
              <h3>${U.t('track.whereToPickup')}</h3>
              <p class="mt-1">${U.esc(order.vendorAddress)}</p>
              ${order.vendorPhone ? raw(`<p class="mt-1">☎ <a href="tel:${U.esc(order.vendorPhone)}">${U.esc(order.vendorPhone)}</a></p>`) : ''}
              <a class="btn btn-outline btn-block mt-2" target="_blank"
                 href="https://maps.google.com/?q=${encodeURIComponent(order.vendorAddress)}">${U.t('track.showOnMap')}</a>
              <p class="tiny muted mt-2">${U.t('common.delivery')} ${U.t('customer.selfPickupNote')}</p>
            </div>

            ${active && order.status === 'pending'
              ? raw(`<button class="btn btn-danger btn-block" data-act="cancel">${U.t('track.cancelOrder')}</button>`)
              : active
                ? raw(`<div class="card card-pad small muted">${U.t('track.alreadyPreparing')}</div>`)
                : ''}

            <div class="card card-pad">
              <h3>${U.t('track.history')}</h3>
              <div class="mt-1">
                ${raw(order.events.map((e) => h`
                  <div class="row-between small" style="padding:5px 0">
                    <span>${U.statusLabel(e.status)}${e.note ? ` — ${e.note}` : ''}</span>
                    <span class="muted">${U.timeOnly(e.at)}</span>
                  </div>`).join(''))}
              </div>
            </div>
          </aside>
        </div>
      </div></div>`;

    const page = U.qs('#track-page');
    let rating = 0;

    // Ulduz seçimi
    U.on(page, 'click', '[data-star]', (e, el) => {
      rating = Number(el.dataset.star);
      U.qsa('[data-star]', page).forEach((btn) => btn.classList.toggle('on', Number(btn.dataset.star) <= rating));
    });

    U.on(page, 'click', '[data-review-submit]', async (e, el) => {
      if (!rating) return U.toast(U.t('review.selectStars'), 'err');
      const comment = U.qs('[data-review-comment]', page)?.value.trim() ?? '';
      el.disabled = true;
      el.textContent = U.t('common.sending');
      try {
        await U.api(`/api/orders/${order.id}/review`, {
          method: 'POST',
          body: { rating, comment, code: order.code },
        });
        U.toast(U.t('review.thanks'), 'ok', 5000);
        await paint();
      } catch (err) {
        U.toast(err.message, 'err');
        el.disabled = false;
        el.textContent = U.t('review.submit');
      }
    });

    U.on(page, 'click', '[data-act="cancel"]', async () => {
      const yes = await U.confirmDialog({
        title: U.t('track.cancelTitle'),
        text: U.t('track.cancelText'),
        okText: U.t('v.cancelOk'), danger: true,
      });
      if (!yes) return;
      try {
        await U.api(`/api/orders/${order.id}/cancel`, { method: 'POST', body: { code: order.code } });
        U.toast(U.t('track.cancelledToast'), 'warn');
        paint();
      } catch (err) { U.toast(err.message, 'err'); }
    });

    if (active) state.trackStop = U.poll(paint, 45000); // SSE üçün ehtiyat

    // Canlı status axını: müştəri sifarişinin vəziyyətini dərhal görür
    state.trackLive = U.subscribeEvents({ orders: order.code }, {
      onStatusChange: async (payload) => {
        if (payload.code !== order.code) return;
        const label = U.statusLabel(payload.status);
        U.toast(`${order.vendorName}: ${label}`, payload.status === 'ready' ? 'ok' : '', 4500);
        if (payload.status === 'ready') {
          U.notify(U.t('track.readyNotifyTitle'), `${U.t('orders.pickupCode')} ${payload.pickupCode ?? order.pickupCode} · ${order.vendorName}`, {
            tag: `ready-${order.code}`,
            url: `/#/sifaris/${order.code}`,
            requireInteraction: true,
          });
        }
        if (payload.status === 'cancelled') U.notify(U.t('track.cancelledToast'), order.code, { tag: `cancelled-${order.code}` });
        await paint();
      },
      onPayment: async (payload) => {
        if (payload.code !== order.code) return;
        if (payload.paymentStatus === 'paid') U.toast(`${U.t('pay.confirmed')} ✅`, 'ok');
        if (payload.paymentStatus === 'refunded') U.toast(U.t('status.refunded'), 'warn');
        await paint();
      },
    });
  };

  await paint();
}

/** Sifariş izləmədə göstərilən rəy kartı */
function reviewCardHtml(review) {
  return `
    <div class="card card-pad">
      <div class="row-between">
        <h3>${U.t('review.yourReview')}</h3>
        <span class="review-badge">✔ ${U.t('review.reviewed')}</span>
      </div>
      <div class="row mt-2" style="gap:8px">
        ${U.starsHtml(review.rating, 18)}
        <span class="small muted">${U.dateTime(review.createdAt)}</span>
      </div>
      ${review.comment ? `<p class="small mt-2">${U.esc(review.comment)}</p>` : ''}
      ${review.reply
    ? `<div class="card card-pad mt-2" style="background:var(--brand-soft);border:none">
             <b class="small">${U.t('review.storeReply')}</b>
             <p class="small mt-1">${U.esc(review.reply)}</p>
           </div>`
    : ''}
    </div>`;
}

/* ------------------------------------------------------------------ *
 * Giriş / Qeydiyyat
 * ------------------------------------------------------------------ */
function renderAuth(mode = 'login') {
  app.innerHTML = h`
    <div id="auth-page"><div class="wrap" style="max-width:560px;padding-top:40px">
      <div class="card card-pad">
        <div class="tabs mb-3">
          <button class="${mode === 'login' ? 'active' : ''}" data-tab="login">${U.t('auth.login')}</button>
          <button class="${mode === 'register' ? 'active' : ''}" data-tab="register">${U.t('auth.register')}</button>
        </div>
        <div id="auth-form"></div>
        <div class="card card-pad mt-3" style="background:var(--surface-2);border:none">
          <b class="small">${U.t('auth.demoAccounts')}</b>
          <p class="small muted mt-1">${U.t('auth.customer')}: <b>0501234567</b> / customer123<br>
          ${U.t('a.roleVendor')}: <b>0501110001</b> / vendor123<br>
          ${U.t('a.roleAdmin')}: <b>0500000000</b> / admin123</p>
        </div>
      </div>
    </div></div>`;
  paintAuthForm(mode);
  U.on(U.qs('#auth-page'), 'click', '[data-tab]', (e, el) => {
    paintAuthForm(el.dataset.tab);
    U.qsa('[data-tab]').forEach((b) => b.classList.toggle('active', b === el));
  });
}

function paintAuthForm(mode) {
  const host = U.qs('#auth-form');
  if (mode === 'login') {
    host.innerHTML = h`
      <div class="col">
        <div class="field"><label>${U.t('common.phone')}</label><input class="input" name="phone" placeholder="${U.t('checkout.phonePlaceholder')}"></div>
        <div class="field"><label>${U.t('auth.password')}</label><input class="input" type="password" name="password" placeholder="••••••"></div>
        <button class="btn btn-primary btn-lg btn-block" data-act="do-login">${U.t('nav.login')}</button>
        <p class="small muted center">${U.t('auth.loginNote')}</p>
      </div>`;
    U.qs('[data-act="do-login"]', host).addEventListener('click', async (e) => {
      const val = (n) => host.querySelector(`[name="${n}"]`).value.trim();
      e.target.disabled = true;
      try {
        const data = await U.login(val('phone'), val('password'));
        state.user = data.user;
        renderHeader();
        U.toast(U.t('auth.welcome', { name: data.user.name }), 'ok');
        location.hash = data.user.role === 'vendor' ? '#/sifarislerim' : '#/';
        if (data.user.role === 'vendor') location.href = '/satis.html';
      } catch (err) {
        U.toast(err.message, 'err');
        e.target.disabled = false;
      }
    });
  } else {
    host.innerHTML = h`
      <div class="col">
        <div class="row" style="gap:8px">
          <button class="chip active" data-role="customer">🙋 ${U.t('auth.customer')}</button>
          <button class="chip" data-role="vendor">🏪 ${U.t('auth.vendor')}</button>
        </div>
        <div class="field"><label>${U.t('checkout.name')}</label><input class="input" name="name" placeholder="${U.t('checkout.namePlaceholder')}"></div>
        <div class="field"><label>${U.t('common.phone')}</label><input class="input" name="phone" placeholder="${U.t('checkout.phonePlaceholder')}"></div>
        <div class="field"><label>${U.t('auth.passwordHint')}</label><input class="input" type="password" name="password"></div>
        <div class="vendor-only hidden col" data-vendor-fields>
          <div class="field"><label>${U.t('auth.vendorName')}</label><input class="input" name="vendorName" placeholder="${U.t('customer.vendorNamePlaceholder')}"></div>
          <div class="field"><label>${U.t('auth.vendorKind')}</label>
            <select class="select" name="vendorKind">
              <option value="restaurant">${U.t('auth.restaurantKind')}</option>
              <option value="market">${U.t('auth.marketKind')}</option>
            </select>
          </div>
          <div class="field"><label>${U.t('common.address')}</label><input class="input" name="address" placeholder="${U.t('customer.addressPlaceholder')}"></div>
        </div>
        <button class="btn btn-primary btn-lg btn-block" data-act="do-register">${U.t('auth.registerButton')}</button>
        <p class="small muted center">${U.t('auth.vendorNote')}</p>
      </div>`;

    let role = 'customer';
    U.qsa('[data-role]', host).forEach((btn) => btn.addEventListener('click', () => {
      role = btn.dataset.role;
      U.qsa('[data-role]', host).forEach((b) => b.classList.toggle('active', b === btn));
      U.qs('[data-vendor-fields]', host).classList.toggle('hidden', role !== 'vendor');
    }));

    U.qs('[data-act="do-register"]', host).addEventListener('click', async (e) => {
      const val = (n) => host.querySelector(`[name="${n}"]`)?.value.trim() ?? '';
      e.target.disabled = true;
      try {
        const data = await U.register({
          role, name: val('name'), phone: val('phone'), password: val('password'),
          vendorName: val('vendorName'), vendorKind: val('vendorKind'), address: val('address'),
        });
        state.user = data.user;
        renderHeader();
        U.toast(data.message ?? U.t('customer.registrationDone'), 'ok', 5000);
        if (role === 'vendor') location.href = '/satis.html';
        else location.hash = '#/';
      } catch (err) {
        U.toast(err.message, 'err');
        e.target.disabled = false;
      }
    });
  }
}

/* ------------------------------------------------------------------ *
 * Qlobal hadisələr
 * ------------------------------------------------------------------ */
document.addEventListener('click', async (e) => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const act = el.dataset.act;
  if (act === 'cart') { e.preventDefault(); openCart(); }
  if (act === 'close-cart') closeCart();
  if (act === 'clear-cart') { U.cart.clear(); U.toast(U.t('cart.cleared')); }
  if (act === 'checkout') checkoutModal();
  if (act === 'logout') {
    await U.logout();
    state.user = null;
    renderHeader();
    U.toast(U.t('auth.loggedOut'));
    location.hash = '#/';
  }
  if (act === 'search-open') {
    const input = U.qs('[data-act="search"]', app);
    if (input) { input.focus(); input.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
    else { location.hash = '#/'; }
  }
  if (act === 'notify') {
    const res = await U.requestNotificationPermission();
    U.toast(res === 'granted'
      ? U.t('notifications.grantedToast')
      : U.t('notifications.deniedToast'), res === 'granted' ? 'ok' : 'warn', 5000);
    renderHeader();
  }
  if (act === 'install') {
    const installed = await U.promptInstall();
    if (installed) U.toast(U.t('install.installed'), 'ok');
    else U.toast(U.t('install.dismissed'), 'warn', 2500);
  }
});
