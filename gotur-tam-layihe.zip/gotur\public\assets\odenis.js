/* ==================================================================
   Götür — ödəniş (checkout) səhifəsi
   • token ilə simulyasiya edilmiş kart ödənişi
   • Stripe hosted checkout-dan qayıdışın təsdiqi (?provider=stripe&session_id=…)
   ================================================================== */
import * as U from './common.js';
const { h, raw } = U;

const root = U.qs('#pay');
const params = new URLSearchParams(location.search);
const token = params.get('token');
const provider = params.get('provider');
const sessionId = params.get('session_id');
const cancelled = params.get('cancelled') === '1';

/* ------------------------------------------------------------------ *
 * Kart nömrəsinin formatlanması və Luhn yoxlaması (server də yoxlayır)
 * ------------------------------------------------------------------ */
const digits = (v) => String(v ?? '').replace(/\D/g, '');
function luhnValid(number) {
  const d = digits(number);
  if (d.length < 12 || d.length > 19) return false;
  let sum = 0;
  let double = false;
  for (let i = d.length - 1; i >= 0; i--) {
    let n = Number(d[i]);
    if (double) { n *= 2; if (n > 9) n -= 9; }
    sum += n;
    double = !double;
  }
  return sum % 10 === 0;
}
const formatCard = (v) => digits(v).slice(0, 19).replace(/(.{4})/g, '$1 ').trim();
const brandOf = (v) => {
  const d = digits(v);
  if (/^4/.test(d)) return 'VISA';
  if (/^5[1-5]/.test(d)) return 'MASTERCARD';
  if (/^9[78]/.test(d)) return 'MAESTRO';
  return 'KART';
};

(async function boot() {
  if (provider === 'stripe') return renderStripeReturn();
  if (!token) return renderError(U.t('pay.wrongLink'), U.t('pay.wrongLinkText'));
  await loadPayment();
})();

/* ------------------------------------------------------------------ *
 * Ödəniş məlumatının yüklənməsi
 * ------------------------------------------------------------------ */
async function loadPayment() {
  let data;
  try {
    data = await U.api(`/api/payments/${encodeURIComponent(token)}`);
  } catch (err) {
    return renderError(U.t('pay.notFound'), err.message);
  }

  const { payment, orderCode } = data;
  if (payment.status === 'paid') return renderSuccess(payment, orderCode, U.t('pay.alreadyPaid'));
  if (payment.status === 'refunded') return renderError(U.t('pay.refunded'), U.t('pay.refundedText'));
  if (payment.status === 'failed') {
    return renderError(U.t('paymentStatus.failed'), payment.error || U.t('errors.card_declined'));
  }
  if (cancelled) U.toast(U.t('pay.cancelled'), 'warn');
  renderForm(payment, orderCode);
}

/* ------------------------------------------------------------------ *
 * Kart forması
 * ------------------------------------------------------------------ */
function renderForm(payment, orderCode) {
  root.innerHTML = h`
    <div class="pay-shell">
      <a class="small muted" href="/#/sifaris/${U.esc(orderCode ?? '')}">${U.t('pay.backToOrder')}</a>
      <div class="card card-pad mt-2">
        <div class="row-between">
          <div>
            <h1 style="font-size:22px">${U.t('pay.title')}</h1>
            <p class="small muted">${payment.order?.vendorName ?? ''} · ${U.t('common.orders')} <b>${U.esc(orderCode ?? '')}</b></p>
          </div>
          <div class="right">
            <div class="tiny muted">${U.t('a.tableAmount')}</div>
            <b style="font-size:22px">${U.azn(payment.amount)}</b>
          </div>
        </div>
        <div class="pickup-box mt-3">
          <p class="small" style="color:#a9cbd9">${U.t('orders.orderCode').toUpperCase()} ${U.esc(payment.order?.code ?? orderCode ?? '')}</p>
          <div class="code">${payment.order?.pickupCode ?? '••••'}</div>
          <p class="small mt-1" style="color:#a9cbd9">${U.t('pay.paidBadge')}</p>
        </div>
      </div>

      <div class="card card-pad mt-3">
        <div class="card-visual mb-3">
          <div class="row-between">
            <div class="chip"></div>
            <b data-brand>${U.t('pay.cardBrandDefault')}</b>
          </div>
          <div class="num" data-visual-number>•••• •••• •••• ••••</div>
          <div class="row-between mt-3" style="font-size:12px">
            <span data-visual-holder>${U.t('pay.holderPlaceholder')}</span>
            <span data-visual-expiry>${U.t('pay.expiryPlaceholder')}</span>
          </div>
        </div>

        <div class="col">
          <div class="field">
            <label>${U.t('pay.cardNumber')}</label>
            <input class="input" name="number" inputmode="numeric" autocomplete="cc-number"
                   placeholder="4242 4242 4242 4242" maxlength="23">
            <span class="hint">${U.t('pay.cardTestHint')}</span>
          </div>
          <div class="pay-row">
            <div class="field">
              <label>${U.t('pay.expiry')}</label>
              <input class="input" name="expiry" placeholder="12/28" maxlength="5" autocomplete="cc-exp">
            </div>
            <div class="field">
              <label>CVV</label>
              <input class="input" name="cvc" placeholder="123" maxlength="4" inputmode="numeric" autocomplete="cc-csc">
            </div>
          </div>
          <div class="field">
            <label>${U.t('pay.holder')}</label>
            <input class="input" name="holder" placeholder="${U.t('pay.holderPlaceholder')}" autocomplete="cc-name">
          </div>
          <button class="btn btn-primary btn-lg btn-block" data-act="pay">🔒 ${U.t('pay.payAmount', { amount: U.azn(payment.amount) })}</button>
          <button class="btn btn-ghost btn-block" data-act="cancel">${U.t('pay.payLater')}</button>
          <div class="secure-note mt-2">
            <span>🛡️</span>
            <span>${U.t('pay.simulationNote')}</span>
          </div>
          ${payment.provider === 'stripe'
            ? raw(`<p class="small mt-2">${U.t('pay.stripeActive')}</p>`)
            : ''}
        </div>
      </div>
    </div>`;

  const numberEl = U.qs('[name="number"]', root);
  const visualNumber = U.qs('[data-visual-number]', root);
  const visualHolder = U.qs('[data-visual-holder]', root);
  const visualExpiry = U.qs('[data-visual-expiry]', root);
  const brandEl = U.qs('[data-brand]', root);

  numberEl.addEventListener('input', () => {
    const pos = numberEl.selectionStart;
    numberEl.value = formatCard(numberEl.value);
    numberEl.setSelectionRange(pos, pos);
    visualNumber.textContent = (numberEl.value || '•••• •••• •••• ••••').padEnd(19, '•');
    brandEl.textContent = brandOf(numberEl.value);
  });
  U.qs('[name="holder"]', root).addEventListener('input', (e) => {
    visualHolder.textContent = e.target.value.toUpperCase() || U.t('pay.holderPlaceholder');
  });
  U.qs('[name="expiry"]', root).addEventListener('input', (e) => {
    let v = digits(e.target.value).slice(0, 4);
    if (v.length > 2) v = `${v.slice(0, 2)}/${v.slice(2)}`;
    e.target.value = v;
    visualExpiry.textContent = v || U.t('pay.expiryPlaceholder');
  });

  U.on(root, 'click', '[data-act="pay"]', async (e, el) => {
    const val = (n) => U.qs(`[name="${n}"]`, root).value.trim();
    if (!luhnValid(val('number'))) return U.toast(U.t('pay.invalidCard'), 'err');
    if (!/^\d{2}\/\d{2}$/.test(val('expiry'))) return U.toast(U.t('pay.invalidExpiry'), 'err');
    if (!/^\d{3,4}$/.test(val('cvc'))) return U.toast(U.t('pay.invalidCvv'), 'err');

    el.disabled = true;
    el.innerHTML = `<span class="spinner"></span> ${U.t('pay.processing')}`;
    try {
      const res = await U.api(`/api/payments/${encodeURIComponent(token)}/pay`, {
        method: 'POST',
        body: { number: val('number'), expiry: val('expiry'), cvc: val('cvc'), holder: val('holder') },
      });
      renderSuccess(res.payment, orderCode, res.message);
    } catch (err) {
      U.toast(U.errText(err), 'err', 6000);
      el.disabled = false;
      el.textContent = `🔒 ${U.t('pay.payAmount', { amount: U.azn(payment.amount) })}`;
      if (err.status === 402) loadPayment();
    }
  });

  U.on(root, 'click', '[data-act="cancel"]', async () => {
    const yes = await U.confirmDialog({
      title: U.t('pay.laterTitle'),
      text: U.t('pay.laterText'),
      okText: U.t('pay.laterOk'),
    });
    if (!yes) return;
    try {
      await U.api(`/api/payments/${encodeURIComponent(token)}/decline`, {
        method: 'POST', body: { reason: U.t('pay.declinedReason') },
      });
    } catch { /* ödəniş artıq bağlanıbsa əhəmiyyətsizdir */ }
    U.toast(U.t('pay.laterToast'), 'warn');
    location.href = `/#/sifaris/${encodeURIComponent(orderCode ?? '')}`;
  });
}

/* ------------------------------------------------------------------ *
 * Uğur ekranı
 * ------------------------------------------------------------------ */
function renderSuccess(payment, orderCode, message) {
  root.innerHTML = h`
    <div class="pay-shell">
      <div class="card card-pad center">
        <div style="font-size:54px">✅</div>
        <h1 style="font-size:24px">${U.esc(message ?? U.t('pay.success'))}</h1>
        <p class="muted mt-1">${payment.order?.vendorName ?? ''} · ${U.azn(payment.amount)}</p>
        ${payment.cardLast4
    ? raw(`<p class="small muted mt-1">${U.t('pay.card', { last4: U.esc(payment.cardLast4) })}</p>`)
    : ''}
        <div class="card card-pad mt-3" style="background:var(--ok-soft);border:none">
          <b>${U.t('pay.orderNumber', { code: U.esc(orderCode ?? '') })}</b>
          <p class="small mt-1">${U.t('pay.successNote')}</p>
        </div>
        <a class="btn btn-primary btn-lg btn-block mt-3" href="/#/sifaris/${U.esc(orderCode ?? '')}">${U.t('pay.trackOrder')}</a>
        <a class="btn btn-ghost btn-block" href="/">${U.t('nav.mainPage')}</a>
      </div>
    </div>`;
}

/* ------------------------------------------------------------------ *
 * Stripe-dən qayıdış
 * ------------------------------------------------------------------ */
async function renderStripeReturn() {
  if (cancelled) U.toast(U.t('pay.stripeCancelled'), 'warn');
  if (!sessionId) {
    return renderError(U.t('pay.notFound'), cancelled
      ? U.t('pay.stripeCancelledText')
      : U.t('pay.stripeNoSession'));
  }
  root.innerHTML = h`<div class="pay-shell"><div class="card card-pad center">
    <div class="spinner" style="border-color:var(--line);border-top-color:var(--brand);width:26px;height:26px"></div>
    <p class="mt-2">${U.t('pay.checkingProvider')}</p></div></div>`;
  try {
    const res = await U.api(`/api/payments/stripe/confirm?session_id=${encodeURIComponent(sessionId)}`);
    if (res.payment.status === 'paid') {
      renderSuccess(res.payment, res.orderCode, U.t('pay.confirmedStripe'));
    } else {
      renderError(U.t('pay.notCompleted'), U.t('pay.notCompletedText'));
    }
  } catch (err) {
    renderError(U.t('pay.cannotVerify'), err.message);
  }
}

/* ------------------------------------------------------------------ *
 * Xəta ekranı
 * ------------------------------------------------------------------ */
function renderError(title, text) {
  root.innerHTML = h`
    <div class="pay-shell">
      <div class="card card-pad center">
        <div style="font-size:50px">⚠️</div>
        <h1 style="font-size:22px">${title}</h1>
        <p class="muted mt-1">${text}</p>
        <a class="btn btn-primary btn-block mt-3" href="/#/sifarislerim">${U.t('nav.myOrders')}</a>
        <a class="btn btn-ghost btn-block" href="/">${U.t('nav.mainPage')}</a>
      </div>
    </div>`;
}
