/* ==================================================================
   Götür — satıcı (restoran / market) paneli
   Bölmələr: #sifarisler | #menyu | #magaza | #statistika
   ================================================================== */
import * as U from './common.js';
const { h, raw } = U;

const main = U.qs('#panel-main');
const sidebar = U.qs('#sidebar');

const state = {
  vendor: null,
  stats: null,
  orders: [],
  products: [],
  coupons: [],
  reviewCount: null,
  counts: {},
  tab: 'active',
  section: 'orders',
  poller: null,
  live: null,
  liveState: 'connecting',
  knownPending: new Set(),
  lastPending: null,
  soundOn: true,
  ready: false,
};

/* ------------------------------------------------------------------ *
 * Başlanğıc
 * ------------------------------------------------------------------ */
(async function boot() {
  const { ok, session } = await U.requireRole('vendor');
  if (!ok) return renderLogin(session?.user);

  state.vendor = session.vendor;
  state.ready = true;
  renderSidebar();
  paintNetworkState();
  bindDelegates();
  U.initPanelMenu('#sidebar');
  const hint = document.getElementById('ptb-hint');
  if (hint) hint.textContent = session.vendor?.name ?? '';

  globalThis.addEventListener?.('online', paintNetworkState);
  globalThis.addEventListener?.('offline', paintNetworkState);

  window.addEventListener('hashchange', () => {
    const hash = location.hash.replace(/^#\/?/, '');
    if (SECTIONS.includes(hash)) {
      state.section = hash;
      renderSidebar();
      paint();
    }
  });
  const initial = location.hash.replace(/^#\/?/, '');
  if (SECTIONS.includes(initial)) state.section = initial;
  paint();
})();

const SECTIONS = ['orders', 'menu', 'settlement', 'store', 'stats', 'coupons', 'reviews'];

function renderLogin(user) {
  document.body.classList.add('no-menu'); // girişsiz vəziyyətdə üst zolaq gizlədilir
  sidebar.innerHTML = '';
  sidebar.style.display = 'none';
  main.innerHTML = h`
    <div style="max-width:520px;margin:40px auto">
      <div class="card card-pad">
        <h1 style="font-size:24px">🏪 ${U.t('nav.vendorPanel')}</h1>
        <p class="muted mt-1">${U.t('v.panelSubtitle')}</p>
        ${user ? raw(`<p class="badge badge-warn mt-2">${U.t('v.notVendorAccount', { role: user.role })}</p>`) : ''}
        <div class="col mt-3">
          <div class="field"><label>${U.t('common.phone')}</label><input class="input" name="phone" placeholder="050 111 00 01"></div>
          <div class="field"><label>${U.t('auth.password')}</label><input class="input" type="password" name="password" placeholder="••••••"></div>
          <button class="btn btn-primary btn-lg btn-block" data-act="login">${U.t('nav.login')}</button>
        </div>
        <div class="card card-pad mt-3" style="background:var(--surface-2);border:none">
          <b class="small">${U.t('v.demoVendorAccount')}</b>
          <p class="small muted mt-1">${U.t('v.demoVendor1')} <b>0501110001</b> / vendor123<br>
          ${U.t('v.demoVendor2')} <b>0501110009</b> / vendor123</p>
        </div>
        <p class="small muted mt-2">${U.t('v.noAccount')} <a href="/#/giris"><b>${U.t('v.registerAsBusiness')}</b></a></p>
        <p class="small muted"><a href="/">${U.t('v.backToApp')}</a></p>
      </div>
    </div>`;

  U.qs('[data-act="login"]', main).addEventListener('click', async (e) => {
    const val = (n) => main.querySelector(`[name="${n}"]`).value.trim();
    e.target.disabled = true;    try {
      const data = await U.login(val('phone'), val('password'));
      if (data.user.role !== 'vendor') {
        U.toast(U.t('v.notVendor'), 'err');
        e.target.disabled = false;
        return;
      }
      location.reload();
    } catch (err) {
      U.toast(err.message, 'err');
      e.target.disabled = false;
    }
  });
}

function renderSidebar() {
  const v = state.vendor;
  const counts = state.counts;
  const item = (key, icon, label, badge) => `
    <a href="#${key}" class="${state.section === key ? 'active' : ''}">
      <span>${icon} ${label}</span>
      ${badge ? `<span class="badge ${badge.cls}">${badge.text}</span>` : ''}
    </a>`;

  sidebar.innerHTML = h`
    <div class="brand"><span class="mark">🛍️</span> ${U.t('app.name')}<small style="font-weight:500;opacity:.7"> ${U.t('v.roleVendor')}</small></div>
    ${raw(item('orders', '📋', U.t('v.sidebarOrders'), counts.pending || counts.active
      ? { text: counts.pending || counts.active, cls: counts.pending ? 'badge-warn' : 'badge-info' } : null))}
    ${raw(item('menu', '🍽️', U.t('v.sidebarMenu'), null))}
    ${raw(item('coupons', '🎁', U.t('v.sidebarCoupons'), null))}
    ${raw(item('reviews', '⭐', U.t('v.sidebarReviews'), state.reviewCount ? { text: state.reviewCount, cls: 'badge-info' } : null))}
    ${raw(item('store', '🏪', U.t('v.sidebarStore'), null))}
    ${raw(item('settlement', '💰', U.t('v.sidebarSettlement'), null))}
    ${raw(item('stats', '📊', U.t('v.sidebarStats'), null))}
    <div class="spacer"></div>
    <label class="switch" style="padding:10px 12px;color:#cfdcea">
      <input type="checkbox" data-act="sound" ${state.soundOn ? 'checked' : ''}>
      <span class="track"></span><span class="small">${U.t('v.soundAlerts')}</span>
    </label>
    <button class="btn btn-sm btn-outline" data-act="notify" style="margin:4px">
      ${U.notificationPermission() === 'granted' ? `🔔 ${U.t('v.notificationsOn')}` : `🔕 ${U.t('v.notificationsOff')}`}
    </button>
    <button class="btn btn-sm btn-outline hidden" data-act="install" style="margin:0 4px">⬇ ${U.t('nav.installTitle')}</button>
    <div class="who">
      <b style="color:#fff">${v?.name ?? ''}</b><br>
      ${v?.approved ? `✔ ${U.t('v.approved')}` : `⏳ ${U.t('v.awaitingApproval')}`} · ${v?.open ? U.t('common.open') : U.t('common.closed')}<br>
      <span data-net-state class="tiny"></span>
      <a href="/" style="color:#7fd6ea">${U.t('nav.toCustomer')}</a>
    </div>
    <button class="btn btn-sm btn-outline" data-act="logout" style="margin:8px 4px">${U.t('nav.logout')}</button>`;

  U.qs('[data-act="sound"]', sidebar)?.addEventListener('change', (e) => {
    state.soundOn = e.target.checked;
  });
  U.qs('[data-act="notify"]', sidebar)?.addEventListener('click', async () => {
    if (U.notificationPermission() === 'granted') {
      U.toast(U.t('notifications.alreadyGranted'), 'ok');
      return;
    }
    const result = await U.requestNotificationPermission();
    U.toast(result === 'granted'
      ? U.t('v.notificationsGrantedToast')
      : U.t('notifications.deniedToast'), result === 'granted' ? 'ok' : 'warn');
    renderSidebar();
  });
  const installBtn = U.qs('[data-act="install"]', sidebar);
  U.onInstallAvailable((available) => installBtn?.classList.toggle('hidden', !available));
  installBtn?.addEventListener('click', async () => {
    const installed = await U.promptInstall();
    if (installed) U.toast(U.t('v.installedToast'), 'ok');
  });
  sidebar.querySelector('[data-act="logout"]')?.addEventListener('click', async () => {
    await U.logout();
    location.href = '/';
  });
}

/** Şəbəkə vəziyyətini yan menyuda göstərir */
function paintNetworkState() {
  const el = U.qs('[data-net-state]', sidebar);
  if (!el) return;
  const online = U.isOnline();
  el.textContent = online ? `● ${U.t('v.netOnline')}` : `● ${U.t('common.offline')}`;
  el.style.color = online ? '#7fd6ea' : '#ffb4b4';
}

/* ------------------------------------------------------------------ *
 * Bölmə keçidi
 * ------------------------------------------------------------------ */
async function paint() {
  state.poller?.stop();
  if (state.section !== 'orders') {
    state.live?.close();
    state.live = null;
  }
  if (state.section === 'orders') return paintOrders();
  if (state.section === 'menu') return paintMenu();
  if (state.section === 'coupons') return paintCoupons();
  if (state.section === 'settlement') return paintSettlement();
  if (state.section === 'reviews') return paintReviews();
  if (state.section === 'store') return paintStore();
  if (state.section === 'stats') return paintStats();
}

function approvalBanner() {
  const v = state.vendor;
  if (v.approved) return '';
  return h`<div class="card card-pad mb-3" style="border-color:#f7d08a;background:var(--warn-soft)">
    <b>${U.t('v.approvalBannerTitle')}</b>
    <p class="small mt-1">${U.t('v.approvalBannerText')}</p>
  </div>`;
}

function vendorHeader(extra = '') {
  const v = state.vendor;
  return h`
    <div class="panel-head">
      <div>
        <h1>${v.name}</h1>
        <p class="muted small mt-1">${v.kind === 'market' ? `🏪 ${U.t('auth.marketKind')}` : `🍽️ ${U.t('auth.restaurantKind')}`} · ${U.esc(v.address || U.t('v.noAddress'))}
        · <a href="/#/v/${U.esc(v.slug)}" target="_blank">${U.t('v.customerView')}</a></p>
      </div>
      <div class="row">
        ${extra ? raw(extra) : ''}
        <label class="switch" title="${U.t('v.toggleOpenTitle')}">
          <input type="checkbox" data-act="toggle-open" ${v.open ? 'checked' : ''}>
          <span class="track"></span>
          <span class="small bold">${v.open ? U.t('common.open') : U.t('common.closed')}</span>
        </label>
      </div>
    </div>`;
}

function bindOpenToggle() {
  U.qs('[data-act="toggle-open"]', main)?.addEventListener('change', async (e) => {
    const open = e.target.checked;
    try {
      const { vendor } = await U.api('/api/vendor/me', { method: 'PATCH', body: { open } });
      state.vendor = vendor;
      U.toast(open ? U.t('v.storeOpened') : U.t('v.storeClosed'), open ? 'ok' : 'warn');
      renderSidebar();
      paint();
    } catch (err) {
      U.toast(err.message, 'err');
      e.target.checked = !open;
    }
  });
}

/* ------------------------------------------------------------------ *
 * Sifarişlər
 * ------------------------------------------------------------------ */
const TABS = [
  { key: 'active', label: U.t('v.tabActive'), status: '' },
  { key: 'pending', label: U.t('v.tabNew'), status: 'pending' },
  { key: 'kitchen', label: U.t('status.preparing'), status: 'accepted,preparing' },
  { key: 'ready', label: U.t('v.tabReady'), status: 'ready' },
  { key: 'today', label: U.t('v.tabToday'), status: 'all', today: true },
];

async function paintOrders() {
  main.innerHTML = h`
    ${raw(approvalBanner())}
    ${raw(vendorHeader(`<span data-live-badge class="badge">${liveBadgeHtml(state.liveState)}</span>`))}
    <div class="tabs mb-3">
      ${raw(TABS.map((t) => `<button data-tab="${t.key}" class="${state.tab === t.key ? 'active' : ''}">
        ${U.esc(t.label)}<span class="n" data-tab-count="${t.key}"></span></button>`).join(''))}
    </div>
    <div id="orders-list"><div class="skeleton" style="height:180px"></div></div>`;

  bindOpenToggle();
  await loadOrders();
  connectLive();
  // SSE qopsa belə məlumat təzə qalsın: yavaş ehtiyat sorğu
  state.poller = U.poll(async () => {
    if (state.section !== 'orders') return;
    await loadOrders({ silent: true });
  }, 90000);
}

/* ------------------------------------------------------------------ *
 * Canlı axın (Server-Sent Events)
 * ------------------------------------------------------------------ */
function liveBadgeHtml(state_) {
  if (state_ === 'online') return `<span style="color:#0b7a45">● ${U.t('v.live')}</span>`;
  if (state_ === 'reconnecting') return `<span style="color:#8a5200">◌ ${U.t('v.reconnecting')}</span>`;
  if (state_ === 'failed') return `<span style="color:#a5181c">● ${U.t('v.disconnected')}</span>`;
  if (state_ === 'unsupported') return `◌ ${U.t('v.notSupported')}`;
  return `◌ ${U.t('v.connecting')}`;
}

function setLiveState(next) {
  state.liveState = next;
  const badge = U.qs('[data-live-badge]', main);
  if (badge) badge.innerHTML = liveBadgeHtml(next);
}

function connectLive() {
  state.live?.close();
  state.live = U.subscribeEvents({ scope: 'vendor' }, {
    onState: setLiveState,
    onCreated: async (payload) => {
      const order = payload.order ?? {};
      U.toast(U.t('notifications.newOrderTitle') + `: ${order.code} · ${order.customerName}`, 'warn', 6000);
      if (state.soundOn) beep();
      U.notify(U.t('notifications.newOrderTitle'), `${order.code} · ${U.azn(order.total)} · ${order.customerName}`, {
        tag: `order-${order.code}`,
        url: '/satis.html#orders',
      });
      await loadOrders({ silent: true });
    },
    onStatusChange: async (payload) => {
      if (payload.status === 'cancelled') {
        U.toast(U.t('v.orderCancelled', { code: payload.code }), 'warn', 5000);
      }
      await loadOrders({ silent: true });
    },
    onPayment: async (payload) => {
      const label = U.paymentStatusLabel(payload.paymentStatus);
      U.toast(`💳 ${payload.code}: ${label}`, payload.paymentStatus === 'paid' ? 'ok' : 'warn', 4500);
      await loadOrders({ silent: true });
    },
  });
}

async function loadOrders({ silent = false } = {}) {
  const tab = TABS.find((t) => t.key === state.tab) ?? TABS[0];
  const params = new URLSearchParams();
  if (tab.status) params.set('status', tab.status);
  if (tab.today) params.set('today', '1');
  try {
    const data = await U.api(`/api/vendor/orders?${params}`);
    state.orders = data.orders;
    state.counts = data.counts;

    const pendingIds = new Set(data.orders.filter((o) => o.status === 'pending').map((o) => o.id));
    const fresh = [...pendingIds].filter((id) => !state.knownPending.has(id) && state.knownPending.size);
    if (fresh.length) {
      U.toast(U.t('v.newOrdersToast', { count: fresh.length }), 'warn', 5000);
      if (state.soundOn && state.liveState !== 'online') beep(); // canlı axın varsa təkrar səs çıxmasın
      document.title = `(${state.counts.pending}) ${U.t('status.pending')} — ${U.t('app.name')}`;
    }
    state.knownPending = pendingIds;
    if (!state.counts.pending) document.title = U.t('v.panelTitle');

    if (state.lastPending !== state.counts.pending) {
      state.lastPending = state.counts.pending;
      renderSidebar();
      paintNetworkState();
    }
    paintOrderTabs();
    paintOrdersList();
  } catch (err) {
    if (err.status === 401) return location.reload();
    if (!silent) U.toast(err.message, 'err');
  }
}

function paintOrderTabs() {
  U.qsa('[data-tab]', main).forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.tab === state.tab);
    const c = state.counts;
    const label = {
      active: c.active, pending: c.pending, kitchen: (c.accepted ?? 0) + (c.preparing ?? 0), ready: c.ready,
    }[btn.dataset.tab];
    const el = btn.querySelector('.n');
    if (el) el.textContent = label ? ` ${label}` : '';
  });
}

function paintOrdersList() {
  const host = U.qs('#orders-list');
  if (!state.orders.length) {
    host.innerHTML = h`<div class="card"><div class="empty"><div class="big">🧾</div>
      <h3>${U.t('v.noOrders')}</h3><p class="muted mt-1">${U.t('v.noOrdersHint')}</p></div></div>`;
    return;
  }
  host.innerHTML = h`<div class="col">${raw(state.orders.map(orderCard).join(''))}</div>`;
}

const NEXT_ACTION = {
  pending: [{ s: 'accepted', label: U.t('v.accept'), cls: 'btn-ok' }, { s: 'cancelled', label: U.t('v.cancelOk'), cls: 'btn-danger' }],
  accepted: [{ s: 'preparing', label: U.t('v.startPreparing'), cls: 'btn-dark' }, { s: 'cancelled', label: U.t('v.cancelOk'), cls: 'btn-danger' }],
  preparing: [{ s: 'ready', label: U.t('v.markReady'), cls: 'btn-primary' }],
  ready: [{ s: 'picked_up', label: U.t('v.handedOver'), cls: 'btn-ok' }],
};

function orderCard(o) {
  const actions = NEXT_ACTION[o.status] ?? [];
  const mins = Math.round((Date.now() - new Date(o.createdAt).getTime()) / 60000);
  const late = ['pending', 'accepted', 'preparing'].includes(o.status) && mins > 25;
  return h`
    <div class="card order-card ${o.status === 'pending' ? 'new-order' : ''}">
      <div class="code-cell">
        <div class="code">${U.esc(o.code)}</div>
        <div class="tiny muted">${U.timeAgo(o.createdAt)}</div>
        <div class="pickup mt-1" title="${U.t('v.pickupCodeTitle')}">${U.esc(o.pickupCode)}</div>
        ${late ? raw(`<div class="badge badge-warn mt-1">${U.t('v.late')}</div>`) : ''}
      </div>
      <div>
        <div class="row wrap-row" style="gap:10px">
          ${U.statusBadge(o.status)}
          ${U.paymentBadge(o.paymentStatus)}
          <b>${U.esc(o.customerName)}</b>
          <a class="small" href="tel:${U.esc(o.customerPhone)}">☎ ${U.esc(o.customerPhone)}</a>
          <span class="small muted">${U.paymentLabel(o.payment)}</span>
        </div>
        <ul>${raw((o.items ?? []).length ? o.items.map((i) => `<li>${i.qty} × ${U.esc(i.name)} — ${U.azn(i.lineTotal)}</li>`).join('')
          : `<li class="muted">${U.t('v.loadingItems')} (${o.itemCount ?? 0} ${U.t('common.items')})</li>`)}</ul>
        ${o.note ? raw(`<p class="small mt-1">📝 ${U.esc(o.note)}</p>`) : ''}
        <div class="row-between mt-2">
          <span class="small muted">${o.itemCount ?? ''} ${U.t('common.items')}
            ${o.couponCode ? `· 🎁 ${U.esc(o.couponCode)} (−${U.azn(o.discount)})` : ''}
            · ${U.esc(o.vendorAddress)}</span>
          <b style="font-size:17px">${U.azn(o.total)}</b>
        </div>
      </div>
      <div class="order-actions">
        ${raw(actions.map((a) => `<button class="btn btn-sm ${a.cls}" data-status="${a.s}" data-order="${o.id}">${a.label}</button>`).join(''))}
        ${o.paymentStatus === 'unpaid' && o.status !== 'cancelled'
          ? raw(`<button class="btn btn-sm btn-outline" data-collect="${o.id}"
               data-method="${o.payment === 'card' ? 'card' : 'cash'}"
               title="${U.t('v.collectTooltip')}">💵 ${U.t('v.collectPayment')}</button>`)
          : ''}
        <button class="btn btn-sm btn-outline" data-detail="${o.id}">${U.t('actions.details')}</button>
        <button class="btn btn-sm btn-ghost" data-print="${o.id}" title="${U.t('receipt.charWidth')}">🖨</button>
      </div>
    </div>`;
}

U.on(main, 'click', '[data-status]', async (e, el) => {
  const id = Number(el.dataset.order);
  const status = el.dataset.status;
  if (status === 'cancelled') {
    const yes = await U.confirmDialog({
      title: U.t('track.cancelTitle'), text: U.t('v.cancelText'),
      okText: U.t('v.cancelOk'), danger: true,
    });
    if (!yes) return;
  }
  el.disabled = true;
  try {
    await U.api(`/api/vendor/orders/${id}/status`, { method: 'POST', body: { status } });
    U.toast(U.t('v.statusUpdated', { status: U.statusLabel(status) }), 'ok', 2200);
    await loadOrders();
  } catch (err) {
    U.toast(err.message, 'err');
    el.disabled = false;
  }
});

U.on(main, 'click', '[data-print]', async (e, el) => {
  const id = Number(el.dataset.print);
  const order = state.orders.find((x) => x.id === id);
  if (!order) return;
  try {
    const { order: full } = await U.api(`/api/orders/${order.code}`);
    U.printReceipt(full, state.vendor);
    U.toast(U.t('receipt.reprint'), 'ok', 2200);
  } catch (err) {
    U.toast(U.errText(err), 'err');
  }
});

U.on(main, 'click', '[data-detail]', async (e, el) => {
  const id = Number(el.dataset.detail);
  try {
    const o = state.orders.find((x) => x.id === id);
    const { order } = await U.api(`/api/orders/${o.code}`);
    U.modal({
      title: `${order.code} · ${order.vendorName}`,
      body: h`
        <div class="row-between"><b>${order.customerName}</b>${U.statusBadge(order.status)}</div>
        <p class="small muted">☎ ${order.customerPhone} · ${U.paymentLabel(order.payment)}</p>
        <p class="mt-2">${U.t('orders.pickupCode')}: <b style="font-size:20px;letter-spacing:.1em">${order.pickupCode}</b></p>
        <div class="mt-2">
          ${raw(order.items.map((i) => h`<div class="row-between small" style="padding:6px 0;border-bottom:1px solid var(--line)">
            <span>${i.qty} × ${i.name}</span><b>${U.azn(i.lineTotal)}</b></div>`).join(''))}
        </div>
        <div class="row-between total mt-2"><b>${U.t('common.total')}</b><b>${U.azn(order.total)}</b></div>
        <div class="row-between small mt-1">
          <span class="muted">${U.t('v.setCommission')}</span><span>−${U.azn(order.commission)}</span>
        </div>
        <div class="row-between small">
          <span class="muted">${U.t('v.setPayout')}</span><b>${U.azn(order.vendorPayout)}</b>
        </div>
        ${order.note ? raw(`<p class="small muted mt-2">📝 ${U.esc(order.note)}</p>`) : ''}
        <h4 class="mt-3">${U.t('track.history')}</h4>
        ${raw(order.events.map((ev) => h`<div class="row-between small"><span>${U.statusLabel(ev.status)}</span>
          <span class="muted">${U.dateTime(ev.at)}</span></div>`).join(''))}`,
      footer: `<button class="btn btn-outline" data-close>${U.t('nav.close')}</button>`,
    });
  } catch (err) { U.toast(err.message, 'err'); }
});

/* ------------------------------------------------------------------ *
 * Menyu
 * ------------------------------------------------------------------ */
async function paintMenu() {
  main.innerHTML = h`
    ${raw(approvalBanner())}
    ${raw(vendorHeader(`<button class="btn btn-primary" data-act="new-product">${U.t('v.newProduct')}</button>`))}
    <div id="menu-area"><div class="skeleton" style="height:260px"></div></div>`;

  bindOpenToggle();
  U.qs('[data-act="new-product"]', main).addEventListener('click', () => productModal(null));
  await loadProducts();
}

async function loadProducts() {
  const { products } = await U.api('/api/vendor/products');
  state.products = products;
  paintMenuTable();
}

function paintMenuTable() {
  const host = U.qs('#menu-area');
  if (!state.products.length) {
    host.innerHTML = h`<div class="card"><div class="empty"><div class="big">🍽️</div>
      <h3>${U.t('vendorPage.menuEmptyShort')}</h3><p class="muted mt-1">${U.t('v.menuEmptyHint')}</p>
      <button class="btn btn-primary mt-3" data-act="new-product">${U.t('v.newProduct')}</button></div></div>`;
    U.qs('[data-act="new-product"]', host)?.addEventListener('click', () => productModal(null));
    return;
  }

  const sections = new Map();
  for (const p of state.products) {
    if (!sections.has(p.section)) sections.set(p.section, []);
    sections.get(p.section).push(p);
  }

  host.innerHTML = h`
    ${raw([...sections.entries()].map(([section, items]) => `
      <div class="card mb-3">
        <div class="card-pad row-between" style="border-bottom:1px solid var(--line)">
          <h3>${U.esc(section)}</h3>
          <span class="badge">${items.length} ${U.t('common.items')}</span>
        </div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th></th><th>${U.t('v.tableName')}</th><th>${U.t('v.tablePrice')}</th><th>${U.t('v.tableUnit')}</th><th>${U.t('v.tableStock')}</th><th>${U.t('v.tableActive')}</th><th></th></tr></thead>
            <tbody>
              ${items.map((p) => `
                <tr>
                  <td style="width:52px">${U.thumbHtml(p.image)}</td>
                  <td>
                    <b>${U.esc(p.name)}</b>
                    ${p.description ? `<div class="tiny muted">${U.esc(p.description)}</div>` : ''}
                  </td>
                  <td class="nowrap"><b>${U.azn(p.price)}</b></td>
                  <td class="muted">${U.esc(p.unit)}</td>
                  <td>${p.stock === null ? `<span class="muted">${U.t('v.unlimited')}</span>`
                    : p.stock > 0 ? `<b>${p.stock}</b>` : `<span class="badge badge-closed">${U.t('v.outOfStock')}</span>`}</td>
                  <td><label class="switch"><input type="checkbox" data-active="${p.id}" ${p.active ? 'checked' : ''}>
                    <span class="track"></span></label></td>
                  <td class="right nowrap">
                    <button class="btn btn-sm btn-outline" data-edit="${p.id}">${U.t('actions.edit')}</button>
                    <button class="btn btn-sm btn-danger" data-del="${p.id}">${U.t('actions.delete')}</button>
                  </td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>`).join(''))}`;
}

function productModal(product) {
  const isNew = !product;
  const sections = [...new Set(state.products.map((p) => p.section))];
  const m = U.modal({
    title: isNew ? U.t('v.newProductTitle') : `${U.t('actions.edit')}: ${product.name}`,
    body: h`
      <div class="form-grid">
        <div class="field" style="grid-column:1/-1">
          <label>${U.t('v.fieldName')}</label>
          <input class="input" name="name" value="${product?.name ?? ''}" placeholder="${U.t('v.productNamePlaceholder')}">
        </div>
        <div class="field">
          <label>${U.t('v.fieldPrice')}</label>
          <input class="input" name="price" type="number" step="0.01" min="0.01"
                 value="${product ? (product.price / 100).toFixed(2) : ''}" placeholder="9.50">
        </div>
        <div class="field">
          <label>${U.t('v.fieldUnit')}</label>
          <input class="input" name="unit" value="${product?.unit ?? U.t('v.unitDefault')}" placeholder="${U.t('v.unitPlaceholder')}">
        </div>
        <div class="field">
          <label>${U.t('v.fieldSection')}</label>
          <input class="input" name="section" list="section-list" value="${product?.section ?? sections[0] ?? U.t('v.sidebarMenu')}">
          <datalist id="section-list">${raw(sections.map((s) => `<option value="${U.esc(s)}"></option>`).join(''))}</datalist>
        </div>
        <div class="field">
          <label>${U.t('v.fieldImage')}</label>
          <input class="input" name="image" value="${product?.image ?? '🍽️'}" placeholder="🍔">
        </div>
        <div class="field">
          <label>${U.t('v.fieldStock')}</label>
          <input class="input" name="stock" type="number" min="0" value="${product?.stock ?? ''}" placeholder="${U.t('common.noMinOrder')}">
          <span class="hint">${U.t('v.fieldStockHint')}</span>
        </div>
        <div class="field">
          <label>${U.t('common.status')}</label>
          <label class="switch" style="padding-top:6px">
            <input type="checkbox" name="active" ${product?.active === false ? '' : 'checked'}>
            <span class="track"></span><span class="small">${U.t('v.fieldVisible')}</span>
          </label>
        </div>
        <div class="field" style="grid-column:1/-1">
          <label>${U.t('v.fieldDescription')}</label>
          <textarea class="textarea" name="description" placeholder="${U.t('v.fieldDescriptionPlaceholder')}">${product?.description ?? ''}</textarea>
        </div>
      </div>`,
    footer: `<button class="btn btn-outline" data-close>${U.t('actions.cancel')}</button>
             <button class="btn btn-primary" data-save>${isNew ? U.t('actions.add') : U.t('actions.save')}</button>`,
  });

  m.root.querySelector('[data-save]').addEventListener('click', async (e) => {
    const val = (n) => m.root.querySelector(`[name="${n}"]`)?.value.trim() ?? '';
    const payload = {
      name: val('name'),
      price: Number(val('price').replace(',', '.')),
      unit: val('unit') || U.t('v.unitDefault'),
      section: val('section') || U.t('v.sidebarMenu'),
      image: val('image') || '🍽️',
      description: val('description'),
      stock: val('stock') === '' ? null : Number(val('stock')),
      active: m.root.querySelector('[name="active"]').checked,
    };
    if (!payload.name) return U.toast(U.t('v.nameRequired'), 'err');
    if (!payload.price) return U.toast(U.t('v.priceRequired'), 'err');
    e.target.disabled = true;
    try {
      if (isNew) await U.api('/api/vendor/products', { method: 'POST', body: payload });
      else await U.api(`/api/vendor/products/${product.id}`, { method: 'PATCH', body: payload });
      m.close();
      U.toast(isNew ? U.t('v.productCreated') : U.t('v.productUpdated'), 'ok');
      await loadProducts();
    } catch (err) {
      U.toast(err.message, 'err');
      e.target.disabled = false;
    }
  });
}

/* ------------------------------------------------------------------ *
 * Kampaniyalar (kuponlar)
 * ------------------------------------------------------------------ */
async function paintCoupons() {
  main.innerHTML = h`
    ${raw(approvalBanner())}
    ${raw(vendorHeader(`<button class="btn btn-primary" data-act="new-coupon">${U.t('v.newCoupon')}</button>`))}
    <div id="coupons-area"><div class="skeleton" style="height:220px"></div></div>
    <div class="card card-pad mt-3" style="background:var(--surface-2);border:none">
      <b class="small">${U.t('vendorPage.howItWorks')}</b>
      <p class="small muted mt-1">${U.t('v.couponsHowText')}</p>
    </div>`;

  bindOpenToggle();
  U.qs('[data-act="new-coupon"]', main).addEventListener('click', () => couponModal(null));
  await loadCoupons();
}

async function loadCoupons() {
  const { coupons } = await U.api('/api/vendor/coupons');
  state.coupons = coupons;
  const host = U.qs('#coupons-area');
  if (!coupons.length) {
    host.innerHTML = h`<div class="card"><div class="empty"><div class="big">🎁</div>
      <h3>${U.t('v.couponsEmpty')}</h3>
      <p class="muted mt-1">${U.t('v.couponsEmptyHint')}</p>
      <button class="btn btn-primary mt-3" data-act="new-coupon-2">${U.t('v.newCoupon')}</button></div></div>`;
    U.qs('[data-act="new-coupon-2"]', host)?.addEventListener('click', () => couponModal(null));
    return;
  }

  host.innerHTML = h`<div class="card"><div class="table-wrap"><table class="table">
    <thead><tr><th>${U.t('v.tableCode')}</th><th>${U.t('common.discount')}</th><th>${U.t('v.tableConditions')}</th><th>${U.t('v.tableUsage')}</th><th>${U.t('receipt.date')}</th><th>${U.t('common.status')}</th><th></th></tr></thead>
    <tbody>${raw(coupons.map((c) => `<tr>
      <td><b style="letter-spacing:.06em">${U.esc(c.code)}</b>
        ${c.description ? `<div class="tiny muted">${U.esc(c.description)}</div>` : ''}</td>
      <td><b>${c.kind === 'percent' ? `${c.value}%` : U.azn(c.value)}</b>
        ${c.maxDiscount ? `<div class="tiny muted">${U.t('v.maxDiscountShort', { amount: U.azn(c.maxDiscount) })}</div>` : ''}</td>
      <td class="small muted">
        ${c.minOrder ? `min ${U.azn(c.minOrder)}<br>` : ''}
        ${c.perUserLimit ? `${U.t('v.perUserTimes', { count: c.perUserLimit })}<br>` : ''}
        ${c.usageLimit ? U.t('v.totalLimit', { count: c.usageLimit }) : U.t('v.unlimitedLimit')}</td>
      <td>${c.stats?.orders ?? 0} ${U.t('common.orders')}
        <div class="tiny muted">−${U.azn(c.stats?.discounted ?? 0)}</div></td>
      <td class="small muted nowrap">${c.expiresAt ? U.t('v.expiresAt', { date: U.dateTime(c.expiresAt) }) : U.t('v.noExpiry')}</td>
      <td>${c.active ? `<span class="badge badge-open">${U.t('v.active')}</span>` : `<span class="badge">${U.t('v.inactive')}</span>`}</td>
      <td class="right nowrap">
        <button class="btn btn-sm btn-outline" data-coupon-edit="${c.id}">${U.t('actions.edit')}</button>
        <button class="btn btn-sm btn-danger" data-coupon-del="${c.id}">${U.t('actions.delete')}</button>
      </td></tr>`).join(''))}</tbody>
  </table></div></div>`;
}

function couponModal(coupon) {
  const isNew = !coupon;
  const m = U.modal({
    title: isNew ? U.t('v.couponCreatedTitle') : `${U.t('actions.edit')}: ${coupon.code}`,
    body: h`
      <div class="form-grid">
        <div class="field"><label>${U.t('v.couponCode')}</label>
          <input class="input" name="code" value="${coupon?.code ?? ''}" placeholder="KABAB15"
                 style="text-transform:uppercase"></div>
        <div class="field"><label>${U.t('v.couponKind')}</label>
          <select class="select" name="kind">
            <option value="percent" ${coupon?.kind !== 'fixed' ? 'selected' : ''}>${U.t('v.couponKindPercent')}</option>
            <option value="fixed" ${coupon?.kind === 'fixed' ? 'selected' : ''}>${U.t('v.couponKindFixed')}</option>
          </select></div>
        <div class="field"><label data-value-label>${U.t('v.couponPercent')}</label>
          <input class="input" name="value" type="number" step="1" min="1"
                 value="${coupon ? (coupon.kind === 'percent' ? coupon.value : (coupon.value / 100).toFixed(2)) : ''}"></div>
        <div class="field"><label>${U.t('v.couponMaxDiscount')}</label>
          <input class="input" name="maxDiscount" type="number" step="0.5" min="0"
                 value="${coupon ? (coupon.maxDiscount / 100).toFixed(2) : '0'}"></div>
        <div class="field"><label>${U.t('v.couponMinOrder')}</label>
          <input class="input" name="minOrder" type="number" step="0.5" min="0"
                 value="${coupon ? (coupon.minOrder / 100).toFixed(2) : '0'}"></div>
        <div class="field"><label>${U.t('v.couponUsageLimit')}</label>
          <input class="input" name="usageLimit" type="number" step="1" min="0" value="${coupon?.usageLimit ?? 0}"></div>
        <div class="field"><label>${U.t('v.couponPerUser')}</label>
          <input class="input" name="perUserLimit" type="number" step="1" min="0" value="${coupon?.perUserLimit ?? 1}"></div>
        <div class="field"><label>${U.t('v.couponExpires')}</label>
          <input class="input" name="expiresAt" type="date"
                 value="${coupon?.expiresAt ? coupon.expiresAt.slice(0, 10) : ''}"></div>
        <div class="field" style="grid-column:1/-1"><label>${U.t('v.couponDescription')}</label>
          <input class="input" name="description" value="${coupon?.description ?? ''}"
                 placeholder="${U.t('v.couponDescriptionPlaceholder')}"></div>
        <div class="field"><label>${U.t('common.status')}</label>
          <label class="switch" style="padding-top:6px">
            <input type="checkbox" name="active" ${coupon?.active === false ? '' : 'checked'}>
            <span class="track"></span><span class="small">${U.t('v.tabActive')}</span></label></div>
      </div>`,
    footer: `<button class="btn btn-outline" data-close>${U.t('actions.cancel')}</button>
             <button class="btn btn-primary" data-save>${isNew ? U.t('actions.create') : U.t('actions.save')}</button>`,
  });

  const kindEl = m.root.querySelector('[name="kind"]');
  const valueLabel = m.root.querySelector('[data-value-label]');
  const syncKind = () => {
    valueLabel.textContent = kindEl.value === 'percent' ? U.t('v.couponPercent') : U.t('v.couponAmount');
  };
  kindEl.addEventListener('change', syncKind);
  syncKind();

  m.root.querySelector('[data-save]').addEventListener('click', async (e) => {
    const val = (n) => m.root.querySelector(`[name="${n}"]`)?.value.trim() ?? '';
    const body = {
      code: val('code'),
      kind: val('kind'),
      value: Number(val('value').replace(',', '.')),
      minOrder: Number(val('minOrder').replace(',', '.')) || 0,
      maxDiscount: Number(val('maxDiscount').replace(',', '.')) || 0,
      usageLimit: Number(val('usageLimit')) || 0,
      perUserLimit: Number(val('perUserLimit')) || 0,
      expiresAt: val('expiresAt') || null,
      description: val('description'),
      active: m.root.querySelector('[name="active"]').checked,
    };
    e.target.disabled = true;
    try {
      if (isNew) await U.api('/api/vendor/coupons', { method: 'POST', body });
      else await U.api(`/api/vendor/coupons/${coupon.id}`, { method: 'PATCH', body });
      m.close();
      U.toast(isNew ? U.t('v.couponCreated') : U.t('v.couponUpdated'), 'ok');
      await loadCoupons();
    } catch (err) {
      U.toast(err.message, 'err', 5000);
      e.target.disabled = false;
    }
  });
}

/* ------------------------------------------------------------------ *
 * Rəylər
 * ------------------------------------------------------------------ */
async function paintReviews() {
  main.innerHTML = h`${raw(approvalBanner())}${raw(vendorHeader())}
    <div id="reviews-area"><div class="skeleton" style="height:240px"></div></div>`;
  bindOpenToggle();

  const { reviews, summary } = await U.api('/api/vendor/reviews');
  state.reviewCount = summary.reviewCount;

  const host = U.qs('#reviews-area');
  if (!reviews.length) {
    host.innerHTML = h`<div class="card"><div class="empty"><div class="big">⭐</div>
      <h3>${U.t('v.reviewsEmpty')}</h3>
      <p class="muted mt-1">${U.t('v.reviewsEmptyHint')}</p>
    </div></div>`;
    return;
  }

  const dist = summary.distribution ?? {};
  host.innerHTML = h`
    <div class="stat-grid mb-3">
      <div class="card stat"><span>${U.t('review.storeRating')}</span><b>${Number(summary.rating).toFixed(1)}</b>
        <span class="tiny muted">${summary.ratingCount} ${U.t('common.rating')}</span></div>
      <div class="card stat"><span>${U.t('v.reviewsNew')}</span><b>${summary.reviewCount}</b>
        <span class="tiny muted">${U.t('v.reviewsAvg', { value: summary.newRating || '—' })}</span></div>
      <div class="card stat"><span>${U.t('v.reviewsDistribution')}</span><b style="font-size:22px">${dist[5] ?? 0} / ${dist[4] ?? 0}</b>
        <span class="tiny muted">3★: ${dist[3] ?? 0} · 2★: ${dist[2] ?? 0} · 1★: ${dist[1] ?? 0}</span></div>
      <div class="card stat"><span>${U.t('v.reviewsUnanswered')}</span>
        <b>${reviews.filter((r) => !r.reply).length}</b>
        <span class="tiny muted">${U.t('v.reviewsUnansweredHint')}</span></div>
    </div>

    <div class="col">${raw(reviews.map((r) => `
      <div class="card card-pad">
        <div class="row-between wrap-row">
          <div>
            <div class="row" style="gap:8px">
              <b>${U.esc(r.authorName)}</b>
              ${U.starsHtml(r.rating, 14)}
              ${r.hidden ? `<span class="badge badge-closed">${U.t('v.hiddenByAdmin')}</span>` : ''}
            </div>
            <span class="tiny muted">${U.t('orders.orderCode')} #${r.orderId} · ${U.dateTime(r.createdAt)}</span>
          </div>
          ${r.reply ? '' : `<button class="btn btn-sm btn-outline" data-reply="${r.id}">${U.t('v.reply')}</button>`}
        </div>
        ${r.comment ? `<p class="mt-2">${U.esc(r.comment)}</p>` : `<p class="muted small mt-2">${U.t('v.noComment')}</p>`}
        ${r.reply ? `<div class="card card-pad mt-2" style="background:var(--brand-soft);border:none">
          <div class="row-between"><b class="small">${U.t('v.yourReply')}</b>
            <button class="btn btn-sm btn-ghost" data-reply="${r.id}">${U.t('v.changeReply')}</button></div>
          <p class="small mt-1">${U.esc(r.reply)}</p></div>` : ''}
      </div>`).join(''))}</div>`;

  renderSidebar();
}

/* ------------------------------------------------------------------ *
 * Hesablaşma (komissiya və ödənişlər)
 * ------------------------------------------------------------------ */
const RANGES = [
  { key: 'month', labelKey: 'v.setThisMonth' },
  { key: 'last', labelKey: 'v.setLastMonth' },
  { key: 'year', labelKey: 'v.setThisYear' },
  { key: 'custom', labelKey: 'v.setCustom' },
];

const rangeParams = (key, custom = {}) => {
  const now = new Date();
  const iso = (d) => d.toISOString();
  if (key === 'month') return { from: iso(new Date(now.getFullYear(), now.getMonth(), 1)), to: iso(now) };
  if (key === 'last') {
    return {
      from: iso(new Date(now.getFullYear(), now.getMonth() - 1, 1)),
      to: iso(new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59)),
    };
  }
  if (key === 'year') return { from: iso(new Date(now.getFullYear(), 0, 1)), to: iso(now) };
  return { from: custom.from || undefined, to: custom.to || undefined };
};

async function paintSettlement() {
  state.settlementRange = state.settlementRange ?? 'month';
  const range = rangeParams(state.settlementRange, state.settlementCustom ?? {});
  const params = new URLSearchParams();
  if (range.from) params.set('from', range.from);
  if (range.to) params.set('to', range.to);

  main.innerHTML = h`${raw(approvalBanner())}${raw(vendorHeader())}
    <div id="settlement-area"><div class="skeleton" style="height:240px"></div></div>`;
  bindOpenToggle();

  let data;
  try {
    data = await U.api(`/api/vendor/settlement?${params}`);
  } catch (err) {
    U.qs('#settlement-area').innerHTML = h`<div class="card card-pad">${U.errText(err)}</div>`;
    return;
  }
  state.settlement = data;
  renderSettlement(data);
}

function renderSettlement(data) {
  const t = data.totals;
  const netPositive = t.net >= 0;
  const host = U.qs('#settlement-area');

  host.innerHTML = h`
    <div class="card card-pad mb-3">
      <div class="row-between wrap-row">
        <div>
          <h3>${U.t('v.setTitle')}</h3>
          <p class="small muted mt-1">${U.t('v.setSubtitle')}</p>
        </div>
        <div class="tabs">
          ${raw(RANGES.map((r) => `<button data-range="${r.key}"
            class="${state.settlementRange === r.key ? 'active' : ''}">${U.t(r.labelKey)}</button>`).join(''))}
        </div>
      </div>
      ${state.settlementRange === 'custom'
        ? raw(`<div class="row wrap-row mt-2" style="gap:10px">
            <div class="field"><label>${U.t('v.setFrom')}</label>
              <input class="input input-sm" type="date" data-from value="${U.esc((state.settlementCustom?.from ?? '').slice(0, 10))}"></div>
            <div class="field"><label>${U.t('v.setTo')}</label>
              <input class="input input-sm" type="date" data-to value="${U.esc((state.settlementCustom?.to ?? '').slice(0, 10))}"></div>
            <button class="btn btn-dark btn-sm" data-act="apply-range" style="align-self:end">${U.t('actions.apply')}</button>
          </div>`)
        : ''}
      <p class="small muted mt-2">
        ${U.t('v.setPeriod')}: ${U.dateTime(data.period.from)} — ${U.dateTime(data.period.to)}
        · ${U.t('v.setCommissionRate')}: <b>${data.commissionPercent}%</b>
      </p>
    </div>

    <div class="stat-grid mb-3">
      <div class="card stat"><span>${U.t('v.setGross')}</span><b>${U.azn(t.gross)}</b>
        <span class="tiny muted">${data.orders.length} ${U.t('common.orders')}</span></div>
      <div class="card stat"><span>${U.t('v.setCommission')}</span><b>${U.azn(t.commission)}</b>
        <span class="tiny muted">${data.commissionPercent}% · ${U.t('v.setPlatformRevenue')} ${U.azn(t.platformRevenue)}</span></div>
      <div class="card stat"><span>${U.t('v.setDiscount')}</span><b>${U.azn(t.discount)}</b>
        <span class="tiny muted">${U.t('v.setDiscountHint')}</span></div>
      <div class="card stat"><span>${U.t('v.setOnline')} / ${U.t('v.setCounter')}</span>
        <b style="font-size:19px">${U.azn(t.online)} <span class="muted">/</span> ${U.azn(t.counter)}</b>
        <span class="tiny muted">${U.t('v.setCollectedHint')}</span></div>
    </div>

    <div class="card card-pad mb-3" style="background:${netPositive ? 'var(--ok-soft)' : 'var(--warn-soft)'};border:none">
      <div class="row-between wrap-row">
        <div>
          <b>${netPositive ? U.t('v.setNetPositive') : U.t('v.setNetNegative')}</b>
          <p class="small muted mt-1">${U.t('v.setNetHint')}</p>
        </div>
        <b style="font-size:26px">${U.azn(Math.abs(t.net))}</b>
      </div>
      <div class="row wrap-row mt-2 small muted" style="gap:16px">
        <span>${U.t('v.setPayout')}: <b>${U.azn(t.payout)}</b></span>
        <span>${U.t('v.setDue')}: <b>${U.azn(t.due)}</b></span>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-pad" style="border-bottom:1px solid var(--line)">
        <h3>${U.t('v.setOrdersTitle')}</h3>
      </div>
      ${data.orders.length
    ? raw(`<div class="table-wrap"><table class="table">
          <thead><tr><th>${U.t('v.setOrderCode')}</th><th>${U.t('v.setDate')}</th><th>${U.t('common.status')}</th>
            <th>${U.t('v.setSubtotal')}</th><th>${U.t('v.setDiscount')}</th><th>${U.t('v.setCommission')}</th>
            <th>${U.t('v.setPayout')}</th><th>${U.t('v.setCollectedBy')}</th></tr></thead>
          <tbody>${data.orders.map((o) => `<tr>
            <td><b>${U.esc(o.code)}</b></td>
            <td class="small muted nowrap">${U.dateTime(o.createdAt)}</td>
            <td>${U.statusBadgeHtml(o.status)}</td>
            <td>${U.azn(o.subtotal)}</td>
            <td>${o.discount ? `−${U.azn(o.discount)}<div class="tiny muted">${U.esc(o.couponCode ?? '')}</div>` : '—'}</td>
            <td>${o.settled ? `<b>−${U.azn(o.commission)}</b>` : `<span class="muted">${U.azn(o.commission)}</span>`}</td>
            <td>${U.azn(o.payout)}</td>
            <td class="small">${o.collectedBy === 'platform' ? U.t('v.setCollectedPlatform') : U.t('v.setCollectedVendor')}</td>
          </tr>`).join('')}</tbody>
        </table></div>`)
    : raw(`<div class="empty"><div class="big">🧾</div><h3>${U.t('v.setNoOrders')}</h3></div>`)}
    </div>

    <div class="card">
      <div class="card-pad" style="border-bottom:1px solid var(--line)">
        <h3>${U.t('v.setHistory')}</h3>
      </div>
      ${data.history?.length
    ? raw(`<div class="table-wrap"><table class="table">
          <thead><tr><th>${U.t('v.setPeriod')}</th><th>${U.t('v.setOrdersTitle')}</th><th>${U.t('v.setCommission')}</th>
            <th>${U.t('v.setPayout')}</th><th>${U.t('common.status')}</th></tr></thead>
          <tbody>${data.history.map((s) => `<tr>
            <td class="small nowrap">${U.dateTime(s.periodStart)} — ${U.dateTime(s.periodEnd)}</td>
            <td>${s.ordersCount}</td>
            <td>${U.azn(s.commission)}</td>
            <td><b>${U.azn(s.payout)}</b></td>
            <td>${s.status === 'paid'
    ? `<span class="badge badge-open">${U.t('v.setStatusPaid')}</span>
                   <div class="tiny muted">${U.dateTime(s.paidAt)}</div>`
    : `<span class="badge badge-warn">${U.t('v.setStatusPending')}</span>`}</td>
          </tr>`).join('')}</tbody>
        </table></div>`)
    : raw(`<div class="empty">${U.t('v.setHistoryEmpty')}</div>`)}
    </div>`;

  U.on(host, 'click', '[data-range]', async (e, el) => {
    state.settlementRange = el.dataset.range;
    if (state.settlementRange !== 'custom') state.settlementCustom = {};
    await paintSettlement();
  });
  U.on(host, 'click', '[data-act="apply-range"]', async () => {
    state.settlementCustom = {
      from: U.qs('[data-from]', host)?.value ?? '',
      to: U.qs('[data-to]', host)?.value ?? '',
    };
    await paintSettlement();
  });
}

/* ------------------------------------------------------------------ *
 * Mağaza ayarları
 * ------------------------------------------------------------------ */
async function paintStore() {
  const v = state.vendor;
  const { categories } = await U.api('/api/categories');
  const cats = categories.filter((c) => c.kind === v.kind);

  main.innerHTML = h`
    ${raw(approvalBanner())}
    ${raw(vendorHeader())}
    <div class="card card-pad">
      <h3>${U.t('v.storeInfo')}</h3>
      <div class="form-grid mt-2">
        <div class="field"><label>${U.t('v.storeName')}</label><input class="input" name="name" value="${v.name}"></div>
        <div class="field"><label>${U.t('auth.vendorKind')}</label>
          <select class="select" name="kind">
            <option value="restaurant" ${v.kind === 'restaurant' ? 'selected' : ''}>${U.t('auth.restaurantKind')}</option>
            <option value="market" ${v.kind === 'market' ? 'selected' : ''}>${U.t('auth.marketKind')}</option>
          </select>
        </div>
        <div class="field"><label>${U.t('v.storeCategory')}</label>
          <select class="select" name="category">
            ${raw(cats.map((c) => `<option value="${U.esc(c.slug)}" ${v.category?.slug === c.slug ? 'selected' : ''}>
              ${U.esc(c.icon)} ${U.esc(c.name)}</option>`).join(''))}
          </select>
        </div>
        <div class="field"><label>${U.t('v.storeLogo')}</label><input class="input" name="logo" value="${v.logo}"></div>
        <div class="field"><label>${U.t('v.storePrepTime')}</label>
          <input class="input" type="number" min="1" max="240" name="prepTime" value="${v.prepTime}"></div>
        <div class="field"><label>${U.t('v.storeMinOrder')}</label>
          <input class="input" type="number" min="0" step="0.5" name="minOrder" value="${(v.minOrder / 100).toFixed(2)}"></div>
        <div class="field" style="grid-column:1/-1"><label>${U.t('common.address')}</label>
          <input class="input" name="address" value="${v.address}"></div>
        <div class="field"><label>${U.t('common.phone')}</label><input class="input" name="phone" value="${v.phone}"></div>
        <div class="field" style="grid-column:1/-1"><label>${U.t('v.storeTagline')}</label>
          <input class="input" name="tagline" value="${v.tagline}"></div>
        <div class="field" style="grid-column:1/-1"><label>${U.t('v.fieldDescription')}</label>
          <textarea class="textarea" name="description">${v.description}</textarea></div>
      </div>
      <div class="row-between mt-3">
        <button class="btn btn-primary btn-lg" data-act="save-store">${U.t('actions.save')}</button>
        <button class="btn btn-outline" data-act="copy-link">${U.t('v.copyCustomerLink')}</button>
      </div>
    </div>

    <div class="card card-pad mt-3">
      <div class="row-between wrap-row">
        <div>
          <h3>📍 ${U.t('v.locationTitle')}</h3>
          <p class="small muted mt-1">${U.t('v.locationHint')}</p>
        </div>
        <span class="badge ${v.hasLocation ? 'badge-open' : 'badge-warn'}">
          ${v.hasLocation ? U.t('v.locationSet') : U.t('v.locationMissing')}</span>
      </div>
      <div class="form-grid mt-2">
        <div class="field"><label>${U.t('v.lat')}</label>
          <input class="input" type="number" step="0.000001" name="lat" value="${v.lat ?? ''}" placeholder="40.682800"></div>
        <div class="field"><label>${U.t('v.lng')}</label>
          <input class="input" type="number" step="0.000001" name="lng" value="${v.lng ?? ''}" placeholder="46.360600"></div>
      </div>
      <div class="row wrap-row mt-2" style="gap:8px">
        <button class="btn btn-dark" data-act="use-loc">📍 ${U.t('v.useMyLocation')}</button>
        <button class="btn btn-primary" data-act="save-loc">${U.t('v.saveLocation')}</button>
        ${v.hasLocation ? raw(`<a class="btn btn-outline" target="_blank" rel="noopener"
          href="https://www.google.com/maps?q=${v.lat},${v.lng}">🗺 ${U.t('v.openInMaps')}</a>
          <button class="btn btn-ghost" data-act="clear-loc">${U.t('v.clearLocation')}</button>`) : ''}
      </div>
      <p class="tiny muted mt-2">${U.t('v.locationNote')}</p>
    </div>

    <div class="card card-pad mt-3">
      <h3>${U.t('v.orderFlowTitle')}</h3>
      <p class="small muted mt-1">${U.t('v.orderFlowText')}</p>
      <p class="small mt-2">${U.t('v.tabNew')} → ${U.t('status.accepted')} → ${U.t('status.preparing')} → <b>${U.t('status.ready')}</b> ${U.t('v.orderFlowNotify')} → ${U.t('status.picked_up')}</p>
    </div>`;

  bindOpenToggle();
  U.qs('[data-act="save-store"]', main).addEventListener('click', async (e) => {
    const val = (n) => main.querySelector(`[name="${n}"]`)?.value.trim() ?? '';
    e.target.disabled = true;
    try {
      const { vendor } = await U.api('/api/vendor/me', {
        method: 'PATCH',
        body: {
          name: val('name'), kind: val('kind'), category: val('category'), logo: val('logo'),
          prepTime: Number(val('prepTime')), minOrder: Number(val('minOrder').replace(',', '.')),
          address: val('address'), phone: val('phone'), tagline: val('tagline'), description: val('description'),
        },
      });
      state.vendor = vendor;
      renderSidebar();
      U.toast(U.t('v.storeSaved'), 'ok');
      paint();
    } catch (err) {
      U.toast(err.message, 'err');
      e.target.disabled = false;
    }
  });
  U.qs('[data-act="copy-link"]', main).addEventListener('click', async () => {
    const link = `${location.origin}/#/v/${state.vendor.slug}`;
    try {
      await navigator.clipboard.writeText(link);
      U.toast(U.t('v.linkCopied'), 'ok');
    } catch { U.toast(link, '', 6000); }
  });

  /* --- Yer (məsafə hesablanması üçün) --- */
  const locVal = (n) => main.querySelector(`[name="${n}"]`)?.value.trim() ?? '';

  U.qs('[data-act="use-loc"]', main)?.addEventListener('click', async (e) => {
    e.target.disabled = true;
    const label = e.target.innerHTML;
    e.target.innerHTML = `⏳ ${U.t('nearby.locating')}`;
    try {
      const loc = await U.geo.request();
      main.querySelector('[name="lat"]').value = loc.lat;
      main.querySelector('[name="lng"]').value = loc.lng;
      U.toast(U.t('v.locationDetected', { accuracy: loc.accuracy }), 'ok');
    } catch (err) {
      U.toast(U.errText(err), 'err', 5000);
    } finally {
      e.target.disabled = false;
      e.target.innerHTML = label;
    }
  });

  U.qs('[data-act="save-loc"]', main)?.addEventListener('click', async (e) => {
    const lat = locVal('lat');
    const lng = locVal('lng');
    e.target.disabled = true;
    try {
      const { vendor } = await U.api('/api/vendor/me', {
        method: 'PATCH',
        body: { lat: lat === '' ? null : Number(lat), lng: lng === '' ? null : Number(lng) },
      });
      state.vendor = vendor;
      U.toast(U.t('v.locationSaved'), 'ok');
      paint();
    } catch (err) {
      U.toast(U.errText(err), 'err', 5000);
      e.target.disabled = false;
    }
  });

  U.qs('[data-act="clear-loc"]', main)?.addEventListener('click', async () => {
    try {
      const { vendor } = await U.api('/api/vendor/me', { method: 'PATCH', body: { lat: null, lng: null } });
      state.vendor = vendor;
      U.toast(U.t('v.locationCleared'), 'warn');
      paint();
    } catch (err) { U.toast(U.errText(err), 'err'); }
  });
}

/* ------------------------------------------------------------------ *
 * Statistika
 * ------------------------------------------------------------------ */
async function paintStats() {
  main.innerHTML = h`${raw(vendorHeader())}<div class="skeleton" style="height:200px"></div>`;
  bindOpenToggle();

  let stats;
  try {
    stats = await U.api('/api/vendor/stats');
  } catch (err) {
    main.innerHTML = h`${raw(approvalBanner())}${raw(vendorHeader())}<div class="card card-pad">${err.message}</div>`;
    bindOpenToggle();
    return;
  }
  state.stats = stats;

  const max = Math.max(1, ...stats.daily.map((d) => d.revenue));
  const bars = stats.daily.length ? stats.daily : [];

  main.innerHTML = h`
    ${raw(vendorHeader())}
    <div class="stat-grid mb-3">
      <div class="card stat"><span>${U.t('v.statsTodayOrders')}</span><b>${stats.today.orders}</b>
        <span class="tiny muted">${U.t('a.stripeOn')}: ${stats.today.active}</span></div>
      <div class="card stat"><span>${U.t('v.statsTodayRevenue')}</span><b>${U.azn(stats.today.revenue)}</b>
        <span class="tiny muted">${U.t('v.statsOnlyDone')}</span></div>
      <div class="card stat"><span>${U.t('v.statsWeekRevenue')}</span><b>${U.azn(stats.week.revenue)}</b>
        <span class="tiny muted">${stats.week.orders} ${U.t('common.orders')}</span></div>
      <div class="card stat"><span>${U.t('v.statsAvgPrep')}</span><b>${stats.avgPrepMinutes || 0} ${U.t('common.minutes')}</b>
        <span class="tiny muted">${U.t('v.statsCancelled', { count: stats.allTime.cancelled })}</span></div>
    </div>

    <div class="stat-grid mb-3">
      <div class="card stat"><span>${U.t('v.statsTodayPaid')}</span><b>${U.azn(stats.payments?.todayPaid)}</b>
        <span class="tiny muted">${U.t('v.statsTotalRevenue', { amount: U.azn(stats.allTime.revenue) })}</span></div>
      <div class="card stat"><span>${U.t('v.statsPendingCash')}</span><b>${U.azn(stats.payments?.todayUnpaid)}</b>
        <span class="tiny muted">${U.t('v.statsPendingCashHint')}</span></div>
      <div class="card stat"><span>${U.t('v.statsOnlineCounter')}</span>
        <b style="font-size:20px">${U.azn(stats.payments?.online)} <span class="muted" style="font-size:14px">/</span> ${U.azn(stats.payments?.counter)}</b>
        <span class="tiny muted">${U.t('v.statsAllTime')}</span></div>
      <div class="card stat"><span>${U.t('v.statsRefunded')}</span><b>${U.azn(stats.payments?.refunded)}</b>
        <span class="tiny muted">${U.t('v.statsRefundedHint')}</span></div>
    </div>

    <div class="card card-pad mb-3">
      <h3>${U.t('common.week')}</h3>
      ${bars.length ? raw(`<div class="row" style="align-items:flex-end;gap:10px;height:150px;margin-top:16px">
          ${bars.map((d) => `
            <div style="flex:1;text-align:center">
              <div style="font-size:11px" class="muted">${U.azn(d.revenue)}</div>
              <div style="height:${Math.max(4, Math.round((d.revenue / max) * 100))}px;background:var(--brand);
                   border-radius:8px 8px 0 0;margin:4px auto 6px;width:70%"></div>
              <div class="tiny muted">${d.day.slice(8)}.${d.day.slice(5, 7)}</div>
            </div>`).join('')}
        </div>`) : raw(`<p class="muted mt-2">${U.t('v.statsNoWeekOrders')}</p>`)}
    </div>

    <div class="card">
      <div class="card-pad" style="border-bottom:1px solid var(--line)"><h3>${U.t('v.statsTopProducts')}</h3></div>
      ${stats.topProducts.length ? raw(`<div class="table-wrap"><table class="table">
        <thead><tr><th>${U.t('common.items')}</th><th>${U.t('v.statsQty')}</th><th>${U.t('v.statsRevenue')}</th></tr></thead>
        <tbody>${stats.topProducts.map((p) => `<tr><td><b>${U.esc(p.name)}</b></td>
          <td>${p.qty}</td><td>${U.azn(p.revenue)}</td></tr>`).join('')}</tbody>
      </table></div>`) : raw(`<div class="empty">${U.t('v.statsNoSales')}</div>`)}
    </div>`;
}

/* ------------------------------------------------------------------ *
 * Hadisə dinləyiciləri — bir dəfə bağlanır (main elementi sabitdir)
 * ------------------------------------------------------------------ */
function bindDelegates() {
  U.on(main, 'click', '[data-tab]', (e, el) => {
    state.tab = el.dataset.tab;
    loadOrders();
  });

  U.on(main, 'click', '[data-edit]', (e, el) =>
    productModal(state.products.find((p) => p.id === Number(el.dataset.edit))));

  U.on(main, 'click', '[data-del]', async (e, el) => {
    const p = state.products.find((x) => x.id === Number(el.dataset.del));
    if (!p) return;
    const yes = await U.confirmDialog({
      title: U.t('v.deleteProductTitle'), text: U.t('v.deleteProductText', { name: p.name }), okText: U.t('actions.delete'), danger: true,
    });
    if (!yes) return;
    try {
      await U.api(`/api/vendor/products/${p.id}`, { method: 'DELETE' });
      U.toast(U.t('v.productDeleted'), 'ok');
      await loadProducts();
    } catch (err) { U.toast(err.message, 'err'); }
  });

  U.on(main, 'change', '[data-active]', async (e, el) => {
    try {
      await U.api(`/api/vendor/products/${Number(el.dataset.active)}`, { method: 'PATCH', body: { active: el.checked } });
      U.toast(el.checked ? U.t('v.productActive') : U.t('v.productHidden'), 'ok', 1600);
    } catch (err) { U.toast(err.message, 'err'); el.checked = !el.checked; }
  });

  U.on(main, 'click', '[data-collect]', async (e, el) => {
    const method = el.dataset.method === 'card' ? U.t('v.card') : U.t('v.cash');
    const yes = await U.confirmDialog({
      title: U.t('v.collectTitle'),
      text: U.t('v.collectText', { method }),
      okText: U.t('v.collectOk'),
    });
    if (!yes) return;
    el.disabled = true;
    try {
      await U.api(`/api/vendor/orders/${Number(el.dataset.collect)}/collect`, {
        method: 'POST', body: { method: el.dataset.method },
      });
      U.toast(U.t('v.collectDone'), 'ok');
      await loadOrders();
    } catch (err) {
      U.toast(err.message, 'err');
      el.disabled = false;
    }
  });

  /* --- Kampaniyalar --- */
  U.on(main, 'click', '[data-coupon-edit]', (e, el) =>
    couponModal(state.coupons.find((c) => c.id === Number(el.dataset.couponEdit))));

  U.on(main, 'click', '[data-coupon-del]', async (e, el) => {
    const coupon = state.coupons.find((c) => c.id === Number(el.dataset.couponDel));
    if (!coupon) return;
    const yes = await U.confirmDialog({
      title: U.t('v.deleteCouponTitle'),
      text: U.t('v.deleteCouponText', { code: coupon.code }),
      okText: U.t('actions.delete'), danger: true,
    });
    if (!yes) return;
    try {
      await U.api(`/api/vendor/coupons/${coupon.id}`, { method: 'DELETE' });
      U.toast(U.t('v.couponDeleted'), 'ok');
      await loadCoupons();
    } catch (err) { U.toast(err.message, 'err'); }
  });

  /* --- Rəylər --- */
  U.on(main, 'click', '[data-reply]', async (e, el) => {
    const id = Number(el.dataset.reply);
    const m = U.modal({
      title: U.t('v.replyTitle'),
      body: h`
        <div class="field">
          <label>${U.t('v.replyLabel')}</label>
          <textarea class="textarea" name="reply" placeholder="${U.t('v.replyPlaceholder')}"></textarea>
        </div>
        <p class="hint mt-1">${U.t('v.replyHint')}</p>`,
      footer: `<button class="btn btn-outline" data-close>${U.t('actions.cancel')}</button>
               <button class="btn btn-primary" data-send>${U.t('v.replySubmit')}</button>`,
    });
    m.root.querySelector('[data-send]').addEventListener('click', async (ev) => {
      const reply = m.root.querySelector('[name="reply"]').value.trim();
      if (!reply) return U.toast(U.t('v.replyEmpty'), 'err');
      ev.target.disabled = true;
      try {
        await U.api(`/api/vendor/reviews/${id}/reply`, { method: 'POST', body: { reply } });
        m.close();
        U.toast(U.t('v.replySent'), 'ok');
        await paintReviews();
      } catch (err) {
        U.toast(err.message, 'err');
        ev.target.disabled = false;
      }
    });
  });
}

/* ------------------------------------------------------------------ *
 * Köməkçilər
 * ------------------------------------------------------------------ */
function beep() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    osc.frequency.setValueAtTime(1180, ctx.currentTime + 0.14);
    gain.gain.setValueAtTime(0.001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.08, ctx.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.4);
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    setTimeout(() => { osc.stop(); ctx.close(); }, 460);
  } catch { /* səs dəstəklənmir */ }
}
