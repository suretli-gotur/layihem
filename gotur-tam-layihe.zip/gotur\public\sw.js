/* ==================================================================
   Götür — Service Worker
   • App shell ön keşləmə (offline açılış)
   • Naviqasiya: network-first → keş → /offline.html
   • Statik fayllar: cache-first + fon revalidasiyası
   • API: kataloq sorğuları üçün network-first + keş fallback
     (şəxsi/mutasiya sorğuları HEÇ VAXT keşlənmir)
   • Bildirişlər: notificationclick + push (Web Push hazır)
   ================================================================== */

const VERSION = 'gotur-v2';
const SHELL_CACHE = `${VERSION}-shell`;
const STATIC_CACHE = `${VERSION}-static`;
const DATA_CACHE = `${VERSION}-data`;

const SHELL = [
  '/',
  '/index.html',
  '/satis.html',
  '/admin.html',
  '/odenis.html',
  '/offline.html',
  '/manifest.webmanifest',
  '/manifest-satis.webmanifest',
  '/manifest-admin.webmanifest',
  '/assets/app.css',
  '/assets/common.js',
  '/assets/customer.js',
  '/assets/vendor.js',
  '/assets/admin.js',
  '/assets/odenis.js',
  '/assets/icons/icon.svg',
  '/assets/icons/icon-192.png',
  '/assets/icons/icon-512.png',
  '/assets/icons/icon-maskable-512.png',
];

/* Yalnız bu API sorğuları keşləşir (kataloq — hər kəsə açıq məlumat) */
const CACHEABLE_API = [
  /^\/api\/categories/,
  /^\/api\/vendors(\?|$)/,
  /^\/api\/vendors\/[^/?]+$/,
];

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(SHELL_CACHE);
    // Bəzi fayllar əlçatan olmasa da quraşdırma davam etsin
    await Promise.allSettled(SHELL.map((url) => cache.add(new Request(url, { cache: 'reload' }))));
    self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k)));
    if (self.registration.navigationPreload) {
      await self.registration.navigationPreload.disable();
    }
    await self.clients.claim();
  })());
});

const isCacheableApi = (url) => CACHEABLE_API.some((re) => re.test(url.pathname + url.search));

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  /* 1) Naviqasiya sorğuları */
  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        return await fetch(request);
      } catch {
        const cached = (await caches.match(request)) ?? (await caches.match('/index.html'));
        return cached ?? (await caches.match('/offline.html'));
      }
    })());
    return;
  }

  /* 2) Kataloq API-si: network-first, offline-da keş */
  if (url.pathname.startsWith('/api/')) {
    if (!isCacheableApi(url)) return; // digər API sorğuları şəbəkəyə gedir
    event.respondWith((async () => {
      const cache = await caches.open(DATA_CACHE);
      try {
        const fresh = await fetch(request);
        if (fresh.ok) cache.put(request, fresh.clone());
        return fresh;
      } catch {
        const cached = await cache.match(request);
        if (cached) {
          const headers = new Headers(cached.headers);
          headers.set('x-gotur-offline', '1');
          return new Response(await cached.blob(), { status: 200, headers });
        }
        return new Response(JSON.stringify({ error: 'Oflayn rejimdə bu məlumat yoxdur', offline: true }), {
          status: 503,
          headers: { 'content-type': 'application/json; charset=utf-8' },
        });
      }
    })());
    return;
  }

  /* 3) Statik fayllar: cache-first + fon yeniləməsi */
  event.respondWith((async () => {
    const cached = await caches.match(request, { ignoreSearch: false });
    const network = fetch(request).then(async (response) => {
      if (response.ok) {
        const cache = await caches.open(STATIC_CACHE);
        cache.put(request, response.clone());
      }
      return response;
    }).catch(() => null);

    if (cached) return cached;
    const fresh = await network;
    if (fresh) return fresh;
    return new Response('Oflayn', { status: 503, headers: { 'content-type': 'text/plain; charset=utf-8' } });
  })());
});

/* ------------------------------------------------------------------ *
 * Mesajlar (səhifədən idarə)
 * ------------------------------------------------------------------ */
self.addEventListener('message', (event) => {
  const data = event.data ?? {};
  if (data.type === 'SKIP_WAITING') self.skipWaiting();
  if (data.type === 'CACHE_URLS' && Array.isArray(data.urls)) {
    event.waitUntil((async () => {
      const cache = await caches.open(DATA_CACHE);
      await Promise.allSettled(data.urls.map((u) => cache.add(u)));
    })());
  }
  if (data.type === 'CLEAR_CACHES') {
    event.waitUntil((async () => {
      const keys = await caches.keys();
      await Promise.all(keys.map((k) => caches.delete(k)));
    })());
  }
});

/* ------------------------------------------------------------------ *
 * Bildirişlər
 * ------------------------------------------------------------------ */
self.addEventListener('notificationclick', (event) => {
  const target = event.notification?.data?.url || '/';
  event.notification?.close();
  event.waitUntil((async () => {
    const all = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of all) {
      if ('focus' in client) {
        await client.focus();
        if ('navigate' in client) await client.navigate(target);
        return;
      }
    }
    await self.clients.openWindow(target);
  })());
});

/* Web Push (server tərəfi VAPID açarları ilə aktivləşir) */
self.addEventListener('push', (event) => {
  let payload = { title: 'Götür', body: 'Yeni bildiriş' };
  try {
    if (event.data) payload = { ...payload, ...event.data.json() };
  } catch {
    if (event.data) payload.body = event.data.text();
  }
  event.waitUntil(self.registration.showNotification(payload.title, {
    body: payload.body,
    icon: '/assets/icons/icon-192.png',
    badge: '/assets/icons/icon-192.png',
    tag: payload.tag,
    data: { url: payload.url || '/' },
    lang: 'az',
  }));
});
