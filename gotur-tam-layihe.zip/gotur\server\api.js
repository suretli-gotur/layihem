import { q, schemaVersion, uniqueSlug } from './db.js';
import { isCoord, sortByDistance, travelEstimates, withDistance } from './geo.js';
import {
  SESSION_COOKIE,
  clearSessionCookie,
  createSession,
  currentUser,
  destroySession,
  publicUser,
  sessionCookie,
} from './session.js';
import {
  HttpError, bad, bool, forbidden, hashPassword, int, normalizePhone, notFound, nowIso, orderCode,
  randomDigits, randomPassword, readJsonBody, requireFields, sendJson, slugify, str, unauthorized,
  verifyPassword,
} from './util.js';
import {
  collectAtCounter, confirmStripeSession, createPaymentForOrder, checkoutInfo, getPaymentByToken,
  getPaymentsForOrder, markFailed, markPaid, paySimulated, refundOrder, serializePayment,
  stripeEnabled, verifyStripeSignature, PAYMENT_STATUS_LABEL,
} from './payments.js';
import { addClient, clientCount, clientStats, publish, removeClient } from './events.js';
import {
  activeCouponsForVendor, createCoupon, deleteCoupon, listCoupons, releaseCoupon,
  serializeCoupon, updateCoupon, validateCoupon, consumeCoupon,
} from './coupons.js';
import {
  adminReviews, assertCanReview, createReview, replyToReview, reviewForOrder, reviewSummary,
  setReviewHidden, vendorReviews,
} from './reviews.js';
import {
  commissionForOrder, computeCommission, createSettlement, deleteSettlement, getSettings,
  listSettlements, markSettlementPaid, platformSettlement, setSetting, setVendorCommission,
  vendorSettlement, commissionPercentFor,
} from './settlements.js';

/* ================================================================== *
 * Serializasiya
 * ================================================================== */
export function serializeVendor(v, { menu = false } = {}) {
  if (!v) return null;
  const cat = v.category_id
    ? q.get('SELECT slug, name, icon FROM categories WHERE id = ?', v.category_id)
    : null;
  const out = {
    id: v.id,
    slug: v.slug,
    name: v.name,
    kind: v.kind,
    tagline: v.tagline || '',
    description: v.description || '',
    address: v.address || '',
    phone: v.phone || '',
    logo: v.logo || '🏪',
    open: !!v.open,
    approved: !!v.approved,
    prepTime: v.prep_time,
    minOrder: v.min_order,
    rating: v.rating,
    ratingCount: v.rating_count,
    category: cat ? { slug: cat.slug, name: cat.name, icon: cat.icon } : null,
    lat: v.lat === null || v.lat === undefined ? null : Number(v.lat),
    lng: v.lng === null || v.lng === undefined ? null : Number(v.lng),
    hasLocation: isCoord(v.lat, v.lng),
    createdAt: v.created_at,
  };
  if (menu) out.menu = vendorMenu(v.id);
  return out;
}

export function vendorMenu(vendorId) {
  const rows = q.all(
    'SELECT * FROM products WHERE vendor_id = ? AND active = 1 ORDER BY sort, id',
    vendorId,
  );
  const sections = [];
  const index = new Map();
  for (const r of rows) {
    if (!index.has(r.section)) {
      const sec = { section: r.section, items: [] };
      index.set(r.section, sec);
      sections.push(sec);
    }
    index.get(r.section).items.push(serializeProduct(r));
  }
  return sections;
}

export function serializeProduct(p) {
  return {
    id: p.id,
    vendorId: p.vendor_id,
    section: p.section,
    name: p.name,
    description: p.description || '',
    price: p.price,
    unit: p.unit,
    image: p.image,
    stock: p.stock === null || p.stock === undefined ? null : p.stock,
    active: !!p.active,
    sort: p.sort,
    inStock: p.stock === null || p.stock === undefined ? true : p.stock > 0,
  };
}

export function serializeOrderBasic(o) {
  return {
    id: o.id,
    code: o.code,
    status: o.status,
    vendorId: o.vendor_id,
    vendorName: o.vendor_name,
    vendorSlug: o.vendor_slug,
    vendorAddress: o.vendor_address,
    vendorPhone: o.vendor_phone,
    customerName: o.customer_name,
    customerPhone: o.customer_phone,
    subtotal: o.subtotal,
    fee: o.fee,
    total: o.total,
    payment: o.payment,
    paymentStatus: o.payment_status ?? 'unpaid',
    paymentStatusLabel: PAYMENT_STATUS_LABEL[o.payment_status ?? 'unpaid'] ?? 'Ödənilməyib',
    paidAt: o.paid_at ?? null,
    couponCode: o.coupon_code || null,
    discount: o.discount ?? 0,
    commission: o.commission ?? 0,
    vendorPayout: o.vendor_payout ?? 0,
    pickupCode: o.pickup_code,
    note: o.note || '',
    createdAt: o.created_at,
    updatedAt: o.updated_at,
    readyAt: o.ready_at,
    pickedUpAt: o.picked_up_at,
    itemCount: o.item_count ?? undefined,
  };
}

export function serializeOrderFull(o) {
  const items = q.all(
    'SELECT * FROM order_items WHERE order_id = ? ORDER BY id',
    o.id,
  ).map((i) => ({
    id: i.id,
    productId: i.product_id,
    name: i.name,
    price: i.price,
    qty: i.qty,
    unit: i.unit,
    image: i.image,
    lineTotal: i.price * i.qty,
  }));
  const events = q.all(
    'SELECT status, note, created_at FROM order_events WHERE order_id = ? ORDER BY id',
    o.id,
  ).map((e) => ({ status: e.status, note: e.note || '', at: e.created_at }));
  return {
    ...serializeOrderBasic(o),
    items,
    events,
    payments: getPaymentsForOrder(o.id).map((p) => serializePayment(p)),
    review: reviewForOrder(o.id),
  };
}

const ORDER_SELECT = `
  SELECT o.*, v.name AS vendor_name, v.slug AS vendor_slug, v.address AS vendor_address,
         v.phone AS vendor_phone, v.prep_time AS vendor_prep,
         (SELECT COALESCE(SUM(qty), 0) FROM order_items WHERE order_id = o.id) AS item_count
  FROM orders o JOIN vendors v ON v.id = o.vendor_id`;

/** Sifariş siyahısına məhsul sətirlərini bir sorğu ilə əlavə edir. */
function withItems(rows) {
  if (!rows.length) return [];
  const ids = rows.map((r) => r.id);
  const byOrder = new Map();
  const placeholders = ids.map(() => '?').join(',');
  for (const it of q.all(
    `SELECT order_id, name, qty, price, unit FROM order_items WHERE order_id IN (${placeholders}) ORDER BY id`,
    ...ids,
  )) {
    if (!byOrder.has(it.order_id)) byOrder.set(it.order_id, []);
    byOrder.get(it.order_id).push({ name: it.name, qty: it.qty, price: it.price, unit: it.unit, lineTotal: it.price * it.qty });
  }
  return rows.map((r) => ({ ...serializeOrderBasic(r), items: byOrder.get(r.id) ?? [] }));
}

/* ================================================================== *
 * Router
 * ================================================================== */
const routes = [];
const route = (method, path, handler, opts = {}) => {
  routes.push({ method, parts: path.split('/').filter(Boolean), handler, opts });
};

/** Frontend müqaviləsini yoxlamaq üçün route cədvəli (tools/static-check.mjs istifadə edir). */
export const routeTable = () =>
  routes.map((r) => ({ method: r.method, path: `/${r.parts.join('/')}`, roles: r.opts.roles ?? null }));

function match(method, pathname) {
  const parts = pathname.split('/').filter(Boolean);
  for (const r of routes) {
    if (r.method !== method || r.parts.length !== parts.length) continue;
    const params = {};
    let ok = true;
    for (let i = 0; i < r.parts.length; i++) {
      const rp = r.parts[i];
      if (rp.startsWith(':')) params[rp.slice(1)] = decodeURIComponent(parts[i]);
      else if (rp !== parts[i]) { ok = false; break; }
    }
    if (ok) return { route: r, params };
  }
  return null;
}

export async function handleApi(req, res, url) {
  const pathname = url.pathname;
  if (!pathname.startsWith('/api/')) return false;

  const hit = match(req.method.toUpperCase(), pathname);
  if (!hit) throw notFound(`API yolu tapılmadı: ${req.method} ${pathname}`);

  const { route: r, params } = hit;
  const user = currentUser(req);

  if (r.opts.roles && !user) throw unauthorized();
  if (r.opts.roles && !r.opts.roles.includes(user.role)) throw forbidden();

  const ctx = {
    req, res, url, params, user,
    query: url.searchParams,
    json: async () => req._body ?? (req._body = await readJsonBody(req)),
  };
  const result = await r.handler(ctx);
  if (res.writableEnded) return true;
  if (res.headersSent) return true; // SSE və digər axınlar başlıqları özü yazır

  if (result && typeof result === 'object' && ('__status' in result || '__headers' in result)) {
    const { __status = 200, __headers = {}, ...body } = result;
    sendJson(res, __status, body, __headers);
  } else {
    sendJson(res, 200, result ?? { ok: true });
  }
  return true;
}

/* ------------------------------------------------------------------ *
 * Auth
 * ------------------------------------------------------------------ */
route('POST', '/api/auth/register', async (ctx) => {
  const b = await ctx.json();
  const name = str(b.name, 80);
  const password = String(b.password ?? '');
  requireFields({ name }, ['name']);
  if (password.length < 6) throw bad('Şifrə ən azı 6 simvol olmalıdır', 'password_short');
  const phone = normalizePhone(b.phone);
  if (q.get('SELECT id FROM users WHERE phone = ?', phone)) {
    throw bad('Bu telefon nömrəsi artıq qeydiyyatdadır', 'phone_exists');
  }

  const role = b.role === 'vendor' ? 'vendor' : 'customer';
  const now = nowIso();
  const info = q.run(
    'INSERT INTO users (role, name, phone, email, password_hash, created_at) VALUES (?, ?, ?, ?, ?, ?)',
    role, name, phone, str(b.email, 120), hashPassword(password), now,
  );
  const userId = Number(info.lastInsertRowid);
  let vendor = null;

  if (role === 'vendor') {
    const { uniqueSlug } = await import('./db.js');
    const vname = str(b.vendorName || b.vendor?.name, 80) || `${name} mağazası`;
    const kind = b.vendorKind === 'market' ? 'market' : 'restaurant';
    const categorySlug = str(b.category, 60);
    const cat = q.get('SELECT id FROM categories WHERE slug = ?', categorySlug)
      ?? q.get(`SELECT id FROM categories WHERE kind = ? ORDER BY sort LIMIT 1`, kind);
    const slug = uniqueSlug(vname);
    const vres = q.run(`INSERT INTO vendors
      (owner_user_id, slug, name, kind, category_id, tagline, description, address, phone, logo,
       open, approved, prep_time, min_order, rating, rating_count, created_at)
      VALUES (?, ?, ?, ?, ?, ?, '', ?, ?, ?, 0, 0, ?, 0, 4.7, 0, ?)`,
      userId, slug, vname, kind, cat?.id ?? null, str(b.tagline, 120),
      str(b.address, 200), phone, kind === 'market' ? '🛒' : '🍽️',
      int(b.prepTime, 20), now);
    vendor = serializeVendor(q.get('SELECT * FROM vendors WHERE id = ?', Number(vres.lastInsertRowid)));
  }

  const { token, expires } = createSession(userId);
  return {
    __headers: { 'set-cookie': sessionCookie(token, expires) },
    user: publicUser(q.get('SELECT * FROM users WHERE id = ?', userId)),
    vendor,
    message: role === 'vendor'
      ? 'Qeydiyyat alındı. Mağazan admin təsdiqindən sonra satışa açılacaq.'
      : 'Xoş gəldiniz!',
  };
});

route('POST', '/api/auth/login', async (ctx) => {
  const b = await ctx.json();
  const phone = normalizePhone(b.phone);
  const user = q.get('SELECT * FROM users WHERE phone = ?', phone);
  if (!user || !verifyPassword(String(b.password ?? ''), user.password_hash)) {
    throw new HttpError(401, 'Telefon və ya şifrə yanlışdır', 'bad_credentials');
  }
  if (user.blocked) throw forbidden('Hesab bloklanıb');
  const { token, expires } = createSession(user.id);
  const vendor = user.role === 'vendor'
    ? serializeVendor(q.get('SELECT * FROM vendors WHERE owner_user_id = ?', user.id))
    : null;
  return {
    __headers: { 'set-cookie': sessionCookie(token, expires) },
    user: publicUser(user),
    vendor,
  };
});

route('POST', '/api/auth/logout', async (ctx) => {
  destroySession(ctx.req);
  return { __headers: { 'set-cookie': clearSessionCookie() }, ok: true };
});

route('GET', '/api/auth/me', async (ctx) => {
  if (!ctx.user) return { user: null, vendor: null };
  const vendor = ctx.user.role === 'vendor'
    ? serializeVendor(q.get('SELECT * FROM vendors WHERE owner_user_id = ?', ctx.user.id))
    : null;
  return { user: publicUser(ctx.user), vendor };
});

/* ------------------------------------------------------------------ *
 * Kataloq
 * ------------------------------------------------------------------ */
/** Sağlamlıq yoxlaması — yerləşdirmə (Render/Fly/Docker) və monitorinq üçün. */
route('GET', '/api/health', async () => ({
  ok: true,
  app: 'Götür',
  schema: schemaVersion(),
  startedAt: STARTED_AT,
  uptimeSeconds: Math.round(process.uptime()),
  counts: {
    vendors: q.get('SELECT COUNT(*) AS c FROM vendors').c,
    products: q.get('SELECT COUNT(*) AS c FROM products').c,
    orders: q.get('SELECT COUNT(*) AS c FROM orders').c,
  },
}));

route('GET', '/api/categories', async (ctx) => {
  const kind = ctx.query.get('kind');
  const rows = kind
    ? q.all('SELECT * FROM categories WHERE kind = ? ORDER BY sort', kind)
    : q.all('SELECT * FROM categories ORDER BY sort');
  return { categories: rows.map((c) => ({ id: c.id, slug: c.slug, name: c.name, icon: c.icon, kind: c.kind })) };
});

route('GET', '/api/vendors', async (ctx) => {
  const kind = ctx.query.get('kind');
  const catSlug = ctx.query.get('category');
  const search = (ctx.query.get('q') || '').trim().toLowerCase();
  const onlyOpen = ctx.query.get('open') === '1';

  const where = ['v.approved = 1'];
  const params = [];
  if (kind) { where.push('v.kind = ?'); params.push(kind); }
  if (catSlug) { where.push('c.slug = ?'); params.push(catSlug); }
  if (onlyOpen) where.push('v.open = 1');
  if (search) {
    where.push(`(LOWER(v.name) LIKE ? OR LOWER(v.tagline) LIKE ? OR LOWER(v.address) LIKE ?
      OR EXISTS (SELECT 1 FROM products p WHERE p.vendor_id = v.id AND p.active = 1 AND LOWER(p.name) LIKE ?))`);
    const like = `%${search}%`;
    params.push(like, like, like, like);
  }

  const rows = q.all(
    `SELECT v.*, (SELECT COUNT(*) FROM products p WHERE p.vendor_id = v.id AND p.active = 1) AS product_count
     FROM vendors v LEFT JOIN categories c ON c.id = v.category_id
     WHERE ${where.join(' AND ')}
     ORDER BY v.open DESC, v.rating DESC, v.name`,
    ...params,
  );

  // Müştərinin koordinatı verilibsə məsafə/vaxt hesablanır
  const lat = ctx.query.get('lat');
  const lng = ctx.query.get('lng');
  const hasFrom = isCoord(lat, lng);
  let vendors = rows.map((v) => ({ ...serializeVendor(v), productCount: v.product_count }));
  if (hasFrom) {
    vendors = sortByDistance(vendors, lat, lng);
    // «sort=nearby» açıq verilməyibsə, sadəcə məsafə əlavə olunur (sıra dəyişmir)
    if (ctx.query.get('sort') !== 'nearby') {
      vendors = rows.map((v) => withDistance({ ...serializeVendor(v), productCount: v.product_count }, lat, lng));
    }
  }
  return { vendors, origin: hasFrom ? { lat: Number(lat), lng: Number(lng) } : null };
});

route('GET', '/api/vendors/:slug', async (ctx) => {
  const v = q.get('SELECT * FROM vendors WHERE slug = ?', ctx.params.slug);
  if (!v || (!v.approved && ctx.user?.role !== 'admin' && ctx.user?.id !== v.owner_user_id)) {
    throw notFound('Mağaza tapılmadı');
  }
  const lat = ctx.query.get('lat');
  const lng = ctx.query.get('lng');
  const vendor = serializeVendor(v, { menu: true });
  return {
    vendor: isCoord(lat, lng) ? withDistance(vendor, lat, lng) : vendor,
    reviews: vendorReviews(v.id, { limit: 20 }),
    reviewSummary: reviewSummary(v.id),
    coupons: activeCouponsForVendor(v.id),
  };
});

/**
 * Yaxınlıqdakı mağazalar — növə görə qruplaşdırılmış və məsafəyə görə sıralanmış.
 *   GET /api/nearby?lat=40.68&lng=46.36&limit=6
 */
route('GET', '/api/nearby', async (ctx) => {
  const lat = ctx.query.get('lat');
  const lng = ctx.query.get('lng');
  if (!isCoord(lat, lng)) {
    throw bad('Məsafə üçün koordinat lazımdır (lat, lng)', 'coords_required');
  }
  const limit = Math.max(1, Math.min(20, int(ctx.query.get('limit'), 6)));
  const onlyOpen = ctx.query.get('open') !== '0';

  const rows = q.all(
    `SELECT v.*, (SELECT COUNT(*) FROM products p WHERE p.vendor_id = v.id AND p.active = 1) AS product_count
     FROM vendors v WHERE v.approved = 1 ${onlyOpen ? 'AND v.open = 1' : ''}`,
  );
  const withKm = rows
    .map((v) => withDistance({ ...serializeVendor(v), productCount: v.product_count }, lat, lng))
    .filter((v) => v.distanceKm !== null)
    .sort((a, b) => a.distanceKm - b.distanceKm);

  // Aptek: kateqoriya «aptek» və ya adında aptek/əczaxana açar sözü olan mağazalar
  const isPharmacy = (v) => (v.category?.slug || '').includes('aptek')
    || /aptek|əczaxana|eczane|pharmacy|аптек/i.test(v.name);

  const groups = {
    restaurants: withKm.filter((v) => v.kind === 'restaurant' && !isPharmacy(v)).slice(0, limit),
    markets: withKm.filter((v) => v.kind === 'market' && !isPharmacy(v)).slice(0, limit),
    pharmacies: withKm.filter(isPharmacy).slice(0, limit),
  };
  return {
    origin: { lat: Number(lat), lng: Number(lng) },
    groups,
    counts: {
      restaurants: withKm.filter((v) => v.kind === 'restaurant' && !isPharmacy(v)).length,
      markets: withKm.filter((v) => v.kind === 'market' && !isPharmacy(v)).length,
      pharmacies: withKm.filter(isPharmacy).length,
    },
  };
});

/* ------------------------------------------------------------------ *
 * Rəylər
 * ------------------------------------------------------------------ */
route('GET', '/api/vendors/:slug/reviews', async (ctx) => {
  const v = q.get('SELECT id FROM vendors WHERE slug = ?', ctx.params.slug);
  if (!v) throw notFound('Mağaza tapılmadı');
  return {
    reviews: vendorReviews(v.id, { limit: Math.min(100, int(ctx.query.get('limit'), 50)) }),
    summary: reviewSummary(v.id),
  };
});

route('POST', '/api/orders/:id/review', async (ctx) => {
  const order = q.get('SELECT * FROM orders WHERE id = ?', int(ctx.params.id));
  if (!order) throw notFound('Sifariş tapılmadı');
  const b = await ctx.json();
  assertCanReview(order, { user: ctx.user, code: b.code });
  const result = createReview(order, {
    rating: b.rating,
    comment: b.comment,
    authorName: b.authorName ?? ctx.user?.name,
    userId: ctx.user?.id ?? null,
  });
  return {
    ...result,
    order: serializeOrderFull(q.get(`${ORDER_SELECT} WHERE o.id = ?`, order.id)),
    message: 'Rəyiniz üçün təşəkkürlər!',
  };
});

route('GET', '/api/vendor/reviews', async (ctx) => {
  const v = myVendor(ctx);
  return {
    reviews: vendorReviews(v.id, { includeHidden: true, limit: 100 }),
    summary: reviewSummary(v.id),
  };
}, { roles: ['vendor'] });

route('POST', '/api/vendor/reviews/:id/reply', async (ctx) => {
  const v = myVendor(ctx);
  const b = await ctx.json();
  return { review: replyToReview(int(ctx.params.id), v.id, b.reply), message: 'Cavab göndərildi' };
}, { roles: ['vendor'] });

route('GET', '/api/admin/reviews', async (ctx) => ({
  reviews: adminReviews({
    vendorId: ctx.query.get('vendor') ? int(ctx.query.get('vendor')) : null,
    hidden: ctx.query.get('hidden') === null ? null : ctx.query.get('hidden') === '1',
  }),
}), { roles: ['admin'] });

route('PATCH', '/api/admin/reviews/:id', async (ctx) => {
  const b = await ctx.json();
  return setReviewHidden(int(ctx.params.id), bool(b.hidden));
}, { roles: ['admin'] });

/* ------------------------------------------------------------------ *
 * Kuponlar
 * ------------------------------------------------------------------ */
route('POST', '/api/coupons/validate', async (ctx) => {
  const b = await ctx.json();
  const vendor = q.get('SELECT id, name FROM vendors WHERE id = ?', int(b.vendorId));
  if (!vendor) throw notFound('Mağaza tapılmadı');
  const subtotal = Math.max(0, int(b.subtotal, 0));
  try {
    const { coupon, discount } = validateCoupon({
      code: b.code,
      vendorId: vendor.id,
      subtotal,
      userId: ctx.user?.id ?? null,
      phone: ctx.user?.phone ?? normalizePhoneSafe(b.phone),
    });
    return {
      valid: true,
      code: coupon.code,
      discount,
      description: coupon.description,
      kind: coupon.kind,
      value: coupon.value,
      total: Math.max(0, subtotal - discount),
    };
  } catch (err) {
    if (err instanceof HttpError && err.status === 400) {
      return { valid: false, error: err.message, discount: 0 };
    }
    throw err;
  }
});

const normalizePhoneSafe = (value) => {
  try { return value ? normalizePhone(value) : null; } catch { return null; }
};

route('GET', '/api/vendors/:slug/coupons', async (ctx) => {
  const v = q.get('SELECT id FROM vendors WHERE slug = ?', ctx.params.slug);
  if (!v) throw notFound('Mağaza tapılmadı');
  return { coupons: activeCouponsForVendor(v.id, new Date(), 10) };
});

route('GET', '/api/vendor/coupons', async (ctx) => {
  const v = myVendor(ctx);
  return { coupons: listCoupons({ vendorId: v.id }) };
}, { roles: ['vendor'] });

route('POST', '/api/vendor/coupons', async (ctx) => {
  const v = myVendor(ctx);
  const b = await ctx.json();
  return { coupon: createCoupon(b, { vendorId: v.id }), message: 'Kampaniya yaradıldı' };
}, { roles: ['vendor'] });

route('PATCH', '/api/vendor/coupons/:id', async (ctx) => {
  const v = myVendor(ctx);
  const b = await ctx.json();
  return { coupon: updateCoupon(int(ctx.params.id), b, { vendorId: v.id }) };
}, { roles: ['vendor'] });

route('DELETE', '/api/vendor/coupons/:id', async (ctx) => {
  const v = myVendor(ctx);
  deleteCoupon(int(ctx.params.id), { vendorId: v.id });
  return { ok: true };
}, { roles: ['vendor'] });

route('GET', '/api/admin/coupons', async () => ({
  coupons: listCoupons({ isAdmin: true }),
}), { roles: ['admin'] });

route('POST', '/api/admin/coupons', async (ctx) => {
  const b = await ctx.json();
  const vendorId = b.vendorId ? int(b.vendorId) : null;
  return { coupon: createCoupon(b, { vendorId }), message: 'Kampaniya yaradıldı' };
}, { roles: ['admin'] });

route('PATCH', '/api/admin/coupons/:id', async (ctx) => {
  const b = await ctx.json();
  return { coupon: updateCoupon(int(ctx.params.id), b, { isAdmin: true }) };
}, { roles: ['admin'] });

route('DELETE', '/api/admin/coupons/:id', async (ctx) => {
  deleteCoupon(int(ctx.params.id), { isAdmin: true });
  return { ok: true };
}, { roles: ['admin'] });

/* ------------------------------------------------------------------ *
 * Satıcı paneli
 * ------------------------------------------------------------------ */
function myVendor(ctx) {
  const v = q.get('SELECT * FROM vendors WHERE owner_user_id = ?', ctx.user.id);
  if (!v) throw notFound('Bu hesaba bağlı mağaza yoxdur');
  return v;
}

route('GET', '/api/vendor/me', async (ctx) => {
  const v = myVendor(ctx);
  const stats = vendorStats(v.id);
  return { vendor: serializeVendor(v), stats };
}, { roles: ['vendor'] });

route('PATCH', '/api/vendor/me', async (ctx) => {
  const v = myVendor(ctx);
  const b = await ctx.json();
  const fields = {
    name: b.name !== undefined ? str(b.name, 80) : v.name,
    tagline: b.tagline !== undefined ? str(b.tagline, 140) : v.tagline,
    description: b.description !== undefined ? str(b.description, 600) : v.description,
    address: b.address !== undefined ? str(b.address, 200) : v.address,
    phone: b.phone !== undefined ? str(b.phone, 40) : v.phone,
    logo: b.logo !== undefined ? str(b.logo, 300) : v.logo,
    open: b.open !== undefined ? bool(b.open) : v.open,
    prep_time: b.prepTime !== undefined ? Math.max(1, Math.min(240, int(b.prepTime, v.prep_time))) : v.prep_time,
    min_order: b.minOrder !== undefined ? Math.max(0, int(b.minOrder, v.min_order)) : v.min_order,
    kind: b.kind === 'market' || b.kind === 'restaurant' ? b.kind : v.kind,
  };
  if (b.category) {
    const cat = q.get('SELECT id FROM categories WHERE slug = ?', str(b.category, 60));
    if (cat) fields.category_id = cat.id;
  }
  // Xəritə koordinatları — müştəriyə məsafə/vaxt göstərmək üçün.
  // null / boş göndərilərsə yer silinir.
  const coordFields = [];
  if (b.lat !== undefined || b.lng !== undefined) {
    const lat = b.lat === null || b.lat === '' ? null : Number(b.lat);
    const lng = b.lng === null || b.lng === '' ? null : Number(b.lng);
    if (lat === null || lng === null) {
      coordFields.push('lat = NULL', 'lng = NULL');
    } else {
      if (!isCoord(lat, lng)) throw bad('Koordinatlar düzgün deyil', 'coords_invalid');
      coordFields.push('lat = ?', 'lng = ?');
      fields.lat = lat;
      fields.lng = lng;
    }
  }
  const coordSql = coordFields.length ? `, ${coordFields.join(', ')}` : '';
  const coordParams = 'lat' in fields ? [fields.lat, fields.lng] : [];
  q.run(`UPDATE vendors SET name = ?, tagline = ?, description = ?, address = ?, phone = ?, logo = ?,
         open = ?, prep_time = ?, min_order = ?, kind = ?${'category_id' in fields ? ', category_id = ?' : ''}${coordSql}
         WHERE id = ?`,
    fields.name, fields.tagline, fields.description, fields.address, fields.phone, fields.logo,
    fields.open, fields.prep_time, fields.min_order, fields.kind,
    ...('category_id' in fields ? [fields.category_id] : []), ...coordParams, v.id);
  return { vendor: serializeVendor(q.get('SELECT * FROM vendors WHERE id = ?', v.id)) };
}, { roles: ['vendor'] });

route('GET', '/api/vendor/products', async (ctx) => {
  const v = myVendor(ctx);
  const rows = q.all('SELECT * FROM products WHERE vendor_id = ? ORDER BY section, sort, id', v.id);
  return { products: rows.map(serializeProduct) };
}, { roles: ['vendor'] });

function productPayload(b, current = {}) {
  const name = b.name !== undefined ? str(b.name, 100) : current.name;
  requireFields({ name }, ['name']);
  const priceRaw = b.price !== undefined ? b.price : (current.price ?? 0) / 100;
  const price = Math.round(Number(priceRaw) * 100);
  if (!Number.isFinite(price) || price <= 0) throw bad('Qiymət düzgün deyil');
  let stock = current.stock ?? null;
  if (b.stock !== undefined) {
    stock = b.stock === null || b.stock === '' ? null : Math.max(0, int(b.stock, 0));
  }
  return {
    section: b.section !== undefined ? (str(b.section, 60) || 'Menyu') : (current.section ?? 'Menyu'),
    name,
    description: b.description !== undefined ? str(b.description, 300) : (current.description ?? ''),
    price,
    unit: b.unit !== undefined ? (str(b.unit, 20) || 'ədəd') : (current.unit ?? 'ədəd'),
    image: b.image !== undefined ? (str(b.image, 300) || '🍽️') : (current.image ?? '🍽️'),
    stock,
    active: b.active !== undefined ? bool(b.active) : (current.active ?? 1),
  };
}

route('POST', '/api/vendor/products', async (ctx) => {
  const v = myVendor(ctx);
  const p = productPayload(await ctx.json());
  const maxSort = q.get('SELECT COALESCE(MAX(sort), 0) AS m FROM products WHERE vendor_id = ?', v.id).m;
  const info = q.run(`INSERT INTO products
    (vendor_id, section, name, description, price, unit, image, stock, active, sort, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    v.id, p.section, p.name, p.description, p.price, p.unit, p.image, p.stock, p.active, maxSort + 1, nowIso());
  return { product: serializeProduct(q.get('SELECT * FROM products WHERE id = ?', Number(info.lastInsertRowid))) };
}, { roles: ['vendor'] });

route('PATCH', '/api/vendor/products/:id', async (ctx) => {
  const v = myVendor(ctx);
  const current = q.get('SELECT * FROM products WHERE id = ? AND vendor_id = ?', int(ctx.params.id), v.id);
  if (!current) throw notFound('Məhsul tapılmadı');
  const p = productPayload(await ctx.json(), current);
  q.run(`UPDATE products SET section = ?, name = ?, description = ?, price = ?, unit = ?, image = ?,
         stock = ?, active = ? WHERE id = ?`,
    p.section, p.name, p.description, p.price, p.unit, p.image, p.stock, p.active, current.id);
  return { product: serializeProduct(q.get('SELECT * FROM products WHERE id = ?', current.id)) };
}, { roles: ['vendor'] });

route('DELETE', '/api/vendor/products/:id', async (ctx) => {
  const v = myVendor(ctx);
  const info = q.run('DELETE FROM products WHERE id = ? AND vendor_id = ?', int(ctx.params.id), v.id);
  if (!info.changes) throw notFound('Məhsul tapılmadı');
  return { ok: true };
}, { roles: ['vendor'] });

route('GET', '/api/vendor/orders', async (ctx) => {
  const v = myVendor(ctx);
  const status = ctx.query.get('status');
  const scope = ctx.query.get('scope') || 'active';
  const where = ['o.vendor_id = ?'];
  const params = [v.id];
  if (status && status !== 'all') {
    const list = status.split(',');
    where.push(`o.status IN (${list.map(() => '?').join(',')})`);
    params.push(...list);
  } else if (!status && scope === 'active') {
    where.push("o.status IN ('pending','accepted','preparing','ready')");
  }
  if (ctx.query.get('today') === '1') {
    where.push('o.created_at >= ?');
    params.push(startOfDay());
  }
  const rows = q.all(`${ORDER_SELECT} WHERE ${where.join(' AND ')} ORDER BY o.created_at DESC LIMIT 200`, ...params);
  return { orders: withItems(rows), counts: vendorCounts(v.id) };
}, { roles: ['vendor'] });

route('POST', '/api/vendor/orders/:id/status', async (ctx) => {
  const v = myVendor(ctx);
  const order = q.get('SELECT * FROM orders WHERE id = ? AND vendor_id = ?', int(ctx.params.id), v.id);
  if (!order) throw notFound('Sifariş tapılmadı');
  const b = await ctx.json();
  const next = str(b.status, 20);
  const allowed = {
    pending: ['accepted', 'cancelled'],
    accepted: ['preparing', 'cancelled'],
    preparing: ['ready', 'cancelled'],
    ready: ['picked_up'],
  }[order.status] ?? [];
  if (!allowed.includes(next)) {
    throw bad(`«${order.status}» statusundan «${next}» statusuna keçmək olmaz`, 'status_transition', {
      from: order.status, to: next,
    });
  }
  await applyStatusWithRefund(order, next, str(b.note, 200));
  return { order: serializeOrderFull(q.get(`${ORDER_SELECT} WHERE o.id = ?`, order.id)) };
}, { roles: ['vendor'] });

/** Ödənişi olan sifariş ləğv edilərsə, pul avtomatik geri qaytarılır. */
async function applyStatusWithRefund(order, next, note = '') {
  applyStatus(order, next, note);
  if (next === 'cancelled') {
    try {
      await refundOrder(order, note || 'Sifariş ləğv edildi');
    } catch (err) {
      console.error('[gotur] refund alınmadı:', err.message);
    }
  }
  return q.get('SELECT * FROM orders WHERE id = ?', order.id);
}

/** Kassada ödənişin qeydə alınması (nağd və ya kart). */
route('POST', '/api/vendor/orders/:id/collect', async (ctx) => {
  const v = myVendor(ctx);
  const order = q.get('SELECT * FROM orders WHERE id = ? AND vendor_id = ?', int(ctx.params.id), v.id);
  if (!order) throw notFound('Sifariş tapılmadı');
  const b = await ctx.json();
  collectAtCounter(order, b.method === 'card' ? 'card' : 'cash');
  return { order: serializeOrderFull(q.get(`${ORDER_SELECT} WHERE o.id = ?`, order.id)) };
}, { roles: ['vendor'] });

route('GET', '/api/vendor/stats', async (ctx) => {
  const v = myVendor(ctx);
  return vendorStats(v.id);
}, { roles: ['vendor'] });

/* ------------------------------------------------------------------ *
 * Komissiya və hesablaşma
 * ------------------------------------------------------------------ */
route('GET', '/api/vendor/settlement', async (ctx) => {
  const v = myVendor(ctx);
  return {
    ...vendorSettlement(v.id, {
      from: ctx.query.get('from') ?? undefined,
      to: ctx.query.get('to') ?? undefined,
    }),
    settings: getSettings(),
    history: listSettlements({ vendorId: v.id, limit: 24 }),
  };
}, { roles: ['vendor'] });

route('GET', '/api/admin/settlements', async (ctx) => ({
  ...platformSettlement({
    from: ctx.query.get('from') ?? undefined,
    to: ctx.query.get('to') ?? undefined,
  }),
  settings: getSettings(),
  history: listSettlements({ limit: 100 }),
}), { roles: ['admin'] });

route('POST', '/api/admin/settlements', async (ctx) => {
  const b = await ctx.json();
  const vendorId = int(b.vendorId);
  if (!vendorId) throw bad('Mağaza seçilməlidir', 'field_required', { field: 'vendorId' });
  return {
    settlement: createSettlement({ vendorId, from: b.from, to: b.to, note: b.note }),
    message: 'Hesablaşma yaradıldı',
  };
}, { roles: ['admin'] });

route('PATCH', '/api/admin/settlements/:id', async (ctx) => {
  const b = await ctx.json();
  return {
    settlement: markSettlementPaid(int(ctx.params.id), { note: b.note }),
    message: 'Hesablaşma ödənildi kimi qeydə alındı',
  };
}, { roles: ['admin'] });

route('DELETE', '/api/admin/settlements/:id', async (ctx) => {
  deleteSettlement(int(ctx.params.id));
  return { ok: true };
}, { roles: ['admin'] });

route('GET', '/api/admin/settings', async () => ({ settings: getSettings() }), { roles: ['admin'] });

route('PATCH', '/api/admin/settings', async (ctx) => {
  const b = await ctx.json();
  if (b.defaultCommission !== undefined) {
    const value = Number(b.defaultCommission);
    if (!Number.isFinite(value) || value < 0 || value > 40) {
      throw bad('Komissiya 0–40% arasında olmalıdır', 'commission_invalid', { min: 0, max: 40 });
    }
    setSetting('default_commission', value);
    // Fərdi faizi olmayan mağazaların gözləyən sifarişlərini yenilə
    for (const vendor of q.all('SELECT id FROM vendors WHERE commission_percent = 0')) {
      q.run(
        `UPDATE orders SET commission = CAST(ROUND(subtotal * ? / 100.0) AS INTEGER),
           vendor_payout = total - CAST(ROUND(subtotal * ? / 100.0) AS INTEGER)
         WHERE vendor_id = ? AND status IN ('pending','accepted','preparing')`,
        value, value, vendor.id,
      );
    }
  }
  if (b.platformName !== undefined) setSetting('platform_name', str(b.platformName, 60));
  return { settings: getSettings(), message: 'Tənzimləmələr yeniləndi' };
}, { roles: ['admin'] });

/* ------------------------------------------------------------------ *
 * Müştəri sifarişləri
 * ------------------------------------------------------------------ */
route('POST', '/api/orders', async (ctx) => {
  const b = await ctx.json();
  const vendor = q.get('SELECT * FROM vendors WHERE id = ?', int(b.vendorId));
  if (!vendor) throw notFound('Mağaza tapılmadı');
  if (!vendor.approved) throw bad('Bu mağaza hələ təsdiqlənməyib', 'store_not_approved');
  if (!vendor.open) throw bad(`${vendor.name} hazırda sifariş qəbul etmir`, 'store_closed', { name: vendor.name });

  const rawItems = Array.isArray(b.items) ? b.items : [];
  if (!rawItems.length) throw bad('Səbət boşdur', 'cart_empty');
  if (rawItems.length > 60) throw bad('Səbətdə çox məhsul var', 'cart_too_many');

  const name = str(b.name, 80) || ctx.user?.name || '';
  const phoneRaw = b.phone || ctx.user?.phone;
  requireFields({ name }, ['name']);
  const phone = normalizePhone(phoneRaw ?? '');

  const lines = [];
  let subtotal = 0;
  for (const it of rawItems) {
    const product = q.get('SELECT * FROM products WHERE id = ? AND vendor_id = ?', int(it.productId), vendor.id);
    if (!product || !product.active) throw bad('Məhsul mövcud deyil', 'product_missing');
    const qty = Math.max(1, Math.min(99, int(it.qty, 1)));
    if (product.stock !== null && product.stock < qty) {
      throw bad(`«${product.name}» üçün anbarda yalnız ${product.stock} ${product.unit} qalıb`, 'stock_low', {
        name: product.name, count: product.stock, unit: product.unit,
      });
    }
    lines.push({ product, qty });
    subtotal += product.price * qty;
  }
  if (subtotal < vendor.min_order) {
    throw bad(`Minimum sifariş məbləği ${(vendor.min_order / 100).toFixed(2)} ₼-dir`, 'min_order', {
      amount: `${(vendor.min_order / 100).toFixed(2)} ₼`,
    });
  }

  // Kupon (əgər göndərilibsə) — bütün yoxlamalar serverdə aparılır
  let coupon = null;
  let discount = 0;
  if (b.coupon) {
    const check = validateCoupon({
      code: b.coupon,
      vendorId: vendor.id,
      subtotal,
      userId: ctx.user?.id ?? null,
      phone,
    });
    coupon = check.coupon;
    discount = check.discount;
  }
  const total = Math.max(0, subtotal - discount);
  // Platforma komissiyası və mağaza payı (Mərhələ 5)
  const { percent: commissionPercent, commission, payout } = commissionForOrder({ subtotal, total, vendor });

  const payment = ['cash', 'card', 'online'].includes(b.payment) ? b.payment : 'cash';
  const now = nowIso();
  const code = orderCode((q.get('SELECT COALESCE(MAX(id), 0) AS m FROM orders').m + 1));
  const info = q.run(`INSERT INTO orders
    (code, customer_user_id, customer_name, customer_phone, vendor_id, status, subtotal, discount,
     coupon_code, fee, total, commission, vendor_payout, payment, pickup_code, note, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, 'pending', ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?)`,
    code, ctx.user?.id ?? null, name, phone, vendor.id, subtotal, discount,
    coupon?.code ?? null, total, commission, payout, payment, randomDigits(4), str(b.note, 300), now, now);
  const orderId = Number(info.lastInsertRowid);

  for (const { product, qty } of lines) {
    q.run(`INSERT INTO order_items (order_id, product_id, name, price, qty, unit, image)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
      orderId, product.id, product.name, product.price, qty, product.unit, product.image);
    if (product.stock !== null) {
      q.run('UPDATE products SET stock = stock - ? WHERE id = ?', qty, product.id);
    }
  }
  q.run('INSERT INTO order_events (order_id, status, note, created_at) VALUES (?, ?, ?, ?)',
    orderId, 'pending', 'Sifariş yaradıldı', now);
  if (coupon) {
    consumeCoupon(coupon);
    q.run('INSERT INTO order_events (order_id, status, note, created_at) VALUES (?, ?, ?, ?)',
      orderId, 'discount', `Kupon tətbiq edildi: ${coupon.code} (−${(discount / 100).toFixed(2)} ₼)`, now);
  }

  const order = q.get(`${ORDER_SELECT} WHERE o.id = ?`, orderId);
  const paymentInit = await createPaymentForOrder(order);
  const full = serializeOrderFull(q.get(`${ORDER_SELECT} WHERE o.id = ?`, orderId));
  publish('order.created', {
    order: {
      id: full.id,
      code: full.code,
      status: full.status,
      pickupCode: full.pickupCode,
      customerName: full.customerName,
      customerPhone: full.customerPhone,
      total: full.total,
      payment: full.payment,
      paymentStatus: full.paymentStatus,
      itemCount: full.itemCount,
      items: full.items,
      note: full.note,
      createdAt: full.createdAt,
    },
  }, {
    vendorId: vendor.id,
    customerUserId: ctx.user?.id ?? null,
    codes: [full.code],
    orderId: full.id,
  });
  return {
    order: full,
    payment: paymentInit
      ? { ...serializePayment(paymentInit.payment), redirectUrl: paymentInit.redirectUrl }
      : null,
    message: paymentInit
      ? `Sifariş qəbul edildi. Ödənişi tamamlayın — götürmə kodu: ${order.pickup_code}`
      : `Sifariş qəbul edildi. Götürmə kodu: ${order.pickup_code}`,
  };
});

route('GET', '/api/orders', async (ctx) => {
  if (!ctx.user) return { orders: [] };
  const rows = q.all(`${ORDER_SELECT} WHERE o.customer_user_id = ? ORDER BY o.created_at DESC LIMIT 100`, ctx.user.id);
  return { orders: rows.map(serializeOrderBasic) };
});

route('GET', '/api/orders/:code', async (ctx) => {
  const key = ctx.params.code;
  const order = q.get(`${ORDER_SELECT} WHERE o.code = ? OR o.id = ?`, key, int(key, -1));
  if (!order) throw notFound('Sifariş tapılmadı');
  const mine = ctx.user && order.customer_user_id === ctx.user.id;
  const isVendor = ctx.user && q.get('SELECT id FROM vendors WHERE id = ? AND owner_user_id = ?', order.vendor_id, ctx.user.id);
  const isAdmin = ctx.user?.role === 'admin';
  if (!mine && !isVendor && !isAdmin) {
    // Qonaq sifarişi: kodu bilən izləyə bilər (Wolt-da olduğu kimi link/kod ilə)
    if (order.customer_user_id) throw forbidden('Bu sifarişə baxmaq icazəniz yoxdur');
  }
  return { order: serializeOrderFull(order) };
});

route('POST', '/api/orders/:id/cancel', async (ctx) => {
  const order = q.get('SELECT * FROM orders WHERE id = ?', int(ctx.params.id));
  if (!order) throw notFound('Sifariş tapılmadı');
  const body = await ctx.json().catch(() => ({}));

  const isOwner = ctx.user && ctx.user.id === order.customer_user_id;
  const isAdmin = ctx.user?.role === 'admin';
  // Qonaq sifarişi: sifariş kodunu bilmək kifayətdir (kod sifarişin sirridir)
  const guestWithCode = !order.customer_user_id
    && String(body.code ?? '').trim().toUpperCase() === order.code;
  if (!isOwner && !isAdmin && !guestWithCode) {
    throw forbidden('Bu sifarişi ləğv etmək üçün sifariş kodu lazımdır');
  }
  if (order.status !== 'pending') {
    throw bad('Sifariş artıq hazırlanır — ləğv etmək üçün mağazanı zəng edin', 'cancel_too_late');
  }
  await applyStatusWithRefund(order, 'cancelled', 'Müştəri ləğv etdi');
  return { order: serializeOrderFull(q.get(`${ORDER_SELECT} WHERE o.id = ?`, order.id)) };
});

/* ------------------------------------------------------------------ *
 * Ödənişlər
 * ------------------------------------------------------------------ */
const orderCodeOfPayment = (payment) =>
  q.get('SELECT code FROM orders WHERE id = ?', payment.order_id)?.code ?? null;

route('GET', '/api/payments/:token', async (ctx) => {
  const payment = getPaymentByToken(ctx.params.token);
  if (!payment) throw notFound('Ödəniş tapılmadı');
  return { payment: checkoutInfo(payment), orderCode: orderCodeOfPayment(payment) };
});

route('POST', '/api/payments/:token/pay', async (ctx) => {
  const b = await ctx.json();
  const payment = paySimulated(ctx.params.token, b);
  const order = q.get(`${ORDER_SELECT} WHERE o.id = ?`, payment.order_id);
  return {
    payment: serializePayment(payment),
    order: serializeOrderFull(order),
    message: 'Ödəniş uğurla tamamlandı',
  };
});

route('POST', '/api/payments/:token/decline', async (ctx) => {
  const payment = getPaymentByToken(ctx.params.token);
  if (!payment) throw notFound('Ödəniş tapılmadı');
  if (payment.status === 'paid') throw bad('Ödəniş artıq tamamlanıb');
  const b = await ctx.json().catch(() => ({}));
  const updated = markFailed(payment, str(b.reason, 120) || 'İstifadəçi ödənişi yarımçıq saxladı');
  return { payment: serializePayment(updated), orderCode: orderCodeOfPayment(updated) };
});

/** Stripe hosted checkout-dan qayıdan istifadəçi üçün təsdiq. */
route('GET', '/api/payments/stripe/confirm', async (ctx) => {
  const sessionId = ctx.query.get('session_id');
  if (!sessionId) throw bad('session_id tələb olunur');
  if (!stripeEnabled()) throw new HttpError(503, 'Stripe konfiqurasiya edilməyib', 'stripe_off');
  const payment = await confirmStripeSession(sessionId);
  return {
    payment: serializePayment(payment),
    orderCode: orderCodeOfPayment(payment),
    message: payment.status === 'paid' ? 'Ödəniş təsdiqləndi' : 'Ödəniş hələ tamamlanmayıb',
  };
});

/** Stripe webhook — imza HMAC-SHA256 ilə yoxlanılır (SDK yoxdur). */
route('POST', '/api/payments/stripe/webhook', async (ctx) => {
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  const signature = ctx.req.headers['stripe-signature'];
  let event;
  try {
    event = await ctx.json();
  } catch {
    throw bad('Webhook gövdəsi JSON deyil');
  }
  const raw = ctx.req._rawBody ?? '';
  if (secret && !verifyStripeSignature(raw, signature, secret)) {
    throw new HttpError(400, 'Webhook imzası yanlışdır', 'bad_signature');
  }
  const type = event?.type;
  if (type === 'checkout.session.completed' || type === 'checkout.session.async_payment_succeeded') {
    const session = event.data?.object ?? {};
    const payment = q.get("SELECT * FROM payments WHERE provider = 'stripe' AND provider_ref = ?", session.id);
    if (payment && payment.status !== 'paid') {
      const expected = Number(session.amount_total ?? payment.amount);
      if (expected !== payment.amount) {
        markFailed(payment, `Məbləğ uyğun deyil: gözlənilən ${payment.amount}, gələn ${expected}`);
      } else {
        markPaid(payment, {
          providerRef: session.id,
          providerIntent: session.payment_intent ?? null,
          method: 'online',
        });
      }
    }
  }
  if (type === 'charge.refunded') {
    const charge = event.data?.object ?? {};
    const intent = charge.payment_intent;
    if (intent) {
      q.run(
        `UPDATE payments SET status = 'refunded', refunded_at = ?
         WHERE provider = 'stripe' AND (provider_intent = ? OR provider_ref = ?)`,
        nowIso(), intent, intent,
      );
    }
  }
  return { received: true, type: type ?? 'unknown' };
});

/* ------------------------------------------------------------------ *
 * Real vaxt (SSE)
 * ------------------------------------------------------------------ */
route('GET', '/api/events', async (ctx) => {
  const { res, req, user } = ctx;
  const scope = ctx.query.get('scope') ?? 'orders';
  const codes = (ctx.query.get('orders') ?? '')
    .split(',')
    .map((c) => c.trim().toUpperCase())
    .filter(Boolean)
    .slice(0, 20);

  let filter;
  let kind;
  if (scope === 'vendor') {
    if (!user || user.role !== 'vendor') throw unauthorized('Satıcı axını üçün giriş tələb olunur');
    const vendor = q.get('SELECT id FROM vendors WHERE owner_user_id = ?', user.id);
    if (!vendor) throw notFound('Bu hesaba bağlı mağaza yoxdur');
    kind = `vendor:${vendor.id}`;
    filter = (meta) => meta.vendorId === vendor.id;
  } else if (scope === 'admin') {
    if (!user || user.role !== 'admin') throw forbidden();
    kind = 'admin';
    filter = () => true;
  } else {
    if (!codes.length) throw bad('Ən azı bir sifariş kodu lazımdır (orders=GT-1001)');
    kind = `orders:${codes.join(',')}`;
    filter = (meta) => Array.isArray(meta.codes) && meta.codes.some((c) => codes.includes(c));
  }

  res.writeHead(200, {
    'content-type': 'text/event-stream; charset=utf-8',
    'cache-control': 'no-cache, no-transform',
    connection: 'keep-alive',
    'x-accel-buffering': 'no',
  });
  res.flushHeaders?.();

  const client = addClient(res, filter, { kind });
  const close = () => removeClient(client);
  req.on('close', close);
  req.on('error', close);
  return null; // cavab artıq axın şəklində yazılır
});

route('GET', '/api/events/stats', async () => ({
  clients: clientCount(),
  list: clientStats(),
}), { roles: ['admin'] });

/* ------------------------------------------------------------------ *
 * Admin
 * ------------------------------------------------------------------ */
route('GET', '/api/admin/stats', async (ctx) => ({
  totals: {
    users: q.get('SELECT COUNT(*) AS c FROM users').c,
    customers: q.get("SELECT COUNT(*) AS c FROM users WHERE role = 'customer'").c,
    vendors: q.get('SELECT COUNT(*) AS c FROM vendors').c,
    pendingVendors: q.get('SELECT COUNT(*) AS c FROM vendors WHERE approved = 0').c,
    products: q.get('SELECT COUNT(*) AS c FROM products WHERE active = 1').c,
    orders: q.get('SELECT COUNT(*) AS c FROM orders').c,
    ordersToday: q.get('SELECT COUNT(*) AS c FROM orders WHERE created_at >= ?', startOfDay()).c,
    gmvToday: q.get(`SELECT COALESCE(SUM(total), 0) AS s FROM orders
      WHERE created_at >= ? AND status IN ('ready','picked_up')`, startOfDay()).s,
    gmvTotal: q.get(`SELECT COALESCE(SUM(total), 0) AS s FROM orders
      WHERE status IN ('ready','picked_up')`).s,
    avgBasket: q.get(`SELECT COALESCE(AVG(total), 0) AS s FROM orders WHERE status != 'cancelled'`).s,
    onlinePaidToday: q.get(`SELECT COALESCE(SUM(amount), 0) AS s FROM payments
      WHERE status = 'paid' AND provider IN ('simulated','stripe') AND paid_at >= ?`, startOfDay()).s,
    counterPaidToday: q.get(`SELECT COALESCE(SUM(amount), 0) AS s FROM payments
      WHERE status = 'paid' AND provider = 'counter' AND paid_at >= ?`, startOfDay()).s,
    unpaidTotal: q.get(`SELECT COALESCE(SUM(total), 0) AS s FROM orders
      WHERE payment_status = 'unpaid' AND status NOT IN ('cancelled','picked_up')`).s,
    refundedTotal: q.get(`SELECT COALESCE(SUM(amount), 0) AS s FROM payments WHERE status = 'refunded'`).s,
    stripeActive: stripeEnabled(),
    reviews: q.get('SELECT COUNT(*) AS c FROM reviews WHERE hidden = 0').c,
    hiddenReviews: q.get('SELECT COUNT(*) AS c FROM reviews WHERE hidden = 1').c,
    newRatingAvg: q.get('SELECT COALESCE(AVG(rating), 0) AS s FROM reviews WHERE hidden = 0').s,
    activeCoupons: q.get('SELECT COUNT(*) AS c FROM coupons WHERE active = 1').c,
    couponOrders: q.get('SELECT COUNT(*) AS c FROM orders WHERE coupon_code IS NOT NULL AND status != ?', 'cancelled').c,
    couponDiscount: q.get(`SELECT COALESCE(SUM(discount), 0) AS s FROM orders WHERE status != 'cancelled'`).s,
    commissionTotal: q.get(`SELECT COALESCE(SUM(commission), 0) AS s FROM orders
      WHERE status IN ('ready','picked_up')`).s,
    commissionToday: q.get(`SELECT COALESCE(SUM(commission), 0) AS s FROM orders
      WHERE status IN ('ready','picked_up') AND created_at >= ?`, startOfDay()).s,
    payoutOnline: q.get(`SELECT COALESCE(SUM(vendor_payout), 0) AS s FROM orders
      WHERE status IN ('ready','picked_up') AND payment = 'online'`).s,
    commissionCounter: q.get(`SELECT COALESCE(SUM(commission), 0) AS s FROM orders
      WHERE status IN ('ready','picked_up') AND payment != 'online'`).s,
  },
  byStatus: q.all("SELECT status, COUNT(*) AS c FROM orders GROUP BY status").map((r) => ({ status: r.status, count: r.c })),
  byPaymentStatus: q.all('SELECT payment_status, COUNT(*) AS c FROM orders GROUP BY payment_status')
    .map((r) => ({ status: r.payment_status, count: r.c })),
  daily: dailySeries(7),
  topVendors: q.all(`SELECT v.name, v.slug, COUNT(o.id) AS orders, COALESCE(SUM(o.total), 0) AS revenue
     FROM vendors v LEFT JOIN orders o ON o.vendor_id = v.id AND o.status != 'cancelled'
     GROUP BY v.id ORDER BY revenue DESC LIMIT 6`)
    .map((r) => ({ name: r.name, slug: r.slug, orders: r.orders, revenue: r.revenue })),
}), { roles: ['admin'] });

route('GET', '/api/admin/payments', async (ctx) => {
  const where = [];
  const params = [];
  const status = ctx.query.get('status');
  if (status && status !== 'all') {
    const list = status.split(',');
    where.push(`p.status IN (${list.map(() => '?').join(',')})`);
    params.push(...list);
  }
  const provider = ctx.query.get('provider');
  if (provider && provider !== 'all') {
    where.push('p.provider = ?');
    params.push(provider);
  }
  const search = (ctx.query.get('q') || '').trim().toLowerCase();
  if (search) {
    where.push('(LOWER(o.code) LIKE ? OR LOWER(v.name) LIKE ? OR LOWER(o.customer_name) LIKE ?)');
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }
  const rows = q.all(
    `SELECT p.*, o.code AS order_code, o.payment AS order_payment, o.status AS order_status,
            v.name AS vendor_name, o.customer_name
     FROM payments p JOIN orders o ON o.id = p.order_id JOIN vendors v ON v.id = o.vendor_id
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
     ORDER BY p.created_at DESC LIMIT 200`,
    ...params,
  );
  const totals = q.get(`SELECT
      COALESCE(SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END), 0) AS paid,
      COALESCE(SUM(CASE WHEN status = 'refunded' THEN amount ELSE 0 END), 0) AS refunded,
      COALESCE(SUM(CASE WHEN status = 'failed' THEN amount ELSE 0 END), 0) AS failed,
      COALESCE(SUM(CASE WHEN status = 'requires_action' THEN amount ELSE 0 END), 0) AS pending
    FROM payments`);
  return {
    payments: rows.map((p) => ({
      ...serializePayment(p, { mask: true }),
      orderCode: p.order_code,
      orderStatus: p.order_status,
      vendorName: p.vendor_name,
      customerName: p.customer_name,
    })),
    totals,
  };
}, { roles: ['admin'] });

route('GET', '/api/admin/vendors', async (ctx) => {
  const rows = q.all(`SELECT v.*, u.name AS owner_name, u.phone AS owner_phone,
      (SELECT COUNT(*) FROM products p WHERE p.vendor_id = v.id) AS product_count,
      (SELECT COUNT(*) FROM orders o WHERE o.vendor_id = v.id) AS order_count,
      (SELECT COALESCE(SUM(total),0) FROM orders o WHERE o.vendor_id = v.id AND o.status != 'cancelled') AS revenue
    FROM vendors v LEFT JOIN users u ON u.id = v.owner_user_id
    ORDER BY v.approved ASC, v.created_at DESC`);
  return {
    vendors: rows.map((v) => ({
      ...serializeVendor(v),
      owner: { name: v.owner_name, phone: v.owner_phone },
      productCount: v.product_count,
      orderCount: v.order_count,
      revenue: v.revenue,
    })),
  };
}, { roles: ['admin'] });

/* ------------------------------------------------------------------ *
 * Admin: mağaza və kateqoriya idarəsi
 * ------------------------------------------------------------------ */

const STARTED_AT = nowIso();

/** Admin birbaşa yeni mağaza (və sahib hesabı) yaradır — sahibə giriş məlumatları verilir. */
route('POST', '/api/admin/vendors', async (ctx) => {
  const b = await ctx.json();
  const ownerName = str(b.ownerName ?? b.name, 80);
  requireFields({ ownerName }, ['ownerName']);
  const vendorName = str(b.vendorName, 80);
  requireFields({ vendorName }, ['vendorName']);

  const phone = normalizePhone(b.phone);
  if (q.get('SELECT id FROM users WHERE phone = ?', phone)) {
    throw bad('Bu telefon nömrəsi artıq qeydiyyatdadır', 'phone_exists');
  }

  // Şifrə verilməyibsə avtomatik yaradılır və adminə qaytarılır
  const providedPassword = String(b.password ?? '').trim();
  if (providedPassword && providedPassword.length < 6) {
    throw bad('Şifrə ən azı 6 simvol olmalıdır', 'password_short');
  }
  const password = providedPassword || randomPassword(10);

  const kind = b.kind === 'market' ? 'market' : 'restaurant';
  const categorySlug = str(b.category, 60);
  const category = (categorySlug && q.get('SELECT id FROM categories WHERE slug = ?', categorySlug))
    || q.get(`SELECT id FROM categories WHERE kind = ? ORDER BY sort LIMIT 1`, kind);

  const approved = b.approved === undefined ? 1 : bool(b.approved);
  const open = b.open === undefined ? approved : bool(b.open);
  const now = nowIso();

  const userInfo = q.run(
    'INSERT INTO users (role, name, phone, email, password_hash, created_at) VALUES (?, ?, ?, ?, ?, ?)',
    'vendor', ownerName, phone, str(b.email, 120), hashPassword(password), now,
  );
  const userId = Number(userInfo.lastInsertRowid);

  const slug = uniqueSlug(vendorName);
  const vendorInfo = q.run(`INSERT INTO vendors
    (owner_user_id, slug, name, kind, category_id, tagline, description, address, phone, logo,
     open, approved, prep_time, min_order, rating, rating_count, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?)`,
    userId, slug, vendorName, kind, category?.id ?? null,
    str(b.tagline, 140), str(b.description, 600), str(b.address, 200), str(b.vendorPhone ?? b.phone ?? phone, 40),
    str(b.logo, 300) || (kind === 'market' ? '🛒' : '🍽️'),
    open, approved, Math.max(1, Math.min(240, int(b.prepTime, 20))),
    Math.max(0, int(b.minOrder, 0)), now);
  const vendorId = Number(vendorInfo.lastInsertRowid);

  if (b.commissionPercent !== undefined) setVendorCommission(vendorId, b.commissionPercent);

  // Xəritə koordinatları (varsa)
  if (isCoord(b.lat, b.lng)) {
    q.run('UPDATE vendors SET lat = ?, lng = ? WHERE id = ?', Number(b.lat), Number(b.lng), vendorId);
  }

  return {
    vendor: serializeVendor(q.get('SELECT * FROM vendors WHERE id = ?', vendorId)),
    owner: { name: ownerName, phone },
    credentials: { phone, password, generated: !providedPassword },
    message: `«${vendorName}» yaradıldı. Sahibə giriş: ${phone} / ${password}`,
  };
}, { roles: ['admin'] });

route('GET', '/api/admin/categories', async () => ({
  categories: q.all(`
    SELECT c.*,
      (SELECT COUNT(*) FROM vendors v WHERE v.category_id = c.id) AS vendor_count,
      (SELECT COUNT(*) FROM products p JOIN vendors v ON v.id = p.vendor_id WHERE v.category_id = c.id) AS product_count
    FROM categories c ORDER BY c.kind, c.sort, c.name
  `).map((c) => ({
    id: c.id,
    slug: c.slug,
    name: c.name,
    icon: c.icon,
    kind: c.kind,
    sort: c.sort,
    vendorCount: c.vendor_count,
    productCount: c.product_count,
  })),
}), { roles: ['admin'] });

route('POST', '/api/admin/categories', async (ctx) => {
  const b = await ctx.json();
  const name = str(b.name, 60);
  requireFields({ name }, ['name']);
  const kind = b.kind === 'restaurant' ? 'restaurant' : 'market';
  // Slug unikal olmalıdır — səssizcə «aptek-2» yaratmaq qarışıqlıq yaradır
  const slug = slugify(b.slug || name, 'kateqoriya');
  if (q.get('SELECT id FROM categories WHERE slug = ?', slug)) {
    throw bad('Bu adda/slug-da kateqoriya artıq var', 'slug_exists');
  }
  const sort = int(b.sort, 0) || (q.get('SELECT COALESCE(MAX(sort), 0) + 1 AS n FROM categories').n);
  const info = q.run('INSERT INTO categories (slug, name, icon, kind, sort) VALUES (?, ?, ?, ?, ?)',
    slug, name, str(b.icon, 20) || (kind === 'market' ? '🛒' : '🍽️'), kind, sort);
  const created = q.get('SELECT * FROM categories WHERE id = ?', Number(info.lastInsertRowid));
  return {
    category: { id: created.id, slug: created.slug, name: created.name, icon: created.icon, kind: created.kind, sort: created.sort },
    message: `«${name}» kateqoriyası əlavə edildi`,
  };
}, { roles: ['admin'] });

route('PATCH', '/api/admin/categories/:id', async (ctx) => {
  const category = q.get('SELECT * FROM categories WHERE id = ?', int(ctx.params.id));
  if (!category) throw notFound('Kateqoriya tapılmadı');
  const b = await ctx.json();
  const name = b.name !== undefined ? str(b.name, 60) : category.name;
  requireFields({ name }, ['name']);
  const kind = b.kind === 'restaurant' || b.kind === 'market' ? b.kind : category.kind;
  let slug = b.slug !== undefined ? slugify(b.slug) : category.slug;
  if (!slug) slug = category.slug;
  const clash = q.get('SELECT id FROM categories WHERE slug = ? AND id != ?', slug, category.id);
  if (clash) throw bad('Bu slug artıq istifadə olunur', 'slug_exists');
  q.run('UPDATE categories SET name = ?, icon = ?, kind = ?, sort = ?, slug = ? WHERE id = ?',
    name, b.icon !== undefined ? (str(b.icon, 20) || category.icon) : category.icon,
    kind, b.sort !== undefined ? int(b.sort, category.sort) : category.sort, slug, category.id);
  const updated = q.get('SELECT * FROM categories WHERE id = ?', category.id);
  return {
    category: { id: updated.id, slug: updated.slug, name: updated.name, icon: updated.icon, kind: updated.kind, sort: updated.sort },
    message: 'Kateqoriya yeniləndi',
  };
}, { roles: ['admin'] });

route('DELETE', '/api/admin/categories/:id', async (ctx) => {
  const category = q.get('SELECT * FROM categories WHERE id = ?', int(ctx.params.id));
  if (!category) throw notFound('Kateqoriya tapılmadı');

  const used = q.get('SELECT COUNT(*) AS c FROM vendors WHERE category_id = ?', category.id).c;
  if (used > 0 && ctx.query.get('force') !== '1') {
    throw bad(`Bu kateqoriyada ${used} mağaza var. Əvvəlcə onları başqa kateqoriyaya keçirin`, 'category_in_use', {
      count: used, name: category.name,
    });
  }
  if (used > 0) {
    // force=1 → mağazalar kateqoriyasız qalır (admin bunu təsdiqləyib)
    q.run('UPDATE vendors SET category_id = NULL WHERE category_id = ?', category.id);
  }
  q.run('DELETE FROM categories WHERE id = ?', category.id);
  return {
    ok: true,
    movedVendors: used,
    message: used > 0
      ? `Kateqoriya silindi, ${used} mağaza kateqoriyasız qaldı`
      : 'Kateqoriya silindi',
  };
}, { roles: ['admin'] });

route('PATCH', '/api/admin/vendors/:id', async (ctx) => {
  const v = q.get('SELECT * FROM vendors WHERE id = ?', int(ctx.params.id));
  if (!v) throw notFound('Mağaza tapılmadı');
  const b = await ctx.json();
  const approved = b.approved !== undefined ? bool(b.approved) : v.approved;
  const open = b.open !== undefined ? bool(b.open) : v.open;
  q.run('UPDATE vendors SET approved = ?, open = ? WHERE id = ?', approved, open, v.id);
  if (b.commissionPercent !== undefined) {
    setVendorCommission(v.id, b.commissionPercent);
  }
  if (ctx.user.role === 'admin' && b.ownerPassword) {
    q.run('UPDATE users SET password_hash = ? WHERE id = ?', hashPassword(String(b.ownerPassword)), v.owner_user_id);
  }
  return {
    vendor: serializeVendor(q.get('SELECT * FROM vendors WHERE id = ?', v.id)),
    commissionPercent: commissionPercentFor(q.get('SELECT * FROM vendors WHERE id = ?', v.id)),
  };
}, { roles: ['admin'] });

route('GET', '/api/admin/orders', async (ctx) => {
  const where = [];
  const params = [];
  const status = ctx.query.get('status');
  if (status && status !== 'all') {
    const list = status.split(',');
    where.push(`o.status IN (${list.map(() => '?').join(',')})`);
    params.push(...list);
  }
  const search = (ctx.query.get('q') || '').trim().toLowerCase();
  if (search) {
    where.push('(LOWER(o.code) LIKE ? OR LOWER(o.customer_name) LIKE ? OR LOWER(v.name) LIKE ?)');
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }
  const rows = q.all(
    `${ORDER_SELECT} ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY o.created_at DESC LIMIT 200`,
    ...params,
  );
  return { orders: withItems(rows) };
}, { roles: ['admin'] });

route('GET', '/api/admin/users', async (ctx) => ({
  users: q.all(`SELECT u.id, u.role, u.name, u.phone, u.blocked, u.created_at,
      (SELECT COUNT(*) FROM orders o WHERE o.customer_user_id = u.id) AS order_count,
      (SELECT COALESCE(SUM(total),0) FROM orders o WHERE o.customer_user_id = u.id AND status != 'cancelled') AS spent
    FROM users u ORDER BY u.created_at DESC LIMIT 200`)
    .map((u) => ({
      id: u.id, role: u.role, name: u.name, phone: u.phone, blocked: !!u.blocked,
      createdAt: u.created_at, orderCount: u.order_count, spent: u.spent,
    })),
}), { roles: ['admin'] });

route('PATCH', '/api/admin/users/:id', async (ctx) => {
  const user = q.get('SELECT * FROM users WHERE id = ?', int(ctx.params.id));
  if (!user) throw notFound('İstifadəçi tapılmadı');
  const b = await ctx.json();
  if (b.blocked !== undefined) {
    if (user.role === 'admin') throw bad('Admin hesabını bloklamaq olmaz');
    q.run('UPDATE users SET blocked = ? WHERE id = ?', bool(b.blocked), user.id);
  }
  return { ok: true };
}, { roles: ['admin'] });

/* ------------------------------------------------------------------ *
 * Köməkçi hesablamalar
 * ------------------------------------------------------------------ */
function applyStatus(order, next, note = '') {
  const now = nowIso();
  const readyAt = next === 'ready' ? now : order.ready_at;
  const pickedUpAt = next === 'picked_up' ? now : order.picked_up_at;
  q.run('UPDATE orders SET status = ?, updated_at = ?, ready_at = ?, picked_up_at = ? WHERE id = ?',
    next, now, readyAt, pickedUpAt, order.id);
  q.run('INSERT INTO order_events (order_id, status, note, created_at) VALUES (?, ?, ?, ?)',
    order.id, next, note, now);
  if (next === 'cancelled' && order.status !== 'cancelled') {
    restoreStock(order.id);
    releaseCoupon(order);
  }

  publish('order.status', {
    orderId: order.id,
    code: order.code,
    status: next,
    note,
    pickupCode: order.pickup_code,
    updatedAt: now,
  }, {
    vendorId: order.vendor_id,
    customerUserId: order.customer_user_id,
    codes: [order.code],
    orderId: order.id,
  });
}

/** Ləğv edilən sifarişin məhsullarını anbara qaytarır (yalnız qalığı izlənən məhsullar). */
function restoreStock(orderId) {
  const items = q.all('SELECT product_id, qty FROM order_items WHERE order_id = ?', orderId);
  for (const it of items) {
    if (it.product_id) {
      q.run('UPDATE products SET stock = stock + ? WHERE id = ? AND stock IS NOT NULL', it.qty, it.product_id);
    }
  }
}

export function startOfDay(date = new Date()) {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d.toISOString();
}

function vendorCounts(vendorId) {
  const rows = q.all('SELECT status, COUNT(*) AS c FROM orders WHERE vendor_id = ? GROUP BY status', vendorId);
  const counts = { pending: 0, accepted: 0, preparing: 0, ready: 0, picked_up: 0, cancelled: 0 };
  for (const r of rows) counts[r.status] = r.c;
  counts.active = counts.pending + counts.accepted + counts.preparing + counts.ready;
  return counts;
}

function vendorStats(vendorId) {
  const today = startOfDay();
  const week = new Date(Date.now() - 6 * 864e5);
  week.setHours(0, 0, 0, 0);
  const num = (sql, ...p) => q.get(sql, ...p).s ?? 0;
  const revenueExpr = `COALESCE(SUM(CASE WHEN status IN ('ready','picked_up') THEN total ELSE 0 END), 0)`;
  const notCancelled = `status != 'cancelled'`;
  return {
    counts: vendorCounts(vendorId),
    today: {
      orders: num('SELECT COUNT(*) AS s FROM orders WHERE vendor_id = ? AND created_at >= ?', vendorId, today),
      active: num(`SELECT COUNT(*) AS s FROM orders WHERE vendor_id = ? AND created_at >= ?
        AND status IN ('pending','accepted','preparing','ready')`, vendorId, today),
      revenue: num(`SELECT ${revenueExpr} AS s FROM orders WHERE vendor_id = ? AND created_at >= ?`, vendorId, today),
    },
    week: {
      orders: num(`SELECT COUNT(*) AS s FROM orders WHERE vendor_id = ? AND created_at >= ? AND ${notCancelled}`, vendorId, week.toISOString()),
      revenue: num(`SELECT ${revenueExpr} AS s FROM orders WHERE vendor_id = ? AND created_at >= ?`, vendorId, week.toISOString()),
    },
    allTime: {
      orders: num(`SELECT COUNT(*) AS s FROM orders WHERE vendor_id = ? AND ${notCancelled}`, vendorId),
      revenue: num(`SELECT ${revenueExpr} AS s FROM orders WHERE vendor_id = ?`, vendorId),
      cancelled: num(`SELECT COUNT(*) AS s FROM orders WHERE vendor_id = ? AND status = 'cancelled'`, vendorId),
    },
    avgPrepMinutes: Math.round(num(`SELECT AVG((julianday(ready_at) - julianday(created_at)) * 1440) AS s
      FROM orders WHERE vendor_id = ? AND ready_at IS NOT NULL`, vendorId)),
    payments: {
      todayPaid: num(`SELECT COALESCE(SUM(p.amount), 0) AS s FROM payments p
        JOIN orders o ON o.id = p.order_id
        WHERE o.vendor_id = ? AND p.status = 'paid' AND p.paid_at >= ?`, vendorId, today),
      todayUnpaid: num(`SELECT COALESCE(SUM(total), 0) AS s FROM orders
        WHERE vendor_id = ? AND created_at >= ? AND payment_status = 'unpaid'
          AND status NOT IN ('cancelled')`, vendorId, today),
      online: num(`SELECT COALESCE(SUM(p.amount), 0) AS s FROM payments p
        JOIN orders o ON o.id = p.order_id
        WHERE o.vendor_id = ? AND p.status = 'paid'
          AND p.provider IN ('simulated','stripe')`, vendorId),
      counter: num(`SELECT COALESCE(SUM(p.amount), 0) AS s FROM payments p
        JOIN orders o ON o.id = p.order_id
        WHERE o.vendor_id = ? AND p.status = 'paid' AND p.provider = 'counter'`, vendorId),
      refunded: num(`SELECT COALESCE(SUM(p.amount), 0) AS s FROM payments p
        JOIN orders o ON o.id = p.order_id
        WHERE o.vendor_id = ? AND p.status = 'refunded'`, vendorId),
    },
    topProducts: q.all(`SELECT oi.name, SUM(oi.qty) AS qty, SUM(oi.qty * oi.price) AS revenue
      FROM order_items oi JOIN orders o ON o.id = oi.order_id
      WHERE o.vendor_id = ? AND o.status != 'cancelled'
      GROUP BY oi.name ORDER BY qty DESC LIMIT 8`, vendorId)
      .map((r) => ({ name: r.name, qty: r.qty, revenue: r.revenue })),
    daily: q.all(`SELECT substr(created_at, 1, 10) AS day, COUNT(*) AS orders,
        COALESCE(SUM(CASE WHEN status IN ('ready','picked_up') THEN total ELSE 0 END), 0) AS revenue
      FROM orders WHERE vendor_id = ? AND created_at >= ?
      GROUP BY day ORDER BY day`, vendorId, week.toISOString())
      .map((r) => ({ day: r.day, orders: r.orders, revenue: r.revenue })),
  };
}

function dailySeries(days) {
  const from = new Date(Date.now() - (days - 1) * 864e5);
  from.setHours(0, 0, 0, 0);
  const rows = q.all(`SELECT substr(created_at, 1, 10) AS day, COUNT(*) AS orders,
      COALESCE(SUM(CASE WHEN status IN ('ready','picked_up') THEN total ELSE 0 END), 0) AS revenue
    FROM orders WHERE created_at >= ? GROUP BY day ORDER BY day`, from.toISOString());
  const map = new Map(rows.map((r) => [r.day, r]));
  const out = [];
  for (let i = 0; i < days; i++) {
    const d = new Date(from.getTime() + i * 864e5);
    const key = d.toISOString().slice(0, 10);
    const row = map.get(key);
    out.push({ day: key, orders: row?.orders ?? 0, revenue: row?.revenue ?? 0 });
  }
  return out;
}
