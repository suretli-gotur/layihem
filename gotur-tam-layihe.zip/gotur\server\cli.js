import { DB_PATH, migrate, q, schemaVersion, seed } from './db.js';

const cmd = process.argv[2] || 'help';

/** Yoxlama/test zamanı yaranan sifarişləri tanıyan ad nümunələri */
const TEST_NAME_PATTERNS = [
  'Canlı Yoxlama', 'Yekun Test', 'Canlı Kupon', 'Canlı Ödəniş', 'Canlı SSE', 'Son Yoxlama',
  'E2E Test Müştəri', 'SSE Müştəri', 'İzləmə Testi', 'Ödəniş Axını', 'Admin Axını', 'Ləğv Axını',
  'Ödəniş Testi', 'Refund Testi', 'Qoruma Testi', 'Rədd Testi', 'İmtina Testi', 'Kupon Testi',
  'Ləğv Kupon', 'Yanlış Kupon', 'Komissiya Testi', 'Fərdi Komissiya', 'Digər', 'Digər Ödəniş',
  'Qurban Müştəri', 'Qurban', 'Rəy Testi', 'Rəy Testi 2', 'Nağd Müştəri', 'Test Müştəri',
];

/** Sonluqla gələn test adları (məsələn «Canlı Yoxlama 4F2A») */
const TEST_LIKE_PATTERNS = [
  'Canlı Yoxlama %', 'Yekun Test %', 'E2E Test %', 'Canlı Kupon %', 'Canlı Ödəniş %',
];

switch (cmd) {
  case 'seed': {
    const res = seed({ force: true });
    console.log(`✔ Demo data yenidən yaradıldı (${res.vendors} mağaza).`);
    console.log(`  Baza: ${DB_PATH}`);
    break;
  }
  case 'reset': {
    migrate();
    for (const t of ['order_events', 'order_items', 'payments', 'orders', 'products', 'sessions', 'vendors', 'categories', 'users']) {
      q.run(`DELETE FROM ${t}`);
    }
    console.log('✔ Bütün məlumat silindi. Yenidən qurmaq üçün: npm run seed');
    break;
  }
  case 'stats': {
    const rows = [
      ['İstifadəçilər', q.get('SELECT COUNT(*) AS c FROM users').c],
      ['Mağazalar', q.get('SELECT COUNT(*) AS c FROM vendors').c],
      ['Məhsullar', q.get('SELECT COUNT(*) AS c FROM products').c],
      ['Sifarişlər', q.get('SELECT COUNT(*) AS c FROM orders').c],
      ['Ödənişlər', q.get('SELECT COUNT(*) AS c FROM payments').c],
      ['Rəylər', q.get('SELECT COUNT(*) AS c FROM reviews').c],
      ['Kampaniyalar', q.get('SELECT COUNT(*) AS c FROM coupons').c],
      ['Hesablaşmalar', q.get('SELECT COUNT(*) AS c FROM settlements').c],
      ['Sxem versiyası', schemaVersion()],
    ];
    console.log(`Baza: ${DB_PATH}`);
    for (const [label, value] of rows) console.log(`  ${label.padEnd(16)} ${value}`);
    break;
  }
  case 'cleanup': {
    // Test/yoxlama sifarişlərini silir, kupon limitlərini azad edir, reytinqləri yeniləyir
    migrate();
    const placeholders = TEST_NAME_PATTERNS.map(() => '?').join(',');
    // «Canlı Yoxlama A1B2» kimi sonluqlu adları da tutmaq üçün LIKE nümunələri
    const likeWhere = TEST_LIKE_PATTERNS.map(() => 'customer_name LIKE ?').join(' OR ');
    const where = `(customer_name IN (${placeholders}) OR ${likeWhere})`;
    const params = [...TEST_NAME_PATTERNS, ...TEST_LIKE_PATTERNS];

    const testOrders = q.all(
      `SELECT id, code, customer_name, coupon_code, status FROM orders WHERE ${where}`,
      ...params,
    );
    if (!testOrders.length) {
      console.log('✔ Silinəcək test sifarişi yoxdur.');
    }
    for (const order of testOrders) {
      const items = q.all('SELECT product_id, qty FROM order_items WHERE order_id = ?', order.id);
      for (const item of items) {
        if (item.product_id) {
          q.run('UPDATE products SET stock = stock + ? WHERE id = ? AND stock IS NOT NULL', item.qty, item.product_id);
        }
      }
      if (order.coupon_code) {
        q.run('UPDATE coupons SET used_count = MAX(0, used_count - 1) WHERE code = ?', order.coupon_code);
      }
      q.run('DELETE FROM reviews WHERE order_id = ?', order.id);
      q.run('DELETE FROM payments WHERE order_id = ?', order.id);
      q.run('DELETE FROM order_events WHERE order_id = ?', order.id);
      q.run('DELETE FROM order_items WHERE order_id = ?', order.id);
      q.run('DELETE FROM orders WHERE id = ?', order.id);
      console.log(`  ✕ ${order.code} — ${order.customer_name} (${order.status})`);
    }
    // Reytinqləri baza + qalan rəylərdən yenidən hesabla
    q.run(`
      UPDATE vendors SET
        rating = CASE WHEN (base_rating_count + (SELECT COUNT(*) FROM reviews r WHERE r.vendor_id = vendors.id AND r.hidden = 0)) = 0
          THEN rating ELSE ROUND((
            base_rating * base_rating_count
            + COALESCE((SELECT SUM(r.rating) FROM reviews r WHERE r.vendor_id = vendors.id AND r.hidden = 0), 0)
          ) * 1.0 / (base_rating_count + (SELECT COUNT(*) FROM reviews r WHERE r.vendor_id = vendors.id AND r.hidden = 0)), 1) END,
        rating_count = base_rating_count + (SELECT COUNT(*) FROM reviews r WHERE r.vendor_id = vendors.id AND r.hidden = 0)
    `);

    // Sifarişi qalmayan test müştərilərini də sil (demo hesablar toxunulmaz qalır)
    const staleUsers = q.all(
      `SELECT u.id, u.name, u.phone FROM users u
       WHERE u.role = 'customer'
         AND (${where.replaceAll('customer_name', 'u.name')})
         AND NOT EXISTS (SELECT 1 FROM orders o WHERE o.customer_user_id = u.id)`,
      ...params,
    );
    for (const user of staleUsers) {
      q.run('DELETE FROM sessions WHERE user_id = ?', user.id);
      q.run('DELETE FROM users WHERE id = ?', user.id);
      console.log(`  ✕ istifadəçi ${user.name} (${user.phone})`);
    }

    console.log(`✔ ${testOrders.length} test sifarişi, ${staleUsers.length} test istifadəçisi silindi; kupon limitləri və reytinqlər yeniləndi.`);
    break;
  }
  case 'vendors': {
    // Bütün mağazalar: növ, təsdiq, məhsul/sifariş sayı, komissiya
    migrate();
    const rows = q.all(`
      SELECT v.id, v.slug, v.name, v.kind, v.approved, v.open, v.commission_percent,
        (SELECT name FROM categories c WHERE c.id = v.category_id) AS category,
        (SELECT COUNT(*) FROM products p WHERE p.vendor_id = v.id) AS products,
        (SELECT COUNT(*) FROM orders o WHERE o.vendor_id = v.id) AS orders,
        (SELECT u.phone FROM users u WHERE u.id = v.owner_user_id) AS owner_phone
      FROM vendors v ORDER BY v.id
    `);
    const defCommission = q.get("SELECT value FROM settings WHERE key = 'default_commission'")?.value ?? '12';
    console.log(`Baza: ${DB_PATH}`);
    console.log(`  ${'ID'.padEnd(4)}${'slug'.padEnd(26)}${'ad'.padEnd(24)}${'növ'.padEnd(11)}${'təsdiq'.padEnd(8)}${'kom.'.padEnd(7)}${'məhsul'.padEnd(8)}${'sifariş'.padEnd(9)}telefon`);
    for (const r of rows) {
      const commission = r.commission_percent ? `${r.commission_percent}%*` : `${defCommission}%`;
      console.log('  '
        + String(r.id).padEnd(4)
        + String(r.slug).padEnd(26)
        + String(r.name).padEnd(24)
        + String(r.kind === 'market' ? 'market' : 'restoran').padEnd(11)
        + String(r.approved ? (r.open ? 'açıq' : 'bağlı') : 'GÖZLƏYİR').padEnd(8)
        + commission.padEnd(7)
        + String(r.products).padEnd(8)
        + String(r.orders).padEnd(9)
        + String(r.owner_phone ?? '—'));
    }
    console.log(`\n  Cəmi: ${rows.length} mağaza · defolt komissiya ${defCommission}% (* = fərdi faiz)`);
    break;
  }
  default:
    console.log('İstifadə: node server/cli.js <seed|reset|stats|vendors|cleanup>');
}
