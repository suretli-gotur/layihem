/**
 * Götür — kupon / endirim modulu.
 *
 * İki növ: `percent` (faiz, 1–90) və `fixed` (sabit məbləğ, qəpik).
 * Kupon ya platforma üzrə (vendor_id = NULL), ya da konkret mağaza üçün ola bilər.
 * Yoxlamalar sifariş yaradılarkən server tərəfində aparılır:
 *   aktivlik, tarix aralığı, minimum səbət, ümumi limit, istifadəçi limiti, mağaza uyğunluğu.
 */
import { q } from './db.js';
import { bad, notFound, nowIso, str } from './util.js';

export const COUPON_KINDS = ['percent', 'fixed'];
const MAX_PERCENT = 90;

export function serializeCoupon(c, { includeStats = false } = {}) {
  if (!c) return null;
  const vendor = c.vendor_id ? q.get('SELECT name, slug FROM vendors WHERE id = ?', c.vendor_id) : null;
  const base = {
    id: c.id,
    code: c.code,
    vendorId: c.vendor_id,
    vendorName: vendor?.name ?? null,
    vendorSlug: vendor?.slug ?? null,
    scope: c.vendor_id ? 'vendor' : 'platform',
    kind: c.kind,
    value: c.value,
    minOrder: c.min_order,
    maxDiscount: c.max_discount,
    usageLimit: c.usage_limit,
    usedCount: c.used_count,
    perUserLimit: c.per_user_limit,
    startsAt: c.starts_at,
    expiresAt: c.expires_at,
    active: !!c.active,
    description: c.description || '',
    createdAt: c.created_at,
  };
  if (includeStats) {
    base.stats = {
      orders: q.get('SELECT COUNT(*) AS c FROM orders WHERE coupon_code = ?', c.code).c,
      discounted: q.get('SELECT COALESCE(SUM(discount), 0) AS s FROM orders WHERE coupon_code = ? AND status != ?',
        c.code, 'cancelled').s,
    };
  }
  return base;
}

export const findCoupon = (code) =>
  q.get('SELECT * FROM coupons WHERE UPPER(code) = ?', str(code, 40).toUpperCase());

export const normalizeCode = (code) =>
  str(code, 40).toUpperCase().replace(/[^A-Z0-9_-]/g, '');

/** Faiz/məbləğ kuponunun səbətə verdiyi endirim (qəpik). */
export function discountFor(coupon, subtotal) {
  if (!coupon) return 0;
  let discount = coupon.kind === 'percent'
    ? Math.round((subtotal * Math.min(coupon.value, MAX_PERCENT)) / 100)
    : coupon.value;
  if (coupon.max_discount > 0) discount = Math.min(discount, coupon.max_discount);
  return Math.max(0, Math.min(discount, subtotal));
}

function usageCount(coupon, { userId, phone }) {
  if (userId) {
    return q.get('SELECT COUNT(*) AS c FROM orders WHERE coupon_code = ? AND customer_user_id = ?',
      coupon.code, userId).c;
  }
  return q.get('SELECT COUNT(*) AS c FROM orders WHERE coupon_code = ? AND customer_phone = ?',
    coupon.code, phone ?? '').c;
}

/**
 * Kuponu yoxlayır və endirimi hesablayır.
 * Uğursuzluqda `bad(...)` atır; uğurda { coupon, discount } qaytarır.
 */
export function validateCoupon({ code, vendorId, subtotal, userId = null, phone = null, now = new Date() }) {
  const normalized = normalizeCode(code);
  if (!normalized) throw bad('Kupon kodu boşdur', 'coupon_code_empty');
  const coupon = findCoupon(normalized);
  if (!coupon) throw bad(`«${normalized}» kuponu tapılmadı`, 'coupon_not_found', { code: normalized });
  if (!coupon.active) throw bad('Bu kupon artıq aktiv deyil', 'coupon_inactive');
  if (coupon.starts_at && new Date(coupon.starts_at) > now) {
    throw bad(`Kupon ${new Date(coupon.starts_at).toLocaleDateString('az-AZ')} tarixindən etibarən işləyir`,
      'coupon_not_started', { date: new Date(coupon.starts_at).toLocaleDateString('az-AZ') });
  }
  if (coupon.expires_at && new Date(coupon.expires_at) < now) {
    throw bad('Kuponun müddəti bitib', 'coupon_expired');
  }
  if (coupon.vendor_id && Number(coupon.vendor_id) !== Number(vendorId)) {
    throw bad('Bu kupon yalnız müəyyən mağazada keçərlidir', 'coupon_vendor_only');
  }
  if (coupon.min_order > 0 && subtotal < coupon.min_order) {
    throw bad(`Kupon üçün minimum səbət ${(coupon.min_order / 100).toFixed(2)} ₼-dir`, 'coupon_min_order', {
      amount: `${(coupon.min_order / 100).toFixed(2)} ₼`,
    });
  }
  if (coupon.usage_limit > 0 && coupon.used_count >= coupon.usage_limit) {
    throw bad('Kuponun istifadə limiti bitib', 'coupon_limit');
  }
  if (coupon.per_user_limit > 0 && usageCount(coupon, { userId, phone }) >= coupon.per_user_limit) {
    throw bad('Bu kuponu artıq istifadə etmisiniz', 'coupon_used');
  }
  const discount = discountFor(coupon, subtotal);
  if (discount <= 0) throw bad('Bu səbətə kupon tətbiq olunmur', 'coupon_not_applicable');
  return { coupon, discount };
}

/** Sifariş yaradılarkən kuponu «xərcləyir». */
export function consumeCoupon(coupon) {
  q.run('UPDATE coupons SET used_count = used_count + 1 WHERE id = ?', coupon.id);
}

/** Sifariş ləğv edilərsə kupon limiti geri qaytarılır. */
export function releaseCoupon(order) {
  if (!order?.coupon_code) return false;
  const coupon = findCoupon(order.coupon_code);
  if (!coupon) return false;
  q.run('UPDATE coupons SET used_count = MAX(0, used_count - 1) WHERE id = ?', coupon.id);
  return true;
}

/** Mağaza səhifəsində göstərilən aktiv kampaniyalar (qısa formada). */
export function activeCouponsForVendor(vendorId, now = new Date(), limit = 5) {
  const rows = q.all(
    `SELECT * FROM coupons
     WHERE active = 1
       AND (vendor_id IS NULL OR vendor_id = ?)
       AND (starts_at IS NULL OR starts_at <= ?)
       AND (expires_at IS NULL OR expires_at >= ?)
       AND (usage_limit = 0 OR used_count < usage_limit)
     ORDER BY (vendor_id IS NOT NULL) DESC, min_order ASC, id DESC
     LIMIT ?`,
    vendorId, now.toISOString(), now.toISOString(), limit,
  );
  return rows.map((c) => ({
    code: c.code,
    kind: c.kind,
    value: c.value,
    minOrder: c.min_order,
    maxDiscount: c.max_discount,
    description: c.description || '',
    expiresAt: c.expires_at,
    label: c.kind === 'percent'
      ? `${c.value}% endirim${c.max_discount ? ` (maks ${(c.max_discount / 100).toFixed(2)} ₼)` : ''}`
      : `${(c.value / 100).toFixed(2)} ₼ endirim`,
  }));
}

/* ------------------------------------------------------------------ *
 * İdarəetmə (admin və satıcı)
 * Pul sahələri API-də AZN ilə gəlir, bazada qəpiklə saxlanılır.
 * ------------------------------------------------------------------ */
const aznToQepik = (value, label) => {
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) throw bad(`${label} düzgün deyil`);
  return Math.round(n * 100);
};

const intOr = (value, fallback, label) => {
  if (value === undefined || value === null || value === '') return fallback;
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) throw bad(`${label} düzgün deyil`);
  return Math.round(n);
};

const parseDate = (value, fallback) => {
  if (value === undefined || value === null || value === '') return fallback ?? null;
  const raw = String(value);
  const d = new Date(raw);
  if (Number.isNaN(d.getTime())) throw bad('Tarix düzgün deyil');
  if (raw.length <= 10) d.setHours(23, 59, 59, 999); // gün sonu
  return d.toISOString();
};

export function couponPayload(body, { current = null, vendorId = null } = {}) {
  const code = normalizeCode(body.code ?? current?.code ?? '');
  if (!code || code.length < 3) throw bad('Kupon kodu ən azı 3 simvol olmalıdır (A-Z, 0-9)');

  const kind = COUPON_KINDS.includes(body.kind) ? body.kind : (current?.kind ?? 'percent');
  let value;
  if (kind === 'percent') {
    const raw = body.value !== undefined ? Number(body.value) : (current?.value ?? 0);
    value = Math.round(raw);
    if (!Number.isFinite(value) || value < 1 || value > MAX_PERCENT) {
      throw bad(`Faiz 1–${MAX_PERCENT} arasında olmalıdır`);
    }
  } else {
    value = body.value !== undefined
      ? aznToQepik(body.value, 'Endirim məbləği')
      : (current?.value ?? 0);
    if (value <= 0) throw bad('Sabit endirim məbləği sıfırdan böyük olmalıdır');
  }

  return {
    code,
    vendor_id: vendorId, // satıcı yalnız öz mağazası üçün yarada bilər (null = platforma)
    kind,
    value,
    min_order: body.minOrder !== undefined
      ? aznToQepik(body.minOrder, 'Minimum səbət')
      : (current?.min_order ?? 0),
    max_discount: body.maxDiscount !== undefined
      ? aznToQepik(body.maxDiscount, 'Maksimum endirim')
      : (current?.max_discount ?? 0),
    usage_limit: intOr(body.usageLimit, current?.usage_limit ?? 0, 'İstifadə limiti'),
    per_user_limit: intOr(body.perUserLimit, current?.per_user_limit ?? 1, 'İstifadəçi limiti'),
    starts_at: parseDate(body.startsAt, current?.starts_at),
    expires_at: parseDate(body.expiresAt, current?.expires_at),
    active: body.active === undefined ? (current?.active ?? 1) : (body.active ? 1 : 0),
    description: str(body.description ?? current?.description ?? '', 200),
  };
}

export function createCoupon(body, { vendorId = null } = {}) {
  const data = couponPayload(body, { vendorId });
  if (findCoupon(data.code)) throw bad(`«${data.code}» kodu artıq mövcuddur`);
  const info = q.run(
    `INSERT INTO coupons (code, vendor_id, kind, value, min_order, max_discount, usage_limit,
       per_user_limit, starts_at, expires_at, active, description, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    data.code, data.vendor_id, data.kind, data.value, data.min_order, data.max_discount,
    data.usage_limit, data.per_user_limit, data.starts_at, data.expires_at, data.active,
    data.description, nowIso(),
  );
  return serializeCoupon(q.get('SELECT * FROM coupons WHERE id = ?', Number(info.lastInsertRowid)), { includeStats: true });
}

export function updateCoupon(id, body, { vendorId = null, isAdmin = false } = {}) {
  const current = q.get('SELECT * FROM coupons WHERE id = ?', id);
  if (!current) throw notFound('Kupon tapılmadı');
  if (!isAdmin && Number(current.vendor_id) !== Number(vendorId)) {
    throw notFound('Kupon tapılmadı');
  }
  const data = couponPayload(body, { current, vendorId: isAdmin ? current.vendor_id : vendorId });
  if (data.code !== current.code && findCoupon(data.code)) {
    throw bad(`«${data.code}» kodu artıq mövcuddur`);
  }
  if (Number(current.used_count) > 0 && data.usage_limit > 0 && data.usage_limit < current.used_count) {
    throw bad(`Bu kupon ${current.used_count} dəfə istifadə olunub — limit ondan az ola bilməz`);
  }
  q.run(
    `UPDATE coupons SET code = ?, kind = ?, value = ?, min_order = ?, max_discount = ?, usage_limit = ?,
       per_user_limit = ?, starts_at = ?, expires_at = ?, active = ?, description = ? WHERE id = ?`,
    data.code, data.kind, data.value, data.min_order, data.max_discount, data.usage_limit,
    data.per_user_limit, data.starts_at, data.expires_at, data.active, data.description, id,
  );
  return serializeCoupon(q.get('SELECT * FROM coupons WHERE id = ?', id), { includeStats: true });
}

export function deleteCoupon(id, { vendorId = null, isAdmin = false } = {}) {
  const current = q.get('SELECT * FROM coupons WHERE id = ?', id);
  if (!current) throw notFound('Kupon tapılmadı');
  if (!isAdmin && Number(current.vendor_id) !== Number(vendorId)) throw notFound('Kupon tapılmadı');
  q.run('DELETE FROM coupons WHERE id = ?', id);
  return { ok: true };
}

export function listCoupons({ vendorId = null, isAdmin = false, includeStats = true } = {}) {
  const rows = isAdmin
    ? q.all('SELECT * FROM coupons ORDER BY active DESC, id DESC LIMIT 200')
    : q.all('SELECT * FROM coupons WHERE vendor_id = ? ORDER BY active DESC, id DESC LIMIT 100', vendorId);
  return rows.map((c) => serializeCoupon(c, { includeStats }));
}

export const couponUsageByCode = (code) =>
  q.get('SELECT COUNT(*) AS c, COALESCE(SUM(discount), 0) AS s FROM orders WHERE coupon_code = ? AND status != ?',
    code, 'cancelled');
