import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { hashPassword, nowIso, orderCode, randomDigits, slugify } from './util.js';
import { categories as seedCategories, demoCoupons, demoOrders, demoReviewAuthors, demoReviews, demoUsers, vendorCoords, vendors as seedVendors } from './seed-data.js';

const here = dirname(fileURLToPath(import.meta.url));
export const ROOT = join(here, '..');
export const DB_PATH = process.env.GOTUR_DB || join(ROOT, 'data', 'gotur.db');

mkdirSync(dirname(DB_PATH), { recursive: true });

export const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  role          TEXT    NOT NULL DEFAULT 'customer',
  name          TEXT    NOT NULL,
  phone         TEXT    NOT NULL UNIQUE,
  email         TEXT    DEFAULT '',
  password_hash TEXT    NOT NULL,
  blocked       INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS categories (
  id    INTEGER PRIMARY KEY AUTOINCREMENT,
  slug  TEXT NOT NULL UNIQUE,
  name  TEXT NOT NULL,
  icon  TEXT NOT NULL DEFAULT '🍽️',
  kind  TEXT NOT NULL DEFAULT 'restaurant',
  sort  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS vendors (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_user_id INTEGER REFERENCES users(id),
  slug          TEXT    NOT NULL UNIQUE,
  name          TEXT    NOT NULL,
  kind          TEXT    NOT NULL DEFAULT 'restaurant',
  category_id   INTEGER REFERENCES categories(id),
  tagline       TEXT    DEFAULT '',
  description   TEXT    DEFAULT '',
  address       TEXT    NOT NULL DEFAULT '',
  phone         TEXT    DEFAULT '',
  logo          TEXT    DEFAULT '🏪',
  open          INTEGER NOT NULL DEFAULT 1,
  approved      INTEGER NOT NULL DEFAULT 0,
  prep_time     INTEGER NOT NULL DEFAULT 20,
  min_order     INTEGER NOT NULL DEFAULT 0,
  rating        REAL    NOT NULL DEFAULT 4.7,
  rating_count  INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  vendor_id   INTEGER NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
  section     TEXT    NOT NULL DEFAULT 'Menyu',
  name        TEXT    NOT NULL,
  description TEXT    DEFAULT '',
  price       INTEGER NOT NULL,
  unit        TEXT    NOT NULL DEFAULT 'ədəd',
  image       TEXT    NOT NULL DEFAULT '🍽️',
  stock       INTEGER,
  active      INTEGER NOT NULL DEFAULT 1,
  sort        INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS orders (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  code             TEXT    NOT NULL UNIQUE,
  customer_user_id INTEGER REFERENCES users(id),
  customer_name    TEXT    NOT NULL,
  customer_phone   TEXT    NOT NULL,
  vendor_id        INTEGER NOT NULL REFERENCES vendors(id),
  status           TEXT    NOT NULL DEFAULT 'pending',
  subtotal         INTEGER NOT NULL DEFAULT 0,
  fee              INTEGER NOT NULL DEFAULT 0,
  total            INTEGER NOT NULL DEFAULT 0,
  payment          TEXT    NOT NULL DEFAULT 'cash',
  pickup_code      TEXT    NOT NULL,
  note             TEXT    DEFAULT '',
  created_at       TEXT    NOT NULL,
  updated_at       TEXT    NOT NULL,
  ready_at         TEXT,
  picked_up_at     TEXT
);

CREATE TABLE IF NOT EXISTS order_items (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id   INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER,
  name       TEXT    NOT NULL,
  price      INTEGER NOT NULL,
  qty        INTEGER NOT NULL,
  unit       TEXT    DEFAULT 'ədəd',
  image      TEXT    DEFAULT '🍽️'
);

CREATE TABLE IF NOT EXISTS order_events (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id   INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  status     TEXT    NOT NULL,
  note       TEXT    DEFAULT '',
  created_at TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token      TEXT PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_products_vendor  ON products(vendor_id, active);
CREATE INDEX IF NOT EXISTS idx_orders_vendor    ON orders(vendor_id, status);
CREATE INDEX IF NOT EXISTS idx_orders_customer  ON orders(customer_user_id);
CREATE INDEX IF NOT EXISTS idx_events_order     ON order_events(order_id);
`;

const META_SCHEMA = `
CREATE TABLE IF NOT EXISTS meta (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
`;

/* ------------------------------------------------------------------ *
 * Miqrasiyalar — hər biri bir dəfə işləyir, mövcud bazanı itirmir
 * ------------------------------------------------------------------ */
function columnExists(table, column) {
  return q.all(`PRAGMA table_info(${table})`).some((c) => c.name === column);
}

function addColumn(table, column, definition) {
  if (!columnExists(table, column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
}

const MIGRATIONS = [
  {
    version: 1,
    name: 'ilkin sxem',
    up() { db.exec(SCHEMA); },
  },
  {
    version: 2,
    name: 'onlayn ödənişlər',
    up() {
      db.exec(`
        CREATE TABLE IF NOT EXISTS payments (
          id              INTEGER PRIMARY KEY AUTOINCREMENT,
          order_id        INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
          provider        TEXT    NOT NULL DEFAULT 'simulated',
          method          TEXT    NOT NULL DEFAULT 'online',
          provider_ref    TEXT,
          provider_intent TEXT,
          token           TEXT    UNIQUE,
          amount          INTEGER NOT NULL,
          status          TEXT    NOT NULL DEFAULT 'requires_action',
          card_last4      TEXT,
          error           TEXT    DEFAULT '',
          created_at      TEXT    NOT NULL,
          paid_at         TEXT,
          refunded_at     TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_payments_order  ON payments(order_id);
        CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
      `);
      addColumn('payments', 'provider_intent', 'TEXT');
      addColumn('orders', 'payment_status', "TEXT NOT NULL DEFAULT 'unpaid'");
      addColumn('orders', 'paid_at', 'TEXT');
    },
  },
  {
    version: 3,
    name: 'rəylər və kuponlar',
    up() {
      db.exec(`
        CREATE TABLE IF NOT EXISTS reviews (
          id          INTEGER PRIMARY KEY AUTOINCREMENT,
          order_id    INTEGER NOT NULL UNIQUE REFERENCES orders(id) ON DELETE CASCADE,
          vendor_id   INTEGER NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
          user_id     INTEGER REFERENCES users(id),
          author_name TEXT    NOT NULL,
          rating      INTEGER NOT NULL,
          comment     TEXT    DEFAULT '',
          reply       TEXT    DEFAULT '',
          replied_at  TEXT,
          hidden      INTEGER NOT NULL DEFAULT 0,
          created_at  TEXT    NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_reviews_vendor ON reviews(vendor_id, hidden);

        CREATE TABLE IF NOT EXISTS coupons (
          id             INTEGER PRIMARY KEY AUTOINCREMENT,
          code           TEXT    NOT NULL UNIQUE,
          vendor_id      INTEGER REFERENCES vendors(id) ON DELETE CASCADE,
          kind           TEXT    NOT NULL DEFAULT 'percent',
          value          INTEGER NOT NULL,
          min_order      INTEGER NOT NULL DEFAULT 0,
          max_discount   INTEGER NOT NULL DEFAULT 0,
          usage_limit    INTEGER NOT NULL DEFAULT 0,
          used_count     INTEGER NOT NULL DEFAULT 0,
          per_user_limit INTEGER NOT NULL DEFAULT 1,
          starts_at      TEXT,
          expires_at     TEXT,
          active         INTEGER NOT NULL DEFAULT 1,
          description    TEXT    DEFAULT '',
          created_at     TEXT    NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_coupons_code ON coupons(code);
      `);
      addColumn('orders', 'coupon_code', 'TEXT');
      addColumn('orders', 'discount', 'INTEGER NOT NULL DEFAULT 0');
      addColumn('vendors', 'base_rating', 'REAL NOT NULL DEFAULT 0');
      addColumn('vendors', 'base_rating_count', 'INTEGER NOT NULL DEFAULT 0');
      // Mövcud reytinqlər «baza» kimi saxlanılır ki, yeni rəylər onu əvəz etməsin
      q.run('UPDATE vendors SET base_rating = rating, base_rating_count = rating_count WHERE base_rating_count = 0');
    },
  },
  {
    version: 4,
    name: 'mövcud bazalara demo kampaniya və rəylər',
    up() {
      // Artıq seed olunmuş bazalarda boş qalan cədvəlləri doldurur.
      // Yalnız BOŞ olduqda işləyir — istifadəçi məlumatına toxunmur.
      // Təzə bazada bu işi `seed()` görür (mağazalar yaradıldıqdan SONRA), çünki
      // mağazaya bağlı kuponlar üçün vendor sətirləri artıq mövcud olmalıdır.
      const vendorsExist = q.get('SELECT COUNT(*) AS c FROM vendors').c > 0;
      if (!vendorsExist) return;
      if (q.get('SELECT COUNT(*) AS c FROM coupons').c === 0) {
        seedDemoCoupons(nowIso());
      }
      if (q.get('SELECT COUNT(*) AS c FROM reviews').c === 0) {
        // Rəylər yalnız demo müştərilərin götürülmüş sifarişlərinə yazılır
        const demoPhones = demoUsers.filter((u) => u.role === 'customer').map((u) => u.phone);
        const placeholders = demoPhones.map(() => '?').join(',');
        const pickedUp = q.all(
          `SELECT o.id, o.vendor_id, o.customer_user_id, o.customer_name
           FROM orders o JOIN users u ON u.id = o.customer_user_id
           WHERE o.status = 'picked_up' AND u.phone IN (${placeholders})
           ORDER BY o.id LIMIT 3`,
          ...demoPhones,
        );
        if (pickedUp.length) {
          seedDemoReviews(pickedUp.map((o) => ({
            id: o.id,
            vendorId: o.vendor_id,
            userId: o.customer_user_id,
            customerName: o.customer_name,
            status: 'picked_up',
          })), nowIso());
        }
      }
    },
  },
  {
    version: 5,
    name: 'komissiya və hesablaşma',
    up() {
      db.exec(`
        CREATE TABLE IF NOT EXISTS settings (
          key   TEXT PRIMARY KEY,
          value TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS settlements (
          id           INTEGER PRIMARY KEY AUTOINCREMENT,
          vendor_id    INTEGER NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
          period_start TEXT    NOT NULL,
          period_end   TEXT    NOT NULL,
          orders_count INTEGER NOT NULL DEFAULT 0,
          gross        INTEGER NOT NULL DEFAULT 0,
          discount     INTEGER NOT NULL DEFAULT 0,
          commission   INTEGER NOT NULL DEFAULT 0,
          online       INTEGER NOT NULL DEFAULT 0,
          counter      INTEGER NOT NULL DEFAULT 0,
          payout       INTEGER NOT NULL DEFAULT 0,
          status       TEXT    NOT NULL DEFAULT 'pending',
          note         TEXT    DEFAULT '',
          created_at   TEXT    NOT NULL,
          paid_at      TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_settlements_vendor ON settlements(vendor_id, period_end);
      `);
      addColumn('vendors', 'commission_percent', 'REAL NOT NULL DEFAULT 0');
      addColumn('orders', 'commission', 'INTEGER NOT NULL DEFAULT 0');
      addColumn('orders', 'vendor_payout', 'INTEGER NOT NULL DEFAULT 0');

      // Platforma defolt komissiyası (faiz)
      if (!q.get("SELECT key FROM settings WHERE key = 'default_commission'")) {
        q.run("INSERT INTO settings (key, value) VALUES ('default_commission', ?)", '12');
      }
      if (!q.get("SELECT key FROM settings WHERE key = 'platform_name'")) {
        q.run("INSERT INTO settings (key, value) VALUES ('platform_name', ?)", 'Götür');
      }

      // Mövcud sifarişlər üçün komissiyanı geriyə hesabla
      const percent = Number(q.get("SELECT value FROM settings WHERE key = 'default_commission'")?.value ?? 12);
      q.run(
        `UPDATE orders SET
           commission = CAST(ROUND(subtotal * ? / 100.0) AS INTEGER),
           vendor_payout = total - CAST(ROUND(subtotal * ? / 100.0) AS INTEGER)
         WHERE commission = 0 AND status != 'cancelled'`,
        percent, percent,
      );
    },
  },
  {
    version: 6,
    name: 'əlavə kateqoriyalar (aptek, gül, ev, elektronika)',
    up() {
      // Yeni şaquli sahələr: mövcud bazalarda da əlavə olunur (təkrar yazılmır).
      // Admin panelindən istənilən vaxt düzəliş/silmə mümkündür.
      const extra = [
        { slug: 'aptek', name: 'Aptek', icon: '🏥', kind: 'market', sort: 15 },
        { slug: 'gul-hediyye', name: 'Gül & Hədiyyə', icon: '💐', kind: 'market', sort: 16 },
        { slug: 'ev-heyvan', name: 'Ev & Heyvan', icon: '🐾', kind: 'market', sort: 17 },
        { slug: 'elektronika', name: 'Elektronika', icon: '🔌', kind: 'market', sort: 18 },
        { slug: 'geyim-aksesuar', name: 'Geyim & Aksesuar', icon: '👕', kind: 'market', sort: 19 },
        { slug: 'kofe-sirniyyat', name: 'Kofe & Şirniyyat', icon: '☕', kind: 'market', sort: 20 },
      ];
      for (const c of extra) {
        if (q.get('SELECT id FROM categories WHERE slug = ?', c.slug)) continue;
        q.run('INSERT INTO categories (slug, name, icon, kind, sort) VALUES (?, ?, ?, ?, ?)',
          c.slug, c.name, c.icon, c.kind, c.sort);
      }
    },
  },
  {
    version: 7,
    name: 'mağaza koordinatları (məsafə və yol vaxtı)',
    up() {
      addColumn('vendors', 'lat', 'REAL');
      addColumn('vendors', 'lng', 'REAL');

      // Demo mağazalar üçün koordinatlar (Gəncə) — yalnız boş olanlar doldurulur,
      // satıcı öz panelindən istənilən vaxt dəyişə bilər.
      const coords = vendorCoords;
      for (const [slug, [lat, lng]] of Object.entries(coords)) {
        q.run('UPDATE vendors SET lat = ?, lng = ? WHERE slug = ? AND (lat IS NULL OR lng IS NULL)',
          lat, lng, slug);
      }
    },
  },
];

export function migrate() {
  db.exec(META_SCHEMA);
  const row = q.get("SELECT value FROM meta WHERE key = 'schema_version'");
  const current = Number(row?.value ?? 0);
  for (const m of MIGRATIONS) {
    if (m.version <= current) continue;
    db.exec('BEGIN');
    try {
      m.up();
      q.run(
        `INSERT INTO meta (key, value) VALUES ('schema_version', ?)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
        String(m.version),
      );
      db.exec('COMMIT');
      if (m.version > 1) console.log(`[gotur] miqrasiya v${m.version} tətbiq olundu: ${m.name}`);
    } catch (err) {
      db.exec('ROLLBACK');
      throw new Error(`Miqrasiya v${m.version} («${m.name}») alınmadı: ${err.message}`);
    }
  }
}

export const schemaVersion = () =>
  Number(q.get("SELECT value FROM meta WHERE key = 'schema_version'")?.value ?? 0);

export function closeDb() {
  try { db.close(); } catch { /* artıq bağlıdır */ }
}

/* ------------------------------------------------------------------ *
 * Kiçik köməkçilər
 * ------------------------------------------------------------------ */
export const q = {
  all: (sql, ...params) => db.prepare(sql).all(...params),
  get: (sql, ...params) => db.prepare(sql).get(...params),
  run: (sql, ...params) => db.prepare(sql).run(...params),
};

export function uniqueSlug(base, table = 'vendors', column = 'slug') {
  const root = slugify(base);
  let candidate = root;
  let i = 2;
  while (q.get(`SELECT id FROM ${table} WHERE ${column} = ?`, candidate)) {
    candidate = `${root}-${i++}`;
  }
  return candidate;
}

export function logEvent(orderId, status, note = '') {
  q.run(
    'INSERT INTO order_events (order_id, status, note, created_at) VALUES (?, ?, ?, ?)',
    orderId, status, note, nowIso(),
  );
}

/* ------------------------------------------------------------------ *
 * Seed
 * ------------------------------------------------------------------ */
const empty = () => q.get('SELECT COUNT(*) AS c FROM vendors').c === 0;

export function seed({ force = false } = {}) {
  migrate();
  if (!force && !empty()) return { skipped: true };

  if (force) {
    for (const t of ['order_events', 'order_items', 'payments', 'reviews', 'orders', 'products', 'coupons', 'sessions', 'vendors', 'categories']) {
      db.exec(`DELETE FROM ${t}`);
    }
    db.exec("DELETE FROM users WHERE role != 'admin'");
  }

  const now = nowIso();
  const catIds = new Map();
  const insertCat = db.prepare('INSERT INTO categories (slug, name, icon, kind, sort) VALUES (?, ?, ?, ?, ?)');
  for (const c of seedCategories) {
    const info = insertCat.run(c.slug, c.name, c.icon, c.kind, c.sort);
    catIds.set(c.slug, Number(info.lastInsertRowid));
  }

  const insertUser = db.prepare(
    'INSERT INTO users (role, name, phone, email, password_hash, created_at) VALUES (?, ?, ?, ?, ?, ?)',
  );
  const userIds = new Map();
  for (const u of demoUsers) {
    const existing = q.get('SELECT id FROM users WHERE phone = ?', u.phone);
    if (existing) { userIds.set(u.phone, existing.id); continue; }
    const info = insertUser.run(u.role, u.name, u.phone, '', hashPassword(u.password), now);
    userIds.set(u.phone, Number(info.lastInsertRowid));
  }
  // Admin həmişə mövcud olsun
  if (!q.get("SELECT id FROM users WHERE role = 'admin' LIMIT 1")) {
    insertUser.run('admin', 'Platforma Admini', '0500000000', '', hashPassword('admin123'), now);
  }

  const insertVendor = db.prepare(`INSERT INTO vendors
    (owner_user_id, slug, name, kind, category_id, tagline, description, address, phone, logo,
     open, approved, prep_time, min_order, rating, rating_count, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?)`);
  const insertProduct = db.prepare(`INSERT INTO products
    (vendor_id, section, name, description, price, unit, image, stock, active, sort, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`);

  const vendorBySlug = new Map();
  for (const v of seedVendors) {
    const owner = insertUser.run('vendor', v.owner.name, v.owner.phone, '', hashPassword(v.owner.password), now);
    const res = insertVendor.run(
      Number(owner.lastInsertRowid), v.slug, v.name, v.kind, catIds.get(v.category) ?? null,
      v.tagline, v.description, v.address, v.phone, v.logo,
      v.open ? 1 : 0, v.prep_time, v.min_order, v.rating, v.rating_count, now,
    );
    const vendorId = Number(res.lastInsertRowid);
    vendorBySlug.set(v.slug, vendorId);
    // Xəritə koordinatları — müştəri tətbiqində məsafə və yol vaxtı üçün
    const coord = vendorCoords[v.slug];
    if (coord) {
      db.prepare('UPDATE vendors SET lat = ?, lng = ? WHERE id = ?').run(coord[0], coord[1], vendorId);
    }
    // Baza reytinqi: demo mağazaların populyarlığı yeni rəylərlə sıfırlanmasın
    db.prepare('UPDATE vendors SET base_rating = ?, base_rating_count = ? WHERE id = ?')
      .run(v.rating, v.rating_count, vendorId);
    let sort = 0;
    const productIds = [];
    for (const sec of v.menu) {
      for (const item of sec.items) {
        const info = insertProduct.run(
          vendorId, sec.section, item.n, item.d ?? '', Math.round(item.p * 100),
          item.u ?? 'ədəd', item.i ?? '🍽️', item.st ?? null, sort, now,
        );
        productIds.push(Number(info.lastInsertRowid));
        sort++;
      }
    }
    v._productIds = productIds;
  }

  const createdOrders = seedDemoOrders(now);
  seedDemoCoupons(now);
  seedDemoReviews(createdOrders, now);

  return { skipped: false, vendors: seedVendors.length };
}

/** Demo kampaniyalar (idempotent: mövcud kodlar təkrar yazılmır) */
function seedDemoCoupons(now) {
  const insert = db.prepare(`INSERT INTO coupons
    (code, vendor_id, kind, value, min_order, max_discount, usage_limit, per_user_limit,
     starts_at, expires_at, active, description, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, 1, ?, ?)`);
  for (const c of demoCoupons) {
    if (q.get('SELECT id FROM coupons WHERE code = ?', c.code)) continue;
    const vendorId = c.vendor ? q.get('SELECT id FROM vendors WHERE slug = ?', c.vendor)?.id ?? null : null;
    const expires = c.expiresDays ? new Date(Date.now() + c.expiresDays * 864e5).toISOString() : null;
    insert.run(
      c.code, vendorId, c.kind, c.value, c.minOrder ?? 0, c.maxDiscount ?? 0,
      c.usageLimit ?? 0, c.perUserLimit ?? 1, expires, c.description ?? '', now,
    );
  }
}

/** Götürülmüş demo sifarişlərə rəylər və mağaza reytinqlərinin yenidən hesablanması (idempotent) */
function seedDemoReviews(createdOrders, now) {
  if (!createdOrders.length) return;
  const insert = db.prepare(`INSERT INTO reviews
    (order_id, vendor_id, user_id, author_name, rating, comment, reply, replied_at, hidden, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`);

  demoReviews.forEach((r, index) => {
    const order = createdOrders[r.order];
    if (!order || order.status !== 'picked_up') return;
    if (q.get('SELECT id FROM reviews WHERE order_id = ?', order.id)) return;
    const repliedAt = r.reply ? new Date(Date.now() - (index + 1) * 3600_000).toISOString() : null;
    insert.run(
      order.id, order.vendorId, order.userId ?? null,
      demoReviewAuthors[index % demoReviewAuthors.length] ?? order.customerName,
      r.rating, r.comment ?? '', r.reply ?? '', repliedAt,
      new Date(Date.now() - (index + 1) * 2 * 3600_000).toISOString(),
    );
  });

  // Reytinqi baza + yeni rəylərdən yenidən hesabla (reviews.js-dən asılılıq olmadan)
  db.exec(`
    UPDATE vendors SET
      rating = ROUND((
        base_rating * base_rating_count
        + COALESCE((SELECT SUM(r.rating) FROM reviews r WHERE r.vendor_id = vendors.id AND r.hidden = 0), 0)
      ) * 1.0 / NULLIF(
        base_rating_count + (SELECT COUNT(*) FROM reviews r WHERE r.vendor_id = vendors.id AND r.hidden = 0), 0
      ), 1),
      rating_count = base_rating_count + (SELECT COUNT(*) FROM reviews r WHERE r.vendor_id = vendors.id AND r.hidden = 0)
    WHERE base_rating_count + (SELECT COUNT(*) FROM reviews r WHERE r.vendor_id = vendors.id AND r.hidden = 0) > 0
  `);
  void now;
}

function seedDemoOrders(now) {
  const insertOrder = db.prepare(`INSERT INTO orders
    (code, customer_user_id, customer_name, customer_phone, vendor_id, status, subtotal, fee, total,
     commission, vendor_payout, payment, pickup_code, note, created_at, updated_at, ready_at, picked_up_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, '', ?, ?, ?, ?)`);
  const insertItem = db.prepare(`INSERT INTO order_items
    (order_id, product_id, name, price, qty, unit, image) VALUES (?, ?, ?, ?, ?, ?, ?)`);

  const customers = q.all("SELECT id, name, phone FROM users WHERE role = 'customer' ORDER BY id");
  if (!customers.length) return [];

  const createdOrders = [];
  for (const o of demoOrders) {
    const vendor = q.get('SELECT * FROM vendors WHERE slug = ?', o.vendor);
    if (!vendor) continue;
    const products = q.all('SELECT * FROM products WHERE vendor_id = ? ORDER BY sort, id', vendor.id);
    if (!products.length) continue;

    const picked = o.items
      .map(([idx, qty]) => ({ product: products[idx % products.length], qty }))
      .filter((x) => x.product);
    const subtotal = picked.reduce((sum, x) => sum + x.product.price * x.qty, 0);
    const created = new Date(Date.now() - o.minutesAgo * 60_000).toISOString();
    const updated = new Date(Date.now() - Math.max(0, o.minutesAgo - 10) * 60_000).toISOString();
    const customer = customers[(o.customer ?? 1) % customers.length];

    const code = `GT-${1000 + (q.get('SELECT COUNT(*) AS c FROM orders').c + 1)}`;
    // Komissiya: mağazanın fərdi faizi, yoxdursa platforma defoltu
    const percent = Number(vendor.commission_percent ?? 0) > 0
      ? Number(vendor.commission_percent)
      : Number(q.get("SELECT value FROM settings WHERE key = 'default_commission'")?.value ?? 12);
    const commission = Math.round((subtotal * percent) / 100);
    const info = insertOrder.run(
      code, customer.id, customer.name, customer.phone, vendor.id, o.status, subtotal, subtotal,
      commission, subtotal - commission,
      o.payment, randomDigits(4), created, updated,
      o.status === 'ready' || o.status === 'picked_up' ? updated : null,
      o.status === 'picked_up' ? updated : null,
    );
    const orderId = Number(info.lastInsertRowid);
    for (const { product, qty } of picked) {
      insertItem.run(orderId, product.id, product.name, product.price, qty, product.unit, product.image);
    }
    const flow = ['pending', 'accepted', 'preparing', 'ready', 'picked_up'];
    const upto = o.status === 'cancelled' ? ['pending', 'cancelled'] : flow.slice(0, flow.indexOf(o.status) + 1);
    for (const st of upto) logEvent(orderId, st, st === 'cancelled' ? 'Müştəri ləğv etdi' : '');

    // Demo ödəniş qeydləri (hesablaşma və ödəniş ekranları boş görünməsin)
    const paidStatuses = ['ready', 'picked_up'];
    if (o.payment === 'online') {
      const paid = paidStatuses.includes(o.status);
      q.run(`INSERT INTO payments (order_id, provider, method, token, amount, status, card_last4, created_at, paid_at)
             VALUES (?, 'simulated', 'online', ?, ?, ?, ?, ?, ?)`,
        orderId, randomDigits(6) + randomDigits(12), subtotal,
        o.status === 'cancelled' ? 'refunded' : paid ? 'paid' : 'requires_action',
        paid ? '4242' : null, created, paid ? updated : null);
      if (paid || o.status === 'cancelled') {
        q.run("UPDATE orders SET payment_status = ?, paid_at = ? WHERE id = ?",
          o.status === 'cancelled' ? 'refunded' : 'paid', updated, orderId);
      }
    } else if (paidStatuses.includes(o.status)) {
      q.run(`INSERT INTO payments (order_id, provider, method, token, amount, status, created_at, paid_at)
             VALUES (?, 'counter', ?, ?, ?, 'paid', ?, ?)`,
        orderId, o.payment === 'card' ? 'card' : 'cash', randomDigits(18), subtotal, updated, updated);
      q.run("UPDATE orders SET payment_status = 'paid', paid_at = ? WHERE id = ?", updated, orderId);
    }

    createdOrders.push({
      id: orderId,
      code,
      vendorId: vendor.id,
      vendorSlug: vendor.slug,
      status: o.status,
      customerName: customer.name,
      userId: customer.id,
    });
  }
  return createdOrders;
}

/** Sifariş kodunun düzgün ardıcıllığını təmin edən köməkçi (real sifarişlər üçün). */
export function nextOrderCode() {
  const last = q.get('SELECT id FROM orders ORDER BY id DESC LIMIT 1');
  return orderCode(last ? last.id + 1 : 1);
}
