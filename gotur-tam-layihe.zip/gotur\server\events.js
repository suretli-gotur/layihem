/**
 * Götür — real vaxt hadisə şini (Server-Sent Events).
 *
 * Xarici asılılıq yoxdur: SSE adi HTTP üzərində işləyir və `fetch`/`EventSource`
 * ilə hər brauzerdə dəstəklənir. Hər bağlantının öz filtri var:
 *   • satıcı   → yalnız öz mağazasının hadisələri
 *   • müştəri  → yalnız izlədiyi sifariş kodları
 *   • admin    → bütün hadisələr
 */

const clients = new Set();
let heartbeat = null;
let seq = 0;

const PING_INTERVAL = 20000;

function tick() {
  for (const client of [...clients]) {
    try {
      client.res.write(': ping\n\n');
    } catch {
      removeClient(client);
    }
  }
}

export function addClient(res, filter, meta = {}) {
  const client = { id: ++seq, res, filter, ...meta, connectedAt: new Date().toISOString() };
  clients.add(client);
  if (!heartbeat) heartbeat = setInterval(tick, PING_INTERVAL);
  try {
    res.write(`event: ready\ndata: ${JSON.stringify({ clientId: client.id, at: client.connectedAt })}\n\n`);
  } catch { /* bağlantı dərhal qapandı */ }
  return client;
}

export function removeClient(client) {
  clients.delete(client);
  if (!clients.size && heartbeat) {
    clearInterval(heartbeat);
    heartbeat = null;
  }
}

/**
 * Hadisə yayır.
 * @param {string} type   məsələn 'order.created' | 'order.status' | 'order.payment'
 * @param {object} data   brauzerə göndərilən yük
 * @param {object} meta   { vendorId, customerUserId, codes: string[], orderId }
 */
export function publish(type, data, meta = {}) {
  if (!clients.size) return 0;
  const payload = `event: ${type}\ndata: ${JSON.stringify(data)}\n\n`;
  let delivered = 0;
  for (const client of [...clients]) {
    try {
      if (client.filter(meta)) {
        client.res.write(payload);
        delivered++;
      }
    } catch {
      removeClient(client);
    }
  }
  return delivered;
}

export const clientCount = () => clients.size;

export const clientStats = () =>
  [...clients].map((c) => ({ id: c.id, kind: c.kind ?? 'unknown', since: c.connectedAt }));
