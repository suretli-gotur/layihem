/**
 * Götür — məsafə və yol vaxtı hesablamaları.
 *
 * Koordinatlar WGS-84 (xəritə ilə eyni). Məsafə düz xətt üzrə (Haversine)
 * hesablanır; vaxtlar şəhər daxili orta sürətlərə görə TƏXMİNİdir:
 *   • yerimə   — 4.8 km/saat
 *   • avtomobil — 25 km/saat + 2 dəqiqə (park/dayanacaq)
 */

const EARTH_RADIUS_KM = 6371.0088;
const WALK_KMH = 4.8;
const DRIVE_KMH = 25;
const DRIVE_OVERHEAD_MIN = 2;

const toRad = (deg) => (deg * Math.PI) / 180;

/**
 * Dəyəri koordinata çevirir. BOŞ dəyərlər (null / undefined / "") NaN olur —
 * `Number(null) === 0` olduğu üçün bu vacibdir, əks halda koordinatsız mağaza
 * (0, 0) nöqtəsində sayılır (Qvineya körfəzi).
 */
const num = (value) => {
  if (value === null || value === undefined || value === '') return Number.NaN;
  const n = Number(value);
  return Number.isFinite(n) ? n : Number.NaN;
};

/** İki nöqtə arasındakı məsafə (km, düz xətt). */
export function haversineKm(lat1, lng1, lat2, lng2) {
  const a1 = num(lat1);
  const o1 = num(lng1);
  const a2 = num(lat2);
  const o2 = num(lng2);
  if (![a1, o1, a2, o2].every(Number.isFinite)) return Number.NaN;
  const dLat = toRad(a2 - a1);
  const dLng = toRad(o2 - o1);
  const a = Math.sin(dLat / 2) ** 2
    + Math.cos(toRad(a1)) * Math.cos(toRad(a2)) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.min(1, Math.sqrt(a)));
}

export const isCoord = (lat, lng) => {
  const a = num(lat);
  const o = num(lng);
  return Number.isFinite(a) && Number.isFinite(o) && Math.abs(a) <= 90 && Math.abs(o) <= 180;
};

/** Məsafədən yol vaxtlarını çıxarır (dəqiqə, tam ədədə yuvarlaqlaşdırılmış). */
export function travelEstimates(km) {
  const safe = Math.max(0, Number(km) || 0);
  return {
    walkMinutes: Math.max(1, Math.round((safe / WALK_KMH) * 60)),
    driveMinutes: Math.max(1, Math.round((safe / DRIVE_KMH) * 60) + DRIVE_OVERHEAD_MIN),
  };
}

/** Mağaza sətrinə məsafə məlumatı əlavə edir (koordinat yoxdursa null qaytarır). */
export function withDistance(vendor, fromLat, fromLng) {
  if (!isCoord(fromLat, fromLng)) return vendor;
  if (!isCoord(vendor.lat, vendor.lng)) {
    return { ...vendor, distanceKm: null, walkMinutes: null, driveMinutes: null };
  }
  const km = haversineKm(fromLat, fromLng, vendor.lat, vendor.lng);
  if (!Number.isFinite(km)) {
    return { ...vendor, distanceKm: null, walkMinutes: null, driveMinutes: null };
  }
  const { walkMinutes, driveMinutes } = travelEstimates(km);
  return {
    ...vendor,
    distanceKm: Math.round(km * 1000) / 1000,
    walkMinutes,
    driveMinutes,
  };
}

/** Məsafəyə görə sıralayır (koordinatı olmayanlar sona düşür). */
export function sortByDistance(list, fromLat, fromLng) {
  if (!isCoord(fromLat, fromLng)) return list;
  return [...list]
    .map((v) => withDistance(v, fromLat, fromLng))
    .sort((a, b) => {
      if (a.distanceKm == null && b.distanceKm == null) return 0;
      if (a.distanceKm == null) return 1;
      if (b.distanceKm == null) return -1;
      return a.distanceKm - b.distanceKm;
    });
}
