import http from 'node:http';
import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { extname, join, normalize, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

import { handleApi } from './api.js';
import { DB_PATH, ROOT, migrate, q, schemaVersion, seed } from './db.js';
import { HttpError, sendJson } from './util.js';

const PUBLIC_DIR = resolve(ROOT, 'public');
const PORT = Number(process.env.PORT || process.env.GOTUR_PORT || 4173);
const HOST = process.env.HOST || '127.0.0.1';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
};

async function serveStatic(req, res, pathname) {
  let rel = pathname === '/' ? '/index.html' : pathname;
  rel = decodeURIComponent(rel.split('?')[0]);
  const target = resolve(join(PUBLIC_DIR, normalize(rel)));
  if (!target.startsWith(PUBLIC_DIR + sep) && target !== PUBLIC_DIR) {
    sendJson(res, 403, { error: 'İcazə yoxdur' });
    return;
  }
  let info;
  try {
    info = await stat(target);
  } catch {
    sendJson(res, 404, { error: 'Fayl tapılmadı', path: pathname });
    return;
  }
  if (info.isDirectory()) {
    sendJson(res, 404, { error: 'Fayl tapılmadı' });
    return;
  }
  const type = MIME[extname(target).toLowerCase()] || 'application/octet-stream';
  const etag = `W/"${info.size}-${Number(info.mtimeMs).toString(36)}"`;
  if (req.headers['if-none-match'] === etag) {
    res.writeHead(304, { etag });
    res.end();
    return;
  }
  res.writeHead(200, {
    'content-type': type,
    'content-length': info.size,
    etag,
    'cache-control': 'no-cache',
  });
  if (req.method === 'HEAD') return res.end();
  createReadStream(target).pipe(res);
}

export function createServer() {
  migrate();
  const seedResult = seed();
  // Bulud/pulsuz serverlərdə baza sıfırlananda demo data avtomatik qurulsun
  if (process.env.GOTUR_SEED === '1' && seedResult.skipped) {
    const empty = q.get('SELECT COUNT(*) AS c FROM vendors').c === 0;
    if (empty) seed({ force: true });
  }

  const server = http.createServer(async (req, res) => {
    const started = Date.now();
    let url;
    try {
      url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    } catch {
      sendJson(res, 400, { error: 'Yanlış URL' });
      return;
    }
    try {
      if (url.pathname.startsWith('/api/')) {
        await handleApi(req, res, url);
      } else if (req.method === 'GET' || req.method === 'HEAD') {
        await serveStatic(req, res, url.pathname);
      } else {
        sendJson(res, 405, { error: 'Metod dəstəklənmir' });
      }
    } catch (err) {
      if (err instanceof HttpError) {
        sendJson(res, err.status, { error: err.message, code: err.code, params: err.params ?? null });
      } else {
        console.error('[gotur] daxili xəta:', err);
        sendJson(res, 500, { error: 'Daxili server xətası' });
      }
    } finally {
      if (process.env.GOTUR_LOG !== '0' && url.pathname.startsWith('/api/')) {
        console.log(`${req.method} ${url.pathname} → ${res.statusCode} (${Date.now() - started}ms)`);
      }
    }
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`\n  ✖ ${HOST}:${PORT} portu artıq məşğuldur.`);
      console.error(`    Başqa portla yoxlayın:  $env:PORT=4180; npm start\n`);
      process.exit(1);
    }
    throw err;
  });

  server.gotur = { seedResult, DB_PATH };
  return server;
}

export function start() {
  const server = createServer();
  server.listen(PORT, HOST, () => {
    const { seedResult } = server.gotur;
    console.log('');
    console.log('  ┌───────────────────────────────────────────────┐');
    console.log('  │   GÖTÜR — sifariş et, özün götür             │');
    console.log('  └───────────────────────────────────────────────┘');
    console.log(`  Müştəri tətbiqi :  http://${HOST}:${PORT}/`);
    console.log(`  Satıcı paneli   :  http://${HOST}:${PORT}/satis.html`);
    console.log(`  Admin paneli    :  http://${HOST}:${PORT}/admin.html`);
    console.log('');
    console.log(`  Baza        : ${DB_PATH}`);
    console.log(`  Demo data   : ${seedResult.skipped ? 'mövcud baza istifadə olunur' : 'yaradıldı'}`);
    console.log('');
    console.log('  Demo girişlər:');
    console.log('    Admin    : 0500000000 / admin123');
    console.log('    Satıcı   : 0501110001 / vendor123   (Şirvanşah Kabab Evi)');
    console.log('    Müştəri  : 0501234567 / customer123');
    console.log('');
    console.log('  Dayandırmaq üçün Ctrl+C');
    console.log('');
  });
  return server;
}

/* Yalnız birbaşa işə salındıqda dinləyir (testlər üçün import edilə bilər) */
const isMain = process.argv[1] && resolve(fileURLToPath(import.meta.url)) === resolve(process.argv[1]);
if (isMain) {
  start();
}
