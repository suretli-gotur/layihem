/**
 * Götür — ödəniş qatı.
 *
 * İki provayder dəstəklənir:
 *   • `simulated` — heç bir xarici xidmət tələb etmir (default). Kart nömrəsi Luhn
 *     alqoritmi ilə yoxlanılır, test kartı ilə uğursuz ödəniş simulyasiya olunur.
 *   • `stripe`    — `STRIPE_SECRET_KEY` verildikdə avtomatik aktivləşir. SDK yoxdur:
 *     Stripe REST API-si birbaşa `fetch` ilə çağırılır, webhook imzası HMAC-SHA256
 *     ilə `node:crypto` vasitəsilə yoxlanılır.
 *
 * Kassada ödənişlər (`counter`) eyni `payments` cədvəlində saxlanılır ki,
 * hesablaşma (settlement) hesabatları vahid olsun.
 */
import crypto from 'node:crypto';
import { q } from './db.js';
import { bad, HttpError, notFound, nowIso, randomToken } from './util.js';
import { publish } from './events.js';

/** Ödəniş hadisələrini həmin sifarişin satıcısına və müştərisinə yayır. */
function publishPaymentEvent(type, orderId, extra = {}) {
  const order = q.get('SELECT id, code, vendor_id, customer_user_id FROM orders WHERE id = ?', orderId);
  if (!order) return;
  publish(type, { orderId: order.id, code: order.code, ...extra, at: nowIso() }, {
    vendorId: order.vendor_id,
    customerUserId: order.customer_user_id,
    codes: [order.code],
    orderId: order.id,
  });
}

export const PROVIDERS = ['simulated', 'stripe'];
export const PAYMENT_STATUSES = ['requires_action', 'paid', 'failed', 'refunded', 'cancelled'];

export const PAYMENT_STATUS_LABEL = {
  requires_action: 'Ödəniş gözləyir',
  paid: 'Ödənilib',
  failed: 'Ödəniş alınmadı',
  refunded: 'Geri qaytarılıb',
  cancelled: 'Ləğv edilib',
};

export const stripeEnabled = () => Boolean(process.env.STRIPE_SECRET_KEY);
export const stripeCurrency = () => (process.env.STRIPE_CURRENCY || 'azn').toLowerCase();
const publicUrl = () => (process.env.PUBLIC_URL || `http://${process.env.HOST || '127.0.0.1'}:${process.env.PORT || 4173}`).replace(/\/$/, '');

/* ------------------------------------------------------------------ *
 * Kart yoxlaması (Luhn) — test edilə bilən təmiz funksiya
 * ------------------------------------------------------------------ */
export function luhnValid(cardNumber) {
  const digits = String(cardNumber ?? '').replace(/\D/g, '');
  if (digits.length < 12 || digits.length > 19) return false;
  let sum = 0;
  let double = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let d = Number(digits[i]);
    if (double) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
    double = !double;
  }
  return sum % 10 === 0;
}

/** MM/YY formatını yoxlayır və keçmiş tarixi rədd edir. */
export function expiryValid(value, now = new Date()) {
  const m = String(value ?? '').trim().match(/^(\d{2})\s*\/?\s*(\d{2,4})$/);
  if (!m) return false;
  const month = Number(m[1]);
  if (month < 1 || month > 12) return false;
  let year = Number(m[2]);
  if (year < 100) year += 2000;
  const end = new Date(year, month, 1); // həmin ayın sonu
  return end > now;
}

export const cvcValid = (value) => /^\d{3,4}$/.test(String(value ?? '').trim());

/* ------------------------------------------------------------------ *
 * Ödəniş yaradılması
 * ------------------------------------------------------------------ */
const insertPayment = (orderId, provider, method, amount, status, extra = {}) => {
  const info = q.run(
    `INSERT INTO payments (order_id, provider, method, provider_ref, provider_intent, token, amount, status, card_last4, error, created_at, paid_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    orderId, provider, method, extra.providerRef ?? null, extra.providerIntent ?? null,
    extra.token ?? randomToken(18),
    amount, status, extra.cardLast4 ?? null, extra.error ?? '', nowIso(), extra.paidAt ?? null,
  );
  return q.get('SELECT * FROM payments WHERE id = ?', Number(info.lastInsertRowid));
};

/**
 * Sifariş üçün ödəniş yaradır.
 * `online` → provayder axını (simulyasiya linki və ya Stripe checkout URL-i).
 * `cash`/`card` → kassada ödəniş: qeyd yaradılmır, sifariş «ödənilməyib» qalır.
 */
export async function createPaymentForOrder(order) {
  if (order.payment !== 'online') {
    q.run("UPDATE orders SET payment_status = 'unpaid' WHERE id = ?", order.id);
    return null;
  }

  if (stripeEnabled()) {
    const session = await stripeCreateCheckoutSession(order);
    const payment = insertPayment(order.id, 'stripe', 'online', order.total, 'requires_action', {
      providerRef: session.id,
    });
    q.run("UPDATE orders SET payment_status = 'unpaid' WHERE id = ?", order.id);
    return { payment, redirectUrl: session.url };
  }

  const payment = insertPayment(order.id, 'simulated', 'online', order.total, 'requires_action', {});
  q.run("UPDATE orders SET payment_status = 'unpaid' WHERE id = ?", order.id);
  return { payment, redirectUrl: `/odenis.html?token=${payment.token}` };
}

export const getPaymentByToken = (token) => q.get('SELECT * FROM payments WHERE token = ?', String(token ?? ''));

export const getPaymentsForOrder = (orderId) =>
  q.all('SELECT * FROM payments WHERE order_id = ? ORDER BY id DESC', orderId);

export function serializePayment(p, { mask = false } = {}) {
  if (!p) return null;
  return {
    id: p.id,
    orderId: p.order_id,
    provider: p.provider,
    method: p.method,
    status: p.status,
    statusLabel: PAYMENT_STATUS_LABEL[p.status] ?? p.status,
    amount: p.amount,
    cardLast4: p.card_last4 || null,
    error: p.error || '',
    token: mask ? undefined : p.token,
    providerRef: mask ? undefined : p.provider_ref,
    createdAt: p.created_at,
    paidAt: p.paid_at,
    refundedAt: p.refunded_at,
  };
}

/** Ödəniş səhifəsi üçün təhlükəsiz (maskalanmış) məlumat. */
export function checkoutInfo(payment) {
  const order = q.get(
    `SELECT o.*, v.name AS vendor_name, v.address AS vendor_address, v.logo AS vendor_logo
     FROM orders o JOIN vendors v ON v.id = o.vendor_id WHERE o.id = ?`,
    payment.order_id,
  );
  return {
    token: payment.token,
    provider: payment.provider,
    status: payment.status,
    statusLabel: PAYMENT_STATUS_LABEL[payment.status] ?? payment.status,
    amount: payment.amount,
    cardLast4: payment.card_last4 || null,
    error: payment.error || '',
    paidAt: payment.paid_at,
    currency: stripeCurrency().toUpperCase(),
    order: order ? {
      code: order.code,
      pickupCode: order.pickup_code,
      vendorName: order.vendor_name,
      vendorAddress: order.vendor_address,
      vendorLogo: order.vendor_logo,
      customerName: order.customer_name,
      total: order.total,
      paymentStatus: order.payment_status,
    } : null,
    stripeConfigured: stripeEnabled(),
  };
}

/* ------------------------------------------------------------------ *
 * Ödənişin tamamlanması / uğursuzluğu
 * ------------------------------------------------------------------ */
export function markPaid(payment, { cardLast4 = null, method = null, providerRef = null, providerIntent = null } = {}) {
  const now = nowIso();
  q.run(
    `UPDATE payments SET status = 'paid', paid_at = ?, card_last4 = COALESCE(?, card_last4),
       method = COALESCE(?, method), provider_ref = COALESCE(?, provider_ref),
       provider_intent = COALESCE(?, provider_intent), error = ''
     WHERE id = ?`,
    now, cardLast4, method, providerRef, providerIntent, payment.id,
  );
  q.run("UPDATE orders SET payment_status = 'paid', paid_at = ?, updated_at = ? WHERE id = ?",
    now, now, payment.order_id);
  q.run('INSERT INTO order_events (order_id, status, note, created_at) VALUES (?, ?, ?, ?)',
    payment.order_id, 'paid',
    payment.provider === 'counter'
      ? `Kassada ödəniş alındı (${method === 'card' ? 'kart' : 'nağd'})`
      : `Onlayn ödəniş alındı${cardLast4 ? ` (•••• ${cardLast4})` : ''}`,
    now);
  publishPaymentEvent('order.payment', payment.order_id, {
    paymentStatus: 'paid',
    status: 'paid',
    amount: payment.amount,
    provider: payment.provider,
    method,
  });
  return q.get('SELECT * FROM payments WHERE id = ?', payment.id);
}

export function markFailed(payment, reason = 'Ödəniş alınmadı') {
  q.run("UPDATE payments SET status = 'failed', error = ? WHERE id = ?", String(reason).slice(0, 200), payment.id);
  q.run("UPDATE orders SET payment_status = 'failed', updated_at = ? WHERE id = ?", nowIso(), payment.order_id);
  publishPaymentEvent('order.payment', payment.order_id, {
    paymentStatus: 'failed',
    status: 'failed',
    error: String(reason).slice(0, 200),
  });
  return q.get('SELECT * FROM payments WHERE id = ?', payment.id);
}

/** Simulyasiya edilmiş kart ödənişi. */
export function paySimulated(token, card = {}) {
  const payment = getPaymentByToken(token);
  if (!payment) throw notFound('Ödəniş tapılmadı');
  if (payment.provider !== 'simulated') throw bad('Bu ödəniş simulyasiya provayderinə aid deyil', 'payment_not_simulated');
  if (payment.status === 'paid') throw bad('Bu ödəniş artıq tamamlanıb', 'payment_done');
  if (payment.status === 'refunded' || payment.status === 'cancelled') {
    throw bad('Bu ödəniş bağlanıb', 'payment_closed');
  }

  const number = String(card.number ?? '').replace(/\D/g, '');
  if (!luhnValid(number)) throw bad('Kart nömrəsi yanlışdır (Luhn yoxlaması uğursuz)', 'invalid_card');
  if (!expiryValid(card.expiry)) throw bad('Son istifadə tarixi yanlışdır (MM/YY)', 'invalid_expiry');
  if (!cvcValid(card.cvc)) throw bad('CVV 3 və ya 4 rəqəm olmalıdır', 'invalid_cvc');

  const last4 = number.slice(-4);
  if (last4 === '0002') {
    markFailed(payment, 'Kart rədd edildi (test kartı •••• 0002)');
    throw new HttpError(402, 'Kart rədd edildi. Başqa kart yoxlayın.', 'card_declined');
  }

  return markPaid(payment, { cardLast4: last4, method: 'online' });
}

/** Kassada (və ya çatdırılmayan ödəniş üçün) ödənişin qeydə alınması. */
export function collectAtCounter(order, method = 'cash') {
  if (order.payment_status === 'paid') throw bad('Bu sifariş artıq ödənilib', 'already_paid');
  if (order.status === 'cancelled') {
    throw bad('Ləğv edilmiş sifariş üçün ödəniş qeydə alınmır', 'cancelled_order_payment');
  }
  const payment = insertPayment(order.id, 'counter', method === 'card' ? 'card' : 'cash', order.total, 'requires_action', {});
  return markPaid(payment, { method: payment.method });
}

/* ------------------------------------------------------------------ *
 * Geri qaytarma (refund)
 * ------------------------------------------------------------------ */
export async function refundOrder(order, reason = 'Sifariş ləğv edildi') {
  const paid = q.all("SELECT * FROM payments WHERE order_id = ? AND status = 'paid'", order.id);
  if (!paid.length) return [];
  const results = [];
  for (const payment of paid) {
    if (payment.provider === 'stripe') {
      try {
        await stripeRefund(payment.provider_intent || payment.provider_ref);
      } catch (err) {
        q.run("UPDATE payments SET error = ? WHERE id = ?", `Refund xətası: ${err.message}`.slice(0, 200), payment.id);
        results.push({ id: payment.id, refunded: false, error: err.message });
        continue;
      }
    }
    const now = nowIso();
    q.run("UPDATE payments SET status = 'refunded', refunded_at = ?, error = '' WHERE id = ?", now, payment.id);
    results.push({ id: payment.id, refunded: true });
  }
  const now = nowIso();
  q.run("UPDATE orders SET payment_status = 'refunded', updated_at = ? WHERE id = ?", now, order.id);
  q.run('INSERT INTO order_events (order_id, status, note, created_at) VALUES (?, ?, ?, ?)',
    order.id, 'refunded', `Ödəniş geri qaytarıldı: ${reason}`, now);
  publishPaymentEvent('order.payment', order.id, { paymentStatus: 'refunded', status: 'refunded', reason });
  return results;
}

/* ------------------------------------------------------------------ *
 * Stripe (SDK-sız, REST + webhook imzası)
 * ------------------------------------------------------------------ */
const STRIPE_API = 'https://api.stripe.com/v1';

async function stripeRequest(path, { method = 'POST', body } = {}) {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) throw new HttpError(503, 'Stripe konfiqurasiya edilməyib', 'stripe_off');
  const res = await fetch(`${STRIPE_API}${path}`, {
    method,
    headers: {
      authorization: `Bearer ${key}`,
      ...(body ? { 'content-type': 'application/x-www-form-urlencoded' } : {}),
    },
    body: body ? new URLSearchParams(body).toString() : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = data?.error?.message || `HTTP ${res.status}`;
    throw new HttpError(502, `Ödəniş provayderi xətası: ${msg}`, 'provider_error');
  }
  return data;
}

export async function stripeCreateCheckoutSession(order) {
  const vendor = q.get('SELECT name FROM vendors WHERE id = ?', order.vendor_id);
  return stripeRequest('/checkout/sessions', {
    body: {
      mode: 'payment',
      'line_items[0][quantity]': '1',
      'line_items[0][price_data][currency]': stripeCurrency(),
      'line_items[0][price_data][unit_amount]': String(order.total),
      'line_items[0][price_data][product_name]': `Sifariş ${order.code} — ${vendor?.name ?? 'Götür'}`,
      success_url: `${publicUrl()}/odenis.html?provider=stripe&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${publicUrl()}/odenis.html?provider=stripe&cancelled=1&order=${encodeURIComponent(order.code)}`,
      client_reference_id: String(order.id),
      'metadata[order_id]': String(order.id),
      'metadata[order_code]': order.code,
    },
  });
}

export const stripeRetrieveSession = (sessionId) =>
  stripeRequest(`/checkout/sessions/${encodeURIComponent(sessionId)}`, { method: 'GET' });

export const stripeRefund = (paymentIntent) =>
  stripeRequest('/refunds', { body: { payment_intent: paymentIntent } });

/**
 * Stripe webhook imzasını yoxlayır (`Stripe-Signature: t=...,v1=...`).
 * Təmiz funksiyadır — şəbəkə tələb etmir, ona görə testlərdə yoxlanılır.
 */
export function verifyStripeSignature(payload, signatureHeader, secret, toleranceSeconds = 300, nowMs = Date.now()) {
  if (!secret) return false;
  const parts = String(signatureHeader ?? '').split(',').reduce((acc, piece) => {
    const [k, v] = piece.split('=');
    if (!k || !v) return acc;
    (acc[k.trim()] ??= []).push(v.trim());
    return acc;
  }, {});
  const timestamp = Number(parts.t?.[0]);
  if (!Number.isFinite(timestamp)) return false;
  if (Math.abs(nowMs / 1000 - timestamp) > toleranceSeconds) return false;

  const expected = crypto
    .createHmac('sha256', secret)
    .update(`${timestamp}.${payload}`)
    .digest('hex');
  const candidates = parts.v1 ?? [];
  return candidates.some((sig) => {
    const a = Buffer.from(sig, 'utf8');
    const b = Buffer.from(expected, 'utf8');
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  });
}

/** Stripe-dən qayıdan istifadəçinin ödənişini yoxlayıb təsdiqləyir. */
export async function confirmStripeSession(sessionId) {
  const session = await stripeRetrieveSession(sessionId);
  const orderId = Number(session.metadata?.order_id ?? session.client_reference_id ?? 0);
  const payment = q.get(
    "SELECT * FROM payments WHERE provider = 'stripe' AND (provider_ref = ? OR order_id = ?) ORDER BY id DESC",
    session.id, orderId,
  );
  if (!payment) throw notFound('Ödəniş tapılmadı');
  if (session.payment_status === 'paid') {
    if (payment.status !== 'paid') {
      return markPaid(payment, {
        providerRef: session.id,
        providerIntent: session.payment_intent ?? null,
        method: 'online',
      });
    }
    return payment;
  }
  if (session.status === 'expired') return markFailed(payment, 'Ödəniş sessiyası vaxtı bitdi');
  return payment;
}
