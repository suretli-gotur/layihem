/**
 * Götür — rəy və reytinq modulu.
 *
 * Qaydalar:
 *   • Rəy yalnız «götürülmüş» (picked_up) sifarişə yazılır — bir sifariş, bir rəy.
 *   • Mağaza reytinqi BAZA reytinqi ilə yeni rəylərin çəkili ortalamasıdır:
 *     (baza × baza sayı + yeni ulduzlar) / (baza sayı + yeni rəy sayı).
 *     Beləliklə demo mağazaların populyarlığı bir rəylə sıfırlanmır.
 *   • Gizlədilən (moderasiya) rəylər reytinqə təsir etmir.
 *   • Satıcı öz rəyinə cavab yaza bilər.
 */
import { q } from './db.js';
import { bad, forbidden, notFound, nowIso, str } from './util.js';
import { publish } from './events.js';

export const MAX_RATING = 5;

export function serializeReview(r) {
  return {
    id: r.id,
    orderId: r.order_id,
    vendorId: r.vendor_id,
    authorName: r.author_name,
    rating: r.rating,
    comment: r.comment || '',
    reply: r.reply || '',
    repliedAt: r.replied_at,
    hidden: !!r.hidden,
    createdAt: r.created_at,
  };
}

/** Mağazanın reytinqini baza + yeni rəylərdən yenidən hesablayır. */
export function recalcVendorRating(vendorId) {
  const vendor = q.get('SELECT id, base_rating, base_rating_count FROM vendors WHERE id = ?', vendorId);
  if (!vendor) return null;
  const agg = q.get(
    'SELECT COUNT(*) AS c, COALESCE(SUM(rating), 0) AS s FROM reviews WHERE vendor_id = ? AND hidden = 0',
    vendorId,
  );
  const count = (vendor.base_rating_count ?? 0) + agg.c;
  const sum = (vendor.base_rating ?? 0) * (vendor.base_rating_count ?? 0) + agg.s;
  const rating = count > 0 ? Math.round((sum / count) * 10) / 10 : 0;
  q.run('UPDATE vendors SET rating = ?, rating_count = ? WHERE id = ?', rating, count, vendorId);
  return { rating, ratingCount: count };
}

/**
 * Sifariş üçün rəy yaradır.
 * @param {object} order  sifariş sətri (tam)
 * @param {{rating:number, comment?:string, authorName?:string, userId?:number}} payload
 */
export function createReview(order, payload) {
  if (order.status !== 'picked_up') {
    throw bad('Rəy yalnız götürülmüş sifarişə yazıla bilər', 'review_not_picked_up');
  }
  if (q.get('SELECT id FROM reviews WHERE order_id = ?', order.id)) {
    throw bad('Bu sifariş üçün artıq rəy yazılıb', 'review_exists');
  }
  const rating = Number(payload.rating);
  if (!Number.isInteger(rating) || rating < 1 || rating > MAX_RATING) {
    throw bad(`Reytinq 1–${MAX_RATING} arasında tam ədəd olmalıdır`, 'review_rating_invalid', { max: MAX_RATING });
  }

  const info = q.run(
    `INSERT INTO reviews (order_id, vendor_id, user_id, author_name, rating, comment, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    order.id, order.vendor_id, payload.userId ?? order.customer_user_id ?? null,
    str(payload.authorName ?? order.customer_name, 80) || 'Müştəri',
    rating, str(payload.comment, 600), nowIso(),
  );
  const review = q.get('SELECT * FROM reviews WHERE id = ?', Number(info.lastInsertRowid));
  const summary = recalcVendorRating(order.vendor_id);

  publish('review.created', {
    review: serializeReview(review),
    orderCode: order.code,
    rating,
    ratingCount: summary?.ratingCount,
    vendorRating: summary?.rating,
  }, {
    vendorId: order.vendor_id,
    customerUserId: order.customer_user_id,
    codes: [order.code],
    orderId: order.id,
  });

  return { review: serializeReview(review), summary };
}

export function reviewForOrder(orderId) {
  const row = q.get('SELECT * FROM reviews WHERE order_id = ?', orderId);
  return row ? serializeReview(row) : null;
}

export function vendorReviews(vendorId, { includeHidden = false, limit = 50 } = {}) {
  const rows = q.all(
    `SELECT * FROM reviews WHERE vendor_id = ? ${includeHidden ? '' : 'AND hidden = 0'}
     ORDER BY created_at DESC LIMIT ?`,
    vendorId, limit,
  );
  return rows.map(serializeReview);
}

/** Ulduz bölgüsü + orta bal (yalnız açıq rəylər). */
export function reviewSummary(vendorId) {
  const rows = q.all(
    'SELECT rating, COUNT(*) AS c FROM reviews WHERE vendor_id = ? AND hidden = 0 GROUP BY rating',
    vendorId,
  );
  const distribution = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  let total = 0;
  let sum = 0;
  for (const row of rows) {
    distribution[row.rating] = row.c;
    total += row.c;
    sum += row.rating * row.c;
  }
  const vendor = q.get('SELECT rating, rating_count FROM vendors WHERE id = ?', vendorId);
  return {
    reviewCount: total,
    newRating: total ? Math.round((sum / total) * 10) / 10 : 0,
    distribution,
    rating: vendor?.rating ?? 0,
    ratingCount: vendor?.rating_count ?? 0,
  };
}

export function replyToReview(reviewId, vendorId, reply) {
  const review = q.get('SELECT * FROM reviews WHERE id = ? AND vendor_id = ?', reviewId, vendorId);
  if (!review) throw notFound('Rəy tapılmadı');
  const text = str(reply, 400);
  if (!text) throw bad('Cavab mətni boşdur');
  q.run('UPDATE reviews SET reply = ?, replied_at = ? WHERE id = ?', text, nowIso(), reviewId);
  publish('review.replied', { reviewId, orderId: review.order_id }, {
    vendorId, customerUserId: review.user_id, orderId: review.order_id, codes: [],
  });
  return serializeReview(q.get('SELECT * FROM reviews WHERE id = ?', reviewId));
}

/** Admin moderasiyası: rəyi gizlət/göstər və reytinqi yenidən hesabla. */
export function setReviewHidden(reviewId, hidden) {
  const review = q.get('SELECT * FROM reviews WHERE id = ?', reviewId);
  if (!review) throw notFound('Rəy tapılmadı');
  q.run('UPDATE reviews SET hidden = ? WHERE id = ?', hidden ? 1 : 0, reviewId);
  const summary = recalcVendorRating(review.vendor_id);
  return { review: serializeReview(q.get('SELECT * FROM reviews WHERE id = ?', reviewId)), summary };
}

export function adminReviews({ vendorId = null, hidden = null, limit = 200 } = {}) {
  const where = [];
  const params = [];
  if (vendorId) { where.push('r.vendor_id = ?'); params.push(vendorId); }
  if (hidden !== null) { where.push('r.hidden = ?'); params.push(hidden ? 1 : 0); }
  const rows = q.all(
    `SELECT r.*, v.name AS vendor_name, v.slug AS vendor_slug FROM reviews r
     JOIN vendors v ON v.id = r.vendor_id
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
     ORDER BY r.created_at DESC LIMIT ?`,
    ...params, limit,
  );
  return rows.map((r) => ({ ...serializeReview(r), vendorName: r.vendor_name, vendorSlug: r.vendor_slug }));
}

/** Rəy yazmaq hüququnu yoxlayır (sahib və ya qonaq + sifariş kodu). */
export function assertCanReview(order, { user, code } = {}) {
  const isOwner = user && user.id === order.customer_user_id;
  const isAdmin = user?.role === 'admin';
  const guestWithCode = !order.customer_user_id && String(code ?? '').trim().toUpperCase() === order.code;
  if (!isOwner && !isAdmin && !guestWithCode) {
    throw forbidden('Bu sifariş üçün rəy yazmaq icazəniz yoxdur');
  }
}
