/**
 * Demo (seed) məlumatları.
 * Məhsul qısa açarlarla yazılıb:
 *   n — ad, p — qiymət (AZN), i — ikon (emoji və ya şəkil URL-i),
 *   d — təsvir, u — ölçü vahidi, st — anbar qalığı (marketlər üçün)
 */

export const categories = [
  { slug: 'kabab-milli', name: 'Kabab & Milli', icon: '🍢', kind: 'restaurant', sort: 1 },
  { slug: 'pizza', name: 'Pizza', icon: '🍕', kind: 'restaurant', sort: 2 },
  { slug: 'burger', name: 'Burger', icon: '🍔', kind: 'restaurant', sort: 3 },
  { slug: 'sushi', name: 'Sushi', icon: '🍣', kind: 'restaurant', sort: 4 },
  { slug: 'asiya', name: 'Asiya mətbəxi', icon: '🍜', kind: 'restaurant', sort: 5 },
  { slug: 'fast-food', name: 'Fast Food', icon: '🌯', kind: 'restaurant', sort: 6 },
  { slug: 'sirniyyat', name: 'Şirniyyat & Kofe', icon: '🍰', kind: 'restaurant', sort: 7 },
  { slug: 'supermarket', name: 'Supermarket', icon: '🛒', kind: 'market', sort: 10 },
  { slug: 'meyve', name: 'Meyvə-tərəvəz', icon: '🍎', kind: 'market', sort: 11 },
  { slug: 'corak-sud', name: 'Çörək & Süd', icon: '🥛', kind: 'market', sort: 12 },
  { slug: 'et-toyuq', name: 'Ət & Toyuq', icon: '🥩', kind: 'market', sort: 13 },
  { slug: 'bakkal', name: 'Bakkal', icon: '🏪', kind: 'market', sort: 14 },
];

export const demoUsers = [
  { role: 'admin', name: 'Platforma Admini', phone: '0500000000', password: 'admin123' },
  { role: 'customer', name: 'Aysel Məmmədova', phone: '0501234567', password: 'customer123' },
  { role: 'customer', name: 'Rəşad Əliyev', phone: '0557654321', password: 'customer123' },
];

export const vendors = [
  {
    slug: 'sirvansah-kabab',
    name: 'Şirvanşah Kabab Evi',
    kind: 'restaurant',
    category: 'kabab-milli',
    tagline: 'Bakının ən köhnə kababxanası',
    description: 'Köz üzərində hazırlanan manqal yeməkləri, milli mətbəx və ev şəraitində hazırlanmış dolmalar.',
    address: 'Nizami küç. 45, Bakı',
    phone: '+994 12 493 11 22',
    logo: '🔥',
    open: 1,
    prep_time: 25,
    min_order: 800,
    rating: 4.8,
    rating_count: 1284,
    owner: { name: 'Kamran Hüseynov', phone: '0501110001', password: 'vendor123' },
    menu: [
      { section: 'Kabablar', items: [
        { n: 'Toyuq kabab', p: 9.5, i: '🍗', d: 'Köz üzərində, nar əti ilə' },
        { n: 'Quzu lülə kabab', p: 14, i: '🍢' },
        { n: 'Tikə kabab', p: 13, i: '🍖' },
        { n: 'Antrikot', p: 16, i: '🥩', d: 'Mal əti, 250 qr' },
      ] },
      { section: 'Milli yeməklər', items: [
        { n: 'Şah plov', p: 11, i: '🍚', d: 'Quzu əti və qarağatla' },
        { n: 'Yarpaq dolması', p: 9, i: '🍃', d: '8 ədəd, qatıqla' },
        { n: 'Dovğa', p: 5.5, i: '🥣' },
        { n: 'Qutab (ətmə)', p: 4.5, i: '🥟' },
        { n: 'Piti', p: 8.5, i: '🍲', d: 'Sacda, əlavə çörəklə' },
      ] },
      { section: 'Salat & Qarnir', items: [
        { n: 'Çoban salatı', p: 5, i: '🥗' },
        { n: 'Manqal kartof', p: 4, i: '🥔' },
        { n: 'Təndir lavash', p: 1, i: '🫓' },
      ] },
      { section: 'İçkilər', items: [
        { n: 'Ayran', p: 2.5, i: '🥛' },
        { n: 'Armudu çay', p: 3, i: '🫖' },
        { n: 'Coca-Cola 0.5L', p: 3, i: '🥤' },
      ] },
    ],
  },
  {
    slug: 'pizza-mizza',
    name: 'Pizza Mizza',
    kind: 'restaurant',
    category: 'pizza',
    tagline: 'İtalyan üsulu, Bakı ürəyi',
    description: 'Daş sobada bişən nazik xəmir pizza və ev pastaları.',
    address: '28 May küç. 12, Bakı',
    phone: '+994 12 498 77 30',
    logo: '🍕',
    open: 1,
    prep_time: 20,
    min_order: 1000,
    rating: 4.6,
    rating_count: 862,
    owner: { name: 'Leyla Qasımova', phone: '0501110002', password: 'vendor123' },
    menu: [
      { section: 'Pizzalar', items: [
        { n: 'Marqarita', p: 12, i: '🍕', d: 'Tomat, mozzarella, reyhan' },
        { n: 'Pepperoni', p: 14.5, i: '🍕' },
        { n: 'Dörd pendir', p: 15, i: '🧀' },
        { n: 'BBQ toyuq', p: 16, i: '🍗' },
        { n: 'Vegetarian', p: 13, i: '🥬' },
      ] },
      { section: 'Pastalar', items: [
        { n: 'Alfredo pasta', p: 14, i: '🍝' },
        { n: 'Bolonez pasta', p: 13.5, i: '🍝' },
      ] },
      { section: 'Qarnir', items: [
        { n: 'Çörək çubuqları (6)', p: 4, i: '🥖' },
        { n: 'Pendirli çörək', p: 5.5, i: '🧄' },
      ] },
      { section: 'İçkilər', items: [
        { n: 'Ev limonadı', p: 4, i: '🍋' },
        { n: 'Coca-Cola 0.5L', p: 3, i: '🥤' },
      ] },
    ],
  },
  {
    slug: 'sushi-baki',
    name: 'Sushi Bakı',
    kind: 'restaurant',
    category: 'sushi',
    tagline: 'Hər gün təzə balıq',
    description: 'Yapon mətbəxi: rulolar, niginri və setlər. Sifariş hazırlanandan sonra 40 dəqiqə ərzində təzə qalır.',
    address: 'Neftçilər pr. 88, Bakı',
    phone: '+994 12 310 44 55',
    logo: '🍣',
    open: 1,
    prep_time: 30,
    min_order: 1500,
    rating: 4.7,
    rating_count: 501,
    owner: { name: 'Elvin Rzayev', phone: '0501110003', password: 'vendor123' },
    menu: [
      { section: 'Rulolar', items: [
        { n: 'Filadelfiya (8)', p: 18, i: '🍣', d: 'Somon, krem pendir' },
        { n: 'Kaliforniya (8)', p: 15, i: '🍥' },
        { n: 'Spaysi tuna (8)', p: 17.5, i: '🌶️' },
        { n: 'Dragon roll (8)', p: 22, i: '🐉' },
      ] },
      { section: 'Setlər', items: [
        { n: 'Set «Bakı» (32 ədəd)', p: 45, i: '🍱', d: '4 növ rulo, soya sousu, vasabi' },
      ] },
      { section: 'Niginri', items: [
        { n: 'Somon niginri', p: 4.5, i: '🐟', u: 'ədəd' },
        { n: 'Unagi niginri', p: 5.5, i: '🍢', u: 'ədəd' },
      ] },
      { section: 'İçkilər', items: [
        { n: 'Yaşıl çay', p: 3, i: '🍵' },
        { n: 'Sake (150 ml)', p: 12, i: '🍶' },
      ] },
    ],
  },
  {
    slug: 'burger-lab',
    name: 'Burger Lab',
    kind: 'restaurant',
    category: 'burger',
    tagline: 'Əl ilə döyülmüş ətlə',
    description: 'Hər burger sifarişdən sonra yığılır. Brioche çörək öz fırınımızda bişir.',
    address: 'Fəvvarələr meydanı 3, Bakı',
    phone: '+994 12 505 12 12',
    logo: '🍔',
    open: 1,
    prep_time: 15,
    min_order: 700,
    rating: 4.5,
    rating_count: 974,
    owner: { name: 'Nihad Abdullayev', phone: '0501110004', password: 'vendor123' },
    menu: [
      { section: 'Burgerlər', items: [
        { n: 'Classic Lab', p: 12, i: '🍔' },
        { n: 'Çizburger', p: 13.5, i: '🧀' },
        { n: 'Toyuq burger', p: 11.5, i: '🍗' },
        { n: 'Vegan burger', p: 12.5, i: '🌱' },
        { n: 'Double Lab', p: 18, i: '🍔', d: 'İki qat ət, iki qat pendir' },
      ] },
      { section: 'Qarnir', items: [
        { n: 'Kartof fri', p: 5, i: '🍟' },
        { n: 'Çeddar kartof', p: 7, i: '🧀' },
        { n: 'Soğan halqaları', p: 6, i: '🧅' },
      ] },
      { section: 'İçkilər', items: [
        { n: 'Milkshake (şokolad)', p: 7, i: '🥤' },
        { n: 'Coca-Cola 0.5L', p: 3, i: '🥤' },
      ] },
    ],
  },
  {
    slug: 'dolma-evi',
    name: 'Dolma Evi',
    kind: 'restaurant',
    category: 'kabab-milli',
    tagline: 'İçərişəhərdə ev yeməkləri',
    description: 'Nənə reseptləri ilə dolmalar, kükü və şirniyyatlar. Kiçik mətbəx, uzun növbə — əvvəlcədən sifariş verin.',
    address: 'İçərişəhər, Kiçik Qala 8, Bakı',
    phone: '+994 12 492 60 60',
    logo: '🍃',
    open: 1,
    prep_time: 35,
    min_order: 900,
    rating: 4.9,
    rating_count: 322,
    owner: { name: 'Səbinə İsmayılova', phone: '0501110005', password: 'vendor123' },
    menu: [
      { section: 'Dolmalar', items: [
        { n: 'Yarpaq dolması (10)', p: 11, i: '🍃' },
        { n: 'Badımcan dolması', p: 10, i: '🍆' },
        { n: 'Toyuq dolması', p: 12, i: '🍗' },
      ] },
      { section: 'Milli yeməklər', items: [
        { n: 'Qovurma', p: 13, i: '🥘' },
        { n: 'Xəngəl', p: 9.5, i: '🍜' },
        { n: 'Göy küküsü', p: 7, i: '🥬' },
      ] },
      { section: 'Şirniyyat', items: [
        { n: 'Şəkərbura', p: 3, i: '🥮' },
        { n: 'Paxlava', p: 4, i: '🍯' },
      ] },
      { section: 'İçkilər', items: [
        { n: 'Şərbət', p: 3, i: '🥤' },
        { n: 'Çay', p: 2, i: '🫖' },
      ] },
    ],
  },
  {
    slug: 'sekerbura-kofe',
    name: 'Şəkərbura & Kofe',
    kind: 'restaurant',
    category: 'sirniyyat',
    tagline: 'Tortlar, şirniyyat və üçüncü dalğa kofe',
    description: 'Günün tortları və xüsusi qarışıq kofe. Ofisə sifariş üçün ideal.',
    address: 'Port Baku Mall, 1-ci mərtəbə',
    phone: '+994 12 310 90 90',
    logo: '🍰',
    open: 1,
    prep_time: 10,
    min_order: 500,
    rating: 4.7,
    rating_count: 610,
    owner: { name: 'Günel Əhmədova', phone: '0501110006', password: 'vendor123' },
    menu: [
      { section: 'Tortlar', items: [
        { n: 'Şokoladlı tort (dilim)', p: 6.5, i: '🍫' },
        { n: 'Çiyələkli çizkek', p: 7, i: '🍓' },
        { n: 'Medovik', p: 6, i: '🍯' },
      ] },
      { section: 'Şirniyyat', items: [
        { n: 'Şəkərbura', p: 2.5, i: '🥮' },
        { n: 'Paxlava', p: 3.5, i: '🍯' },
        { n: 'Badambura', p: 3, i: '🥜' },
      ] },
      { section: 'Kofe', items: [
        { n: 'Espresso', p: 3, i: '☕' },
        { n: 'Kapuçino', p: 4.5, i: '☕' },
        { n: 'Latte', p: 5, i: '🥛' },
        { n: 'Flat White', p: 5, i: '☕' },
      ] },
      { section: 'Çay', items: [{ n: 'İngilis çayı', p: 4, i: '🫖' }] },
    ],
  },
  {
    slug: 'wok-street',
    name: 'Wok Street',
    kind: 'restaurant',
    category: 'asiya',
    tagline: 'Bir dəqiqədə bişən wok',
    description: 'Açıq mətbəx, güclü od və təzə tərəvəz.',
    address: 'Əhməd Cavad küç. 5, Bakı',
    phone: '+994 12 565 33 22',
    logo: '🍜',
    open: 1,
    prep_time: 22,
    min_order: 800,
    rating: 4.4,
    rating_count: 288,
    owner: { name: 'Tural Nəsibov', phone: '0501110007', password: 'vendor123' },
    menu: [
      { section: 'Wok', items: [
        { n: 'Toyuq noodle', p: 12, i: '🍜' },
        { n: 'Ətli wok', p: 14, i: '🥡' },
        { n: 'Tərəvəzli düyü', p: 10, i: '🍚' },
      ] },
      { section: 'Asiya', items: [
        { n: 'Pad Thai', p: 13.5, i: '🍤' },
        { n: 'Tom Yum şorbası', p: 11, i: '🍲' },
        { n: 'Dim Sum (6)', p: 9, i: '🥟' },
      ] },
      { section: 'İçkilər', items: [
        { n: 'Kokos suyu', p: 5, i: '🥥' },
        { n: 'Yaşıl çay', p: 3, i: '🍵' },
      ] },
    ],
  },
  {
    slug: 'doner-time',
    name: 'Doner Time',
    kind: 'restaurant',
    category: 'fast-food',
    tagline: 'Sürətli, dadlı, sərfəli',
    description: 'Gecə yarısı da açıq olan dönər nöqtəsi. Sifariş 12 dəqiqəyə hazır.',
    address: 'Bakıxanov küç. 21, Bakı',
    phone: '+994 12 555 78 78',
    logo: '🌯',
    open: 1,
    prep_time: 12,
    min_order: 400,
    rating: 4.3,
    rating_count: 1533,
    owner: { name: 'Orxan Vəliyev', phone: '0501110008', password: 'vendor123' },
    menu: [
      { section: 'Dönərlər', items: [
        { n: 'Toyuq dönər', p: 5, i: '🌯' },
        { n: 'Ət dönər', p: 7, i: '🥙' },
        { n: 'Dönər durum', p: 6.5, i: '🌮' },
        { n: 'Çizli dönər', p: 6, i: '🧀' },
      ] },
      { section: 'Fast food', items: [
        { n: 'Şaurma', p: 7.5, i: '🥙' },
        { n: 'Hot-dog', p: 4.5, i: '🌭' },
        { n: 'Nuggets (6)', p: 5.5, i: '🍗' },
      ] },
      { section: 'İçkilər', items: [
        { n: 'Ayran', p: 2, i: '🥛' },
        { n: 'Coca-Cola 0.5L', p: 2.5, i: '🥤' },
      ] },
    ],
  },
  {
    slug: 'market-247',
    name: 'Market 24/7',
    kind: 'market',
    category: 'supermarket',
    tagline: 'Gecə-gündüz açıq',
    description: 'Gündəlik ehtiyac üçün hər şey. Sifarişi 15 dəqiqəyə yığıb kassada veririk.',
    address: 'Sülh küç. 7, Bakı',
    phone: '+994 12 440 24 07',
    logo: '🛒',
    open: 1,
    prep_time: 15,
    min_order: 0,
    rating: 4.6,
    rating_count: 421,
    owner: { name: 'Market 24/7 rəhbəri', phone: '0501110009', password: 'vendor123' },
    menu: [
      { section: 'Süd & Yumurta', items: [
        { n: 'Süd 1L', p: 2.2, i: '🥛', u: 'ədəd', st: 60 },
        { n: 'Kefir 1L', p: 2.4, i: '🥛', st: 40 },
        { n: 'Yumurta (10)', p: 3.8, i: '🥚', u: 'qab', st: 35 },
        { n: 'Qatıq', p: 3.2, i: '🍶', u: 'kq', st: 25 },
      ] },
      { section: 'Çörək & Un', items: [
        { n: 'Ağ çörək', p: 0.6, i: '🍞', u: 'ədəd', st: 80 },
        { n: 'Təndir lavash', p: 1, i: '🫓', u: 'ədəd', st: 50 },
        { n: 'Un', p: 1.8, i: '🌾', u: 'kq', st: 30 },
      ] },
      { section: 'Ət & Toyuq', items: [
        { n: 'Toyuq filesi', p: 9.9, i: '🍗', u: 'kq', st: 18 },
        { n: 'Mal əti (antrikot)', p: 16.5, i: '🥩', u: 'kq', st: 10 },
        { n: 'Kolbasa', p: 8.5, i: '🌭', u: 'kq', st: 12 },
      ] },
      { section: 'Meyvə-tərəvəz', items: [
        { n: 'Pomidor', p: 3.2, i: '🍅', u: 'kq', st: 45 },
        { n: 'Xiyar', p: 2.9, i: '🥒', u: 'kq', st: 42 },
        { n: 'Alma', p: 2.4, i: '🍎', u: 'kq', st: 55 },
        { n: 'Banan', p: 3.6, i: '🍌', u: 'kq', st: 38 },
        { n: 'Kartof', p: 1.5, i: '🥔', u: 'kq', st: 70 },
      ] },
      { section: 'İçkilər', items: [
        { n: 'Su 1.5L', p: 1.2, i: '💧', u: 'butulka', st: 90 },
        { n: 'Coca-Cola 1.5L', p: 3.2, i: '🥤', st: 40 },
        { n: 'Şirə 1L', p: 3.8, i: '🧃', st: 33 },
      ] },
      { section: 'Ev & Gigiyena', items: [
        { n: 'Sabun', p: 2.2, i: '🧼', u: 'ədəd', st: 25 },
        { n: 'Kağız dəsmal', p: 3.4, i: '🧻', u: 'qab', st: 28 },
      ] },
    ],
  },
  {
    slug: 'meyve-terevez-baki',
    name: 'Meyvə Tərəvəz Bakı',
    kind: 'market',
    category: 'meyve',
    tagline: 'Hər səhər bazadan təzə',
    description: 'Günün təzə meyvə və tərəvəzi. Kəsimə görə çəki dəqiqləşdirilir.',
    address: 'Təzə Bazar, Bakı',
    phone: '+994 12 493 22 11',
    logo: '🍎',
    open: 1,
    prep_time: 20,
    min_order: 500,
    rating: 4.8,
    rating_count: 197,
    owner: { name: 'Vüqar Səmədov', phone: '0501110010', password: 'vendor123' },
    menu: [
      { section: 'Meyvə', items: [
        { n: 'Alma', p: 2.2, i: '🍎', u: 'kq', st: 50 },
        { n: 'Armud', p: 3.4, i: '🍐', u: 'kq', st: 30 },
        { n: 'Üzüm', p: 4.2, i: '🍇', u: 'kq', st: 25 },
        { n: 'Nar', p: 3.8, i: '🍎', u: 'kq', st: 22 },
        { n: 'Portağal', p: 3.6, i: '🍊', u: 'kq', st: 28 },
      ] },
      { section: 'Tərəvəz', items: [
        { n: 'Pomidor', p: 3, i: '🍅', u: 'kq', st: 35 },
        { n: 'Xiyar', p: 2.6, i: '🥒', u: 'kq', st: 32 },
        { n: 'Badımcan', p: 2.8, i: '🍆', u: 'kq', st: 20 },
        { n: 'Bibər', p: 3.4, i: '🫑', u: 'kq', st: 18 },
        { n: 'Göbələk', p: 5, i: '🍄', u: 'kq', st: 12 },
      ] },
      { section: 'Göyərti', items: [
        { n: 'Reyhan', p: 0.8, i: '🌿', u: 'dəstə', st: 40 },
        { n: 'Cəfəri', p: 0.7, i: '🌿', u: 'dəstə', st: 40 },
        { n: 'Şüyüd', p: 0.7, i: '🌿', u: 'dəstə', st: 35 },
      ] },
    ],
  },
  {
    slug: 'sud-corak-evi',
    name: 'Süd & Çörək Evi',
    kind: 'market',
    category: 'corak-sud',
    tagline: 'Səhər sifarişləri üçün',
    description: 'Məhəllə mağazası: süd məhsulları, təndir çörəyi və ev şirniyyatı.',
    address: 'Yasamal, Şərifzadə 30, Bakı',
    phone: '+994 12 440 15 15',
    logo: '🥛',
    open: 1,
    prep_time: 10,
    min_order: 0,
    rating: 4.7,
    rating_count: 143,
    owner: { name: 'Xəyal Məlikov', phone: '0501110011', password: 'vendor123' },
    menu: [
      { section: 'Süd məhsulları', items: [
        { n: 'Süd 1L', p: 2.3, i: '🥛', st: 45 },
        { n: 'Qatıq', p: 3, i: '🍶', u: 'kq', st: 20 },
        { n: 'Ağ pendir', p: 9.5, i: '🧈', u: 'kq', st: 15 },
        { n: 'Kərə yağı 200 q', p: 4.2, i: '🧈', u: 'qab', st: 22 },
      ] },
      { section: 'Çörək', items: [
        { n: 'Təndir çörəyi', p: 1.2, i: '🫓', u: 'ədəd', st: 60 },
        { n: 'Qara çörək', p: 1, i: '🍞', u: 'ədəd', st: 45 },
        { n: 'Bulka', p: 0.8, i: '🥐', u: 'ədəd', st: 50 },
      ] },
      { section: 'Şirniyyat', items: [
        { n: 'Şəkərbura', p: 2.5, i: '🥮', st: 30 },
        { n: 'Paxlava', p: 3.5, i: '🍯', st: 25 },
      ] },
    ],
  },
  {
    slug: 'bakkal-kicik',
    name: 'Kiçik Bakkal',
    kind: 'market',
    category: 'bakkal',
    tagline: 'Məhəllənin 24 saat bakkalı',
    description: 'Kiçik həcmli sifarişlər üçün: çips, su, siqaret yoxdur — yalnız qida və içki.',
    address: 'Xətai, Babək pr. 40, Bakı',
    phone: '+994 12 379 11 11',
    logo: '🏪',
    open: 0,
    prep_time: 8,
    min_order: 0,
    rating: 4.5,
    rating_count: 88,
    owner: { name: 'Ramil Cəfərov', phone: '0501110012', password: 'vendor123' },
    menu: [
      { section: 'Qəlyanaltı', items: [
        { n: 'Çips', p: 2.8, i: '🍟', st: 40 },
        { n: 'Qoz-fındıq qarışığı', p: 6.5, i: '🥜', u: 'kq', st: 10 },
        { n: 'Şokolad', p: 2.2, i: '🍫', st: 55 },
        { n: 'Peçenye', p: 2.5, i: '🍪', st: 30 },
      ] },
      { section: 'İçkilər', items: [
        { n: 'Su 0.5L', p: 0.7, i: '💧', st: 100 },
        { n: 'Enerji içkisi', p: 3.5, i: '⚡', st: 24 },
        { n: 'Soyuq çay', p: 2.5, i: '🧊', st: 36 },
      ] },
      { section: 'Gündəlik', items: [
        { n: 'Diş pastası', p: 4.5, i: '🪥', st: 14 },
        { n: 'Salfet', p: 1.2, i: '🧻', st: 40 },
      ] },
    ],
  },
];

/** Demo sifarişlər panel boş görünməsin deyə (statuslar qarışıq). */
export const demoOrders = [
  { vendor: 'sirvansah-kabab', customer: 1, status: 'picked_up', minutesAgo: 1500, items: [[0, 1], [4, 2], [10, 1]], payment: 'cash' },
  { vendor: 'pizza-mizza', customer: 1, status: 'picked_up', minutesAgo: 700, items: [[1, 1], [7, 1]], payment: 'card' },
  { vendor: 'market-247', customer: 2, status: 'picked_up', minutesAgo: 260, items: [[0, 2], [4, 1], [11, 2]], payment: 'cash' },
  { vendor: 'burger-lab', customer: 2, status: 'ready', minutesAgo: 40, items: [[0, 2], [5, 1]], payment: 'card' },
  { vendor: 'sushi-baki', customer: 1, status: 'preparing', minutesAgo: 22, items: [[0, 1], [2, 1]], payment: 'online' },
  { vendor: 'market-247', customer: 2, status: 'pending', minutesAgo: 6, items: [[1, 1], [13, 1], [16, 3]], payment: 'cash' },
  { vendor: 'doner-time', customer: 1, status: 'cancelled', minutesAgo: 90, items: [[0, 3]], payment: 'cash' },
];

/** Demo kampaniyalar: platforma üzrə və mağazaya aid. */
export const demoCoupons = [
  {
    code: 'GOTUR10', vendor: null, kind: 'percent', value: 10, minOrder: 500,
    maxDiscount: 300, perUserLimit: 1, usageLimit: 0,
    description: 'Platforma üzrə ilk sifarişə 10% endirim (maks. 3 ₼)',
  },
  {
    code: 'ILK15', vendor: null, kind: 'fixed', value: 150, minOrder: 1000,
    perUserLimit: 1, usageLimit: 200,
    description: '1.50 ₼ endirim — 10 ₼-dən yuxarı sifarişlərə',
  },
  {
    code: 'KABAB15', vendor: 'sirvansah-kabab', kind: 'percent', value: 15, minOrder: 1500,
    maxDiscount: 500, perUserLimit: 2,
    description: 'Kabab Evi: 15% endirim (maks. 5 ₼)',
  },
  {
    code: 'MARKET5', vendor: 'market-247', kind: 'percent', value: 5, minOrder: 2000,
    description: 'Market 24/7: 20 ₼-dən yuxarı sifarişlərə 5% endirim',
  },
  {
    code: 'SUSHI20', vendor: 'sushi-baki', kind: 'percent', value: 20, minOrder: 2500,
    maxDiscount: 800, perUserLimit: 1, description: 'Sushi Bakı: setlərə 20% endirim',
  },
];

/** Götürülmüş demo sifarişlərə yazılan rəylər (sifariş nömrəsi demoOrders indeksidir). */
export const demoReviews = [
  {
    order: 0, rating: 5,
    comment: 'Kabablar əla idi, sifariş 20 dəqiqəyə hazır oldu. Götürmə kodu ilə heç növbə gözləmədim.',
    reply: 'Təşəkkür edirik! Hər gün gözləyirik 🙌',
  },
  {
    order: 1, rating: 4,
    comment: 'Pizza dadlı idi, amma gözlədiyimdən 5 dəqiqə gec hazır oldu.',
  },
  {
    order: 2, rating: 5,
    comment: 'Market sifarişini 15 dəqiqəyə yığdılar, hər şey siyahıda olduğu kimi.',
    reply: 'Sağ olun! Gecə sifarişləriniz üçün də açığıq.',
  },
];

/** Rəy yazmaq üçün istifadə olunan demo müştəri adları. */
export const demoReviewAuthors = ['Aysel M.', 'Rəşad Ə.', 'Nigar H.'];

/**
 * Demo mağazaların xəritə koordinatları (Gəncə, WGS-84).
 * Müştəri tətbiqində məsafə (km), yerimə və avtomobil vaxtı buradan hesablanır.
 * Satıcı öz panelindən («Mağaza» → yer) bunları dəyişə bilər.
 */
export const vendorCoords = {
  'sirvansah-kabab': [40.6775, 46.3530],
  'pizza-mizza': [40.6862, 46.3665],
  'sushi-baki': [40.6790, 46.3585],
  'burger-lab': [40.6835, 46.3612],
  'dolma-evi': [40.6748, 46.3648],
  'sekerbura-kofe': [40.6805, 46.3570],
  'wok-street': [40.6880, 46.3590],
  'doner-time': [40.6755, 46.3555],
  'market-247': [40.6818, 46.3625],
  'meyve-terevez-baki': [40.6735, 46.3520],
  'sud-corak-evi': [40.6850, 46.3545],
  'bakkal-kicik': [40.6770, 46.3600],
  'leziz-dad': [40.6798, 46.3592],
  'kanon-aptek-ataturk': [40.6801, 46.3558],
};

