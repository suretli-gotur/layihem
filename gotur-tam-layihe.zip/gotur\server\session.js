import { q } from './db.js';
import { nowIso, parseCookies, randomToken } from './util.js';

export const SESSION_COOKIE = 'gotur_session';
const SESSION_DAYS = 30;

export function createSession(userId) {
  const token = randomToken(24);
  const expires = new Date(Date.now() + SESSION_DAYS * 864e5).toISOString();
  q.run('INSERT INTO sessions (token, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)',
    token, userId, nowIso(), expires);
  return { token, expires };
}

export const sessionCookie = (token, expires) =>
  `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Expires=${new Date(expires).toUTCString()}`;

export const clearSessionCookie = () =>
  `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`;

export function currentUser(req) {
  const token = parseCookies(req.headers?.cookie)[SESSION_COOKIE];
  if (!token) return null;
  const row = q.get(
    `SELECT u.*, s.expires_at AS session_expires
     FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ?`,
    token,
  );
  if (!row) return null;
  if (new Date(row.session_expires).getTime() < Date.now()) {
    q.run('DELETE FROM sessions WHERE token = ?', token);
    return null;
  }
  if (row.blocked) return null;
  return row;
}

export function destroySession(req) {
  const token = parseCookies(req.headers?.cookie)[SESSION_COOKIE];
  if (token) q.run('DELETE FROM sessions WHERE token = ?', token);
}

export const publicUser = (u) => (u ? {
  id: u.id,
  role: u.role,
  name: u.name,
  phone: u.phone,
  email: u.email || '',
  createdAt: u.created_at,
} : null);
