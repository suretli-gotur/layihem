/**
 * Götür — komissiya və hesablaşma (settlement) modulu.
 *
 * Model (sadə və şəffaf):
 *   • Müştərinin ödədiyi:      total = subtotal − endirim
 *   • Platforma komissiyası:   commission = round(subtotal × faiz / 100)
 *   • Mağazaya çatası:         payout = subtotal − commission
 *   • Kupon endirimi platformanın payına düşür (platformanın xalis gəliri = commission − endirim)
 *
 * Pulun kimin əlində olduğu vacibdir:
 *   • onlayn ödəniş (simulyasiya/Stripe) → pul platformadadır, mağaza `payout` alacaqlıdır
 *   • kassada ödəniş                    → pul mağazadadır, mağaza `commission` borcludur
 * Hesablaşma hesabatı ikisini birləşdirir: net = Σ(payout|onlayn) − Σ(commission|kassa)
 */
import { q } from './db.js';
import { bad, notFound, nowIso, str } from './util.js';

export const COMMISSION_MIN = 0;
export const COMMISSION_MAX = 40;

/* ------------------------------------------------------------------ *
 * Tənzimləmələr
 * ------------------------------------------------------------------ */
export function getSetting(key, fallback = null) {
  const row = q.get('SELECT value FROM settings WHERE key = ?', key);
  return row ? row.value : fallback;
}

export function setSetting(key, value) {
  q.run(
    `INSERT INTO settings (key, value) VALUES (?, ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
    key, String(value),
  );
  return getSetting(key);
}

export const getSettings = () => ({
  defaultCommission: Number(getSetting('default_commission', '12')),
  platformName: getSetting('platform_name', 'Götür'),
});

/** Mağaza üçün qüvvədə olan komissiya faizi (0 → platforma defoltu). */
export function commissionPercentFor(vendor) {
  const own = Number(vendor?.commission_percent ?? 0);
  if (own > 0) return own;
  return getSettings().defaultCommission;
}

export const computeCommission = (subtotal, percent) =>
  Math.max(0, Math.round((Number(subtotal) * Number(percent)) / 100));

/** Sifariş üçün komissiya və mağaza payını hesablayır (sifariş yaradılarkən). */
export function commissionForOrder({ subtotal, total, vendor }) {
  const percent = commissionPercentFor(vendor);
  const commission = computeCommission(subtotal, percent);
  const payout = Math.max(0, total - commission);
  return { percent, commission, payout };
}

/* ------------------------------------------------------------------ *
 * Hesablaşma hesabatı
 * ------------------------------------------------------------------ */
const startOfMonth = (date = new Date()) => {
  const d = new Date(date);
  d.setDate(1);
  d.setHours(0, 0, 0, 0);
  return d;
};

export function periodRange({ from, to } = {}) {
  const now = new Date();
  const start = from ? new Date(from) : startOfMonth(now);
  const end = to ? new Date(to) : now;
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) throw bad('Tarix aralığı düzgün deyil', 'date_invalid');
  if (start > end) throw bad('Başlanğıc tarixi bitmə tarixindən sonra ola bilməz', 'date_invalid');
  if (!from) start.setHours(0, 0, 0, 0);
  return { from: start.toISOString(), to: end.toISOString() };
}

const SETTLED_STATUSES = "('ready','picked_up')";

/**
 * Bir mağaza üçün dövr hesabatı.
 * @param {number} vendorId
 * @param {{from?:string,to?:string}} range
 */
export function vendorSettlement(vendorId, range = {}) {
  const { from, to } = periodRange(range);
  const rows = q.all(
    `SELECT o.id, o.code, o.status, o.payment, o.payment_status, o.subtotal, o.discount, o.coupon_code,
            o.total, o.commission, o.vendor_payout, o.created_at,
            (SELECT provider FROM payments p WHERE p.order_id = o.id AND p.status = 'paid' ORDER BY p.id DESC LIMIT 1) AS paid_provider
     FROM orders o
     WHERE o.vendor_id = ? AND o.created_at >= ? AND o.created_at <= ? AND o.status != 'cancelled'
     ORDER BY o.created_at DESC`,
    vendorId, from, to,
  );

  const totals = {
    orders: rows.length,
    gross: 0, discount: 0, commission: 0, total: 0,
    online: 0, counter: 0, payout: 0, due: 0,
  };

  const orders = rows.map((o) => {
    const settled = ['ready', 'picked_up'].includes(o.status);
    const provider = o.paid_provider ?? (o.payment === 'online' ? 'simulated' : 'counter');
    const collectedByPlatform = provider !== 'counter';
    const commission = o.commission ?? 0;
    const payout = o.vendor_payout ?? 0;

    totals.orders += 1;
    totals.gross += o.subtotal;
    totals.discount += o.discount ?? 0;
    totals.total += o.total;
    if (settled) {
      totals.commission += commission;
      if (collectedByPlatform) { totals.online += o.total; totals.payout += payout; } else { totals.counter += o.total; totals.due += commission; }
    }
    return {
      id: o.id,
      code: o.code,
      status: o.status,
      payment: o.payment,
      paymentStatus: o.payment_status,
      collectedBy: collectedByPlatform ? 'platform' : 'vendor',
      provider,
      subtotal: o.subtotal,
      discount: o.discount ?? 0,
      couponCode: o.coupon_code || null,
      total: o.total,
      commission,
      payout,
      settled,
      createdAt: o.created_at,
    };
  });

  /** Mağazanın xalis vəziyyəti: alacaqlı (platformadan) − borclu (kassadan) */
  const net = totals.payout - totals.due;
  const vendor = q.get('SELECT id, name, slug, commission_percent FROM vendors WHERE id = ?', vendorId);
  const percent = commissionPercentFor(vendor);

  return {
    vendorId,
    vendorName: vendor?.name ?? null,
    vendorSlug: vendor?.slug ?? null,
    commissionPercent: percent,
    ownCommissionPercent: Number(vendor?.commission_percent ?? 0),
    period: { from, to },
    totals: {
      ...totals,
      net,
      platformRevenue: totals.commission - totals.discount,
    },
    orders,
  };
}

/** Bütün mağazalar üzrə hesablaşma (admin) */
export function platformSettlement(range = {}) {
  const { from, to } = periodRange(range);
  // Bütün təsdiqlənmiş mağazalar göstərilir (sifarişi olmayanlar sıfırla)
  const vendorRows = q.all(
    `SELECT v.id AS vendor_id, v.name AS vendor_name, v.slug AS vendor_slug, v.commission_percent,
            COUNT(o.id) AS orders_count,
            COALESCE(SUM(o.subtotal), 0) AS gross,
            COALESCE(SUM(o.discount), 0) AS discount,
            COALESCE(SUM(o.total), 0) AS total,
            COALESCE(SUM(CASE WHEN o.status IN ${SETTLED_STATUSES} THEN o.commission ELSE 0 END), 0) AS commission,
            COALESCE(SUM(CASE WHEN o.status IN ${SETTLED_STATUSES} AND o.payment = 'online' THEN o.total ELSE 0 END), 0) AS online,
            COALESCE(SUM(CASE WHEN o.status IN ${SETTLED_STATUSES} AND o.payment != 'online' THEN o.total ELSE 0 END), 0) AS counter,
            COALESCE(SUM(CASE WHEN o.status IN ${SETTLED_STATUSES} AND o.payment = 'online' THEN o.vendor_payout ELSE 0 END), 0) AS payout_online,
            COALESCE(SUM(CASE WHEN o.status IN ${SETTLED_STATUSES} AND o.payment != 'online' THEN o.commission ELSE 0 END), 0) AS commission_counter
     FROM vendors v
     LEFT JOIN orders o ON o.vendor_id = v.id
       AND o.created_at >= ? AND o.created_at <= ? AND o.status != 'cancelled'
     WHERE v.approved = 1
     GROUP BY v.id
     ORDER BY commission DESC, v.name`,
    from, to,
  );

  const vendors = vendorRows.map((r) => ({
    vendorId: r.vendor_id,
    name: r.vendor_name,
    slug: r.vendor_slug,
    commissionPercent: Number(r.commission_percent ?? 0) > 0
      ? Number(r.commission_percent)
      : getSettings().defaultCommission,
    ownCommissionPercent: Number(r.commission_percent ?? 0),
    orders: r.orders_count,
    gross: r.gross,
    discount: r.discount,
    total: r.total,
    commission: r.commission,
    online: r.online,
    counter: r.counter,
    payout: r.payout_online,
    due: r.commission_counter,
    net: r.payout_online - r.commission_counter,
    platformRevenue: r.commission - r.discount,
  }));

  const totals = vendors.reduce((acc, v) => ({
    vendors: acc.vendors + 1,
    orders: acc.orders + v.orders,
    gross: acc.gross + v.gross,
    discount: acc.discount + v.discount,
    total: acc.total + v.total,
    commission: acc.commission + v.commission,
    online: acc.online + v.online,
    counter: acc.counter + v.counter,
    payout: acc.payout + v.payout,
    due: acc.due + v.due,
    net: acc.net + v.net,
    platformRevenue: acc.platformRevenue + v.platformRevenue,
  }), {
    vendors: 0, orders: 0, gross: 0, discount: 0, total: 0,
    commission: 0, online: 0, counter: 0, payout: 0, due: 0, net: 0, platformRevenue: 0,
  });

  return { period: { from, to }, totals, vendors };
}

/* ------------------------------------------------------------------ *
 * Hesablaşma qeydləri (payouts)
 * ------------------------------------------------------------------ */
export function serializeSettlement(s) {
  return {
    id: s.id,
    vendorId: s.vendor_id,
    vendorName: s.vendor_name ?? null,
    periodStart: s.period_start,
    periodEnd: s.period_end,
    ordersCount: s.orders_count,
    gross: s.gross,
    discount: s.discount,
    commission: s.commission,
    online: s.online,
    counter: s.counter,
    payout: s.payout,
    status: s.status,
    note: s.note || '',
    createdAt: s.created_at,
    paidAt: s.paid_at,
  };
}

export function listSettlements({ vendorId = null, limit = 100 } = {}) {
  const rows = vendorId
    ? q.all(`SELECT s.*, v.name AS vendor_name FROM settlements s JOIN vendors v ON v.id = s.vendor_id
             WHERE s.vendor_id = ? ORDER BY s.period_end DESC, s.id DESC LIMIT ?`, vendorId, limit)
    : q.all(`SELECT s.*, v.name AS vendor_name FROM settlements s JOIN vendors v ON v.id = s.vendor_id
             ORDER BY s.period_end DESC, s.id DESC LIMIT ?`, limit);
  return rows.map(serializeSettlement);
}

export function createSettlement({ vendorId, from, to, note = '' }) {
  const report = vendorSettlement(vendorId, { from, to });
  if (!report.orders.length) throw bad('Bu dövrdə hesablaşılacaq sifariş yoxdur', 'settlement_empty');

  const already = q.get(
    `SELECT id FROM settlements WHERE vendor_id = ? AND period_start = ? AND period_end = ?`,
    vendorId, report.period.from, report.period.to,
  );
  if (already) throw bad('Bu dövr üçün hesablaşma artıq yaradılıb', 'settlement_exists');

  const info = q.run(
    `INSERT INTO settlements
      (vendor_id, period_start, period_end, orders_count, gross, discount, commission, online, counter, payout,
       status, note, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)`,
    vendorId, report.period.from, report.period.to, report.totals.orders, report.totals.gross,
    report.totals.discount, report.totals.commission, report.totals.online, report.totals.counter,
    report.totals.net, str(note, 200), nowIso(),
  );
  const row = q.get(
    `SELECT s.*, v.name AS vendor_name FROM settlements s JOIN vendors v ON v.id = s.vendor_id WHERE s.id = ?`,
    Number(info.lastInsertRowid),
  );
  return serializeSettlement(row);
}

export function markSettlementPaid(id, { note = '' } = {}) {
  const row = q.get('SELECT * FROM settlements WHERE id = ?', id);
  if (!row) throw notFound('Hesablaşma tapılmadı');
  if (row.status === 'paid') throw bad('Bu hesablaşma artıq ödənilib', 'settlement_paid');
  q.run(
    `UPDATE settlements SET status = 'paid', paid_at = ?, note = CASE WHEN ? = '' THEN note ELSE ? END WHERE id = ?`,
    nowIso(), str(note, 200), str(note, 200), id,
  );
  return serializeSettlement(q.get(
    `SELECT s.*, v.name AS vendor_name FROM settlements s JOIN vendors v ON v.id = s.vendor_id WHERE s.id = ?`,
    id,
  ));
}

export function deleteSettlement(id) {
  const row = q.get('SELECT * FROM settlements WHERE id = ?', id);
  if (!row) throw notFound('Hesablaşma tapılmadı');
  q.run('DELETE FROM settlements WHERE id = ?', id);
  return { ok: true };
}

/** Mağazanın komissiya faizini təyin edir (0 → platforma defoltu). */
export function setVendorCommission(vendorId, percent) {
  const vendor = q.get('SELECT id FROM vendors WHERE id = ?', vendorId);
  if (!vendor) throw notFound('Mağaza tapılmadı');
  const value = Number(percent);
  if (!Number.isFinite(value) || value < COMMISSION_MIN || value > COMMISSION_MAX) {
    throw bad(`Komissiya ${COMMISSION_MIN}–${COMMISSION_MAX}% arasında olmalıdır`, 'commission_invalid', {
      min: COMMISSION_MIN, max: COMMISSION_MAX,
    });
  }
  q.run('UPDATE vendors SET commission_percent = ? WHERE id = ?', value, vendorId);
  // Gözləyən (hələ yekunlaşmamış) sifarişlərin komissiyasını yenilə
  q.run(
    `UPDATE orders SET commission = CAST(ROUND(subtotal * ? / 100.0) AS INTEGER),
       vendor_payout = total - CAST(ROUND(subtotal * ? / 100.0) AS INTEGER)
     WHERE vendor_id = ? AND status IN ('pending','accepted','preparing')`,
    value, value, vendorId,
  );
  return { vendorId, commissionPercent: value };
}
