import crypto from 'node:crypto';

/* ------------------------------------------------------------------ *
 * Xətalar
 * ------------------------------------------------------------------ */
export class HttpError extends Error {
  /**
   * @param {number} status HTTP statusu
   * @param {string} message azərbaycanca mesaj (ehtiyat variant)
   * @param {string} code    maşın oxunaqlı kod — frontend bunu cari dilə çevirir (errors.<code>)
   * @param {object} params  mesajdakı yer tutucular ({field}, {amount}, {name}…)
   */
  constructor(status, message, code = 'error', params = null) {
    super(message);
    this.status = status;
    this.code = code;
    this.params = params;
  }
}

export const bad = (msg, code = 'bad_request', params = null) => new HttpError(400, msg, code, params);
export const unauthorized = (msg = 'Giriş tələb olunur') => new HttpError(401, msg, 'unauthorized');
export const forbidden = (msg = 'Bu əməliyyat üçün icazəniz yoxdur') => new HttpError(403, msg, 'forbidden');
export const notFound = (msg = 'Tapılmadı') => new HttpError(404, msg, 'not_found');

/* ------------------------------------------------------------------ *
 * Şifrələr (yalnız Node daxili crypto — heç bir asılılıq yoxdur)
 * ------------------------------------------------------------------ */
export function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), salt, 32).toString('hex');
  return `scrypt$${salt}$${hash}`;
}

export function verifyPassword(password, stored) {
  try {
    const [algo, salt, hash] = String(stored || '').split('$');
    if (algo !== 'scrypt' || !salt || !hash) return false;
    const calc = crypto.scryptSync(String(password), salt, 32);
    const want = Buffer.from(hash, 'hex');
    return calc.length === want.length && crypto.timingSafeEqual(calc, want);
  } catch {
    return false;
  }
}

export const randomToken = (bytes = 24) => crypto.randomBytes(bytes).toString('base64url');

export const randomDigits = (n = 4) => {
  let out = '';
  while (out.length < n) out += String(crypto.randomInt(0, 10));
  return out;
};

/** Oxunaqlı, təhlükəsiz müvəqqəti şifrə (0/O, 1/l kimi qarışan simvollar yoxdur). */
export function randomPassword(length = 10) {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
  let out = '';
  while (out.length < length) out += alphabet[crypto.randomInt(0, alphabet.length)];
  return out;
}

/* ------------------------------------------------------------------ *
 * HTTP köməkçiləri
 * ------------------------------------------------------------------ */
export function sendJson(res, status, data, extraHeaders = {}) {
  const body = JSON.stringify(data ?? null);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'content-length': Buffer.byteLength(body),
    ...extraHeaders,
  });
  res.end(body);
}

export function parseCookies(header = '') {
  const out = {};
  for (const part of String(header).split(';')) {
    const idx = part.indexOf('=');
    if (idx < 0) continue;
    const k = part.slice(0, idx).trim();
    const v = part.slice(idx + 1).trim();
    if (k) out[k] = decodeURIComponent(v);
  }
  return out;
}

export async function readJsonBody(req, limit = 512 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) throw new HttpError(413, 'Sorğu çox böyükdür', 'too_large');
    chunks.push(chunk);
  }
  if (!chunks.length) {
    req._rawBody = '';
    return {};
  }
  const raw = Buffer.concat(chunks).toString('utf8');
  req._rawBody = raw;
  const trimmed = raw.trim();
  if (!trimmed) return {};
  try {
    const parsed = JSON.parse(trimmed);
    if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
      throw new Error('obyekt deyil');
    }
    return parsed;
  } catch {
    throw bad('JSON formatı yanlışdır', 'bad_json');
  }
}

/* ------------------------------------------------------------------ *
 * Mətn / pul köməkçiləri
 * ------------------------------------------------------------------ */
export const nowIso = () => new Date().toISOString();

export const money = (qepik) =>
  `${(Number(qepik || 0) / 100).toFixed(2).replace('.', ',')} \u20BC`;

export const digits = (value) => String(value ?? '').replace(/\D+/g, '');

export function normalizePhone(value) {
  const d = digits(value);
  if (d.length < 9) throw bad('Telefon nömrəsi düzgün deyil', 'phone_invalid');
  return d.length === 9 ? `0${d}` : d;
}

export function slugify(value, fallback = 'magaza') {
  const map = { ə: 'e', ö: 'o', ü: 'u', ğ: 'g', ş: 's', ç: 'c', ı: 'i', İ: 'i', Ə: 'e', Ö: 'o', Ü: 'u', Ğ: 'g', Ş: 's', Ç: 'c' };
  const base = String(value || '')
    .split('')
    .map((ch) => map[ch] ?? ch)
    .join('')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48);
  return base || fallback;
}

export const str = (value, max = 500) => String(value ?? '').trim().slice(0, max);
export const int = (value, def = 0) => {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) ? n : def;
};
export const bool = (value) => (value === true || value === 1 || value === '1' || value === 'true' ? 1 : 0);

export function requireFields(obj, fields) {
  for (const f of fields) {
    const v = obj?.[f];
    if (v === undefined || v === null || String(v).trim() === '') {
      throw bad(`«${f}» sahəsi mütləqdir`, 'field_required', { field: f });
    }
  }
}

/* ------------------------------------------------------------------ *
 * Sifariş statusları
 * ------------------------------------------------------------------ */
export const STATUS_FLOW = ['pending', 'accepted', 'preparing', 'ready', 'picked_up'];

export const STATUS_LABEL = {
  pending: 'Yeni sifariş',
  accepted: 'Qəbul edildi',
  preparing: 'Hazırlanır',
  ready: 'Hazırdır — götürün',
  picked_up: 'Götürüldü',
  cancelled: 'Ləğv edildi',
  paid: 'Ödəniş alındı',
  refunded: 'Ödəniş geri qaytarıldı',
};

export const PAYMENT_STATUS_LABEL = {
  unpaid: 'Ödənilməyib',
  paid: 'Ödənilib',
  refunded: 'Geri qaytarılıb',
  failed: 'Ödəniş alınmadı',
};

export const PAYMENT_LABEL = {
  cash: 'Kassada nağd',
  card: 'Kassada kart',
  online: 'Onlayn (simulyasiya)',
};

export const NO_COURIER_NOTE =
  'Götür platformasında çatdırılma yoxdur: sifarişi restoran/market özü hazırlayır, müştəri gəlib götürür.';

export const orderCode = (id) => `GT-${1000 + Number(id)}`;
