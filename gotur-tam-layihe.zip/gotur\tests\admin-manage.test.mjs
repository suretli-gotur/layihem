/**
 * Götür — admin tərəfindən mağaza yaratma (A) və kateqoriya idarəsi (B) testləri.
 */
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { after, before, describe, it } from 'node:test';

const workDir = mkdtempSync(join(tmpdir(), 'gotur-admin-'));
process.env.GOTUR_DB = join(workDir, 'admin.db');
process.env.GOTUR_LOG = '0';

const { createServer } = await import('../server/index.js');
const { closeDb, q } = await import('../server/db.js');

let server;
let base;

function client() {
  let cookie = '';
  return {
    async call(method, path, body) {
      const res = await fetch(base + path, {
        method,
        headers: {
          ...(body ? { 'content-type': 'application/json' } : {}),
          ...(cookie ? { cookie } : {}),
        },
        body: body ? JSON.stringify(body) : undefined,
      });
      for (const c of res.headers.getSetCookie?.() ?? []) {
        const pair = c.split(';')[0];
        if (pair.includes('gotur_session=')) cookie = pair;
      }
      const text = await res.text();
      return { status: res.status, data: text ? JSON.parse(text) : null };
    },
  };
}
const api = (c, m, p, b) => c.call(m, p, b);

const admin = client();
const customer = client();

before(async () => {
  server = createServer();
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
  await api(admin, 'POST', '/api/auth/login', { phone: '0500000000', password: 'admin123' });
  await api(customer, 'POST', '/api/auth/login', { phone: '0501234567', password: 'customer123' });
});

after(async () => {
  await new Promise((r) => server.close(r));
  closeDb();
  try { rmSync(workDir, { recursive: true, force: true }); } catch { /* Windows kilidi */ }
});

/* ================================================================== *
 * A) Admin mağaza yaradır
 * ================================================================== */
describe('A) admin mağaza yaradır', () => {
  let created;

  it('mağaza + sahib hesabı yaradılır və avtomatik şifrə qaytarılır', async () => {
    const res = await api(admin, 'POST', '/api/admin/vendors', {
      ownerName: 'Ləziz Dad sahibi',
      vendorName: 'Ləziz Dad',
      phone: '0512345678',
      kind: 'restaurant',
      category: 'sirniyyat',
      address: 'Nizami küç. 12, Bakı',
      vendorPhone: '+994 12 555 11 22',
      tagline: 'Ev şirniyyatları, hər gün təzə',
      logo: '🍰',
      prepTime: 25,
      minOrder: 500,
      commissionPercent: 10,
    });
    assert.equal(res.status, 200, JSON.stringify(res.data));
    created = res.data;

    assert.equal(created.vendor.name, 'Ləziz Dad');
    assert.equal(created.vendor.slug, 'leziz-dad');
    assert.equal(created.vendor.approved, true, 'yaradılan mağaza dərhal təsdiqli olur');
    assert.equal(created.vendor.open, true, 'və açıq olur');
    assert.equal(created.vendor.prepTime, 25);
    assert.equal(created.vendor.minOrder, 500);
    assert.equal(created.owner.phone, '0512345678');
    assert.equal(created.credentials.generated, true);
    assert.ok(created.credentials.password.length >= 8, 'avtomatik şifrə güclüdür');
    assert.equal(created.vendor.category.slug, 'sirniyyat', 'kateqoriya təyin olundu');
    assert.equal(q.get('SELECT commission_percent FROM vendors WHERE id = ?', created.vendor.id).commission_percent, 10);
  });

  it('yeni sahib həmin şifrə ilə satıcı panelinə girə bilir', async () => {
    const owner = client();
    const login = await api(owner, 'POST', '/api/auth/login', {
      phone: created.credentials.phone,
      password: created.credentials.password,
    });
    assert.equal(login.status, 200, JSON.stringify(login.data));
    assert.equal(login.data.user.role, 'vendor');
    assert.equal(login.data.vendor.name, 'Ləziz Dad');

    const me = await api(owner, 'GET', '/api/vendor/me');
    assert.equal(me.data.vendor.slug, 'leziz-dad');
    assert.equal(me.data.stats.counts.pending, 0);
  });

  it('sahib öz menyusunu doldura bilir (təsdiq gözləmədən)', async () => {
    const owner = client();
    const login = await api(owner, 'POST', '/api/auth/login', {
      phone: created.credentials.phone, password: created.credentials.password,
    });
    assert.equal(login.status, 200);
    const product = await api(owner, 'POST', '/api/vendor/products', {
      name: 'Şəkərbura', price: 2.5, section: 'Şirniyyat', image: '🥮', stock: 20,
    });
    assert.equal(product.status, 200, JSON.stringify(product.data));
    assert.equal(product.data.product.price, 250);
  });

  it('mağaza müştəri tətbiqində görünür və sifariş qəbul edir', async () => {
    const list = await api(client(), 'GET', '/api/vendors?kind=restaurant&q=ləziz');
    assert.ok(list.data.vendors.some((v) => v.slug === 'leziz-dad'), 'axtarışda tapılır');

    const page = await api(client(), 'GET', '/api/vendors/leziz-dad');
    assert.equal(page.data.vendor.name, 'Ləziz Dad');
    assert.equal(page.data.vendor.menu[0].items[0].name, 'Şəkərbura');

    const productId = page.data.vendor.menu[0].items[0].id;
    const order = await api(customer, 'POST', '/api/orders', {
      vendorId: page.data.vendor.id, name: 'Aysel Məmmədova', phone: '0501234567',
      payment: 'cash', items: [{ productId, qty: 4 }],
    });
    assert.equal(order.status, 200, JSON.stringify(order.data));
    assert.equal(order.data.order.total, 1000);
    assert.equal(order.data.order.commission, 100, '10% fərdi komissiya tətbiq olundu');
  });

  it('təsdiqsiz yaradıla bilər (approved: false)', async () => {
    const res = await api(admin, 'POST', '/api/admin/vendors', {
      ownerName: 'Test Sahib', vendorName: 'Gözləyən Mağaza', phone: '0512345679',
      kind: 'market', approved: false,
    });
    assert.equal(res.status, 200);
    assert.equal(res.data.vendor.approved, false);
    assert.equal(res.data.vendor.open, false);
    const publicList = await api(client(), 'GET', '/api/vendors?q=gözləyən');
    assert.equal(publicList.data.vendors.length, 0, 'təsdiqsiz mağaza müştəriyə görünmür');
  });

  it('eyni telefonla ikinci mağaza yaradılmır', async () => {
    const res = await api(admin, 'POST', '/api/admin/vendors', {
      ownerName: 'Başqa', vendorName: 'Başqa Mağaza', phone: '0512345678',
    });
    assert.equal(res.status, 400);
    assert.match(res.data.error, /artıq qeydiyyatdadır/);
  });

  it('boş ad/telefon rədd olunur', async () => {
    const noName = await api(admin, 'POST', '/api/admin/vendors', { ownerName: '', vendorName: 'X', phone: '0512345680' });
    assert.equal(noName.status, 400);
    const noStore = await api(admin, 'POST', '/api/admin/vendors', { ownerName: 'X', vendorName: '', phone: '0512345680' });
    assert.equal(noStore.status, 400);
    const badPhone = await api(admin, 'POST', '/api/admin/vendors', { ownerName: 'X', vendorName: 'Y', phone: '123' });
    assert.equal(badPhone.status, 400);
  });

  it('şifrə verilərsə həmin şifrə istifadə olunur', async () => {
    const res = await api(admin, 'POST', '/api/admin/vendors', {
      ownerName: 'Öz Şifrə', vendorName: 'Öz Şifrə Mağazası', phone: '0512345681', password: 'menimSifrem1',
    });
    assert.equal(res.status, 200);
    assert.equal(res.data.credentials.generated, false);
    assert.equal(res.data.credentials.password, 'menimSifrem1');
    const owner = client();
    const login = await api(owner, 'POST', '/api/auth/login', { phone: '0512345681', password: 'menimSifrem1' });
    assert.equal(login.status, 200);

    const short = await api(admin, 'POST', '/api/admin/vendors', {
      ownerName: 'Qısa', vendorName: 'Qısa Şifrə', phone: '0512345682', password: '123',
    });
    assert.equal(short.status, 400);
  });

  it('müştəri/satıcı bu endpointi çağıra bilmir', async () => {
    const res = await api(customer, 'POST', '/api/admin/vendors', {
      ownerName: 'Yox', vendorName: 'Yox', phone: '0512345699',
    });
    assert.equal(res.status, 403);
  });
});

/* ================================================================== *
 * B) Kateqoriya idarəsi
 * ================================================================== */
describe('B) kateqoriya idarəsi', () => {
  let newCategoryId;

  it('admin bütün kateqoriyaları istifadə sayı ilə görür', async () => {
    const { status, data } = await api(admin, 'GET', '/api/admin/categories');
    assert.equal(status, 200);
    assert.ok(data.categories.length >= 18, `kateqoriya sayı: ${data.categories.length}`);
    const withCounts = data.categories.find((c) => c.slug === 'sirniyyat');
    assert.ok(withCounts.vendorCount >= 1, 'istifadə sayı hesablanır');
    assert.ok(withCounts.productCount >= 1);
    assert.ok(data.categories.some((c) => c.slug === 'aptek'), 'v6 miqrasiyası ilə Aptek kateqoriyası var');
  });

  it('yeni kateqoriya yaradılır (slug avtomatik)', async () => {
    const res = await api(admin, 'POST', '/api/admin/categories', {
      name: 'Kitab & Dəftərxana', icon: '📚', kind: 'market',
    });
    assert.equal(res.status, 200, JSON.stringify(res.data));
    assert.equal(res.data.category.slug, 'kitab-defterxana');
    assert.equal(res.data.category.kind, 'market');
    newCategoryId = res.data.category.id;

    const list = await api(client(), 'GET', '/api/categories?kind=market');
    assert.ok(list.data.categories.some((c) => c.slug === 'kitab-defterxana'), 'müştəri tətbiqi dərhal görür');
  });

  it('kateqoriya düzəliş olunur (ad, ikon, sıra)', async () => {
    const res = await api(admin, 'PATCH', `/api/admin/categories/${newCategoryId}`, {
      name: 'Kitabxana', icon: '📖', sort: 3,
    });
    assert.equal(res.status, 200);
    assert.equal(res.data.category.name, 'Kitabxana');
    assert.equal(res.data.category.icon, '📖');
    assert.equal(res.data.category.sort, 3);
  });

  it('kateqoriyaya mağaza təyin olunur və müştəri onu görür', async () => {
    const created = await api(admin, 'POST', '/api/admin/vendors', {
      ownerName: 'Kitabçı', vendorName: 'Kitab Evi', phone: '0512345690',
      kind: 'market', category: 'kitab-defterxana', approved: true,
    });
    assert.equal(created.status, 200, JSON.stringify(created.data));

    const filtered = await api(client(), 'GET', '/api/vendors?category=kitab-defterxana');
    assert.equal(filtered.data.vendors.length, 1);
    assert.equal(filtered.data.vendors[0].name, 'Kitab Evi');
  });

  it('istifadədə olan kateqoriya təsdiqsiz silinmir', async () => {
    const res = await api(admin, 'DELETE', `/api/admin/categories/${newCategoryId}`);
    assert.equal(res.status, 400);
    assert.match(res.data.error, /mağaza var/);
    assert.equal(res.data.code, 'category_in_use');
    assert.equal(res.data.params.count, 1);
  });

  it('force=1 ilə silinir və mağaza kateqoriyasız qalır', async () => {
    const res = await api(admin, 'DELETE', `/api/admin/categories/${newCategoryId}?force=1`);
    assert.equal(res.status, 200);
    assert.equal(res.data.movedVendors, 1);

    const vendor = q.get("SELECT category_id FROM vendors WHERE slug = 'kitab-evi'");
    assert.equal(vendor.category_id, null, 'mağaza kateqoriyasız qaldı');

    const list = await api(client(), 'GET', '/api/categories');
    assert.ok(!list.data.categories.some((c) => c.slug === 'kitab-defterxana'), 'kateqoriya silindi');
  });

  it('boş kateqoriya birbaşa silinir', async () => {
    const created = await api(admin, 'POST', '/api/admin/categories', { name: 'Müvəqqəti', kind: 'market' });
    assert.equal(created.status, 200);
    const res = await api(admin, 'DELETE', `/api/admin/categories/${created.data.category.id}`);
    assert.equal(res.status, 200);
    assert.equal(res.data.movedVendors, 0);
  });

  it('eyni slug/ad ilə ikinci kateqoriya yaradılmır', async () => {
    const bySlug = await api(admin, 'POST', '/api/admin/categories', { name: 'Aptek', slug: 'aptek', kind: 'market' });
    assert.equal(bySlug.status, 400);
    assert.equal(bySlug.data.code, 'slug_exists');

    // Ad eynidirsə slug da eyni olur → yenə xəta
    const byName = await api(admin, 'POST', '/api/admin/categories', { name: 'Aptek', kind: 'market' });
    assert.equal(byName.status, 400);
    assert.match(byName.data.error, /artıq var/);
  });

  it('boş ad rədd olunur', async () => {
    const res = await api(admin, 'POST', '/api/admin/categories', { name: '', kind: 'market' });
    assert.equal(res.status, 400);
  });

  it('müştəri kateqoriya idarəsinə girmir', async () => {
    assert.equal((await api(customer, 'GET', '/api/admin/categories')).status, 403);
    assert.equal((await api(customer, 'POST', '/api/admin/categories', { name: 'X' })).status, 403);
    assert.equal((await api(customer, 'DELETE', '/api/admin/categories/1')).status, 403);
  });

  it('yeni kateqoriya satıcı panelində seçilə bilir', async () => {
    const created = await api(admin, 'POST', '/api/admin/categories', { name: 'Çiçək Dükanı', icon: '🌷', kind: 'restaurant' });
    assert.equal(created.status, 200);
    const vendor = await api(admin, 'POST', '/api/admin/vendors', {
      ownerName: 'Çiçəkçi', vendorName: 'Gül Dükanı', phone: '0512345691',
      kind: 'restaurant', category: 'cicek-dukani',
    });
    assert.equal(vendor.status, 200);
    assert.equal(vendor.data.vendor.category.slug, 'cicek-dukani');

    // Satıcı özü də kateqoriyanı dəyişə bilir
    const owner = client();
    await api(owner, 'POST', '/api/auth/login', { phone: '0512345691', password: vendor.data.credentials.password });
    const patched = await api(owner, 'PATCH', '/api/vendor/me', { category: 'cicek-dukani' });
    assert.equal(patched.status, 200);
    assert.equal(patched.data.vendor.category.slug, 'cicek-dukani');
  });
});
