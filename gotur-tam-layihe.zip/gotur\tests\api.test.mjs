/**
 * Götür — API smoke testləri.
 * İşə salmaq:  npm test
 * Test ayrı bir müvəqqəti bazada işləyir (real məlumatlara toxunmur).
 */
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { after, before, describe, it } from 'node:test';

const workDir = mkdtempSync(join(tmpdir(), 'gotur-test-'));
process.env.GOTUR_DB = join(workDir, 'test.db');
process.env.GOTUR_LOG = '0';

const { createServer } = await import('../server/index.js');
const { closeDb } = await import('../server/db.js');

let server;
let base;

/** Cookie saxlayan kiçik HTTP klienti */
function client() {
  let cookie = '';
  return {
    get cookie() { return cookie; },
    async call(method, path, body) {
      const res = await fetch(base + path, {
        method,
        headers: {
          ...(body ? { 'content-type': 'application/json' } : {}),
          ...(cookie ? { cookie } : {}),
        },
        body: body ? JSON.stringify(body) : undefined,
      });
      const setCookie = res.headers.getSetCookie?.() ?? [];
      for (const c of setCookie) {
        const pair = c.split(';')[0];
        if (pair.includes('gotur_session=')) cookie = pair;
      }
      const text = await res.text();
      const data = text ? JSON.parse(text) : null;
      return { status: res.status, data };
    },
  };
}

const api = (c, method, path, body) => c.call(method, path, body);

before(async () => {
  server = createServer();
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  closeDb();
  try {
    rmSync(workDir, { recursive: true, force: true });
  } catch {
    /* Windows bəzən fayl hələ də açıq olduqda silmir — zərərsizdir */
  }
});

describe('kataloq', () => {
  it('kateqoriyaları qaytarır', async () => {
    const { status, data } = await api(client(), 'GET', '/api/categories');
    assert.equal(status, 200);
    assert.ok(data.categories.length >= 10);
  });

  it('restoranları və marketləri ayırır', async () => {
    const c = client();
    const rest = await api(c, 'GET', '/api/vendors?kind=restaurant');
    const market = await api(c, 'GET', '/api/vendors?kind=market');
    assert.ok(rest.data.vendors.length >= 6, 'restoranlar tapıldı');
    assert.ok(market.data.vendors.length >= 3, 'marketlər tapıldı');
    assert.ok(rest.data.vendors.every((v) => v.kind === 'restaurant'));
  });

  it('axtarış məhsul adı ilə işləyir', async () => {
    const { data } = await api(client(), 'GET', '/api/vendors?q=dolma');
    assert.ok(data.vendors.length >= 1);
  });

  it('mağaza menyusunu qaytarır', async () => {
    const { status, data } = await api(client(), 'GET', '/api/vendors/sirvansah-kabab');
    assert.equal(status, 200);
    assert.ok(data.vendor.menu.length >= 3);
    assert.ok(data.vendor.menu[0].items[0].price > 0);
  });

  it('olmayan mağaza üçün 404 verir', async () => {
    const { status } = await api(client(), 'GET', '/api/vendors/yoxdur-bu');
    assert.equal(status, 404);
  });
});

describe('auth və icazələr', () => {
  it('giriş etmədən satıcı endpointi 401 verir', async () => {
    const { status } = await api(client(), 'GET', '/api/vendor/me');
    assert.equal(status, 401);
  });

  it('müştəri admin endpointinə girə bilmir (403)', async () => {
    const c = client();
    const login = await api(c, 'POST', '/api/auth/login', { phone: '0501234567', password: 'customer123' });
    assert.equal(login.status, 200);
    const stats = await api(c, 'GET', '/api/admin/stats');
    assert.equal(stats.status, 403);
  });

  it('yanlış şifrə ilə giriş uğursuz olur', async () => {
    const { status } = await api(client(), 'POST', '/api/auth/login', { phone: '0501234567', password: 'sehv' });
    assert.equal(status, 401);
  });

  it('yeni satıcı qeydiyyatı təsdiq gözləyir', async () => {
    const c = client();
    const reg = await api(c, 'POST', '/api/auth/register', {
      role: 'vendor', name: 'Test Sahib', phone: '0559998877', password: 'test1234',
      vendorName: 'Test Kafe', vendorKind: 'restaurant', address: 'Test küç. 1',
    });
    assert.equal(reg.status, 200);
    assert.equal(reg.data.vendor.approved, false);
    assert.equal(reg.data.vendor.open, false);
  });
});

describe('sifariş axını (uçdan-uca)', () => {
  const vendor = client();
  const customer = client();
  let vendorId;
  let productId;
  let orderId;
  let pickupCode;

  it('admin satıcını təsdiqləyir', async () => {
    const admin = client();
    const login = await api(admin, 'POST', '/api/auth/login', { phone: '0500000000', password: 'admin123' });
    assert.equal(login.status, 200);
    const list = await api(admin, 'GET', '/api/admin/vendors');
    const pending = list.data.vendors.find((v) => v.slug === 'test-kafe');
    assert.ok(pending, 'gözləyən satıcı tapıldı');
    const res = await api(admin, 'PATCH', `/api/admin/vendors/${pending.id}`, { approved: true, open: true });
    assert.equal(res.status, 200);
    assert.equal(res.data.vendor.approved, true);
  });

  it('satıcı menyuya məhsul əlavə edir', async () => {
    const login = await api(vendor, 'POST', '/api/auth/login', { phone: '0559998877', password: 'test1234' });
    assert.equal(login.status, 200);
    const me = await api(vendor, 'GET', '/api/vendor/me');
    vendorId = me.data.vendor.id;
    const created = await api(vendor, 'POST', '/api/vendor/products', {
      name: 'Test Burger', price: 9.5, section: 'Burgerlər', image: '🍔', stock: 5,
    });
    assert.equal(created.status, 200);
    productId = created.data.product.id;
    assert.equal(created.data.product.price, 950);
    assert.equal(created.data.product.stock, 5);
  });

  it('müştəri qeydiyyatdan keçir və sifariş verir', async () => {
    const reg = await api(customer, 'POST', '/api/auth/register', {
      name: 'Test Müştəri', phone: '0771234567', password: 'test1234',
    });
    assert.equal(reg.status, 200);
    const order = await api(customer, 'POST', '/api/orders', {
      vendorId, items: [{ productId, qty: 2 }], payment: 'cash', note: 'Acı olsun',
    });
    assert.equal(order.status, 200, JSON.stringify(order.data));
    assert.equal(order.data.order.total, 1900);
    assert.equal(order.data.order.status, 'pending');
    assert.equal(order.data.order.items[0].qty, 2);
    orderId = order.data.order.id;
    pickupCode = order.data.order.pickupCode;
    assert.match(pickupCode, /^\d{4}$/);
  });

  it('stok azalır', async () => {
    const { data } = await api(vendor, 'GET', '/api/vendor/products');
    const p = data.products.find((x) => x.id === productId);
    assert.equal(p.stock, 3);
  });

  it('satıcı sifarişi qəbul edib hazır edir', async () => {
    for (const status of ['accepted', 'preparing', 'ready', 'picked_up']) {
      const res = await api(vendor, 'POST', `/api/vendor/orders/${orderId}/status`, { status });
      assert.equal(res.status, 200, `${status}: ${JSON.stringify(res.data)}`);
      assert.equal(res.data.order.status, status);
    }
  });

  it('status tarixçəsi qeyd olunur', async () => {
    const { data } = await api(customer, 'GET', `/api/orders/${orderId}`);
    const seq = data.order.events.map((e) => e.status);
    assert.deepEqual(seq, ['pending', 'accepted', 'preparing', 'ready', 'picked_up']);
  });

  it('satıcı sifariş siyahısında tərkib görünür', async () => {
    const { status, data } = await api(vendor, 'GET', '/api/vendor/orders?status=all');
    assert.equal(status, 200);
    const found = data.orders.find((o) => o.id === orderId);
    assert.ok(found, 'sifariş siyahıda var');
    assert.equal(found.items.length, 1);
    assert.equal(found.items[0].qty, 2);
    assert.equal(found.items[0].lineTotal, 1900);
    assert.equal(found.itemCount, 2);
    assert.equal(found.status, 'picked_up');
  });

  it('yanlış status keçidi bloklanır', async () => {
    const res = await api(vendor, 'POST', `/api/vendor/orders/${orderId}/status`, { status: 'preparing' });
    assert.equal(res.status, 400);
  });

  it('səbət boş olsa sifariş qəbul edilmir', async () => {
    const res = await api(customer, 'POST', '/api/orders', { vendorId, items: [] });
    assert.equal(res.status, 400);
  });

  it('stokdan çox sifariş bloklanır', async () => {
    const res = await api(customer, 'POST', '/api/orders', { vendorId, items: [{ productId, qty: 50 }] });
    assert.equal(res.status, 400);
  });

  it('minimum məbləğ yoxlanılır', async () => {
    const { data } = await api(client(), 'GET', '/api/vendors/sirvansah-kabab');
    const cheapest = data.vendor.menu.flatMap((s) => s.items).sort((a, b) => a.price - b.price)[0];
    const res = await api(customer, 'POST', '/api/orders', {
      vendorId: data.vendor.id, items: [{ productId: cheapest.id, qty: 1 }], payment: 'cash',
    });
    assert.equal(res.status, 400);
    assert.match(res.data.error, /Minimum/);
  });

  it('müştəri öz sifarişini ləğv edə bilir', async () => {
    const order = await api(customer, 'POST', '/api/orders', {
      vendorId, items: [{ productId, qty: 2 }], payment: 'cash',
    });
    assert.equal(order.status, 200);
    const cancel = await api(customer, 'POST', `/api/orders/${order.data.order.id}/cancel`);
    assert.equal(cancel.status, 200);
    assert.equal(cancel.data.order.status, 'cancelled');
    const again = await api(customer, 'POST', `/api/orders/${order.data.order.id}/cancel`);
    assert.equal(again.status, 400);
  });

  it('başqa müştəri sifarişə baxa bilmir', async () => {
    const other = client();
    await api(other, 'POST', '/api/auth/register', { name: 'Digər', phone: '0701112233', password: 'test1234' });
    const res = await api(other, 'GET', `/api/orders/${orderId}`);
    assert.equal(res.status, 403);
  });

  it('ləğv edilən sifarişin stoku anbara qaytarılır', async () => {
    const { data } = await api(vendor, 'GET', '/api/vendor/products');
    const p = data.products.find((x) => x.id === productId);
    assert.equal(p.stock, 3, 'ləğvdən sonra stok bərpa olundu');
  });

  it('qonaq (girişsiz) sifariş verə bilir', async () => {
    const guest = client();
    const res = await api(guest, 'POST', '/api/orders', {
      vendorId, name: 'Qonaq Müştəri', phone: '0509998877',
      items: [{ productId, qty: 2 }], payment: 'cash',
    });
    assert.equal(res.status, 200);
    const track = await api(guest, 'GET', `/api/orders/${res.data.order.code}`);
    assert.equal(track.status, 200);
    assert.equal(track.data.order.customerName, 'Qonaq Müştəri');
  });

  it('satıcı statistikası hesablanır', async () => {
    const { status, data } = await api(vendor, 'GET', '/api/vendor/stats');
    assert.equal(status, 200);
    assert.ok(data.today.orders >= 3);
    assert.ok(data.allTime.revenue > 0);
    assert.ok(Array.isArray(data.topProducts));
  });

  it('admin statistikası işləyir', async () => {
    const admin = client();
    await api(admin, 'POST', '/api/auth/login', { phone: '0500000000', password: 'admin123' });
    const { data } = await api(admin, 'GET', '/api/admin/stats');
    assert.ok(data.totals.orders > 0);
    assert.equal(data.daily.length, 7);
    assert.ok(data.topVendors.length > 0);
  });

  it('satıcı mağaza ayarlarını dəyişir', async () => {
    const res = await api(vendor, 'PATCH', '/api/vendor/me', { open: false, prepTime: 45, tagline: 'Yeni şüar' });
    assert.equal(res.status, 200);
    assert.equal(res.data.vendor.open, false);
    assert.equal(res.data.vendor.prepTime, 45);
    const blocked = await api(client(), 'POST', '/api/orders', { vendorId, name: 'X', phone: '0501112233', items: [{ productId, qty: 2 }] });
    assert.equal(blocked.status, 400);
  });

  it('məhsul silinir', async () => {
    const res = await api(vendor, 'DELETE', `/api/vendor/products/${productId}`);
    assert.equal(res.status, 200);
    const list = await api(vendor, 'GET', '/api/vendor/products');
    assert.ok(!list.data.products.some((p) => p.id === productId));
  });
});

describe('statik fayllar', () => {
  it('ana səhifə HTML qaytarır', async () => {
    const res = await fetch(base + '/');
    assert.equal(res.status, 200);
    assert.match(res.headers.get('content-type'), /text\/html/);
    const html = await res.text();
    assert.match(html, /Götür/);
  });

  it('satıcı və admin səhifələri mövcuddur', async () => {
    for (const p of ['/satis.html', '/admin.html']) {
      const res = await fetch(base + p);
      assert.equal(res.status, 200, p);
    }
  });

  it('qovluqdan kənara çıxmaq mümkün deyil', async () => {
    const res = await fetch(base + '/../package.json');
    assert.ok([403, 404].includes(res.status));
  });
});
