/**
 * Götür — HTML escape reqressiya testi.
 *
 * `h` şablonunda `arr.map(...).join('')` kimi HTML parçaları `raw()` ilə
 * sarılmalıdır; yoxsa ekranda HTML kodu mətn kimi görünür (bu, sifariş
 * izləmə səhifəsində real baq kimi çıxmışdı).
 */
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, it } from 'node:test';

import { findEscapeProblems } from '../tools/escape-check.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => readFileSync(join(root, p), 'utf8');

describe('HTML escape', () => {
  it('escape edilməmiş HTML interpolyasiyası yoxdur', () => {
    const problems = findEscapeProblems();
    const report = problems.map((p) => `${p.file}:${p.line} → ${p.text.slice(0, 70)}`).join('\n  ');
    assert.deepEqual(problems, [], `raw() ilə sarılmalıdır:\n  ${report}`);
  });

  it('sifariş tərkibi və tarixçə raw() ilə yerləşdirilir', () => {
    const customer = read('public/assets/customer.js');
    assert.match(customer, /\$\{raw\(order\.items\.map\(/);
    assert.match(customer, /\$\{raw\(order\.events\.map\(/);

    const vendor = read('public/assets/vendor.js');
    assert.match(vendor, /\$\{raw\(order\.items\.map\(/);
    assert.match(vendor, /\$\{raw\(order\.events\.map\(/);

    const admin = read('public/assets/admin.js');
    assert.match(admin, /\$\{raw\(stats\.byStatus\.map\(/);
    assert.match(admin, /\$\{raw\(order\.items\.map\(/);
  });

  it('h şablonu interpolyasiyaları escape edir, raw() keçirir', () => {
    const common = read('public/assets/common.js');
    assert.match(common, /export function h\(strings, \.\.\.values\)/);
    assert.match(common, /if \(value && value\[RAW\] !== undefined\) return value\[RAW\]/);
    assert.match(common, /export const raw = /);
    // Massiv birbaşa verilərsə hər element ayrıca çevrilir
    assert.match(common, /Array\.isArray\(v\) \? v\.map\(stringify\)\.join\(''\)/);
  });
});
