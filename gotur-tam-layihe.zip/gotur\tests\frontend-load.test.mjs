/**
 * Götür — frontend "yüklənmə" smoke testi.
 *
 * Brauzer olmadan müştəri/satıcı/admin/ödəniş modullarını minimal DOM stub-u ilə
 * import edir. Məqsəd: import zamanı və ilk render zamanı yaranan xətaları
 * (məsələn silinmiş export-a müraciət) test mərhələsində tutmaq.
 */
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

/* ------------------------------------------------------------------ *
 * Minimal DOM / brauzer stub-u
 * ------------------------------------------------------------------ */
const makeElement = () => {
  const el = {
    innerHTML: '',
    textContent: '',
    value: '',
    checked: false,
    style: {},
    dataset: {},
    title: '',
    classList: { add() {}, remove() {}, toggle() {}, contains: () => false },
    addEventListener() {},
    removeEventListener() {},
    appendChild() {},
    remove() {},
    setAttribute() {},
    getAttribute: () => null,
    closest: () => null,
    focus() {},
    scrollIntoView() {},
    querySelector: () => makeElement(),
    querySelectorAll: () => [],
    contentDocument: null,
    contentWindow: null,
  };
  return el;
};

const jsonResponse = (data, status = 200) => ({
  ok: status >= 200 && status < 300,
  status,
  headers: { get: () => 'application/json' },
  text: async () => JSON.stringify(data),
  json: async () => data,
});

const settlementPayload = {
  vendorId: 1,
  vendorName: 'Test Mağaza',
  vendorSlug: 'test',
  commissionPercent: 12,
  ownCommissionPercent: 0,
  period: { from: '2026-02-01T00:00:00.000Z', to: '2026-02-28T00:00:00.000Z' },
  totals: {
    orders: 2, gross: 3800, discount: 190, commission: 456, total: 3610,
    online: 1900, counter: 1710, payout: 1672, due: 228, net: 1444, platformRevenue: 266,
  },
  orders: [{
    id: 1, code: 'GT-1001', status: 'picked_up', payment: 'online', paymentStatus: 'paid',
    collectedBy: 'platform', provider: 'simulated', subtotal: 1900, discount: 190,
    couponCode: 'GOTUR10', total: 1710, commission: 228, payout: 1482, settled: true,
    createdAt: '2026-02-10T10:00:00.000Z',
  }],
  settings: { defaultCommission: 12, platformName: 'Götür' },
  history: [{
    id: 1, vendorId: 1, vendorName: 'Test Mağaza', periodStart: '2026-01-01T00:00:00.000Z',
    periodEnd: '2026-01-31T00:00:00.000Z', ordersCount: 5, gross: 9000, discount: 0,
    commission: 1080, online: 4000, counter: 5000, payout: 2920, status: 'paid',
    note: '', createdAt: '2026-02-01T00:00:00.000Z', paidAt: '2026-02-02T00:00:00.000Z',
  }],
};

const platformSettlementPayload = {
  period: { from: '2026-02-01T00:00:00.000Z', to: '2026-02-28T00:00:00.000Z' },
  totals: {
    vendors: 2, orders: 3, gross: 5700, discount: 190, total: 5510,
    commission: 684, online: 1900, counter: 3610, payout: 1482, due: 456, net: 1026, platformRevenue: 494,
  },
  vendors: [
    {
      vendorId: 1, name: 'Test Mağaza', slug: 'test', commissionPercent: 12, ownCommissionPercent: 0,
      orders: 2, gross: 3800, discount: 190, total: 3610, commission: 456, online: 1900,
      counter: 1710, payout: 1482, due: 228, net: 1254, platformRevenue: 266,
    },
    {
      vendorId: 2, name: 'Boş Mağaza', slug: 'empty', commissionPercent: 15, ownCommissionPercent: 15,
      orders: 0, gross: 0, discount: 0, total: 0, commission: 0, online: 0, counter: 0, payout: 0,
      due: 0, net: 0, platformRevenue: 0,
    },
  ],
  settings: { defaultCommission: 12, platformName: 'Götür' },
  history: settlementPayload.history,
};

const apiStub = (url) => {
  if (path.includes('/api/auth/me')) return { user: null, vendor: null };
  if (path.includes('/api/nearby')) {
    return {
      origin: { lat: 40.6828, lng: 46.3606 },
      groups: {
        restaurants: [nearbyVendor('pizza-mizza', 'Pizza Mizza', 'restaurant', 'pizza', '🍕', 0.42)],
        markets: [nearbyVendor('market-247', 'Market 24/7', 'market', 'supermarket', '🛒', 0.2)],
        pharmacies: [nearbyVendor('aptek-1', 'Kanon Aptek', 'market', 'aptek', '🏥', 0.85)],
      },
      counts: { restaurants: 4, markets: 5, pharmacies: 1 },
    };
  }
  if (path.includes('/api/admin/categories')) {
    return {
      categories: [
        { id: 1, slug: 'aptek', name: 'Aptek', icon: '🏥', kind: 'market', sort: 15, vendorCount: 0, productCount: 0 },
        { id: 2, slug: 'sirniyyat', name: 'Şirniyyat & Kofe', icon: '🍰', kind: 'restaurant', sort: 7, vendorCount: 1, productCount: 4 },
      ],
    };
  }
  if (path.includes('/api/categories')) return { categories: [{ id: 1, slug: 'pizza', name: 'Pizza', icon: '🍕', kind: 'restaurant' }] };
  if (path.includes('/api/vendor/settlement')) return settlementPayload;
  if (path.includes('/api/admin/settlements')) return platformSettlementPayload;
  if (path.includes('/api/admin/settings')) return { settings: { defaultCommission: 12, platformName: 'Götür' } };
  if (path.includes('/api/vendor/reviews')) return { reviews: [], summary: { reviewCount: 0, rating: 4.5, ratingCount: 1, distribution: {} } };
  if (path.includes('/api/vendor/coupons')) return { coupons: [] };
  if (path.includes('/api/vendor/products')) return { products: [] };
  if (path.includes('/api/vendor/orders')) {
    return {
      orders: [{
        id: 1, code: 'GT-1001', status: 'pending', vendorId: 1, vendorName: 'Test', vendorSlug: 'test',
        vendorAddress: 'Bakı', vendorPhone: '+994', customerName: 'Aysel', customerPhone: '0501234567',
        subtotal: 1900, fee: 0, total: 1900, discount: 0, couponCode: null, payment: 'cash',
        paymentStatus: 'unpaid', pickupCode: '4821', note: '', createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(), readyAt: null, pickedUpAt: null, itemCount: 2,
        items: [{ name: 'Pizza', qty: 2, price: 950, unit: 'ədəd', lineTotal: 1900 }],
      }],
      counts: { pending: 1, accepted: 0, preparing: 0, ready: 0, picked_up: 0, cancelled: 0, active: 1 },
    };
  }
  if (path.includes('/api/vendor/stats')) {
    return {
      counts: { pending: 1, active: 1 },
      today: { orders: 1, active: 1, revenue: 1900 },
      week: { orders: 3, revenue: 5700 },
      allTime: { orders: 10, revenue: 19_000, cancelled: 1 },
      avgPrepMinutes: 18,
      payments: { todayPaid: 1900, todayUnpaid: 0, online: 1000, counter: 900, refunded: 0 },
      topProducts: [], daily: [],
    };
  }
  if (path.includes('/api/vendor/me')) {
    return {
      vendor: {
        id: 1, slug: 'test', name: 'Test', kind: 'restaurant', logo: '🍕', open: true, approved: true,
        prepTime: 20, minOrder: 0, rating: 4.5, ratingCount: 10, address: 'Bakı', phone: '+994',
        tagline: 't', description: 'd', category: { slug: 'pizza', name: 'Pizza', icon: '🍕' },
      },
      stats: null,
    };
  }
  if (path.includes('/api/vendors/')) {
    return {
      vendor: {
        id: 1, slug: 'test', name: 'Test', kind: 'restaurant', logo: '🍕', open: true, approved: true,
        prepTime: 20, minOrder: 0, rating: 4.5, ratingCount: 10, address: 'Bakı', phone: '+994', tagline: 't',
        description: 'd', menu: [{ section: 'Menyu', items: [{ id: 1, name: 'Pizza', price: 1000, unit: 'ədəd', image: '🍕', stock: null, active: true, inStock: true }] }],
      },
      reviews: [], reviewSummary: { reviewCount: 0, rating: 4.5, ratingCount: 10, distribution: {} }, coupons: [],
    };
  }
  if (path.includes('/api/vendors')) {
    return {
      vendors: [{
        id: 1, slug: 'test', name: 'Test', kind: 'restaurant', logo: '🍕', open: true, approved: true,
        prepTime: 20, minOrder: 0, rating: 4.5, ratingCount: 10, address: 'Bakı, küç. 1', tagline: 't', category: { name: 'Pizza', icon: '🍕' },
      }],
    };
  }
  if (path.includes('/api/admin/stats')) {
    return {
      totals: {
        users: 1, customers: 1, vendors: 1, pendingVendors: 0, products: 1, orders: 1, ordersToday: 1,
        gmvToday: 1000, gmvTotal: 1000, avgBasket: 1000, onlinePaidToday: 0, counterPaidToday: 0,
        unpaidTotal: 0, refundedTotal: 0, stripeActive: false, reviews: 0, hiddenReviews: 0,
        newRatingAvg: 0, activeCoupons: 0, couponOrders: 0, couponDiscount: 0,
        commissionTotal: 120, commissionToday: 120, payoutOnline: 0, commissionCounter: 120,
      },
      byStatus: [], byPaymentStatus: [], daily: [], topVendors: [],
    };
  }
  if (path.includes('/api/admin/vendors') || path.includes('/api/admin/orders')
    || path.includes('/api/admin/payments') || path.includes('/api/admin/users')
    || path.includes('/api/admin/coupons') || path.includes('/api/admin/reviews')) {
    return { vendors: [], orders: [], payments: [], users: [], coupons: [], reviews: [],
      totals: { paid: 0, pending: 0, failed: 0, refunded: 0 } };
  }
  if (path.includes('/api/orders/')) return { order: null };
  if (path.includes('/api/orders')) return { orders: [] };
  if (path.includes('/api/payments/')) return { payment: { status: 'requires_action', amount: 1000, order: null } };
  return {};
};

/** Node-un bəzi qlobalları yalnız oxunaqlıdır — defineProperty ilə əvəz edirik. */
const define = (name, value) => Object.defineProperty(globalThis, name, {
  value, configurable: true, writable: true,
});

const installStubs = () => {
  define('document', {
    title: 'test',
    readyState: 'complete',
    documentElement: { lang: 'az' },
    body: makeElement(),
    head: makeElement(),
    createElement: () => makeElement(),
    querySelector: () => makeElement(),
    querySelectorAll: () => [],
    addEventListener() {},
    removeEventListener() {},
  });
  define('window', globalThis);
  define('location', { hash: '', pathname: '/', search: '', href: '', reload() {} });
  define('navigator', {
    language: 'az',
    languages: ['az'],
    onLine: true,
    serviceWorker: undefined,
    permissions: { query: async () => ({ state: 'granted' }) },
    // Saxta geolocation: Gəncə mərkəzi
    geolocation: {
      getCurrentPosition: (ok) => setTimeout(() => ok({
        coords: { latitude: 40.6828, longitude: 46.3606, accuracy: 12 },
      }), 0),
    },
  });
  const store = new Map();
  define('localStorage', {
    getItem: (k) => (store.has(k) ? store.get(k) : null),
    setItem: (k, v) => store.set(k, String(v)),
    removeItem: (k) => store.delete(k),
    clear: () => store.clear(),
  });
  define('EventSource', class {
    constructor() { this.readyState = 0; }
    addEventListener() {}
    close() {}
  });
  define('matchMedia', () => ({ matches: false, addEventListener() {}, addListener() {} }));
  define('requestAnimationFrame', (fn) => setTimeout(fn, 0));
  define('Notification', undefined);
  // Brauzerdə `window` EventTarget-dir; Node-da bu metodlar yoxdur
  if (typeof globalThis.addEventListener !== 'function') {
    define('addEventListener', () => {});
    define('removeEventListener', () => {});
    define('dispatchEvent', () => true);
  }
  define('scrollTo', () => {});
  define('focus', () => {});
  define('open', () => null);
  define('alert', () => {});

  // Şəffaf fetch stub-u: frontend modulları nisbi yollar (`/api/...`) çağırır və
  // stub cavab alır; digər testlər isə real serverə (http://127.0.0.1:...) gedir.
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url, init) => {
    const target = String(url);
    if (/^https?:\/\//i.test(target)) return realFetch(url, init);
    return jsonResponse(apiStub(target));
  };
};

installStubs();

const collected = [];
process.on('unhandledRejection', (reason) => {
  collected.push(reason instanceof Error ? reason : new Error(String(reason)));
});
process.on('uncaughtException', (err) => collected.push(err));

const wait = (ms = 120) => new Promise((r) => setTimeout(r, ms));

/* ------------------------------------------------------------------ *
 * Testlər
 * ------------------------------------------------------------------ */
describe('frontend modulları yüklənir', () => {
  it('common.js və i18n.js problemsiz import olunur', async () => {
    const U = await import('../public/assets/common.js');
    const i18n = await import('../public/assets/i18n.js');
    assert.equal(typeof U.t, 'function');
    assert.equal(typeof U.printReceipt, 'function');
    assert.equal(typeof U.receiptText, 'function');
    assert.equal(typeof U.subscribeEvents, 'function');
    assert.equal(typeof U.errText, 'function');
    assert.equal(typeof U.paymentLabel, 'function');
    assert.equal(typeof U.statusLabel, 'function');
    assert.equal(typeof i18n.translate, 'function');
    await wait();
    assert.deepEqual(collected, [], 'gözlənilməz xəta baş verdi');
  });

  it('müştəri tətbiqi (customer.js) import olunur və ilk ekranı qurur', async () => {
    await import('../public/assets/customer.js');
    await wait(200);
    assert.deepEqual(collected, []);
  });

  it('satıcı paneli (vendor.js) import olunur', async () => {
    await import('../public/assets/vendor.js');
    await wait(200);
    assert.deepEqual(collected, []);
  });

  it('admin paneli (admin.js) import olunur', async () => {
    await import('../public/assets/admin.js');
    await wait(200);
    assert.deepEqual(collected, []);
  });

  it('ödəniş səhifəsi (odenis.js) import olunur', async () => {
    await import('../public/assets/odenis.js');
    await wait(200);
    assert.deepEqual(collected, []);
  });

  it('modullar silinmiş export-lara müraciət etmir', async () => {
    const U = await import('../public/assets/common.js');
    // Köhnə sabit lüğətlər funksiyalarla əvəz olunub — onlara müraciət olmamalıdır
    assert.equal(U.STATUS_LABEL, undefined);
    assert.equal(U.PAYMENT_LABEL, undefined);
    assert.equal(U.PAYMENT_STATUS_LABEL, undefined);
  });

  it('satıcı panelində hesablaşma bölməsi render olunur', async () => {
    globalThis.location.hash = '#settlement';
    await import('../public/assets/vendor.js?bolme=settlement');
    await wait(260);
    assert.deepEqual(collected, []);
    globalThis.location.hash = '';
  });

  it('admin panelində hesablaşma bölməsi render olunur', async () => {
    globalThis.location.hash = '#hesablasma';
    await import('../public/assets/admin.js?bolme=hesablasma');
    await wait(260);
    assert.deepEqual(collected, []);
    globalThis.location.hash = '';
  });

  it('admin panelində kateqoriyalar bölməsi render olunur', async () => {
    globalThis.location.hash = '#kateqoriyalar';
    await import('../public/assets/admin.js?bolme=kateqoriyalar');
    await wait(280);
    assert.deepEqual(collected, []);
    globalThis.location.hash = '';
  });

  it('admin panelində satıcılar bölməsi «Yeni mağaza» düyməsi ilə render olunur', async () => {
    globalThis.location.hash = '#saticalar';
    await import('../public/assets/admin.js?bolme=saticalar');
    await wait(280);
    assert.deepEqual(collected, []);
    globalThis.location.hash = '';
  });

  it('qəbz çapı brauzer olmadan da xəta atmır', async () => {
    const U = await import('../public/assets/common.js');
    const order = {
      code: 'GT-1001', pickupCode: '4821', customerName: 'Aysel', customerPhone: '0501234567',
      payment: 'cash', paymentStatus: 'paid', subtotal: 1900, discount: 0, total: 1900,
      createdAt: new Date().toISOString(), items: [{ name: 'Pizza', qty: 2, price: 950, lineTotal: 1900 }],
    };
    const text = U.receiptText(order, { name: 'Test', address: 'Bakı', phone: '+994' });
    assert.ok(text.includes('GT-1001'));
    // iframe stub-u contentDocument qaytarmır → funksiya xəta atmadan false qaytarır
    assert.equal(U.printReceipt(order, { name: 'Test' }), false);
    await wait(60);
    assert.deepEqual(collected, []);
  });
});
