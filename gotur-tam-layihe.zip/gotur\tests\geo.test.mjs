/**
 * Götür — məsafə, yerimə/avtomobil vaxtı və yaxınlıq testləri.
 */
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { after, before, describe, it } from 'node:test';

import { haversineKm, isCoord, sortByDistance, travelEstimates, withDistance } from '../server/geo.js';

const workDir = mkdtempSync(join(tmpdir(), 'gotur-geo-'));
process.env.GOTUR_DB = join(workDir, 'geo.db');
process.env.GOTUR_LOG = '0';

const { createServer } = await import('../server/index.js');
const { closeDb } = await import('../server/db.js');

let server;
let base;

function client() {
  let cookie = '';
  return {
    async call(method, path, body) {
      const res = await fetch(base + path, {
        method,
        headers: {
          ...(body ? { 'content-type': 'application/json' } : {}),
          ...(cookie ? { cookie } : {}),
        },
        body: body ? JSON.stringify(body) : undefined,
      });
      for (const c of res.headers.getSetCookie?.() ?? []) {
        const pair = c.split(';')[0];
        if (pair.includes('gotur_session=')) cookie = pair;
      }
      const text = await res.text();
      return { status: res.status, data: text ? JSON.parse(text) : null };
    },
  };
}

const guest = client();
const vendor = client();
const admin = client();
const GANJA = { lat: 40.6828, lng: 46.3606 };

before(async () => {
  server = createServer();
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
  await vendor.call('POST', '/api/auth/login', { phone: '0501110001', password: 'vendor123' });
  await admin.call('POST', '/api/auth/login', { phone: '0500000000', password: 'admin123' });
});

after(async () => {
  await new Promise((r) => server.close(r));
  closeDb();
  try { rmSync(workDir, { recursive: true, force: true }); } catch { /* Windows kilidi */ }
});

/* ================================================================== *
 * Hesablama
 * ================================================================== */
describe('geo: hesablamalar', () => {
  it('Haversine məsafəni düzgün hesablayır', () => {
    // 1 dərəcə enlik ≈ 111.19 km
    const oneDegree = haversineKm(40, 46, 41, 46);
    assert.ok(Math.abs(oneDegree - 111.19) < 0.5, `1° enlik: ${oneDegree}`);

    // Eyni nöqtə → 0
    assert.equal(haversineKm(40.5, 46.5, 40.5, 46.5), 0);

    // Bakı → Gəncə ≈ 300 km (düz xətt)
    const bakuGanja = haversineKm(40.4093, 49.8671, 40.6828, 46.3606);
    assert.ok(bakuGanja > 280 && bakuGanja < 320, `Bakı→Gəncə: ${bakuGanja}`);
  });

  it('yerimə və avtomobil vaxtını düzgün təxmin edir', () => {
    const zero = travelEstimates(0);
    assert.equal(zero.walkMinutes, 1, 'çox yaxın məsafə ən azı 1 dəqiqə');
    assert.equal(zero.driveMinutes, 2, 'avtomobil üçün +2 dəq ehtiyat');

    const walk = travelEstimates(4.8); // 4.8 km/saat → tam 60 dəqiqə
    assert.equal(walk.walkMinutes, 60);

    const drive = travelEstimates(25); // 25 km/saat → 60 + 2
    assert.equal(drive.driveMinutes, 62);

    // Artan məsafə → artan vaxt
    assert.ok(travelEstimates(3).walkMinutes > travelEstimates(1).walkMinutes);
  });

  it('isCoord boş və yanlış dəyərləri rədd edir', () => {
    assert.equal(isCoord(null, null), false);
    assert.equal(isCoord(undefined, undefined), false);
    assert.equal(isCoord('', ''), false);
    assert.equal(isCoord('abc', '46'), false);
    assert.equal(isCoord(91, 46), false, 'enlik 90-dan böyük ola bilməz');
    assert.equal(isCoord(40, 181), false, 'uzunluq 180-dən böyük ola bilməz');
    assert.equal(isCoord(0, 0), true, 'ekvator/başlanğıc meridian etibarlıdır');
    assert.equal(isCoord('40.68', '46.36'), true, 'sətir koordinat qəbul olunur');
  });

  it('withDistance koordinat olmayanda null qaytarır', () => {
    const noCoord = withDistance({ name: 'x', lat: null, lng: null }, GANJA.lat, GANJA.lng);
    assert.equal(noCoord.distanceKm, null);
    assert.equal(noCoord.walkMinutes, null);

    const noOrigin = withDistance({ name: 'y', lat: 40.68, lng: 46.36 }, null, null);
    assert.equal(noOrigin.distanceKm, undefined, 'müştəri koordinatı yoxdursa heç nə əlavə olunmur');

    const ok = withDistance({ name: 'z', lat: 40.6835, lng: 46.3612 }, GANJA.lat, GANJA.lng);
    assert.ok(ok.distanceKm > 0 && ok.distanceKm < 1, `məsafə: ${ok.distanceKm}`);
    assert.ok(ok.walkMinutes >= 1 && ok.driveMinutes >= 1);
  });

  it('sortByDistance yaxını əvvələ, koordinatsızı sona qoyur', () => {
    const list = [
      { name: 'koordinatsız', lat: null, lng: null },
      { name: 'uzaq', lat: 40.6880, lng: 46.3590 },
      { name: 'yaxın', lat: 40.6835, lng: 46.3612 },
    ];
    const sorted = sortByDistance(list, GANJA.lat, GANJA.lng);
    assert.deepEqual(sorted.map((v) => v.name), ['yaxın', 'uzaq', 'koordinatsız']);
  });
});

/* ================================================================== *
 * API
 * ================================================================== */
describe('geo: API', () => {
  it('koordinatsız istək məsafə qaytarmır', async () => {
    const { data } = await guest.call('GET', '/api/vendors');
    assert.ok(data.vendors.length >= 12);
    assert.equal(data.origin, null);
    assert.ok(!('distanceKm' in data.vendors[0]), 'məsafə sahəsi olmamalıdır');
  });

  it('başlanğıc nöqtəsi ilə məsafə, yerimə və avtomobil vaxtı gəlir', async () => {
    const { status, data } = await guest.call('GET', `/api/vendors?lat=${GANJA.lat}&lng=${GANJA.lng}`);
    assert.equal(status, 200);
    assert.deepEqual(data.origin, { lat: GANJA.lat, lng: GANJA.lng });
    const withKm = data.vendors.filter((v) => v.distanceKm !== null && v.distanceKm !== undefined);
    assert.ok(withKm.length >= 10, `məsafəli mağaza: ${withKm.length}`);
    for (const v of withKm) {
      assert.ok(v.distanceKm > 0 && v.distanceKm < 20, `${v.name}: ${v.distanceKm} km`);
      assert.ok(Number.isInteger(v.walkMinutes) && v.walkMinutes >= 1);
      assert.ok(Number.isInteger(v.driveMinutes) && v.driveMinutes >= 1);
      assert.equal(typeof v.hasLocation, 'boolean');
    }
  });

  it('sort=nearby məsafəyə görə sıralayır', async () => {
    const { data } = await guest.call('GET', `/api/vendors?lat=${GANJA.lat}&lng=${GANJA.lng}&sort=nearby`);
    const distances = data.vendors.map((v) => v.distanceKm).filter((d) => d !== null);
    const sorted = [...distances].sort((a, b) => a - b);
    assert.deepEqual(distances, sorted, 'məsafələr artan sırada olmalıdır');
    assert.ok(distances[0] < 1, `ən yaxın mağaza: ${distances[0]} km`);
  });

  it('/api/nearby növə görə qruplaşdırır', async () => {
    const { status, data } = await guest.call('GET', `/api/nearby?lat=${GANJA.lat}&lng=${GANJA.lng}&limit=4`);
    assert.equal(status, 200, JSON.stringify(data));
    assert.ok(data.groups.restaurants.length > 0, 'restoran qrupu boşdur');
    assert.ok(data.groups.markets.length > 0, 'market qrupu boşdur');
    assert.ok(data.groups.restaurants.length <= 4, 'limit tətbiq olunur');
    for (const list of Object.values(data.groups)) {
      const d = list.map((v) => v.distanceKm);
      assert.deepEqual(d, [...d].sort((a, b) => a - b), 'hər qrup məsafəyə görə sıralanmalıdır');
    }
    assert.ok(data.counts.restaurants >= data.groups.restaurants.length);
  });

  it('koordinatsız /api/nearby xəta qaytarır', async () => {
    const { status, data } = await guest.call('GET', '/api/nearby');
    assert.equal(status, 400);
    assert.equal(data.code, 'coords_required');
    const empty = await guest.call('GET', '/api/nearby?lat=&lng=');
    assert.equal(empty.status, 400, 'boş koordinat (0,0) sayılmamalıdır');
  });

  it('mağaza səhifəsi məsafəni göstərir', async () => {
    const { data } = await guest.call('GET', `/api/vendors/sirvansah-kabab?lat=${GANJA.lat}&lng=${GANJA.lng}`);
    assert.ok(data.vendor.distanceKm > 0);
    assert.ok(data.vendor.walkMinutes >= 1);
    assert.equal(data.vendor.hasLocation, true);

    const plain = await guest.call('GET', '/api/vendors/sirvansah-kabab');
    assert.equal(plain.data.vendor.distanceKm, undefined);
    assert.equal(plain.data.vendor.hasLocation, true, 'mağazanın öz koordinatı var');
  });

  it('kateqoriya filtri məsafə ilə birlikdə işləyir', async () => {
    const { data } = await guest.call('GET', `/api/vendors?kind=market&lat=${GANJA.lat}&lng=${GANJA.lng}&sort=nearby`);
    assert.ok(data.vendors.length >= 4);
    assert.ok(data.vendors.every((v) => v.kind === 'market'));
    // Koordinatı olan marketlər məsafə almalıdır (digər test faylları yeni
    // mağazalar yarada bilər, ona görə hamısı üçün tələb etmirik)
    const located = data.vendors.filter((v) => v.hasLocation);
    assert.ok(located.length >= 4, `koordinatlı market: ${located.length}`);
    assert.ok(located.every((v) => typeof v.distanceKm === 'number' && v.distanceKm >= 0));
  });

  it('satıcı öz yerini təyin edir və dəyişir', async () => {
    const me = await vendor.call('GET', '/api/vendor/me');
    const before = me.data.vendor;
    assert.equal(before.hasLocation, true, 'demo mağazanın koordinatı var');

    const moved = await vendor.call('PATCH', '/api/vendor/me', { lat: 40.7, lng: 46.4 });
    assert.equal(moved.status, 200, JSON.stringify(moved.data));
    assert.equal(moved.data.vendor.lat, 40.7);
    assert.equal(moved.data.vendor.lng, 46.4);

    // Məsafə yeni koordinata görə hesablanır
    const page = await guest.call('GET', `/api/vendors/sirvansah-kabab?lat=40.7&lng=46.4`);
    assert.equal(page.data.vendor.distanceKm, 0);

    // Geri qaytar
    const back = await vendor.call('PATCH', '/api/vendor/me', { lat: 40.6775, lng: 46.3530 });
    assert.equal(back.data.vendor.lat, 40.6775);
  });

  it('yanlış koordinat rədd olunur, boş göndərmə yeri silir', async () => {
    const bad1 = await vendor.call('PATCH', '/api/vendor/me', { lat: 999, lng: 46.36 });
    assert.equal(bad1.status, 400);
    assert.equal(bad1.data.code, 'coords_invalid');

    const bad2 = await vendor.call('PATCH', '/api/vendor/me', { lat: 'abc', lng: 'def' });
    assert.equal(bad2.status, 400);

    const cleared = await vendor.call('PATCH', '/api/vendor/me', { lat: null, lng: null });
    assert.equal(cleared.status, 200);
    assert.equal(cleared.data.vendor.hasLocation, false);
    assert.equal(cleared.data.vendor.lat, null);

    // Koordinatsız mağaza məsafə hesablamasında null alır
    const list = await guest.call('GET', `/api/vendors?lat=${GANJA.lat}&lng=${GANJA.lng}&sort=nearby`);
    const target = list.data.vendors.find((v) => v.slug === 'sirvansah-kabab');
    assert.equal(target.distanceKm, null);

    // Bərpa et
    await vendor.call('PATCH', '/api/vendor/me', { lat: 40.6775, lng: 46.3530 });
  });

  it('admin yeni mağazanı koordinatla yaradır', async () => {
    const created = await admin.call('POST', '/api/admin/vendors', {
      ownerName: 'Yer Testi', vendorName: 'Yer Testi Mağazası', phone: '0512399999',
      kind: 'restaurant', lat: 40.69, lng: 46.37,
    });
    assert.equal(created.status, 200, JSON.stringify(created.data));
    assert.equal(created.data.vendor.hasLocation, true);
    assert.equal(created.data.vendor.lat, 40.69);

    const list = await guest.call('GET', `/api/vendors?lat=${GANJA.lat}&lng=${GANJA.lng}&sort=nearby`);
    const found = list.data.vendors.find((v) => v.slug === 'yer-testi-magazasi');
    assert.ok(found, 'yeni mağaza siyahıda görünür');
    assert.ok(found.distanceKm > 0 && found.distanceKm < 5);
  });

  it('koordinatsız yeni mağaza məsafəsiz görünür', async () => {
    const created = await admin.call('POST', '/api/admin/vendors', {
      ownerName: 'Yersiz', vendorName: 'Yersiz Mağaza', phone: '0512399998', kind: 'market',
    });
    assert.equal(created.status, 200);
    assert.equal(created.data.vendor.hasLocation, false);

    const list = await guest.call('GET', `/api/vendors?lat=${GANJA.lat}&lng=${GANJA.lng}&sort=nearby`);
    const found = list.data.vendors.find((v) => v.slug === 'yersiz-magaza');
    assert.equal(found.distanceKm, null);
    // Koordinatsızlar siyahının sonunda olmalıdır
    const last = list.data.vendors[list.data.vendors.length - 1];
    assert.equal(last.distanceKm, null);
  });
});
