/**
 * Götür — i18n (çoxdillilik) testləri.
 * Lüğətlərin tamlığını, yer tutucu uyğunluğunu və tərcümə funksiyasının
 * davranışını yoxlayır. Brauzer tələb etmir.
 */
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

const i18n = await import('../public/assets/i18n.js');
const U = await import('../public/assets/common.js');

// Node-un `navigator.language`-i 'en-US' ola bilər — testlər AZ üzərində qurulub
U.setLang('az');

const { LANGS, DEFAULT_LANG, dictionaries, translate, detectLang, keysOf, makeT } = i18n;

const placeholders = (value) => [...String(value).matchAll(/\{(\w+)\}/g)].map((m) => m[1]).sort().join(',');

describe('lüğət strukturu', () => {
  it('üç dil dəstəklənir və default az-dır', () => {
    assert.deepEqual([...LANGS], ['az', 'en', 'ru']);
    assert.equal(DEFAULT_LANG, 'az');
    for (const lang of LANGS) assert.equal(typeof dictionaries[lang], 'object');
  });

  it('bütün dillərdə eyni açarlar var', () => {
    const azKeys = keysOf('az');
    assert.ok(azKeys.length > 600, `kifayət qədər açar var (${azKeys.length})`);
    for (const lang of ['en', 'ru']) {
      const keys = keysOf(lang);
      const missing = azKeys.filter((k) => !keys.includes(k));
      const extra = keys.filter((k) => !azKeys.includes(k));
      assert.deepEqual(missing, [], `${lang}: çatışmayan açarlar`);
      assert.deepEqual(extra, [], `${lang}: artıq açarlar`);
    }
  });

  it('heç bir dəyər boş deyil', () => {
    for (const lang of LANGS) {
      for (const key of keysOf(lang)) {
        const value = translate(lang, key);
        assert.equal(typeof value, 'string', `${lang}.${key}`);
        assert.ok(value.trim().length > 0, `${lang}.${key} boşdur`);
      }
    }
  });

  it('yer tutucular dillər arasında uyğundur', () => {
    const problems = [];
    for (const key of keysOf('az')) {
      const expected = placeholders(translate('az', key));
      for (const lang of ['en', 'ru']) {
        const actual = placeholders(translate(lang, key));
        if (actual !== expected) problems.push(`${lang}.${key}: «${expected}» ≠ «${actual}»`);
      }
    }
    assert.deepEqual(problems, []);
  });
});

describe('tərcümə funksiyası', () => {
  it('seçilmiş dilə uyğun mətn qaytarır', () => {
    assert.equal(translate('az', 'nav.cart'), 'Səbət');
    assert.notEqual(translate('en', 'nav.cart'), translate('az', 'nav.cart'));
    assert.notEqual(translate('ru', 'nav.cart'), translate('az', 'nav.cart'));
    assert.equal(typeof translate('en', 'nav.cart'), 'string');
  });

  it('yer tutucuları əvəz edir', () => {
    const az = translate('az', 'home.storesCount', { count: 7 });
    assert.match(az, /7/);
    assert.ok(!az.includes('{count}'));
    for (const lang of LANGS) {
      const text = translate(lang, 'units.minutesShort', { count: 5 });
      assert.match(text, /5/);
      assert.ok(!text.includes('{count}'), lang);
    }
  });

  it('çatışmayan açar üçün açarın özünü qaytarır (səssiz sızma yoxdur)', () => {
    assert.equal(translate('az', 'yx.bu.açar.yoxdur'), 'yx.bu.açar.yoxdur');
  });

  it('naməlum dil üçün az-a düşür', () => {
    assert.equal(translate('de', 'nav.cart'), translate('az', 'nav.cart'));
  });

  it('makeT qısa funksiya yaradır', () => {
    const ru = makeT('ru');
    assert.equal(ru('nav.cart'), translate('ru', 'nav.cart'));
  });
});

describe('dil aşkarlanması', () => {
  it('brauzer siyahısından uyğun dili seçir', () => {
    assert.equal(detectLang(['az-AZ', 'ru-RU', 'en-US']), 'az');
    assert.equal(detectLang(['ru-RU']), 'ru');
    assert.equal(detectLang(['en-GB', 'ru-RU']), 'en');
    assert.equal(detectLang(['de-DE', 'fr-FR']), 'az', 'naməlum dil → default az');
    assert.equal(detectLang([]), 'az');
    assert.equal(detectLang([undefined, null, '']), 'az');
  });
});

describe('frontend dil dəyişdirmə', () => {
  // Qeyd: bu testlər qlobal dili dəyişir — ona görə digər test faylları
  // dilə bağlı olmayan gözləntilər yazır (U.t(...) ilə müqayisə).
  it('setLang cari dili dəyişir və geri qaytarıla bilir', () => {
    const original = U.lang();
    try {
      U.setLang('en');
      assert.equal(U.lang(), 'en');
      U.setLang('ru');
      assert.equal(U.lang(), 'ru');
    } finally {
      U.setLang(original, { persist: false });
    }
    assert.equal(U.lang(), original);
  });

  it('dil dəyişdikdə köməkçi funksiyalar yeni dili istifadə edir', () => {
    const original = U.lang();
    try {
      U.setLang('ru');
      assert.equal(U.paymentLabel('cash'), translate('ru', 'payment.cash'));
      assert.equal(U.paymentStatusLabel('paid'), translate('ru', 'paymentStatus.paid'));
      assert.equal(U.t('nav.cart'), translate('ru', 'nav.cart'));
    } finally {
      U.setLang(original, { persist: false });
    }
  });

  it('dil dəyişdiricisi üç dil üçün düymə qurur', () => {
    const html = U.langSwitcherHtml();
    for (const lang of LANGS) assert.match(html, new RegExp(`data-lang="${lang}"`));
    assert.match(html, /class="on"/, 'cari dil işarələnir');
  });

  it('xəta mətnini koddan tərcümə edir', () => {
    const original = U.lang();
    try {
      U.setLang('az');
      const err = { code: 'min_order', params: { amount: '8,00 ₼' }, message: 'baxılmır' };
      const text = U.errText(err);
      assert.notEqual(text, 'bazılmır');
      assert.match(text, /8,00/);
      assert.ok(!text.includes('{amount}'));

      // Kodu olmayan xəta → server mesajı
      assert.equal(U.errText({ message: 'Xüsusi mesaj' }), 'Xüsusi mesaj');
      // Naməlum kod → server mesajına düşür
      assert.equal(U.errText({ code: 'yoxdur_bu_kod', message: 'Fallback' }), 'Fallback');
    } finally {
      U.setLang(original, { persist: false });
    }
  });
});

describe('qəbz (58mm)', () => {
  const order = {
    code: 'GT-1042',
    pickupCode: '4821',
    customerName: 'Aysel M.',
    customerPhone: '0501234567',
    payment: 'cash',
    paymentStatus: 'paid',
    subtotal: 2150,
    discount: 200,
    couponCode: 'GOTUR10',
    total: 1950,
    createdAt: new Date('2026-02-12T14:35:00Z').toISOString(),
    items: [
      { name: 'Toyuq kabab', qty: 2, price: 950, lineTotal: 1900 },
      { name: 'Ayran', qty: 1, price: 250, lineTotal: 250 },
    ],
  };
  const vendor = { name: 'Şirvanşah Kabab Evi', address: 'Nizami küç. 45, Bakı', phone: '+994 12 493 11 22' };

  it('qəbz mətnini 32 simvolluq sətirlərlə qurur', () => {
    const text = U.receiptText(order, vendor, { lang: 'az' });
    assert.match(text, /GT-1042/);
    assert.match(text, /4821/);
    assert.match(text, /Toyuq kabab/);
    assert.ok(text.includes(translate('az', 'receipt.pickupCode')));
    for (const line of text.split('\n')) {
      assert.ok(line.length <= 32, `sətir 32 simvolu keçdi: «${line}» (${line.length})`);
    }
  });

  it('endirimi və yekunu göstərir', () => {
    const text = U.receiptText(order, vendor, { lang: 'az' });
    assert.ok(text.includes(translate('az', 'common.discount')));
    assert.match(text, /19,50/);
  });

  it('qəbz seçilmiş dildə yazılır', () => {
    const az = U.receiptText(order, vendor, { lang: 'az' });
    const ru = U.receiptText(order, vendor, { lang: 'ru' });
    const en = U.receiptText(order, vendor, { lang: 'en' });
    assert.notEqual(ru, az, 'rus dili azərbaycan dili ilə eyni olmamalıdır');
    assert.notEqual(en, az, 'ingilis dili azərbaycan dili ilə eyni olmamalıdır');
    assert.ok(az.includes(translate('az', 'receipt.pickupCode')));
    assert.ok(ru.includes(translate('ru', 'receipt.pickupCode')));
    assert.ok(en.includes(translate('en', 'receipt.pickupCode')));
  });
});
