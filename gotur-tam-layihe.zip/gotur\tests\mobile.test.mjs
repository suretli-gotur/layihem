/**
 * Götür — mobil uyğunluq və klik baqları üçün reqressiya testləri.
 *
 * 1) Gizli təbəqələr (backdrop) klikləri bloklamamalıdır — bir dəfə bu baq
 *    məhsul seçəndən sonra bütün səhifəni "ölü" edirdi.
 * 2) Bütün səhifələr mobil viewport, alt naviqasiya / off-canvas menyu və
 *    toxunuş üçün uyğun ölçülər elan etməlidir.
 */
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, it } from 'node:test';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => readFileSync(join(root, p), 'utf8');
const css = read('public/assets/app.css');

/** CSS-də selektorun bütün gövdələri (media query-lər daxil) */
function bodiesFor(selector) {
  const out = [];
  const re = new RegExp(`(^|[},])\\s*${selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*\\{([^}]*)\\}`, 'gm');
  let m;
  while ((m = re.exec(css)) !== null) out.push(m[2]);
  return out;
}

describe('mobil: gizli təbəqələr klikləri bloklamır', () => {
  for (const selector of ['.drawer-backdrop', '.sidebar-backdrop']) {
    it(`${selector} bağlı halda klik keçirir, açıq halda qəbul edir`, () => {
      const all = bodiesFor(selector);
      assert.ok(all.length > 0, `${selector} qaydası yoxdur`);
      const inert = all.some((b) => b.includes('pointer-events: none'))
        || all.some((b) => b.includes('visibility: hidden'))
        || all.some((b) => b.includes('display: none'));
      assert.ok(inert, `${selector} bağlı halda klikləri bloklayır`);

      const open = bodiesFor(`${selector}.open`).join(' ');
      assert.match(open, /pointer-events:\s*auto/, `${selector}.open klik qəbul etməlidir`);
    });
  }

  it('səbət fonu yalnız açıq olanda DOM-a əlavə olunur', () => {
    const customer = read('public/assets/customer.js');
    // renderDrawer: backdrop yalnız isOpen olduqda şablona daxil edilir
    assert.match(customer, /isOpen \? raw\('<div class="drawer-backdrop open"/);
    // və açılışda ayrıca əlavə olunur
    assert.match(customer, /insertAdjacentHTML\('afterbegin', '<div class="drawer-backdrop"/);
  });

  it('modal fonu bağlananda DOM-dan silinir', () => {
    const common = read('public/assets/common.js');
    assert.match(common, /backdrop\.remove\(\)/);
  });
});

describe('mobil: viewport və struktur', () => {
  const pages = ['index.html', 'satis.html', 'admin.html', 'odenis.html', 'offline.html'];

  it('hər səhifə mobil viewport elan edir', () => {
    for (const page of pages) {
      const meta = read(`public/${page}`).match(/<meta name="viewport" content="([^"]+)"/)?.[1] ?? '';
      assert.ok(meta.includes('width=device-width'), `${page}: width=device-width yoxdur`);
      assert.ok(meta.includes('initial-scale=1'), `${page}: initial-scale yoxdur`);
      assert.ok(meta.includes('viewport-fit=cover'), `${page}: viewport-fit=cover yoxdur`);
    }
  });

  it('müştəri tətbiqində alt naviqasiya var və render olunur', () => {
    assert.match(read('public/index.html'), /class="mobile-tabbar"[^>]*id="tabbar"/);
    const customer = read('public/assets/customer.js');
    assert.match(customer, /function renderTabbar\(\)/);
    assert.ok((customer.match(/renderTabbar\(\);/g) ?? []).length >= 3, 'boot, route və səbət dəyişikliyində çağırılmalıdır');
    assert.match(customer, /classList\.add\('has-tabbar'\)/);
  });

  it('tabbar səbət düyməsi mövcud olmayan marşruta getmir, səbəti açır', () => {
    const customer = read('public/assets/customer.js');
    assert.ok(!customer.includes("'#/sebet'"), 'mövcud olmayan #/sebet marşrutu istifadə olunmamalıdır');
    assert.match(customer, /<button type="button" data-act="cart"/);
    // Tabbar düymələri də CSS-də stillənməlidir (yalnız <a> yox)
    assert.match(css, /\.mobile-tabbar a, \.mobile-tabbar button \{/);
  });

  it('satıcı və admin panellərində off-canvas menyu var', () => {
    for (const page of ['satis.html', 'admin.html']) {
      const html = read(`public/${page}`);
      assert.match(html, /class="panel-topbar"/, page);
      assert.match(html, /data-act="menu"/, page);
      assert.match(html, /class="sidebar-backdrop"/, page);
    }
    for (const panel of ['vendor.js', 'admin.js']) {
      assert.match(read(`public/assets/${panel}`), /U\.initPanelMenu\('#sidebar'\)/, panel);
    }
    const common = read('public/assets/common.js');
    assert.match(common, /export function initPanelMenu/);
    // Esc və ekran böyüdükdə bağlanma
    assert.match(common, /key === 'Escape'\) setOpen\(false\)/);
    assert.match(common, /innerWidth > 980\) setOpen\(false\)/);
  });

  it('giriş ekranlarında üst zolaq gizlədilir', () => {
    assert.match(read('public/assets/app.css'), /body\.no-menu \.panel-topbar \{ display: none; \}/);
    assert.match(read('public/assets/vendor.js'), /classList\.add\('no-menu'\)/);
    assert.match(read('public/assets/admin.js'), /classList\.add\('no-menu'\)/);
  });
});

describe('mobil: CSS breykpointləri və toxunuş', () => {
  it('breakpoint-lər mövcuddur (980 / 640 / 400)', () => {
    const bps = [...css.matchAll(/@media\s*\(max-width:\s*(\d+)px\)/g)].map((m) => Number(m[1]));
    for (const need of [980, 640, 400]) assert.ok(bps.includes(need), `${need}px breakpoint yoxdur`);
  });

  it('daşma qoruması var', () => {
    assert.match(css, /html,\s*body\s*\{[^}]*overflow-x:\s*hidden/);
    assert.match(css, /overflow-wrap:\s*anywhere/);
  });

  it('toxunuş hədəfləri və safe-area təyin olunub', () => {
    const mobile = css.split('@media (max-width: 980px)').slice(1).join('');
    assert.match(mobile, /\.btn\s*\{[^}]*min-height:\s*(4[0-9]|[5-9]\d)px/);
    assert.ok((css.match(/env\(safe-area-inset-bottom/g) ?? []).length >= 3, 'safe-area dəstəyi zəifdir');
  });

  it('mobil üçün gizlədilən mətn/sütun sinifləri var', () => {
    assert.match(css, /\.btn-label \{ display: none; \}/);
    assert.match(css, /\.hide-sm \{ display: none !important; \}/);
    assert.match(css, /\.only-sm \{ display: none; \}/);
  });

  it('müştəri məhsul sətri telefondə sıxlaşdırılır', () => {
    const mobile640 = css.split('@media (max-width: 640px)')[1] ?? '';
    assert.match(mobile640, /\.item-row/);
    assert.match(mobile640, /\.site-footer|\.form-grid/);
  });

  it('geniş cədvəllərdə ilk sütun sabitlənir (mobil oxunaqlıq)', () => {
    const mobile640 = css.split('@media (max-width: 640px)')[1] ?? '';
    assert.match(mobile640, /table\.table td:first-child[\s\S]{0,120}position:\s*sticky/);
  });

  it('müştəri başlığında düymə mətnləri mobil siniflə sarılır', () => {
    const customer = read('public/assets/customer.js');
    for (const key of ['nav.search', 'nav.cart']) {
      assert.ok(customer.includes(`<span class="btn-label">\${U.t('${key}')}</span>`), `${key} üçün btn-label yoxdur`);
    }
  });
});

describe('məsafə: yaxınlıq UI-ı', () => {
  it('müştəri tətbiqində yaxınlıq bölməsi və məsafə nişanları var', () => {
    const customer = read('public/assets/customer.js');
    assert.match(customer, /id="nearby-area"/);
    assert.match(customer, /async function paintNearby\(\)/);
    assert.match(customer, /data-act="share-loc"/);
    assert.match(customer, /data-act="clear-loc"/);
    assert.match(customer, /U\.travelChipsHtml\(v\)/);
    assert.match(customer, /U\.t\('nearby\.walkMinutes'/);
    assert.match(customer, /U\.t\('nearby\.driveMinutes'/);
  });

  it('mağaza səhifəsi məsafəni koordinatla soruşur', () => {
    const customer = read('public/assets/customer.js');
    assert.match(customer, /api\/vendors\/\$\{encodeURIComponent\(slug\)\}\$\{query\}/);
    assert.match(customer, /const query = loc \? `\?lat=\$\{loc\.lat\}&lng=\$\{loc\.lng\}` : ''/);
    assert.match(customer, /class="travel-bar/);
  });

  it('satıcı panelində yer təyin etmə bloku var', () => {
    const vendor = read('public/assets/vendor.js');
    assert.match(vendor, /data-act="use-loc"/);
    assert.match(vendor, /data-act="save-loc"/);
    assert.match(vendor, /data-act="clear-loc"/);
    assert.match(vendor, /name="lat"/);
    assert.match(vendor, /name="lng"/);
    assert.match(vendor, /google\.com\/maps\?q=/);
  });

  it('CSS-də məsafə nişanları və yaxınlıq kartları stillənib', () => {
    for (const sel of ['.dist-chip', '.dist-row', '.travel-bar', '.nearby-grid', '.nearby-card', '.nc-badge']) {
      assert.ok(css.includes(sel), `${sel} stili yoxdur`);
    }
  });

  it('geolocation köməkçisi common.js-də ixrac olunur', () => {
    const common = read('public/assets/common.js');
    assert.match(common, /export const geo = \{/);
    for (const fn of ['cached', 'request', 'clear']) {
      assert.ok(new RegExp(`${fn}\\(`).test(common), `geo.${fn} yoxdur`);
    }
    assert.match(common, /export function kmText/);
    assert.match(common, /export function travelChipsHtml/);
    assert.match(common, /export function byDistance/);
    // Boş dəyərlər (0, 0) kimi sayılmamalıdır
    assert.match(common, /Number\.isFinite\(parsed\.lat\)/);
  });
});
