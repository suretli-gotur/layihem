/**
 * Götür — ödəniş (Mərhələ 1) testləri.
 * Simulyasiya provayderi uçdan-uca, Stripe hissəsi isə təmiz funksiyalarla yoxlanılır.
 */
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { after, before, describe, it } from 'node:test';

const workDir = mkdtempSync(join(tmpdir(), 'gotur-pay-'));
process.env.GOTUR_DB = join(workDir, 'pay.db');
process.env.GOTUR_LOG = '0';
delete process.env.STRIPE_SECRET_KEY;

const { createServer } = await import('../server/index.js');
const { closeDb } = await import('../server/db.js');
const { luhnValid, expiryValid, cvcValid, verifyStripeSignature, stripeEnabled } = await import('../server/payments.js');

let server;
let base;

function client() {
  let cookie = '';
  return {
    async call(method, path, body) {
      const res = await fetch(base + path, {
        method,
        headers: {
          ...(body ? { 'content-type': 'application/json' } : {}),
          ...(cookie ? { cookie } : {}),
        },
        body: body ? JSON.stringify(body) : undefined,
      });
      for (const c of res.headers.getSetCookie?.() ?? []) {
        const pair = c.split(';')[0];
        if (pair.includes('gotur_session=')) cookie = pair;
      }
      const text = await res.text();
      return { status: res.status, data: text ? JSON.parse(text) : null };
    },
  };
}
const api = (c, m, p, b) => c.call(m, p, b);

before(async () => {
  server = createServer();
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  await new Promise((r) => server.close(r));
  closeDb();
  try { rmSync(workDir, { recursive: true, force: true }); } catch { /* Windows kilidi */ }
});

/* ------------------------------------------------------------------ *
 * Kart köməkçiləri
 * ------------------------------------------------------------------ */
describe('kart yoxlaması', () => {
  it('Luhn alqoritmi doğru kartları qəbul edir', () => {
    for (const good of ['4242424242424242', '4000 0000 0000 0002', '5555555555554444', '378282246310005']) {
      assert.equal(luhnValid(good), true, good);
    }
  });

  it('Luhn yanlış kartları rədd edir', () => {
    for (const badNumber of ['4242424242424241', '1234567890123456', '4242', 'abcd']) {
      assert.equal(luhnValid(badNumber), false, badNumber);
    }
  });

  it('son istifadə tarixini yoxlayır', () => {
    const now = new Date('2026-06-15T00:00:00Z');
    assert.equal(expiryValid('12/28', now), true);
    assert.equal(expiryValid('06/26', now), true, 'cari ay hələ keçməyib');
    assert.equal(expiryValid('05/26', now), false, 'keçmiş ay');
    assert.equal(expiryValid('13/28', now), false, 'yanlış ay');
    assert.equal(expiryValid('1/28', now), false, 'format səhvdir');
  });

  it('CVV formatını yoxlayır', () => {
    assert.equal(cvcValid('123'), true);
    assert.equal(cvcValid('1234'), true);
    assert.equal(cvcValid('12'), false);
    assert.equal(cvcValid('abc'), false);
  });
});

/* ------------------------------------------------------------------ *
 * Stripe imzası (şəbəkəsiz)
 * ------------------------------------------------------------------ */
describe('stripe webhook imzası', () => {
  const secret = 'whsec_test_123';
  const payload = JSON.stringify({ type: 'checkout.session.completed', data: { object: { id: 'cs_test_1' } } });
  const timestamp = 1_700_000_000;

  it('düzgün imzanı qəbul edir', async () => {
    const { createHmac } = await import('node:crypto');
    const sig = createHmac('sha256', secret).update(`${timestamp}.${payload}`).digest('hex');
    const header = `t=${timestamp},v1=${sig}`;
    assert.equal(verifyStripeSignature(payload, header, secret, 300, timestamp * 1000), true);
  });

  it('yanlış imzanı rədd edir', async () => {
    const { createHmac } = await import('node:crypto');
    const sig = createHmac('sha256', 'başqa_açar').update(`${timestamp}.${payload}`).digest('hex');
    assert.equal(verifyStripeSignature(payload, `t=${timestamp},v1=${sig}`, secret, 300, timestamp * 1000), false);
  });

  it('köhnə timestamp-i rədd edir (replay qoruması)', async () => {
    const { createHmac } = await import('node:crypto');
    const sig = createHmac('sha256', secret).update(`${timestamp}.${payload}`).digest('hex');
    const old = timestamp * 1000 - 3600_000;
    assert.equal(verifyStripeSignature(payload, `t=${timestamp},v1=${sig}`, secret, 300, old), false);
  });

  it('boş secret ilə heç vaxt təsdiqləmir', () => {
    assert.equal(verifyStripeSignature(payload, 't=1,v1=abc', '', 300, 1000), false);
  });

  it('çoxsaylı v1 imzasından biri uyğun gələrsə keçir', async () => {
    const { createHmac } = await import('node:crypto');
    const sig = createHmac('sha256', secret).update(`${timestamp}.${payload}`).digest('hex');
    const header = `t=${timestamp},v1=səhv,v1=${sig}`;
    assert.equal(verifyStripeSignature(payload, header, secret, 300, timestamp * 1000), true);
  });

  it('Stripe açarı olmadan provayder söndürülmüş sayılır', () => {
    assert.equal(stripeEnabled(), false);
  });
});

/* ------------------------------------------------------------------ *
 * Onlayn ödəniş axını (uçdan-uca, simulyasiya)
 * ------------------------------------------------------------------ */
describe('onlayn ödəniş axını', () => {
  const customer = client();
  let vendorId;
  let productId;
  let orderCode;
  let token;

  before(async () => {
    const { data } = await api(client(), 'GET', '/api/vendors/sirvansah-kabab');
    vendorId = data.vendor.id;
    productId = data.vendor.menu.flatMap((s) => s.items).find((i) => i.price >= 900).id;
  });

  it('onlayn ödənişli sifariş yaradılır və ödəniş linki qaytarılır', async () => {
    const res = await api(customer, 'POST', '/api/orders', {
      vendorId, name: 'Ödəniş Testi', phone: '0505556677', payment: 'online',
      items: [{ productId, qty: 2 }],
    });
    assert.equal(res.status, 200, JSON.stringify(res.data));
    assert.equal(res.data.order.paymentStatus, 'unpaid');
    assert.ok(res.data.payment, 'ödəniş obyekti var');
    assert.equal(res.data.payment.provider, 'simulated');
    assert.equal(res.data.payment.status, 'requires_action');
    assert.match(res.data.payment.redirectUrl, /^\/odenis\.html\?token=/);
    orderCode = res.data.order.code;
    token = res.data.payment.token;
  });

  it('ödəniş səhifəsi tokenlə məlumat verir', async () => {
    const { status, data } = await api(client(), 'GET', `/api/payments/${token}`);
    assert.equal(status, 200);
    assert.equal(data.payment.order.code, orderCode);
    assert.ok(data.payment.order.pickupCode);
    assert.equal(data.payment.status, 'requires_action');
    assert.equal(data.orderCode, orderCode);
  });

  it('naməlum token 404 verir', async () => {
    const { status } = await api(client(), 'GET', '/api/payments/yoxdur-bu-token');
    assert.equal(status, 404);
  });

  it('yanlış kart nömrəsi rədd olunur', async () => {
    const { status, data } = await api(client(), 'POST', `/api/payments/${token}/pay`, {
      number: '4242424242424241', expiry: '12/30', cvc: '123',
    });
    assert.equal(status, 400);
    assert.match(data.error, /Luhn/);
  });

  it('keçmiş tarixli kart rədd olunur', async () => {
    const { status } = await api(client(), 'POST', `/api/payments/${token}/pay`, {
      number: '4242424242424242', expiry: '01/20', cvc: '123',
    });
    assert.equal(status, 400);
  });

  it('uğurlu ödəniş sifarişi «ödənilib» edir', async () => {
    const res = await api(client(), 'POST', `/api/payments/${token}/pay`, {
      number: '4242 4242 4242 4242', expiry: '12/30', cvc: '123', holder: 'TEST USER',
    });
    assert.equal(res.status, 200, JSON.stringify(res.data));
    assert.equal(res.data.payment.status, 'paid');
    assert.equal(res.data.payment.cardLast4, '4242');
    assert.equal(res.data.order.paymentStatus, 'paid');
    assert.equal(res.data.order.code, orderCode);
  });

  it('sifariş detalında ödəniş görünür və tarixçədə qeyd var', async () => {
    const { data } = await api(client(), 'GET', `/api/orders/${orderCode}`);
    assert.equal(data.order.payments.length, 1);
    assert.equal(data.order.payments[0].status, 'paid');
    assert.ok(data.order.events.some((e) => e.status === 'paid'));
  });

  it('eyni ödənişi iki dəfə etmək olmur', async () => {
    const { status, data } = await api(client(), 'POST', `/api/payments/${token}/pay`, {
      number: '4242424242424242', expiry: '12/30', cvc: '123',
    });
    assert.equal(status, 400);
    assert.match(data.error, /tamamlanıb/);
  });

  it('ödənilmiş sifariş ləğv ediləndə pul geri qaytarılır', async () => {
    const create = await api(customer, 'POST', '/api/orders', {
      vendorId, name: 'Refund Testi', phone: '0505556677', payment: 'online',
      items: [{ productId, qty: 2 }],
    });
    const pay = await api(customer, 'POST', `/api/payments/${create.data.payment.token}/pay`, {
      number: '5555555555554444', expiry: '11/29', cvc: '999',
    });
    assert.equal(pay.data.payment.status, 'paid');

    const cancel = await api(customer, 'POST', `/api/orders/${create.data.order.id}/cancel`, {
      code: create.data.order.code,
    });
    assert.equal(cancel.status, 200, JSON.stringify(cancel.data));
    assert.equal(cancel.data.order.paymentStatus, 'refunded');
    assert.equal(cancel.data.order.payments[0].status, 'refunded');
    assert.ok(cancel.data.order.events.some((e) => e.status === 'refunded'));
  });

  it('qonaq sifariş kodunu bilmədən ləğv edə bilmir (403)', async () => {
    const create = await api(customer, 'POST', '/api/orders', {
      vendorId, name: 'Qoruma Testi', phone: '0505556677', payment: 'cash',
      items: [{ productId, qty: 2 }],
    });
    const bad = await api(client(), 'POST', `/api/orders/${create.data.order.id}/cancel`);
    assert.equal(bad.status, 403);
  });

  it('başqa müştəri kodu bilsə də özgə sifarişi ləğv edə bilmir', async () => {
    const victimClient = client();
    await api(victimClient, 'POST', '/api/auth/register', {
      name: 'Qurban Müştəri', phone: '0709998811', password: 'test1234',
    });
    const victim = await api(victimClient, 'POST', '/api/orders', {
      vendorId, name: 'Qurban Müştəri', phone: '0709998811', payment: 'cash',
      items: [{ productId, qty: 2 }],
    });

    const other = client();
    await api(other, 'POST', '/api/auth/register', {
      name: 'Digər Ödəniş', phone: '0709998877', password: 'test1234',
    });
    const own = await api(other, 'POST', '/api/orders', {
      vendorId, name: 'Digər Ödəniş', phone: '0709998877', payment: 'cash',
      items: [{ productId, qty: 2 }],
    });

    const res = await api(other, 'POST', `/api/orders/${victim.data.order.id}/cancel`, {
      code: victim.data.order.code,
    });
    assert.equal(res.status, 403, 'qeydiyyatlı müştərinin sifarişini kodla ləğv etmək olmaz');

    const ownCancel = await api(other, 'POST', `/api/orders/${own.data.order.id}/cancel`);
    assert.equal(ownCancel.status, 200, 'sahibi öz sifarişini kodsuz ləğv edir');
  });

  it('rədd edilən test kartı ödənişi uğursuz edir', async () => {
    const create = await api(customer, 'POST', '/api/orders', {
      vendorId, name: 'Rədd Testi', phone: '0505556677', payment: 'online',
      items: [{ productId, qty: 2 }],
    });
    const res = await api(customer, 'POST', `/api/payments/${create.data.payment.token}/pay`, {
      number: '4000000000000002', expiry: '12/30', cvc: '123',
    });
    assert.equal(res.status, 402);
    const check = await api(client(), 'GET', `/api/payments/${create.data.payment.token}`);
    assert.equal(check.data.payment.status, 'failed');
    assert.match(check.data.payment.error, /rədd/i);
  });

  it('ödənişdən imtina edilə bilər', async () => {
    const create = await api(customer, 'POST', '/api/orders', {
      vendorId, name: 'İmtina Testi', phone: '0505556677', payment: 'online',
      items: [{ productId, qty: 2 }],
    });
    const res = await api(client(), 'POST', `/api/payments/${create.data.payment.token}/decline`, { reason: 'test' });
    assert.equal(res.status, 200);
    assert.equal(res.data.payment.status, 'failed');
  });
});

/* ------------------------------------------------------------------ *
 * Kassada ödəniş + hesabatlar
 * ------------------------------------------------------------------ */
describe('kassada ödəniş və ödəniş hesabatları', () => {
  const vendor = client();
  const admin = client();
  let vendorId;
  let productId;
  let orderId;

  before(async () => {
    await api(vendor, 'POST', '/api/auth/login', { phone: '0501110001', password: 'vendor123' });
    await api(admin, 'POST', '/api/auth/login', { phone: '0500000000', password: 'admin123' });
    const { data } = await api(client(), 'GET', '/api/vendors/sirvansah-kabab');
    vendorId = data.vendor.id;
    productId = data.vendor.menu.flatMap((s) => s.items).find((i) => i.price >= 900).id;
  });

  it('nağd sifariş «ödənilməyib» başlayır', async () => {
    const res = await api(client(), 'POST', '/api/orders', {
      vendorId, name: 'Nağd Müştəri', phone: '0502223344', payment: 'cash', items: [{ productId, qty: 2 }],
    });
    assert.equal(res.data.order.paymentStatus, 'unpaid');
    assert.equal(res.data.payment, null, 'onlayn ödəniş linki yaradılmır');
    orderId = res.data.order.id;
  });

  it('satıcı kassada ödənişi qeydə alır', async () => {
    const res = await api(vendor, 'POST', `/api/vendor/orders/${orderId}/collect`, { method: 'cash' });
    assert.equal(res.status, 200, JSON.stringify(res.data));
    assert.equal(res.data.order.paymentStatus, 'paid');
    assert.equal(res.data.order.payments[0].provider, 'counter');
    assert.equal(res.data.order.payments[0].method, 'cash');
  });

  it('eyni sifariş üçün ödəniş təkrar qeydə alınmır', async () => {
    const res = await api(vendor, 'POST', `/api/vendor/orders/${orderId}/collect`, { method: 'cash' });
    assert.equal(res.status, 400);
    assert.match(res.data.error, /artıq ödənilib/);
  });

  it('başqa satıcı bu sifarişin ödənişini qeydə ala bilmir', async () => {
    const other = client();
    await api(other, 'POST', '/api/auth/login', { phone: '0501110002', password: 'vendor123' });
    const res = await api(other, 'POST', `/api/vendor/orders/${orderId}/collect`, { method: 'cash' });
    assert.equal(res.status, 404);
  });

  it('satıcı statistikasında ödəniş bölgüsü var', async () => {
    const { data } = await api(vendor, 'GET', '/api/vendor/stats');
    assert.ok(data.payments.todayPaid > 0);
    assert.ok(data.payments.counter > 0);
  });

  it('admin ödəniş siyahısını görür', async () => {
    const { status, data } = await api(admin, 'GET', '/api/admin/payments');
    assert.equal(status, 200);
    assert.ok(data.payments.length >= 5);
    assert.ok(data.totals.paid > 0);
    assert.ok(['simulated', 'counter'].includes(data.payments[0].provider));
    assert.ok(data.payments[0].orderCode);
  });

  it('admin ödənişi statusa görə filtrləyir', async () => {
    const { data } = await api(admin, 'GET', '/api/admin/payments?status=refunded');
    assert.ok(data.payments.every((p) => p.status === 'refunded'));
  });

  it('admin statistikasında ödəniş göstəriciləri var', async () => {
    const { data } = await api(admin, 'GET', '/api/admin/stats');
    assert.ok(data.totals.counterPaidToday > 0);
    assert.ok(data.totals.refundedTotal > 0);
    assert.equal(data.totals.stripeActive, false);
    assert.ok(Array.isArray(data.byPaymentStatus));
  });

  it('müştəri admin ödəniş endpointinə girə bilmir', async () => {
    const c = client();
    await api(c, 'POST', '/api/auth/login', { phone: '0501234567', password: 'customer123' });
    const { status } = await api(c, 'GET', '/api/admin/payments');
    assert.equal(status, 403);
  });

  it('webhook imzasız (secret yoxdursa) qəbul olunur, naməlum hadisə təsir etmir', async () => {
    const res = await api(client(), 'POST', '/api/payments/stripe/webhook', {
      type: 'customer.created', data: { object: {} },
    });
    assert.equal(res.status, 200);
    assert.equal(res.data.received, true);
  });
});
