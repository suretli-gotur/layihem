/**
 * Götür — Mərhələ 2: real vaxt (SSE) və PWA testləri.
 * SSE real HTTP axını ilə yoxlanılır (Node-un fetch-i stream dəstəkləyir).
 */
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { after, before, describe, it } from 'node:test';

const workDir = mkdtempSync(join(tmpdir(), 'gotur-live-'));
process.env.GOTUR_DB = join(workDir, 'live.db');
process.env.GOTUR_LOG = '0';

const { createServer } = await import('../server/index.js');
const { closeDb } = await import('../server/db.js');
const { clientCount } = await import('../server/events.js');

let server;
let base;

function client() {
  let cookie = '';
  return {
    get cookie() { return cookie; },
    async call(method, path, body) {
      const res = await fetch(base + path, {
        method,
        headers: {
          ...(body ? { 'content-type': 'application/json' } : {}),
          ...(cookie ? { cookie } : {}),
        },
        body: body ? JSON.stringify(body) : undefined,
      });
      for (const c of res.headers.getSetCookie?.() ?? []) {
        const pair = c.split(';')[0];
        if (pair.includes('gotur_session=')) cookie = pair;
      }
      const text = await res.text();
      return { status: res.status, data: text ? JSON.parse(text) : null };
    },
  };
}
const api = (c, m, p, b) => c.call(m, p, b);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** SSE axınını oxuyan kiçik müştəri */
async function openStream(path, { cookie } = {}) {
  const controller = new AbortController();
  const res = await fetch(base + path, {
    headers: { accept: 'text/event-stream', ...(cookie ? { cookie } : {}) },
    signal: controller.signal,
  });
  const events = [];
  if (!res.ok || !res.body) {
    return { res, events, close: () => controller.abort(), waitFor: async () => null, next: async () => null };
  }

  const decoder = new TextDecoder();
  let buffer = '';

  const pump = (async () => {
    try {
      for await (const chunk of res.body) {
        buffer += decoder.decode(chunk, { stream: true });
        let index;
        while ((index = buffer.indexOf('\n\n')) >= 0) {
          const raw = buffer.slice(0, index);
          buffer = buffer.slice(index + 2);
          if (raw.startsWith(':')) continue; // ping şərhi
          const evLine = raw.split('\n').find((l) => l.startsWith('event: '));
          const dataLine = raw.split('\n').find((l) => l.startsWith('data: '));
          events.push({
            type: evLine ? evLine.slice(7).trim() : 'message',
            data: dataLine ? JSON.parse(dataLine.slice(6)) : null,
          });
        }
      }
    } catch { /* abort edildi */ }
  })();
  void pump;

  const waitFor = async (predicate, timeout = 4000) => {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const found = events.find(predicate);
      if (found) return found;
      await sleep(50);
    }
    return null;
  };

  return {
    res,
    events,
    close: () => controller.abort(),
    next: (type, timeout) => waitFor((e) => e.type === type, timeout),
    waitFor,
  };
}

before(async () => {
  server = createServer();
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  await new Promise((r) => server.close(r));
  closeDb();
  try { rmSync(workDir, { recursive: true, force: true }); } catch { /* Windows kilidi */ }
});

/* ------------------------------------------------------------------ *
 * SSE
 * ------------------------------------------------------------------ */
describe('real vaxt (SSE)', () => {
  let vendorA;
  let vendorB;
  let customer;
  let vendorIdA;
  let vendorIdB;
  let productA;
  let productB;

  before(async () => {
    vendorA = client();
    vendorB = client();
    customer = client();
    await api(vendorA, 'POST', '/api/auth/login', { phone: '0501110001', password: 'vendor123' });
    await api(vendorB, 'POST', '/api/auth/login', { phone: '0501110002', password: 'vendor123' });
    const a = (await api(client(), 'GET', '/api/vendors/sirvansah-kabab')).data.vendor;
    const b = (await api(client(), 'GET', '/api/vendors/pizza-mizza')).data.vendor;
    vendorIdA = a.id;
    vendorIdB = b.id;
    productA = a.menu.flatMap((s) => s.items).find((i) => i.price >= 900).id;
    productB = b.menu.flatMap((s) => s.items).find((i) => i.price >= 900).id;
  });

  it('satıcı axını giriş tələb edir (401)', async () => {
    const res = await fetch(`${base}/api/events?scope=vendor`);
    assert.equal(res.status, 401);
  });

  it('admin axını yalnız admin üçün açıqdır (403)', async () => {
    const res = await fetch(`${base}/api/events?scope=admin`, { headers: { cookie: customer.cookie } });
    assert.equal(res.status, 403);
  });

  it('sifariş kodları olmadan müştəri axını 400 verir', async () => {
    const res = await fetch(`${base}/api/events?scope=orders`);
    assert.equal(res.status, 400);
  });

  it('satıcı öz mağazasına gələn yeni sifarişi dərhal görür, digər satıcı görmür', async () => {
    const streamA = await openStream('/api/events?scope=vendor', { cookie: vendorA.cookie });
    const streamB = await openStream('/api/events?scope=vendor', { cookie: vendorB.cookie });
    assert.equal(streamA.res.status, 200);
    assert.equal(streamA.res.headers.get('content-type'), 'text/event-stream; charset=utf-8');
    await streamA.next('ready');
    await streamB.next('ready');

    const order = await api(customer, 'POST', '/api/orders', {
      vendorId: vendorIdA, name: 'SSE Müştəri', phone: '0503334455', payment: 'cash',
      items: [{ productId: productA, qty: 2 }],
    });
    assert.equal(order.status, 200);
    const code = order.data.order.code;

    const eventA = await streamA.next('order.created');
    assert.ok(eventA, 'A satıcısı hadisəni aldı');
    assert.equal(eventA.data.order.code, code);
    assert.equal(eventA.data.order.customerName, 'SSE Müştəri');
    assert.ok(Array.isArray(eventA.data.order.items) && eventA.data.order.items.length === 1);

    await sleep(300);
    assert.equal(streamB.events.filter((e) => e.type === 'order.created').length, 0, 'B satıcısı hadisəni almamalıdır');

    streamA.close();
    streamB.close();
  });

  it('müştəri yalnız öz sifarişinin statusunu alır', async () => {
    const order = await api(customer, 'POST', '/api/orders', {
      vendorId: vendorIdA, name: 'İzləmə Testi', phone: '0503334455', payment: 'cash',
      items: [{ productId: productA, qty: 2 }],
    });
    const code = order.data.order.code;

    const stream = await openStream(`/api/events?orders=${code}`);
    await stream.next('ready');

    await api(vendorA, 'POST', `/api/vendor/orders/${order.data.order.id}/status`, { status: 'accepted' });
    const event = await stream.next('order.status');
    assert.ok(event, 'status hadisəsi gəldi');
    assert.equal(event.data.status, 'accepted');
    assert.equal(event.data.code, code);

    // Başqa sifariş üzrə hadisə bu axına düşməməlidir
    const other = await api(customer, 'POST', '/api/orders', {
      vendorId: vendorIdB, name: 'Digər', phone: '0503334455', payment: 'cash',
      items: [{ productId: productB, qty: 2 }],
    });
    await api(vendorB, 'POST', `/api/vendor/orders/${other.data.order.id}/status`, { status: 'accepted' });
    await sleep(300);
    const codes = stream.events.filter((e) => e.type === 'order.status').map((e) => e.data.code);
    assert.deepEqual(codes, [code], 'yalnız izlənilən sifariş gəldi');

    stream.close();
  });

  it('ödəniş hadisəsi həm satıcıya, həm müştəriyə gedir', async () => {
    const order = await api(customer, 'POST', '/api/orders', {
      vendorId: vendorIdA, name: 'Ödəniş Axını', phone: '0503334455', payment: 'online',
      items: [{ productId: productA, qty: 2 }],
    });
    const code = order.data.order.code;
    const token = order.data.payment.token;

    const vendorStream = await openStream('/api/events?scope=vendor', { cookie: vendorA.cookie });
    const customerStream = await openStream(`/api/events?orders=${code}`);
    await vendorStream.next('ready');
    await customerStream.next('ready');

    await api(customer, 'POST', `/api/payments/${token}/pay`, {
      number: '4242424242424242', expiry: '12/30', cvc: '123',
    });

    const forVendor = await vendorStream.next('order.payment');
    const forCustomer = await customerStream.next('order.payment');
    assert.ok(forVendor && forCustomer, 'hər iki axın ödəniş hadisəsini aldı');
    assert.equal(forVendor.data.paymentStatus, 'paid');
    assert.equal(forCustomer.data.code, code);

    vendorStream.close();
    customerStream.close();
  });

  it('admin bütün hadisələri alır və statistika endpointi işləyir', async () => {
    const admin = client();
    await api(admin, 'POST', '/api/auth/login', { phone: '0500000000', password: 'admin123' });
    const stream = await openStream('/api/events?scope=admin', { cookie: admin.cookie });
    await stream.next('ready');

    await api(customer, 'POST', '/api/orders', {
      vendorId: vendorIdB, name: 'Admin Axını', phone: '0503334455', payment: 'cash',
      items: [{ productId: productB, qty: 2 }],
    });
    const event = await stream.next('order.created');
    assert.ok(event, 'admin hadisəni aldı');

    const stats = await api(admin, 'GET', '/api/events/stats');
    assert.equal(stats.status, 200);
    assert.ok(stats.data.clients >= 1);
    stream.close();
    await sleep(200);
    assert.ok(clientCount() >= 0);
  });

  it('sifariş ləğv edildikdə satıcı axınına status hadisəsi gedir', async () => {
    const order = await api(customer, 'POST', '/api/orders', {
      vendorId: vendorIdA, name: 'Ləğv Axını', phone: '0503334455', payment: 'cash',
      items: [{ productId: productA, qty: 2 }],
    });
    const stream = await openStream('/api/events?scope=vendor', { cookie: vendorA.cookie });
    await stream.next('ready');

    await api(customer, 'POST', `/api/orders/${order.data.order.id}/cancel`, { code: order.data.order.code });
    const event = await stream.waitFor((e) => e.type === 'order.status' && e.data.status === 'cancelled');
    assert.ok(event, 'ləğv hadisəsi gəldi');
    stream.close();
  });
});

/* ------------------------------------------------------------------ *
 * PWA
 * ------------------------------------------------------------------ */
describe('PWA faylları', () => {
  it('manifest düzgün JSON və tələb olunan sahələrlə verilir', async () => {
    const res = await fetch(`${base}/manifest.webmanifest`);
    assert.equal(res.status, 200);
    assert.match(res.headers.get('content-type'), /application\/manifest\+json|application\/json/);
    const manifest = await res.json();
    assert.equal(manifest.name.includes('Götür'), true);
    assert.equal(manifest.short_name, 'Götür');
    assert.equal(manifest.display, 'standalone');
    assert.equal(manifest.start_url.startsWith('/'), true);
    assert.equal(manifest.scope, '/');
    assert.ok(manifest.icons.length >= 3);
    assert.ok(manifest.icons.some((i) => i.sizes === '512x512' && i.purpose === 'any'));
    assert.ok(manifest.icons.some((i) => i.purpose === 'maskable'));
    assert.ok(manifest.shortcuts.length >= 2);
  });

  it('bütün manifest ikonları mövcuddur', async () => {
    const manifest = await (await fetch(`${base}/manifest.webmanifest`)).json();
    for (const icon of manifest.icons) {
      const res = await fetch(base + icon.src);
      assert.equal(res.status, 200, icon.src);
      assert.match(res.headers.get('content-type'), /image\//, icon.src);
    }
  });

  it('service worker kökdə və düzgün tiplə verilir', async () => {
    const res = await fetch(`${base}/sw.js`);
    assert.equal(res.status, 200);
    assert.match(res.headers.get('content-type'), /javascript/);
    const text = await res.text();
    assert.match(text, /addEventListener\('install'/);
    assert.match(text, /addEventListener\('fetch'/);
    assert.match(text, /notificationclick/);
  });

  it('oflayn səhifəsi mövcuddur', async () => {
    const res = await fetch(`${base}/offline.html`);
    assert.equal(res.status, 200);
    const html = await res.text();
    assert.match(html, /oflayn|Oflayn/i);
  });

  it('ana səhifə manifest və apple-touch-icon elan edir', async () => {
    const html = await (await fetch(`${base}/`)).text();
    assert.match(html, /rel="manifest" href="\/manifest\.webmanifest"/);
    assert.match(html, /apple-touch-icon/);
    assert.match(html, /id="offline-bar"/);
  });

  it('hər panel öz manifestini elan edir (ayrı tətbiq kimi quraşdırılsın)', async () => {
    const expected = {
      '/': '/manifest.webmanifest',
      '/satis.html': '/manifest-satis.webmanifest',
      '/admin.html': '/manifest-admin.webmanifest',
    };
    for (const [page, manifest] of Object.entries(expected)) {
      const html = await (await fetch(base + page)).text();
      assert.match(html, new RegExp(`rel="manifest" href="${manifest.replace(/\./g, '\\.')}"`), page);
    }
  });

  it('hər manifest düzgün start_url və ikon elan edir', async () => {
    const expected = {
      '/manifest.webmanifest': '/',
      '/manifest-satis.webmanifest': '/satis.html',
      '/manifest-admin.webmanifest': '/admin.html',
    };
    for (const [path, startUrl] of Object.entries(expected)) {
      const res = await fetch(base + path);
      assert.equal(res.status, 200, path);
      const manifest = await res.json();
      assert.ok(manifest.start_url.startsWith(startUrl), `${path}: ${manifest.start_url}`);
      assert.equal(manifest.display, 'standalone', path);
      assert.ok(manifest.icons.some((i) => i.sizes === '512x512' && i.purpose === 'maskable'), path);
      assert.ok(manifest.name.includes('Götür'), path);
    }
  });

  it('ikon faylları həqiqi PNG-dir (sehrli baytlar)', async () => {
    const buf = Buffer.from(await (await fetch(`${base}/assets/icons/icon-192.png`)).arrayBuffer());
    assert.equal(buf.subarray(0, 8).toString('hex'), '89504e470d0a1a0a');
  });
});
