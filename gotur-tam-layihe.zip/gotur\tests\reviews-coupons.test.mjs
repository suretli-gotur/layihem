/**
 * Götür — Mərhələ 3: rəy/reytinq və kupon testləri.
 */
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { after, before, describe, it } from 'node:test';

const workDir = mkdtempSync(join(tmpdir(), 'gotur-rev-'));
process.env.GOTUR_DB = join(workDir, 'rev.db');
process.env.GOTUR_LOG = '0';

const { createServer } = await import('../server/index.js');
const { closeDb, q } = await import('../server/db.js');
const { discountFor, normalizeCode } = await import('../server/coupons.js');

let server;
let base;

function client() {
  let cookie = '';
  return {
    async call(method, path, body) {
      const res = await fetch(base + path, {
        method,
        headers: {
          ...(body ? { 'content-type': 'application/json' } : {}),
          ...(cookie ? { cookie } : {}),
        },
        body: body ? JSON.stringify(body) : undefined,
      });
      for (const c of res.headers.getSetCookie?.() ?? []) {
        const pair = c.split(';')[0];
        if (pair.includes('gotur_session=')) cookie = pair;
      }
      const text = await res.text();
      return { status: res.status, data: text ? JSON.parse(text) : null };
    },
  };
}
const api = (c, m, p, b) => c.call(m, p, b);

before(async () => {
  server = createServer();
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  await new Promise((r) => server.close(r));
  closeDb();
  try { rmSync(workDir, { recursive: true, force: true }); } catch { /* Windows kilidi */ }
});

/* ------------------------------------------------------------------ *
 * Kupon hesablamaları (təmiz funksiyalar)
 * ------------------------------------------------------------------ */
describe('kupon hesablamaları', () => {
  it('faiz endirimini hesablayır', () => {
    assert.equal(discountFor({ kind: 'percent', value: 10, max_discount: 0 }, 10_000), 1000);
    assert.equal(discountFor({ kind: 'percent', value: 15, max_discount: 0 }, 3333), 500);
  });

  it('maksimum endirim həddini tətbiq edir', () => {
    assert.equal(discountFor({ kind: 'percent', value: 50, max_discount: 800 }, 10_000), 800);
  });

  it('sabit endirimi tətbiq edir və səbətdən çox olmur', () => {
    assert.equal(discountFor({ kind: 'fixed', value: 500, max_discount: 0 }, 3000), 500);
    assert.equal(discountFor({ kind: 'fixed', value: 5000, max_discount: 0 }, 3000), 3000);
  });

  it('kod normalizasiyası yalnız icazəli simvolları saxlayır', () => {
    assert.equal(normalizeCode(' gotur10 '), 'GOTUR10');
    assert.equal(normalizeCode('kabab-15!'), 'KABAB-15');
  });
});

/* ------------------------------------------------------------------ *
 * Rəylər
 * ------------------------------------------------------------------ */
describe('rəylər və reytinq', () => {
  const customer = client();
  const vendor = client();
  const admin = client();
  let vendorId;
  let productId;
  let orderId;
  let orderCode;

  before(async () => {
    await api(customer, 'POST', '/api/auth/login', { phone: '0501234567', password: 'customer123' });
    await api(vendor, 'POST', '/api/auth/login', { phone: '0501110001', password: 'vendor123' });
    await api(admin, 'POST', '/api/auth/login', { phone: '0500000000', password: 'admin123' });
    const { data } = await api(client(), 'GET', '/api/vendors/sirvansah-kabab');
    vendorId = data.vendor.id;
    productId = data.vendor.menu.flatMap((s) => s.items).find((i) => i.price >= 900).id;
  });

  it('mağaza səhifəsi demo rəyləri və xülasəni qaytarır', async () => {
    const { data } = await api(client(), 'GET', '/api/vendors/sirvansah-kabab');
    assert.ok(data.reviews.length >= 1);
    assert.ok(data.reviewSummary.reviewCount >= 1);
    assert.ok(data.reviewSummary.distribution[5] >= 1);
    assert.ok(data.coupons.length >= 1, 'aktiv kampaniyalar göstərilir');
  });

  it('götürülməmiş sifarişə rəy yazılmır', async () => {
    const order = await api(customer, 'POST', '/api/orders', {
      vendorId, name: 'Rəy Testi', phone: '0501234567', payment: 'cash', items: [{ productId, qty: 2 }],
    });
    orderId = order.data.order.id;
    orderCode = order.data.order.code;
    const res = await api(customer, 'POST', `/api/orders/${orderId}/review`, { rating: 5 });
    assert.equal(res.status, 400);
    assert.match(res.data.error, /götürülmüş/);
  });

  it('götürüldükdən sonra rəy qəbul olunur və reytinq yenilənir', async () => {
    for (const status of ['accepted', 'preparing', 'ready', 'picked_up']) {
      await api(vendor, 'POST', `/api/vendor/orders/${orderId}/status`, { status });
    }
    const before = q.get('SELECT rating, rating_count FROM vendors WHERE id = ?', vendorId);

    const res = await api(customer, 'POST', `/api/orders/${orderId}/review`, {
      rating: 5, comment: 'Test rəyi: hər şey əla idi',
    });
    assert.equal(res.status, 200, JSON.stringify(res.data));
    assert.equal(res.data.review.rating, 5);
    assert.equal(res.data.review.comment, 'Test rəyi: hər şey əla idi');
    assert.equal(res.data.order.review.rating, 5, 'sifariş detalında rəy görünür');

    const after = q.get('SELECT rating, rating_count FROM vendors WHERE id = ?', vendorId);
    assert.equal(after.rating_count, before.rating_count + 1);
    assert.ok(after.rating >= before.rating, '5★ reytinqi aşağı salmır');
  });

  it('bir sifarişə ikinci rəy yazılmır', async () => {
    const res = await api(customer, 'POST', `/api/orders/${orderId}/review`, { rating: 3 });
    assert.equal(res.status, 400);
    assert.match(res.data.error, /artıq rəy/);
  });

  it('yanlış ulduz sayı rədd olunur', async () => {
    const other = await api(customer, 'POST', '/api/orders', {
      vendorId, name: 'Rəy Testi 2', phone: '0501234567', payment: 'cash', items: [{ productId, qty: 2 }],
    });
    for (const status of ['accepted', 'preparing', 'ready', 'picked_up']) {
      await api(vendor, 'POST', `/api/vendor/orders/${other.data.order.id}/status`, { status });
    }
    for (const rating of [0, 6, 2.5, 'beş']) {
      const res = await api(customer, 'POST', `/api/vendor/../orders/${other.data.order.id}/review`, { rating });
      assert.equal(res.status, 400, `rating=${rating}`);
    }
  });

  it('başqa müştəri özgə sifarişinə rəy yaza bilmir', async () => {
    const other = client();
    await api(other, 'POST', '/api/auth/login', { phone: '0557654321', password: 'customer123' });
    const res = await api(other, 'POST', `/api/orders/${orderId}/review`, { rating: 1, code: orderCode });
    assert.equal(res.status, 403);
  });

  it('satıcı rəyi görür və cavab yazır', async () => {
    const list = await api(vendor, 'GET', '/api/vendor/reviews');
    assert.equal(list.status, 200);
    const review = list.data.reviews.find((r) => r.orderId === orderId);
    assert.ok(review, 'rəy siyahıda var');

    const reply = await api(vendor, 'POST', `/api/vendor/reviews/${review.id}/reply`, {
      reply: 'Təşəkkür edirik, yenidən gözləyirik!',
    });
    assert.equal(reply.status, 200);
    assert.equal(reply.data.review.reply, 'Təşəkkür edirik, yenidən gözləyirik!');

    const publicList = await api(client(), 'GET', '/api/vendors/sirvansah-kabab/reviews');
    const publicReview = publicList.data.reviews.find((r) => r.id === review.id);
    assert.equal(publicReview.reply.length > 0, true, 'cavab müştəriyə görünür');
  });

  it('başqa satıcı bu rəyə cavab yaza bilmir', async () => {
    const other = client();
    await api(other, 'POST', '/api/auth/login', { phone: '0501110002', password: 'vendor123' });
    const list = await api(vendor, 'GET', '/api/vendor/reviews');
    const review = list.data.reviews[0];
    const res = await api(other, 'POST', `/api/vendor/reviews/${review.id}/reply`, { reply: 'yox' });
    assert.equal(res.status, 404);
  });

  it('admin rəyi gizlədir və reytinq yenidən hesablanır', async () => {
    const list = await api(admin, 'GET', '/api/admin/reviews');
    assert.ok(list.data.reviews.length >= 3);
    const target = list.data.reviews.find((r) => r.orderId === orderId);
    const beforeRating = q.get('SELECT rating_count FROM vendors WHERE id = ?', vendorId).rating_count;

    const hide = await api(admin, 'PATCH', `/api/admin/reviews/${target.id}`, { hidden: true });
    assert.equal(hide.status, 200);
    assert.equal(hide.data.review.hidden, true);
    const afterRating = q.get('SELECT rating_count FROM vendors WHERE id = ?', vendorId).rating_count;
    assert.equal(afterRating, beforeRating - 1, 'gizlədilən rəy reytinqdən çıxarılır');

    const publicList = await api(client(), 'GET', '/api/vendors/sirvansah-kabab/reviews');
    assert.ok(!publicList.data.reviews.some((r) => r.id === target.id), 'gizli rəy müştəriyə görünmür');

    await api(admin, 'PATCH', `/api/admin/reviews/${target.id}`, { hidden: false });
    const restored = q.get('SELECT rating_count FROM vendors WHERE id = ?', vendorId).rating_count;
    assert.equal(restored, beforeRating);
  });

  it('müştəri admin rəy endpointinə girə bilmir', async () => {
    const res = await api(customer, 'GET', '/api/admin/reviews');
    assert.equal(res.status, 403);
  });
});

/* ------------------------------------------------------------------ *
 * Kuponlar
 * ------------------------------------------------------------------ */
describe('kuponlar', () => {
  const customer = client();
  const vendor = client();
  const admin = client();
  let vendorId;
  let productId;
  let platformCouponId;

  before(async () => {
    await api(customer, 'POST', '/api/auth/login', { phone: '0501234567', password: 'customer123' });
    await api(vendor, 'POST', '/api/auth/login', { phone: '0501110001', password: 'vendor123' });
    await api(admin, 'POST', '/api/auth/login', { phone: '0500000000', password: 'admin123' });
    const { data } = await api(client(), 'GET', '/api/vendors/sirvansah-kabab');
    vendorId = data.vendor.id;
    productId = data.vendor.menu.flatMap((s) => s.items).find((i) => i.price >= 900).id;
  });

  it('demo kuponlar seed olunub', async () => {
    const { data } = await api(admin, 'GET', '/api/admin/coupons');
    assert.ok(data.coupons.length >= 5);
    assert.ok(data.coupons.some((c) => c.scope === 'platform' && c.code === 'GOTUR10'));
    assert.ok(data.coupons.some((c) => c.scope === 'vendor' && c.code === 'KABAB15'));
  });

  it('kupon yoxlaması endirimi qaytarır (maksimum hədd nəzərə alınmaqla)', async () => {
    const res = await api(customer, 'POST', '/api/coupons/validate', {
      code: 'gotur10', vendorId, subtotal: 10_000,
    });
    assert.equal(res.status, 200);
    assert.equal(res.data.valid, true);
    // GOTUR10: 10%, maksimum 3 ₼ → 100 ₼ səbətdə 10 ₼ yox, 3 ₼ endirim
    assert.equal(res.data.discount, 300);
    assert.equal(res.data.code, 'GOTUR10');
    assert.equal(res.data.total, 9700);

    // Kiçik səbətdə faiz tam tətbiq olunur (maksimuma çatmır)
    const small = await api(customer, 'POST', '/api/coupons/validate', {
      code: 'GOTUR10', vendorId, subtotal: 2000,
    });
    assert.equal(small.data.discount, 200);
    assert.equal(small.data.total, 1800);
  });

  it('minimum səbət və mağaza uyğunluğu yoxlanılır', async () => {
    const small = await api(customer, 'POST', '/api/coupons/validate', {
      code: 'GOTUR10', vendorId, subtotal: 100,
    });
    assert.equal(small.data.valid, false);
    assert.match(small.data.error, /minimum/i);

    const wrongVendor = await api(customer, 'POST', '/api/coupons/validate', {
      code: 'MARKET5', vendorId, subtotal: 10_000,
    });
    assert.equal(wrongVendor.data.valid, false);
    assert.match(wrongVendor.data.error, /mağaza/i);
  });

  it('naməlum kod üçün xəta qaytarır', async () => {
    const res = await api(customer, 'POST', '/api/coupons/validate', {
      code: 'YOXDUR99', vendorId, subtotal: 10_000,
    });
    assert.equal(res.data.valid, false);
    assert.match(res.data.error, /tapılmadı/);
  });

  it('kuponla sifariş verilir və endirim tətbiq olunur', async () => {
    const res = await api(customer, 'POST', '/api/orders', {
      vendorId, name: 'Kupon Testi', phone: '0501234567', payment: 'cash', coupon: 'GOTUR10',
      items: [{ productId, qty: 2 }],
    });
    assert.equal(res.status, 200, JSON.stringify(res.data));
    const order = res.data.order;
    assert.equal(order.couponCode, 'GOTUR10');
    assert.equal(order.subtotal, 1900);
    assert.equal(order.discount, 190, '10% → 190 qəpik');
    assert.equal(order.total, 1710);
    assert.ok(order.events.some((e) => e.status === 'discount'));

    const coupon = q.get("SELECT used_count FROM coupons WHERE code = 'GOTUR10'");
    assert.equal(coupon.used_count, 1, 'istifadə sayı artırıldı');
  });

  it('bir müştəri eyni kuponu limitdən çox istifadə edə bilmir', async () => {
    const res = await api(customer, 'POST', '/api/coupons/validate', {
      code: 'GOTUR10', vendorId, subtotal: 10_000,
    });
    assert.equal(res.data.valid, false);
    assert.match(res.data.error, /istifadə etmisiniz/);
  });

  it('sifariş ləğv edilərsə kupon limiti geri qaytarılır', async () => {
    const order = await api(customer, 'POST', '/api/orders', {
      vendorId, name: 'Ləğv Kupon', phone: '0501234567', payment: 'cash', coupon: 'KABAB15',
      items: [{ productId, qty: 4 }],
    });
    if (order.status !== 200) {
      // KABAB15 minimum səbəbi ilə keçməyibsə, bahalı səbətlə yoxla
      const bigger = await api(customer, 'POST', '/api/orders', {
        vendorId, name: 'Ləğv Kupon', phone: '0501234567', payment: 'cash', coupon: 'KABAB15',
        items: [{ productId, qty: 6 }],
      });
      assert.equal(bigger.status, 200, JSON.stringify(bigger.data));
      const before = q.get("SELECT used_count FROM coupons WHERE code = 'KABAB15'").used_count;
      await api(customer, 'POST', `/api/orders/${bigger.data.order.id}/cancel`, { code: bigger.data.order.code });
      const after = q.get("SELECT used_count FROM coupons WHERE code = 'KABAB15'").used_count;
      assert.equal(after, before - 1);
      return;
    }
    const before = q.get("SELECT used_count FROM coupons WHERE code = 'KABAB15'").used_count;
    await api(customer, 'POST', `/api/orders/${order.data.order.id}/cancel`, { code: order.data.order.code });
    const after = q.get("SELECT used_count FROM coupons WHERE code = 'KABAB15'").used_count;
    assert.equal(after, before - 1);
  });

  it('yanlış kupon kodu ilə sifariş qəbul edilmir', async () => {
    const res = await api(customer, 'POST', '/api/orders', {
      vendorId, name: 'Yanlış Kupon', phone: '0501234567', payment: 'cash', coupon: 'YOXDUR',
      items: [{ productId, qty: 2 }],
    });
    assert.equal(res.status, 400);
    assert.match(res.data.error, /tapılmadı/);
  });

  it('admin platforma kuponu yaradır və düzəliş edir', async () => {
    const created = await api(admin, 'POST', '/api/admin/coupons', {
      code: 'test20', kind: 'percent', value: 20, minOrder: 5, maxDiscount: 4,
      usageLimit: 10, perUserLimit: 1, description: 'Test kampaniyası',
    });
    assert.equal(created.status, 200, JSON.stringify(created.data));
    assert.equal(created.data.coupon.code, 'TEST20');
    assert.equal(created.data.coupon.minOrder, 500);
    assert.equal(created.data.coupon.maxDiscount, 400);
    platformCouponId = created.data.coupon.id;

    const patched = await api(admin, 'PATCH', `/api/admin/coupons/${platformCouponId}`, {
      code: 'TEST20', kind: 'percent', value: 25, active: false,
    });
    assert.equal(patched.status, 200);
    assert.equal(patched.data.coupon.value, 25);
    assert.equal(patched.data.coupon.active, false);
  });

  it('eyni kodla ikinci kupon yaradılmır', async () => {
    const res = await api(admin, 'POST', '/api/admin/coupons', { code: 'TEST20', kind: 'percent', value: 5 });
    assert.equal(res.status, 400);
    assert.match(res.data.error, /artıq mövcuddur/);
  });

  it('yanlış faiz aralığı rədd olunur', async () => {
    for (const value of [0, 91, -5]) {
      const res = await api(admin, 'POST', '/api/admin/coupons', { code: `BAD${value}`, kind: 'percent', value });
      assert.equal(res.status, 400, `value=${value}`);
    }
  });

  it('satıcı yalnız öz mağazası üçün kupon yaradır', async () => {
    const created = await api(vendor, 'POST', '/api/vendor/coupons', {
      code: 'kababtest', kind: 'fixed', value: 2, minOrder: 10, perUserLimit: 1,
      description: 'Satıcı kampaniyası',
    });
    assert.equal(created.status, 200, JSON.stringify(created.data));
    assert.equal(created.data.coupon.vendorId, vendorId, 'kupon mağazaya bağlanır');

    const list = await api(vendor, 'GET', '/api/vendor/coupons');
    assert.ok(list.data.coupons.every((c) => c.vendorId === vendorId), 'satıcı yalnız öz kuponlarını görür');

    const del = await api(vendor, 'DELETE', `/api/vendor/coupons/${created.data.coupon.id}`);
    assert.equal(del.status, 200);
  });

  it('satıcı platforma kuponunu düzəldə bilmir', async () => {
    const res = await api(vendor, 'PATCH', `/api/vendor/coupons/${platformCouponId}`, { value: 90 });
    assert.equal(res.status, 404);
  });

  it('admin statistikasında kupon göstəriciləri var', async () => {
    const { data } = await api(admin, 'GET', '/api/admin/stats');
    assert.ok(data.totals.activeCoupons >= 4);
    assert.ok(data.totals.couponOrders >= 1);
    assert.ok(data.totals.couponDiscount >= 100);
    assert.ok(data.totals.reviews >= 3);
  });
});
