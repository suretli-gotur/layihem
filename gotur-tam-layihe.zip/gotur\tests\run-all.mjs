/**
 * Bütün testləri BİR prosesdə işə salır.
 * (Windows-da `node --test` alt proseslər üçün boru açmağa çalışır və sandbox bunu bloklayır.)
 * İstifadə: npm test
 */
await import('./api.test.mjs');
await import('./payments.test.mjs');
await import('./realtime.test.mjs');
await import('./reviews-coupons.test.mjs');
await import('./settlements.test.mjs');
await import('./admin-manage.test.mjs');
await import('./geo.test.mjs');
await import('./escape.test.mjs');
await import('./mobile.test.mjs');
await import('./i18n.test.mjs');
await import('./ui-helpers.test.mjs');
await import('./frontend-load.test.mjs');
