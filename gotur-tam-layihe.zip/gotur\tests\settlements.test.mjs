/**
 * Götür — Mərhələ 5: komissiya və hesablaşma testləri.
 */
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { after, before, describe, it } from 'node:test';

const workDir = mkdtempSync(join(tmpdir(), 'gotur-set-'));
process.env.GOTUR_DB = join(workDir, 'set.db');
process.env.GOTUR_LOG = '0';

const { createServer } = await import('../server/index.js');
const { closeDb, q } = await import('../server/db.js');
const { computeCommission } = await import('../server/settlements.js');

let server;
let base;

function client() {
  let cookie = '';
  return {
    async call(method, path, body) {
      const res = await fetch(base + path, {
        method,
        headers: {
          ...(body ? { 'content-type': 'application/json' } : {}),
          ...(cookie ? { cookie } : {}),
        },
        body: body ? JSON.stringify(body) : undefined,
      });
      for (const c of res.headers.getSetCookie?.() ?? []) {
        const pair = c.split(';')[0];
        if (pair.includes('gotur_session=')) cookie = pair;
      }
      const text = await res.text();
      return { status: res.status, data: text ? JSON.parse(text) : null };
    },
  };
}
const api = (c, m, p, b) => c.call(m, p, b);

const vendor = client();
const admin = client();
const customer = client();
let vendorId;
let productId;

before(async () => {
  server = createServer();
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
  await api(vendor, 'POST', '/api/auth/login', { phone: '0501110001', password: 'vendor123' });
  await api(admin, 'POST', '/api/auth/login', { phone: '0500000000', password: 'admin123' });
  await api(customer, 'POST', '/api/auth/login', { phone: '0501234567', password: 'customer123' });
  const { data } = await api(client(), 'GET', '/api/vendors/sirvansah-kabab');
  vendorId = data.vendor.id;
  productId = data.vendor.menu.flatMap((s) => s.items).find((i) => i.price >= 900).id;
});

after(async () => {
  await new Promise((r) => server.close(r));
  closeDb();
  try { rmSync(workDir, { recursive: true, force: true }); } catch { /* Windows kilidi */ }
});

/* ------------------------------------------------------------------ *
 * Hesablama
 * ------------------------------------------------------------------ */
describe('komissiya hesablanması', () => {
  it('faizə görə komissiya hesablayır', () => {
    assert.equal(computeCommission(10_000, 12), 1200);
    assert.equal(computeCommission(1900, 12), 228);
    assert.equal(computeCommission(333, 12), 40);
    assert.equal(computeCommission(1000, 0), 0);
  });

  it('yeni sifarişdə komissiya və mağaza payı yazılır', async () => {
    const res = await api(customer, 'POST', '/api/orders', {
      vendorId, name: 'Komissiya Testi', phone: '0501234567', payment: 'cash',
      items: [{ productId, qty: 2 }],
    });
    assert.equal(res.status, 200, JSON.stringify(res.data));
    const order = res.data.order;
    assert.equal(order.subtotal, 1900);
    assert.equal(order.commission, 228, '12% → 228 qəpik');
    assert.equal(order.vendorPayout, 1672);

    const row = q.get('SELECT commission, vendor_payout FROM orders WHERE id = ?', order.id);
    assert.equal(row.commission, 228);
    assert.equal(row.vendor_payout, 1672);
  });

  it('kupon endirimi platformanın payına düşür, komissiya ara cəmdən hesablanır', async () => {
    const res = await api(customer, 'POST', '/api/orders', {
      vendorId, name: 'Kupon + Komissiya', phone: '0501234567', payment: 'online', coupon: 'KABAB15',
      items: [{ productId, qty: 2 }],
    });
    if (res.status !== 200) return; // kupon limiti bitibsə keç
    const order = res.data.order;
    assert.equal(order.discount, Math.round(order.subtotal * 0.15));
    assert.equal(order.commission, Math.round(order.subtotal * 0.12), 'komissiya endirimdən əvvəl hesablanır');
    assert.equal(order.vendorPayout, order.total - order.commission);
  });
});

/* ------------------------------------------------------------------ *
 * Mağaza hesabatı
 * ------------------------------------------------------------------ */
describe('mağaza hesablaşma hesabatı', () => {
  it('satıcı öz hesabatını görür', async () => {
    const { status, data } = await api(vendor, 'GET', '/api/vendor/settlement');
    assert.equal(status, 200);
    assert.equal(data.vendorId, vendorId);
    assert.ok(data.totals.orders >= 1);
    assert.ok(data.totals.gross > 0);
    assert.ok(data.totals.commission > 0);
    assert.ok(data.totals.discount >= 0);
    assert.equal(data.totals.net, data.totals.payout - data.totals.due);
    assert.equal(data.totals.platformRevenue, data.totals.commission - data.totals.discount);
    assert.ok(Array.isArray(data.orders));
    assert.ok(data.settings.defaultCommission >= 0);
    assert.equal(typeof data.commissionPercent, 'number');
  });

  it('hesabatda toplanma yeri (platforma/kassa) göstərilir', async () => {
    const { data } = await api(vendor, 'GET', '/api/vendor/settlement');
    for (const order of data.orders) {
      assert.ok(['platform', 'vendor'].includes(order.collectedBy));
      assert.ok(order.commission >= 0);
      assert.ok(order.payout >= 0);
    }
  });

  it('satıcı başqa mağazanın hesabatına baxa bilmir (öz mağazası qaytarılır)', async () => {
    const other = client();
    await api(other, 'POST', '/api/auth/login', { phone: '0501110002', password: 'vendor123' });
    const { data } = await api(other, 'GET', '/api/vendor/settlement');
    assert.notEqual(data.vendorId, vendorId);
  });

  it('müştəri hesabat endpointinə girə bilmir', async () => {
    const res = await api(customer, 'GET', '/api/vendor/settlement');
    assert.equal(res.status, 403);
    const res2 = await api(customer, 'GET', '/api/admin/settlements');
    assert.equal(res2.status, 403);
  });

  it('tarix aralığı yoxlanılır', async () => {
    const bad1 = await api(vendor, 'GET', '/api/vendor/settlement?from=2026-01-01&to=2025-01-01');
    assert.equal(bad1.status, 400);
    const bad2 = await api(vendor, 'GET', '/api/vendor/settlement?from=yoxdur');
    assert.equal(bad2.status, 400);
  });
});

/* ------------------------------------------------------------------ *
 * Admin: platforma hesabatı, komissiya faizi, hesablaşma qeydləri
 * ------------------------------------------------------------------ */
describe('admin hesablaşma və komissiya idarəsi', () => {
  it('platforma hesabatı bütün mağazaları əhatə edir', async () => {
    const { status, data } = await api(admin, 'GET', '/api/admin/settlements');
    assert.equal(status, 200);
    assert.ok(data.vendors.length >= 5);
    assert.ok(data.totals.commission > 0);
    assert.ok(data.totals.orders > 0);
    const sum = data.vendors.reduce((acc, v) => acc + v.commission, 0);
    assert.equal(sum, data.totals.commission, 'cəm sətirlərin cəminə bərabərdir');
    assert.ok(data.settings.defaultCommission > 0);
  });

  it('platforma defolt komissiyasını dəyişmək olur', async () => {
    const res = await api(admin, 'PATCH', '/api/admin/settings', { defaultCommission: 15 });
    assert.equal(res.status, 200);
    assert.equal(res.data.settings.defaultCommission, 15);

    const bad1 = await api(admin, 'PATCH', '/api/admin/settings', { defaultCommission: 99 });
    assert.equal(bad1.status, 400);

    await api(admin, 'PATCH', '/api/admin/settings', { defaultCommission: 12 });
  });

  it('mağazaya fərdi komissiya faizi təyin olunur və yeni sifarişə tətbiq edilir', async () => {
    const set = await api(admin, 'PATCH', `/api/admin/vendors/${vendorId}`, { commissionPercent: 20 });
    assert.equal(set.status, 200);
    assert.equal(set.data.commissionPercent, 20);

    const order = await api(customer, 'POST', '/api/orders', {
      vendorId, name: 'Fərdi Komissiya', phone: '0501234567', payment: 'cash',
      items: [{ productId, qty: 2 }],
    });
    assert.equal(order.data.order.commission, 380, '20% → 380 qəpik');
    assert.equal(order.data.order.vendorPayout, 1520);

    const bad = await api(admin, 'PATCH', `/api/admin/vendors/${vendorId}`, { commissionPercent: 80 });
    assert.equal(bad.status, 400);
    await api(admin, 'PATCH', `/api/admin/vendors/${vendorId}`, { commissionPercent: 0 });
  });

  it('hesablaşma yaradılır və ödənildi kimi qeyd olunur', async () => {
    const report = await api(admin, 'GET', '/api/admin/settlements');
    const row = report.data.vendors.find((v) => v.vendorId === vendorId);
    assert.ok(row, 'mağaza hesabatda var');
    assert.ok(row.orders >= 1);

    const created = await api(admin, 'POST', '/api/admin/settlements', {
      vendorId, from: report.data.period.from, to: report.data.period.to, note: 'Test hesablaşma',
    });
    assert.equal(created.status, 200, JSON.stringify(created.data));
    const settlement = created.data.settlement;
    assert.equal(settlement.vendorId, vendorId);
    assert.equal(settlement.status, 'pending');
    assert.equal(settlement.payout, row.net, 'hesablaşma məbləği hesabatdakı net-ə bərabərdir');
    assert.ok(settlement.ordersCount >= 1);

    const duplicate = await api(admin, 'POST', '/api/admin/settlements', {
      vendorId, from: report.data.period.from, to: report.data.period.to,
    });
    assert.equal(duplicate.status, 400);
    assert.match(duplicate.data.error, /artıq yaradılıb/);

    const paid = await api(admin, 'PATCH', `/api/admin/settlements/${settlement.id}`, { note: 'Köçürüldü' });
    assert.equal(paid.status, 200);
    assert.equal(paid.data.settlement.status, 'paid');
    assert.ok(paid.data.settlement.paidAt);

    const again = await api(admin, 'PATCH', `/api/admin/settlements/${settlement.id}`, {});
    assert.equal(again.status, 400);

    const history = await api(vendor, 'GET', '/api/vendor/settlement');
    assert.ok(history.data.history.some((s) => s.id === settlement.id), 'satıcı öz tarixçəsində görür');

    const del = await api(admin, 'DELETE', `/api/admin/settlements/${settlement.id}`);
    assert.equal(del.status, 200);
  });

  it('sifarişsiz dövr üçün hesablaşma yaradılmır', async () => {
    const res = await api(admin, 'POST', '/api/admin/settlements', {
      vendorId, from: '2020-01-01', to: '2020-01-31',
    });
    assert.equal(res.status, 400);
    assert.match(res.data.error, /sifariş yoxdur/);
  });

  it('admin statistikasında komissiya göstəriciləri var', async () => {
    const { data } = await api(admin, 'GET', '/api/admin/stats');
    assert.ok(data.totals.commissionTotal > 0);
    assert.ok(data.totals.payoutOnline >= 0);
    assert.ok(data.totals.commissionCounter >= 0);
  });
});
