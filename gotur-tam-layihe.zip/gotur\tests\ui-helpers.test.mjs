/**
 * Götür — frontend kitabxanasının unit testləri (brauzer tələb etmir).
 * common.js-də DOM-a top-level müraciət yoxdur, ona görə Node-da birbaşa import olunur.
 * İstifadə: node tests/ui-helpers.test.mjs
 */
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

// localStorage stub (səbət testləri üçün)
const store = new Map();
globalThis.localStorage = {
  getItem: (k) => (store.has(k) ? store.get(k) : null),
  setItem: (k, v) => store.set(k, String(v)),
  removeItem: (k) => store.delete(k),
  clear: () => store.clear(),
};

const U = await import('../public/assets/common.js');

// Testlər AZ üzərində qurulub (Node-un `navigator.language`-i 'en-US' ola bilər)
U.setLang('az');

describe('h`…` şablonu', () => {
  it('interpolyasiyanı escape edir (XSS qoruması)', () => {
    const out = U.h`<b>${'<script>alert(1)</script>'}</b>`;
    assert.equal(out, '<b>&lt;script&gt;alert(1)&lt;/script&gt;</b>');
  });

  it('raw() escape-i söndürür', () => {
    assert.equal(U.h`<div>${U.raw('<span>ok</span>')}</div>`, '<div><span>ok</span></div>');
  });

  it('massivləri birləşdirir və elementləri escape edir', () => {
    assert.equal(U.h`${['a', '<b>', 'c']}`, 'a&lt;b&gt;c');
  });

  it('esc() nəticəsi h`…` içinə verilərsə ikiqat escape olunmur', () => {
    assert.equal(String(U.esc('<b>')), '&lt;b&gt;');
    assert.equal(U.h`${U.esc('<b>')}`, '&lt;b&gt;');
    assert.equal(U.h`<i>${'<b>'}</i>`, '<i>&lt;b&gt;</i>');
  });

  it('dırnaq və ampersandı düzgün əvəz edir', () => {
    assert.equal(String(U.esc(`A&B "C" 'D'`)), 'A&amp;B &quot;C&quot; &#39;D&#39;');
  });

  it('raw qaytaran köməkçi düz şablon içində [object Object] verir (reqressiya xatırlatması)', () => {
    // Bu, uğursuz naxışdır — kod belə yazılmamalıdır:
    const broken = `${U.thumb('🍔')}`;
    assert.match(broken, /object Object/);
    // Düzgün yol:
    assert.match(U.thumbHtml('🍔'), /🍔/);
  });
});

describe('formatlaşdırma', () => {
  it('qəpiyi AZN kimi göstərir', () => {
    assert.equal(U.azn(0), '0,00 \u20BC');
    assert.equal(U.azn(950), '9,50 \u20BC');
    assert.equal(U.azn(123456), '1234,56 \u20BC');
  });

  // Qeyd: bu fayl dilə bağlı olmayan gözləntilər yazır (U.t(...) ilə müqayisə),
  // çünki i18n testləri qlobal dili dəyişir.

  it('status nişanını düzgün siniflə qurur', () => {
    assert.match(U.statusBadgeHtml('ready'), /status-ready/);
    assert.ok(U.statusBadgeHtml('ready').includes(U.t('status.ready')));
    assert.ok(U.statusBadgeHtml('picked_up').includes(U.t('status.picked_up')));
    // Naməlum status üçün lüğətdə açar yoxdur → açarın özü qaytarılır (səssiz sızma olmasın)
    assert.match(U.statusBadgeHtml('naməlum'), /status\.naməlum/);
  });

  it('emoji və URL şəkillərini fərqli render edir', () => {
    assert.match(U.thumbHtml('🍕'), /<span class="tile tile-56">🍕<\/span>/);
    assert.match(U.thumbHtml('https://x.test/a.png'), /<img src="https:\/\/x\.test\/a\.png"/);
    assert.match(U.thumbHtml('javascript:alert(1)'), /javascript:alert\(1\)/); // escape olunur, tag deyil
  });

  it('vaxt mətnlərini hesablayır', () => {
    assert.equal(U.timeAgo(new Date().toISOString()), U.t('units.now'));
    assert.equal(
      U.timeAgo(new Date(Date.now() - 5 * 60000).toISOString()),
      U.t('units.minutesAgo', { count: 5 }),
    );
    assert.equal(
      U.timeAgo(new Date(Date.now() - 3 * 3600000).toISOString()),
      U.t('units.hoursAgo', { count: 3 }),
    );
    assert.equal(U.minutesLabel(90), U.t('units.hoursMinutes', { hours: 1, minutes: 30 }));
    assert.equal(U.minutesLabel(45), U.t('units.minutesShort', { count: 45 }));
  });

  it('baş hərfləri götürür', () => {
    assert.equal(U.initials('Aysel Məmmədova'), 'AM');
    assert.equal(U.initials('Rəşad'), 'R');
  });
});

describe('səbət', () => {
  const vendor = { id: 1, slug: 'test-kafe', name: 'Test Kafe', minOrder: 1000, logo: '🍽️' };
  const kebab = { id: 10, name: 'Toyuq kabab', price: 950, unit: 'ədəd', image: '🍢', stock: 5 };
  const cay = { id: 11, name: 'Çay', price: 300, unit: 'ədəd', image: '🫖', stock: null };

  it('məhsul əlavə edir və cəmi hesablayır', () => {
    U.cart.clear();
    U.cart.add(vendor, kebab, 2);
    U.cart.add(vendor, cay, 1);
    assert.equal(U.cart.count(), 3);
    assert.equal(U.cart.subtotal(), 950 * 2 + 300);
    assert.equal(U.cart.qty(10), 2);
  });

  it('sifariş payload-u düzgün qurur', () => {
    assert.deepEqual(U.cart.payload(), {
      vendorId: 1,
      items: [{ productId: 10, qty: 2 }, { productId: 11, qty: 1 }],
    });
  });

  it('anbar limitindən çox əlavə etmir', () => {
    U.cart.clear();
    U.cart.add(vendor, kebab, 9);
    assert.equal(U.cart.qty(10), 5, 'stock 5-dir');
  });

  it('miqdarı azaldır və sıfırda sətri silir', () => {
    U.cart.clear();
    U.cart.add(vendor, cay, 2);
    U.cart.setQty(11, 1);
    assert.equal(U.cart.count(), 1);
    U.cart.setQty(11, 0);
    assert.equal(U.cart.isEmpty(), true);
    assert.equal(U.cart.get().vendorId, null);
  });

  it('başqa mağazadan əlavə edəndə səbəti sıfırlayır', () => {
    U.cart.clear();
    U.cart.add(vendor, kebab, 1);
    const other = { id: 2, slug: 'pizza', name: 'Pizza Mizza', minOrder: 0, logo: '🍕' };
    U.cart.add(other, { id: 20, name: 'Marqarita', price: 1200, unit: 'ədəd', image: '🍕', stock: null }, 1);
    assert.equal(U.cart.get().vendorId, 2);
    assert.equal(U.cart.count(), 1);
    assert.equal(U.cart.qty(10), 0);
  });

  it('dəyişiklikləri abunəçilərə bildirir', () => {
    U.cart.clear();
    let calls = 0;
    const off = U.cart.onChange(() => { calls++; });
    U.cart.add(vendor, cay, 1);
    assert.equal(calls, 1);
    off();
    U.cart.add(vendor, cay, 1);
    assert.equal(calls, 1);
  });

  it('minimum sifariş həddini bilir', () => {
    U.cart.clear();
    U.cart.add(vendor, cay, 1);
    assert.equal(U.cart.get().minOrder, 1000);
    assert.ok(U.cart.subtotal() < U.cart.get().minOrder);
  });

  it('zədələnmiş localStorage-u təmiz səbət kimi oxuyur', () => {
    localStorage.setItem('gotur.cart.v1', '{ bu JSON deyil');
    assert.equal(U.cart.isEmpty(), true);
    assert.equal(U.cart.count(), 0);
  });
});
