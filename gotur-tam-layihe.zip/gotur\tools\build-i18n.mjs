/**
 * Götür — i18n lüğətini yığır.
 *
 * Mənbə:  i18n/az.json, i18n/en.json, i18n/ru.json  (əl ilə redaktə olunur)
 * Çıxış:  public/assets/i18n.js  (həm brauzer, həm server tərəfindən import olunur)
 *
 * İstifadə:  node tools/build-i18n.mjs
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const ROOT = process.cwd();
const LANGS = ['az', 'en', 'ru'];

const loaded = {};
for (const lang of LANGS) {
  const path = join(ROOT, 'i18n', `${lang}.json`);
  loaded[lang] = JSON.parse(readFileSync(path, 'utf8'));
}

/* ---- Yoxlama: bütün dillərdə eyni açarlar olmalıdır ---- */
const flatten = (obj, prefix = '', out = {}) => {
  for (const [key, value] of Object.entries(obj)) {
    const full = prefix ? `${prefix}.${key}` : key;
    if (value && typeof value === 'object' && !Array.isArray(value)) flatten(value, full, out);
    else out[full] = value;
  }
  return out;
};

const flatAz = flatten(loaded.az);
const flat = {};
const problems = [];
for (const lang of LANGS) {
  flat[lang] = flatten(loaded[lang]);
  const missing = Object.keys(flatAz).filter((k) => !(k in flat[lang]));
  const extra = Object.keys(flat[lang]).filter((k) => !(k in flatAz));
  if (missing.length) problems.push(`${lang}: ${missing.length} açar yoxdur → ${missing.slice(0, 8).join(', ')}${missing.length > 8 ? '…' : ''}`);
  if (extra.length) problems.push(`${lang}: ${extra.length} artıq açar → ${extra.slice(0, 8).join(', ')}${extra.length > 8 ? '…' : ''}`);
}

if (problems.length) {
  console.error('\n  ✖ Lüğətlər uyğun deyil:');
  problems.forEach((p) => console.error(`   - ${p}`));
  console.error('\n  Düzəldib yenidən işə salın.\n');
  process.exit(1);
}

/* ---- JS modulu ---- */
const json = (value) => JSON.stringify(value, null, 2);
const banner = `/* ==================================================================
   Götür — i18n lüğəti (AVTOMATİK YARADILIB — əl ilə redaktə etməyin!)
   Mənbə: i18n/{az,en,ru}.json   ·   Yeniləmək: node tools/build-i18n.mjs
   Açarların sayı: ${Object.keys(flatAz).length}
   ================================================================== */`;

const output = `${banner}
export const LANGS = ${json(LANGS)};
export const DEFAULT_LANG = 'az';
export const LANG_LABELS = { az: 'AZ', en: 'EN', ru: 'RU' };
export const LANG_NAMES = { az: 'Azərbaycanca', en: 'English', ru: 'Русский' };

export const dictionaries = {
${LANGS.map((lang) => `  ${lang}: ${json(loaded[lang])},`).join('\n')}
};

/** Lüğətdə açarı tapır: seçilmiş dil → az (ehtiyat) → açarın özü. */
export function lookup(lang, key) {
  for (const candidate of [lang, DEFAULT_LANG]) {
    if (!candidate) continue;
    let node = dictionaries[candidate];
    if (!node) continue;
    let ok = true;
    for (const part of String(key).split('.')) {
      if (node && typeof node === 'object' && part in node) node = node[part];
      else { ok = false; break; }
    }
    if (ok && (typeof node === 'string' || typeof node === 'number')) return String(node);
  }
  return null;
}

/** {ad} kimi yer tutucuları əvəz edir. */
export function interpolate(template, params) {
  if (!params) return template;
  return String(template).replace(/\\{(\\w+)\\}/g, (match, name) =>
    (params[name] === undefined || params[name] === null ? match : String(params[name])));
}

/** Tərcümə: translate('en', 'nav.cart', { count: 3 }) */
export function translate(lang, key, params) {
  const template = lookup(lang, key);
  if (template === null) return String(key); // çatışmayan açar görünsün (səssiz sızma olmasın)
  return interpolate(template, params);
}

/** Seçilmiş dil üçün qısa funksiya: const t = makeT('ru'); t('nav.cart') */
export const makeT = (lang) => (key, params) => translate(lang, key, params);

/** Lüğətdəki bütün açarların siyahısı (testlər üçün). */
export const keysOf = (lang) => {
  const out = [];
  const walk = (node, prefix) => {
    for (const [key, value] of Object.entries(node)) {
      const full = prefix ? \`\${prefix}.\${key}\` : key;
      if (value && typeof value === 'object') walk(value, full);
      else out.push(full);
    }
  };
  walk(dictionaries[lang] ?? {}, '');
  return out;
};

export const isSupported = (lang) => LANGS.includes(lang);

/** Brauzer dilindən uyğun dil seçir. */
export function detectLang(candidates = []) {
  for (const raw of candidates) {
    const code = String(raw ?? '').toLowerCase();
    if (!code) continue;
    if (code.startsWith('az')) return 'az';
    if (code.startsWith('ru')) return 'ru';
    if (code.startsWith('en')) return 'en';
  }
  return DEFAULT_LANG;
}
`;

writeFileSync(join(ROOT, 'public', 'assets', 'i18n.js'), output, 'utf8');
console.log(`  ✔ public/assets/i18n.js yaradıldı — ${LANGS.length} dil, ${Object.keys(flatAz).length} açar`);
