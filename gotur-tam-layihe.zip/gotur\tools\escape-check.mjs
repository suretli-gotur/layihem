/**
 * Götür — HTML escape auditi.
 *
 * `h` şablonu interpolyasiyaları avtomatik escape edir. HTML parçası (məsələn
 * `arr.map(...).join('')` və ya iç-içə `h` nəticəsi) yerləşdirilirsə, MÜTLƏQ
 * `raw(...)` ilə sarılmalıdır — yoxsa ekranda HTML kodu mətn kimi görünür.
 *
 * Bu alət həmin səhvi sistematik tapır:
 *   node tools/escape-check.mjs
 */
import { readdirSync, readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const assetsDir = join(root, 'public', 'assets');

/**
 * `h` etiketli şablonların daxilindəki `${...}` ifadələrini tapır.
 * İç-içə şablonlar, sətirlər və mötərizələr nəzərə alınır.
 */
function findInterpolations(source) {
  const found = [];
  let i = 0;
  let line = 1;

  const countLines = (from, to) => {
    for (let k = from; k < to; k++) if (source[k] === '\n') line++;
  };

  /** `${`-dən başlayaraq ifadənin mətnini və sonunu qaytarır */
  const readExpression = (start) => {
    let depth = 1;
    let j = start;
    while (j < source.length && depth > 0) {
      const c = source[j];
      if (c === '\\') { j += 2; continue; }
      if (c === '\'' || c === '"') { // sadə sətir
        const quote = c;
        j++;
        while (j < source.length && source[j] !== quote) {
          if (source[j] === '\\') j++;
          j++;
        }
        j++;
        continue;
      }
      if (c === '`') { // iç-içə şablon
        j++;
        let nested = 0;
        while (j < source.length) {
          if (source[j] === '\\') { j += 2; continue; }
          if (source[j] === '`' && nested === 0) { j++; break; }
          if (source[j] === '$' && source[j + 1] === '{') { nested++; j += 2; continue; }
          if (source[j] === '}' && nested > 0) { nested--; j++; continue; }
          j++;
        }
        continue;
      }
      if (c === '{') depth++;
      else if (c === '}') depth--;
      j++;
    }
    return { text: source.slice(start, j - 1), end: j };
  };

  while (i < source.length) {
    const c = source[i];
    if (c === '\n') { line++; i++; continue; }
    // `h` etiketli şablonun başlanğıcı: h`  (həm də raw h` kimi hallarda)
    if (c === '`' && /(^|[^\w$])h$/.test(source.slice(Math.max(0, i - 2), i))) {
      i++;
      while (i < source.length) {
        if (source[i] === '\\') { i += 2; continue; }
        if (source[i] === '\n') { line++; i++; continue; }
        if (source[i] === '`') { i++; break; }
        if (source[i] === '$' && source[i + 1] === '{') {
          const startLine = line;
          const { text, end } = readExpression(i + 2);
          countLines(i, end);
          found.push({ line: startLine, text: text.trim() });
          i = end;
          continue;
        }
        i++;
      }
      continue;
    }
    i++;
  }
  return found;
}

/**
 * `common.js`-də `raw()` qaytaran köməkçiləri avtomatik tapır — onlar
 * `h` şablonunda təhlükəsizdir (artıq HTML kimi işarələnib).
 */
function safeHelpersFrom(commonSource) {
  const safe = new Set();
  const chunks = commonSource.split(/\nexport /).slice(1);
  for (const chunk of chunks) {
    const name = chunk.match(/^(?:const|function|async function)\s+(\w+)/)?.[1];
    if (!name) continue;
    if (/raw\(/.test(chunk)) safe.add(name);
  }
  return safe;
}

/** İfadə HTML parçası yaradırsa və `raw(...)` ilə sarılmayıbsa → problem */
function makeIsUnsafe(safeHelpers) {
  return (expr) => {
    if (/^raw\s*\(/.test(expr)) return false;            // düzgün sarılıb
    if (/^esc\s*\(/.test(expr)) return false;            // açıq escape
    if (/^(U\.)?esc\s*\(/.test(expr)) return false;
    // `raw(...)` HTML yaradan hissədən ƏVVƏL gəlirsə (ternary budaqları) təhlükəsizdir
    const rawAt = expr.indexOf('raw(');
    const htmlAt = Math.min(
      ...[expr.indexOf('.map('), expr.indexOf('.join('), expr.indexOf('h`')]
        .filter((n) => n >= 0)
        .concat([Number.POSITIVE_INFINITY]),
    );
    if (rawAt >= 0 && rawAt < htmlAt) return false;
    // `raw()` qaytaran köməkçi çağırışı
    const helper = expr.match(/^(?:U\.)?(\w+)\s*\(/)?.[1];
    if (helper && safeHelpers.has(helper)) return false;
    if (/\.map\(|\.join\(/.test(expr)) return true;      // massiv → HTML
    if (/^h`/.test(expr) || /\bh`/.test(expr)) return true; // iç-içə h şablonu
    if (/^(U\.)?(statusBadgeHtml|paymentBadgeHtml)\s*\(/.test(expr)) return true;
    return false;
  };
}

/**
 * Bütün frontend fayllarını yoxlayır və problemlərin siyahısını qaytarır.
 * @returns {{file: string, line: number, text: string}[]}
 */
export function findEscapeProblems() {
  const files = readdirSync(assetsDir)
    .filter((f) => f.endsWith('.js') && f !== 'i18n.js')
    .map((f) => join(assetsDir, f));

  const safeHelpers = safeHelpersFrom(readFileSync(join(assetsDir, 'common.js'), 'utf8'));
  const isUnsafe = makeIsUnsafe(safeHelpers);

  const problems = [];
  for (const file of files) {
    const source = readFileSync(file, 'utf8');
    const rel = file.slice(root.length + 1).replace(/\\/g, '/');
    for (const hit of findInterpolations(source)) {
      if (isUnsafe(hit.text)) problems.push({ file: rel, line: hit.line, text: hit.text });
    }
  }
  return problems;
}

/* ------------------------------------------------------------------ *
 * CLI
 * ------------------------------------------------------------------ */
const isMain = process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url));

if (isMain) {
  console.log('\n── Götür HTML escape auditi ──\n');
  const problems = findEscapeProblems();
  let last = '';
  for (const p of problems) {
    if (p.file !== last) { console.log(`  ✖ ${p.file}`); last = p.file; }
    const short = p.text.length > 90 ? `${p.text.slice(0, 90)}…` : p.text;
    console.log(`      sətir ${p.line}: ${short.replace(/\s+/g, ' ')}`);
  }
  if (!problems.length) console.log('  ✔ Escape edilməmiş HTML interpolyasiyası tapılmadı');
  console.log(`\n${problems.length === 0 ? '✅' : '❌'} ${problems.length} problem\n`);
  process.exit(problems.length ? 1 : 0);
}
