/**
 * Götür — i18n kod-modu.
 *
 * Frontend fayllarındakı AZ mətnləri `t('açar')` çağırışları ilə əvəz edir.
 * YALNIZ sətir mətnlərinə toxunur — kod məntiqi dəyişmir.
 *
 *   • Şablon mətnində (`...`)  →  `${U.t('açar')}`
 *   • Tək/cüt dırnaqlı sətir tam uyğun gəlirsə  →  `U.t('açar')`
 *   • Yer tutucu ({...}) olan açarlar və söz sərhədi pozulan hallar toxunulmur
 *
 * Qeyd: `U.t(...)` istifadə olunur (`t` yox), çünki bəzi fayllarda `t` adlı
 * dövr dəyişəni var və kölgələmə yaranardı.
 *
 * İstifadə:
 *   node tools/i18n-codemod.mjs --dry     (yalnız hesabat)
 *   node tools/i18n-codemod.mjs --write   (faylları dəyişir)
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const ROOT = process.cwd();
const WRITE = process.argv.includes('--write');

const dictionary = JSON.parse(readFileSync(join(ROOT, 'i18n', 'az.json'), 'utf8'));

const flatten = (obj, prefix = '', out = {}) => {
  for (const [key, value] of Object.entries(obj)) {
    const full = prefix ? `${prefix}.${key}` : key;
    if (value && typeof value === 'object') flatten(value, full, out);
    else out[full] = value;
  }
  return out;
};

const flat = flatten(dictionary);
// Yer tutucular əl ilə işlənir; çox qısa mətnlər yanlış uyğunluq riski yaradır
const entries = Object.entries(flat)
  .filter(([, value]) => typeof value === 'string' && value.length >= 4 && !value.includes('{'))
  .sort((a, b) => b[1].length - a[1].length);

const isWordChar = (ch) => Boolean(ch) && /[\p{L}\p{N}_]/u.test(ch);

const TARGETS = [
  'public/assets/customer.js',
  'public/assets/vendor.js',
  'public/assets/admin.js',
  'public/assets/odenis.js',
];

/** Şablon mətnində ən uzun uyğun açarı tapır (söz sərhədi ilə). */
function matchInTemplate(text, index) {
  for (const [key, value] of entries) {
    if (!text.startsWith(value, index)) continue;
    const before = index > 0 ? text[index - 1] : '';
    const after = text[index + value.length] ?? '';
    if (isWordChar(before) || isWordChar(after)) continue;
    return { key, value };
  }
  return null;
}

const report = [];

for (const rel of TARGETS) {
  const path = join(ROOT, rel);
  const source = readFileSync(path, 'utf8');
  let out = '';
  let i = 0;
  let changed = 0;
  // Vəziyyətlər: code | template | single | double | lineComment | blockComment | regex
  let state = 'code';
  let templateDepth = 0; // ${ ... } daxilində kod vəziyyəti

  while (i < source.length) {
    const ch = source[i];
    const next = source[i + 1];

    if (state === 'code') {
      if (ch === '/' && next === '/') { state = 'lineComment'; out += ch; i++; continue; }
      if (ch === '/' && next === '*') { state = 'blockComment'; out += ch + next; i += 2; continue; }
      if (ch === '`') { state = 'template'; out += ch; i++; continue; }
      if (ch === "'") { state = 'single'; i++; continue; }
      if (ch === '"') { state = 'double'; i++; continue; }
      out += ch; i++; continue;
    }

    if (state === 'lineComment') {
      out += ch; i++;
      if (ch === '\n') state = 'code';
      continue;
    }

    if (state === 'blockComment') {
      out += ch; i++;
      if (ch === '*' && next === '/') { out += next; i++; state = 'code'; }
      continue;
    }

    if (state === 'single' || state === 'double') {
      const quote = state === 'single' ? "'" : '"';
      // Tam sətir uyğunluğu: 'Mətn' → t('açar')
      let end = i;
      let escaped = false;
      while (end < source.length) {
        const c = source[end];
        if (escaped) { escaped = false; end++; continue; }
        if (c === '\\') { escaped = true; end++; continue; }
        if (c === quote) break;
        end++;
      }
      const literal = source.slice(i, end); // dırnaqsız
      const key = Object.keys(flat).find((k) => flat[k] === literal);
      if (key) {
        out += `U.t('${key}')`;
        report.push(`${rel}: ${quote}${literal}${quote} → U.t('${key}')`);
        changed++;
        i = end;
        if (source[end] === quote) i++; // bağlayan dırnaq artıq U.t(...) içindədir
      } else {
        out += quote + literal;
        i = end;
        if (source[end] === quote) { out += quote; i++; }
      }
      state = 'code';
      continue;
    }

    if (state === 'template') {
      if (ch === '\\') { out += ch + (next ?? ''); i += 2; continue; }
      if (ch === '`' && templateDepth === 0) { state = 'code'; out += ch; i++; continue; }
      if (ch === '$' && next === '{') {
        // Şablon ifadəsi: kod vəziyyətinə keçirik, bağlayan } -i sayırıq
        out += '${';
        i += 2;
        let depth = 1;
        let inner = '';
        while (i < source.length && depth > 0) {
          const c = source[i];
          if (c === '{') depth++;
          else if (c === '}') { depth--; if (depth === 0) break; }
          else if (c === "'" || c === '"') {
            const quote = c;
            inner += c; i++;
            while (i < source.length) {
              inner += source[i];
              if (source[i] === '\\') { inner += source[i + 1] ?? ''; i += 2; continue; }
              if (source[i] === quote) { i++; break; }
              i++;
            }
            continue;
          } else if (c === '`') {
            // İç içə şablon — sadəcə keçirik
            inner += c; i++;
            let nested = 1;
            while (i < source.length && nested > 0) {
              if (source[i] === '\\') { inner += source[i] + (source[i + 1] ?? ''); i += 2; continue; }
              if (source[i] === '`') nested--;
              if (nested > 0) inner += source[i];
              i++;
            }
            inner += '`';
            continue;
          }
          inner += c; i++;
        }
        out += inner;
        if (source[i] === '}') { out += '}'; i++; }
        continue;
      }
      const hit = matchInTemplate(source, i);
      if (hit) {
        out += `\${U.t('${hit.key}')}`;
        report.push(`${rel}: «${hit.value}» → U.t('${hit.key}')`);
        changed++;
        i += hit.value.length;
        continue;
      }
      out += ch; i++; continue;
    }
  }

  if (WRITE && changed) writeFileSync(path, out, 'utf8');
  console.log(`  ${WRITE ? '✔' : '·'} ${rel}: ${changed} əvəzləmə`);
}

console.log(`\n  Cəmi ${report.length} əvəzləmə`);
if (process.argv.includes('--list')) {
  console.log('');
  report.forEach((r) => console.log('   ', r));
}
if (!WRITE) console.log('\n  (quru rejim — dəyişiklik yazılmadı; yazmaq üçün --write)');
