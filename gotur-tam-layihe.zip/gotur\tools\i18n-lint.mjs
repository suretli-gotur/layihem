/**
 * Götür — i18n lint.
 *
 * Frontend fayllarında tərcümə olunmamış (sərt yazılmış) istifadəçi mətnlərini tapır.
 * Şərhlər və `${...}` ifadələri nəzərə alınmır.
 *
 * İstifadə:  node tools/i18n-lint.mjs
 */
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

const ROOT = process.cwd();
const TARGETS = [
  'public/assets/customer.js',
  'public/assets/vendor.js',
  'public/assets/admin.js',
  'public/assets/odenis.js',
  'public/assets/common.js',
  'public/offline.html',
];

/* AZ mətnini tanıyan siqnallar */
const AZ_CHARS = /[əıöüğşçƏİÖÜĞŞÇ]/;
const AZ_WORDS = /\b(sifariş|Sifariş|mağaza|Mağaza|qiymət|ödəniş|Ödəniş|müştəri|Müştəri|kupon|endirim|rəy|Rəy|səbət|Səbət|cəm|Cəmi|dəq|Yeni|Sil|Əlavə|Düzəliş|Yadda|Götür|satıcı|kassada|Kassada)\b/;

const looksLikeText = (value) => {
  const raw = String(value);
  // Developer loqları istifadəçiyə görünmür
  if (raw.includes('[gotur]')) return false;
  // HTML teqlərini, atributları və boşluqları çıxarırıq — yalnız görünən mətn qalır
  const text = raw
    .replace(/<[^>]*>/g, ' ')
    .replace(/&[a-z#\d]+;/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (text.length < 3) return false;
  if (!/\p{L}/u.test(text)) return false;
  // Yalnız texniki tokenlər (class adları, fayl yolları) ola bilər
  if (/^[\w\s.,:/#()\-–—+%₼]+$/u.test(text) && !AZ_CHARS.test(text)) return false;
  return AZ_CHARS.test(text) || AZ_WORDS.test(text);
};

const problems = [];

/** `/` simvolu regex literalinin başlanğıcıdırmı? */
function isRegexStart(source, index) {
  let j = index - 1;
  while (j >= 0 && /\s/.test(source[j])) j--;
  if (j < 0) return true;
  return '([{,;:=!&|?+-*%~^<>'.includes(source[j]) || source[j] === '\n';
}

/** Regex literalinin sonunu tapır (`\` escape və `[...]` sinfi nəzərə alınır). */
function skipRegex(source, index) {
  let i = index + 1;
  let inClass = false;
  while (i < source.length) {
    const c = source[i];
    if (c === '\\') { i += 2; continue; }
    if (c === '\n') return i; // bitməmiş regex — təhlükəsiz çıxış
    if (c === '[') inClass = true;
    else if (c === ']') inClass = false;
    else if (c === '/' && !inClass) return i + 1;
    i++;
  }
  return i;
}

for (const rel of TARGETS) {
  const source = readFileSync(join(ROOT, rel), 'utf8');
  let state = 'code';
  let i = 0;
  let line = 1;
  let buffer = '';
  let bufferLine = 1;

  const flush = (kind) => {
    if (buffer && looksLikeText(buffer)) {
      const visible = buffer
        .replace(/<[^>]*>/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 80);
      if (visible.length >= 3) {
        problems.push({ file: rel, line: bufferLine, kind, text: visible });
      }
    }
    buffer = '';
  };

  while (i < source.length) {
    const ch = source[i];
    const next = source[i + 1];
    if (ch === '\n') line++;

    if (state === 'code') {
      flush('code');
      if (ch === '/' && next === '/') { state = 'lineComment'; i += 2; continue; }
      if (ch === '/' && next === '*') { state = 'blockComment'; i += 2; continue; }
      // Regex literali: əvvəlki mənalı simvol onu təsdiqləyirsə, sətirin sonuna kimi ötür
      if (ch === '/' && isRegexStart(source, i)) {
        i = skipRegex(source, i);
        continue;
      }
      if (ch === '`') { state = 'template'; bufferLine = line; buffer = ''; i++; continue; }
      if (ch === "'" || ch === '"') { state = ch === "'" ? 'single' : 'double'; bufferLine = line; buffer = ''; i++; continue; }
      i++; continue;
    }

    if (state === 'lineComment') { if (ch === '\n') state = 'code'; i++; continue; }
    if (state === 'blockComment') {
      if (ch === '*' && next === '/') { state = 'code'; i += 2; continue; }
      i++; continue;
    }

    if (state === 'single' || state === 'double') {
      const quote = state === 'single' ? "'" : '"';
      if (ch === '\\') { buffer += source.slice(i, i + 2); i += 2; continue; }
      if (ch === quote) { flush('string'); state = 'code'; i++; continue; }
      buffer += ch; i++; continue;
    }

    if (state === 'template') {
      if (ch === '\\') { buffer += source.slice(i, i + 2); i += 2; continue; }
      if (ch === '`') { flush('template'); state = 'code'; i++; continue; }
      if (ch === '$' && next === '{') {
        flush('template');
        // ${...} ifadəsini ötür (kod daxilində sətirlər ayrıca yoxlanılır)
        i += 2;
        let depth = 1;
        let inner = '';
        let innerLine = line;
        while (i < source.length && depth > 0) {
          const c = source[i];
          if (c === '\n') line++;
          if (c === '{') depth++;
          else if (c === '}') { depth--; if (depth === 0) break; }
          else if (c === "'" || c === '"') {
            const quote = c;
            let lit = '';
            i++;
            while (i < source.length && source[i] !== quote) {
              if (source[i] === '\\') { lit += source[i + 1] ?? ''; i += 2; continue; }
              if (source[i] === '\n') line++;
              lit += source[i]; i++;
            }
            if (looksLikeText(lit)) problems.push({ file: rel, line: innerLine, kind: 'expression', text: lit.slice(0, 90) });
            i++;
            continue;
          }
          inner += c; i++;
        }
        void inner;
        if (source[i] === '}') i++;
        bufferLine = line;
        continue;
      }
      buffer += ch; i++; continue;
    }
  }
  flush('code');
}

console.log('\n── Götür i18n lint ─────────────────────────────\n');
if (!problems.length) {
  console.log('  ✔ Tərcümə olunmamış istifadəçi mətni tapılmadı\n');
  process.exit(0);
}
console.log(`  ${problems.length} namizəd (əl ilə yoxlanmalı):\n`);
for (const p of problems) {
  console.log(`   ${p.file}:${p.line}  [${p.kind}]  ${p.text}`);
}
console.log('');
process.exit(1);
