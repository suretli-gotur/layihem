/**
 * Götür — canlı (işləyən serverə qarşı) uçdan-uca yoxlama.
 *
 * Server işləyərkən işə salınır:
 *   node server/index.js        (bir terminalda)
 *   node tools/live-check.mjs   (digərində)
 *
 * Yoxlanır: statik fayllar, i18n, uçdan-uca sifariş (kupon → ödəniş → statuslar → rəy),
 * komissiya/hesablaşma, SSE axını və təhlükəsizlik qaydaları.
 */
const BASE = process.env.APP_URL || 'http://127.0.0.1:4173';

let passed = 0;
let failed = 0;
const check = (condition, message) => {
  if (condition) { passed++; console.log(`  ✔ ${message}`); } else { failed++; console.log(`  ✖ ${message}`); }
};

const req = async (path, options = {}) => {
  const res = await fetch(BASE + path, options);
  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data, headers: res.headers };
};

const json = (body, cookie) => ({
  method: 'POST',
  headers: { 'content-type': 'application/json', ...(cookie ? { cookie } : {}) },
  body: JSON.stringify(body),
});

const login = async (phone, password) => {
  const res = await fetch(`${BASE}/api/auth/login`, json({ phone, password }));
  return res.headers.getSetCookie()[0].split(';')[0];
};

const main = async () => {
  console.log(`\n── Götür canlı yoxlama (${BASE}) ──\n`);

  /* 1. Statik fayllar */
  console.log('1. Statik fayllar və PWA');
  for (const path of ['/', '/satis.html', '/admin.html', '/odenis.html', '/offline.html',
    '/manifest.webmanifest', '/sw.js', '/assets/i18n.js', '/assets/app.css',
    '/assets/icons/icon-512.png', '/assets/icons/icon-maskable-512.png']) {
    const { status, headers } = await req(path);
    check(status === 200, `${path} → ${status} ${headers.get('content-type') ?? ''}`);
  }

  const health = await req('/api/health');
  check(health.status === 200 && health.data?.ok === true, `/api/health > sxem v${health.data?.schema}`);

  /* 2. i18n */
  console.log('\n2. Çoxdillilik');
  const i18nSource = await (await fetch(`${BASE}/assets/i18n.js`)).text();
  for (const lang of ['az', 'en', 'ru']) {
    check(i18nSource.includes(`${lang}: {`), `i18n.js-də «${lang}» lüğəti var`);
  }
  const receiptLabels = ['GÖTÜRMƏ KODU', 'PICKUP CODE', 'КОД ПОЛУЧЕНИЯ'].filter((l) => i18nSource.includes(l));
  check(receiptLabels.length === 3, `qəbz başlığı 3 dildə (${receiptLabels.length}/3)`);

  /* 3. Uçdan-uca sifariş */
  console.log('\n3. Uçdan-uca sifariş: kupon → ödəniş → statuslar → rəy');
  const vendor = await login('0501110001', 'vendor123');
  const admin = await login('0500000000', 'admin123');
  check(Boolean(vendor && admin), 'demo hesablar giriş edir');

  // Hər işə salışda TƏZƏ müştəri: kuponun «bir istifadəçiyə bir dəfə» limiti
  // təkrar yoxlamaya mane olmasın (yaradılanları `cli cleanup` silir).
  const runId = Math.random().toString(36).slice(2, 6).toUpperCase();
  const testName = `Canlı Yoxlama ${runId}`;
  const testPhone = `055${Math.floor(Math.random() * 9000000) + 1000000}`;
  const registered = (await req('/api/auth/register', json({
    name: testName, phone: testPhone, password: 'live1234', role: 'customer',
  }))).data;
  check(Boolean(registered.user), `canlı yoxlama müştərisi yaradıldı (${testPhone})`);
  const customer = (await fetch(`${BASE}/api/auth/login`, json({ phone: testPhone, password: 'live1234' })))
    .headers.getSetCookie()[0].split(';')[0];

  const vendorData = (await req('/api/vendors/sirvansah-kabab')).data.vendor;
  const product = vendorData.menu.flatMap((s) => s.items).find((i) => i.price >= 900);

  const created = (await req('/api/orders', json({
    vendorId: vendorData.id, name: testName, phone: testPhone, payment: 'online',
    coupon: 'KABAB15', items: [{ productId: product.id, qty: 2 }],
  }, customer))).data;

  check(Boolean(created.order), `sifariş yaradıldı: ${created.order?.code ?? JSON.stringify(created)}`);
  if (created.order) {
    const o = created.order;
    check(o.discount === Math.round(o.subtotal * 0.15), `kupon endirimi: ${o.discount} qəpik (15%)`);
    check(o.commission === Math.round(o.subtotal * 0.12), `komissiya: ${o.commission} qəpik (12%)`);
    check(o.vendorPayout === o.total - o.commission, `mağaza payı: ${o.vendorPayout} qəpik`);
    check(String(created.payment?.redirectUrl ?? '').startsWith('/odenis.html'), 'ödəniş linki qaytarıldı');

    const paid = (await req(`/api/payments/${created.payment.token}/pay`, json({
      number: '4242424242424242', expiry: '12/30', cvc: '123',
    }))).data;
    check(paid.payment?.status === 'paid', `ödəniş uğurlu (kart ••••${paid.payment?.cardLast4})`);

    for (const status of ['accepted', 'preparing', 'ready', 'picked_up']) {
      await req(`/api/vendor/orders/${o.id}/status`, json({ status }, vendor));
    }
    const full = (await req(`/api/orders/${o.code}`, { headers: { cookie: customer } })).data.order;
    check(full.status === 'picked_up', `status axını: ${full.events.map((e) => e.status).join(' → ')}`);
    check(full.paymentStatus === 'paid', `ödəniş statusu: ${full.paymentStatus}`);

    const review = (await req(`/api/orders/${o.id}/review`, json({
      rating: 5, comment: 'Canlı yoxlama rəyi',
    }, customer))).data;
    check(review.review?.rating === 5, `rəy yazıldı, mağaza reytinqi: ${review.summary?.rating}`);
  }

  /* 4. Hesablaşma */
  console.log('\n4. Komissiya və hesablaşma');
  const platform = (await req('/api/admin/settlements', { headers: { cookie: admin } })).data;
  check(platform.vendors?.length >= 12, `platforma hesabatı: ${platform.vendors?.length} mağaza`);
  check(platform.totals?.commission > 0, `ümumi komissiya: ${platform.totals?.commission} qəpik`);

  const own = (await req('/api/vendor/settlement', { headers: { cookie: vendor } })).data;
  check(own.totals?.orders >= 1, `satıcı hesabatı: ${own.totals?.orders} sifariş`);
  check(own.totals?.net === own.totals?.payout - own.totals?.due, `xalis = ödəniş − borc (${own.totals?.net})`);
  check(typeof own.commissionPercent === 'number', `komissiya faizi: ${own.commissionPercent}%`);

  const settings = (await req('/api/admin/settings', { headers: { cookie: admin } })).data;
  check(settings.settings?.defaultCommission >= 0, `defolt komissiya: ${settings.settings?.defaultCommission}%`);

  /* 5. Real vaxt */
  console.log('\n5. Real vaxt (SSE)');
  const stream = await fetch(`${BASE}/api/events?scope=vendor`, { headers: { cookie: vendor } });
  check(stream.status === 200 && (stream.headers.get('content-type') ?? '').includes('text/event-stream'),
    'satıcı SSE axını açılır');
  try { await stream.body?.cancel(); } catch { /* artıq bağlıdır */ }

  /* 6. Təhlükəsizlik */
  console.log('\n6. Təhlükəsizlik');
  check((await req('/api/admin/stats', { headers: { cookie: customer } })).status === 403,
    'müştəri admin endpointinə girmir (403)');
  check((await req('/api/vendor/me')).status === 401, 'girişsiz satıcı endpointi 401');
  check([403, 404].includes((await req('/../package.json')).status), 'path traversal bloklanır');
  check((await req('/api/yoxdur-bu-yol')).status === 404, 'naməlum API yolu 404');

  console.log(`\n${failed === 0 ? '✅' : '❌'} ${passed} yoxlama keçdi, ${failed} uğursuz\n`);
  process.exit(failed ? 1 : 0);
};

main().catch((err) => {
  console.error('\n  ✖ Canlı yoxlama kəsildi:', err.message);
  console.error('    Server işləyirmi? → node server/index.js\n');
  process.exit(1);
});
