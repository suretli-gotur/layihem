"""Götür — PWA ikonlarının generasiyası (Pillow).

İstifadə:  python tools/make-icons.py
Çıxış:     public/assets/icons/*.png

Dizayn: yumşaq künclü, mavi-yaşıl qradient fon + ağ alış-veriş çantası.
Şəkil faylları repoya düşür, ona görə bu skript yalnız dizaynı dəyişəndə lazımdır.
"""
from pathlib import Path
import sys

from PIL import Image, ImageDraw

# Windows konsolu bəzən UTF-8 olmur — çıxışı təhlükəsiz edirik
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

OUT = Path(__file__).resolve().parent.parent / "public" / "assets" / "icons"
OUT.mkdir(parents=True, exist_ok=True)

TOP = (0, 212, 245)
BOTTOM = (0, 128, 173)
WHITE = (255, 255, 255, 255)


def gradient(size: int) -> Image.Image:
    img = Image.new("RGB", (size, size))
    draw = ImageDraw.Draw(img)
    for y in range(size):
        t = y / max(1, size - 1)
        color = tuple(int(TOP[i] + (BOTTOM[i] - TOP[i]) * t) for i in range(3))
        draw.line([(0, y), (size, y)], fill=color)
    return img


def draw_bag(draw: ImageDraw.ImageDraw, size: int, scale: float = 1.0) -> None:
    """Ağ alış-veriş çantası: sap (arxada) + gövdə (önündə) + iki nöqtə."""
    s = size * scale
    ox = (size - s) / 2
    oy = (size - s) / 2

    # Əvvəlcə sap çəkilir ki, gövdə onun aşağı hissəsini örtsün.
    # Sap nazik və hündürdür — çanta oxunması üçün vacibdir.
    hw = s * 0.105
    draw.arc(
        [ox + s * 0.5 - hw, oy + s * 0.225, ox + s * 0.5 + hw, oy + s * 0.53],
        start=180, end=360, fill=WHITE, width=max(2, int(s * 0.036)),
    )

    # Gövdə — enli və bir az alçaq (çanta silueti)
    bx0, by0 = ox + s * 0.175, oy + s * 0.44
    bx1, by1 = ox + s * 0.825, oy + s * 0.80
    draw.rounded_rectangle([bx0, by0, bx1, by1], radius=s * 0.07, fill=WHITE)

    # Gövdənin yuxarı hissəsində incə kölgə xətti (dərinlik effekti)
    band = s * 0.035
    draw.rounded_rectangle(
        [bx0 + s * 0.02, by0 + band, bx1 - s * 0.02, by0 + band * 2],
        radius=s * 0.02, fill=(226, 246, 252, 255),
    )


def icon(size: int, *, maskable: bool = False, radius_ratio: float = 0.22, scale: float = 1.0) -> Image.Image:
    base = gradient(size).convert("RGBA")
    if maskable:
        canvas = base  # maskable ikonlar tam kvadrat olur
    else:
        canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        mask = Image.new("L", (size, size), 0)
        ImageDraw.Draw(mask).rounded_rectangle(
            [0, 0, size - 1, size - 1], radius=int(size * radius_ratio), fill=255
        )
        canvas.paste(base, (0, 0), mask)

    draw_bag(ImageDraw.Draw(canvas), size, scale=scale)
    return canvas


def main() -> None:
    targets = [
        ("icon-192.png", 192, False, 1.0),
        ("icon-512.png", 512, False, 1.0),
        ("icon-maskable-512.png", 512, True, 0.72),
        ("apple-touch-icon.png", 180, False, 1.0),
        ("favicon-64.png", 64, False, 1.0),
    ]
    for name, size, maskable, scale in targets:
        path = OUT / name
        icon(size, maskable=maskable, scale=scale).save(path, "PNG", optimize=True)
        print(f"  ✔ {path.relative_to(OUT.parent.parent.parent)} ({size}×{size}, {path.stat().st_size} B)")

    # SVG versiyası (ölçəklənən, eyni dizayn)
    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" role="img" aria-label="Götür">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#00d4f5"/><stop offset="1" stop-color="#0080ad"/>
    </linearGradient>
  </defs>
  <rect width="512" height="512" rx="113" fill="url(#g)"/>
  <path d="M256 115a54 54 0 0 1 54 54v98h-26v-95a28 28 0 0 0-56 0v95h-26v-98a54 54 0 0 1 54-54z" fill="#fff"/>
  <rect x="90" y="225" width="332" height="185" rx="36" fill="#fff"/>
  <rect x="100" y="243" width="312" height="18" rx="9" fill="#e2f6fc"/>
</svg>
"""
    (OUT / "icon.svg").write_text(svg, encoding="utf-8")
    print(f"  ✔ icons/icon.svg (vektor)")


if __name__ == "__main__":
    main()
