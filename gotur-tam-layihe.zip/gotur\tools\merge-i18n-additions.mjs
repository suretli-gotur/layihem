/**
 * Götür — i18n əlavələrini birləşdirir.
 *
 * Alt-agentlər və ya əl ilə yazılmış `i18n/additions-*.json` fayllarını
 * `i18n/az.json` içinə dərin birləşdirir. Toqquşma olarsa xəbərdarlıq edir
 * (mövcud açarın dəyəri dəyişdirilmir).
 *
 * İstifadə:  node tools/merge-i18n-additions.mjs
 */
import { readFileSync, writeFileSync, readdirSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const ROOT = process.cwd();
const I18N = join(ROOT, 'i18n');
const AZ = join(I18N, 'az.json');

const az = JSON.parse(readFileSync(AZ, 'utf8'));
const clashes = [];
let added = 0;

const merge = (target, source, prefix = '') => {
  for (const [key, value] of Object.entries(source)) {
    const full = prefix ? `${prefix}.${key}` : key;
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      if (target[key] === undefined) target[key] = {};
      if (typeof target[key] !== 'object') {
        clashes.push(`${full} (mövcud dəyər sətirdir, əlavə obyektdir)`);
        continue;
      }
      merge(target[key], value, full);
      continue;
    }
    if (target[key] === undefined) {
      target[key] = value;
      added++;
    } else if (target[key] !== value) {
      clashes.push(`${full}: az.json="${target[key]}" ≠ əlavə="${value}"`);
    }
  }
};

const files = readdirSync(I18N).filter((f) => /^additions-.*\.json$/.test(f)).sort();
if (!files.length) {
  console.log('  ℹ Birləşdiriləcək əlavə fayl yoxdur.');
  process.exit(0);
}

for (const file of files) {
  const data = JSON.parse(readFileSync(join(I18N, file), 'utf8'));
  merge(az, data);
  console.log(`  · ${file} birləşdirildi`);
}

/* Sabit açar sırası: əlifba sırası ilə yazırıq ki, diff-lər oxunaqlı olsun */
const sortDeep = (obj) => {
  const out = {};
  for (const key of Object.keys(obj).sort()) {
    const value = obj[key];
    out[key] = value && typeof value === 'object' && !Array.isArray(value) ? sortDeep(value) : value;
  }
  return out;
};

writeFileSync(AZ, `${JSON.stringify(sortDeep(az), null, 2)}\n`, 'utf8');

for (const file of files) {
  const path = join(I18N, file);
  if (existsSync(path)) writeFileSync(path, '{}\n', 'utf8'); // təmizlənir
}

console.log(`  ✔ ${added} yeni açar az.json-a əlavə olundu (${files.length} fayl təmizləndi)`);
if (clashes.length) {
  console.log(`\n  ⚠ ${clashes.length} toqquşma (dəyərlər dəyişdirilmədi):`);
  clashes.forEach((c) => console.log(`   - ${c}`));
}
