/**
 * Götür — MOBİL UYĞUNLUQ AUDİTİ
 *
 * Brauzer olmadan CSS/HTML-i yoxlayır: daşma (overflow) yarada biləcək sabit
 * ölçülər, gizli təbəqələrin klikləri bloklaması, toxunuş hədəfləri, breakpoint-lər,
 * safe-area dəstəyi və hər səhifənin viewport konfiqurasiyası.
 *
 *   node tools/mobile-check.mjs
 */
import { readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => readFileSync(join(root, p), 'utf8');

const PAGES = ['index.html', 'satis.html', 'admin.html', 'odenis.html', 'offline.html'];
const css = read('public/assets/app.css');

let errors = 0;
let warnings = 0;
const fail = (msg) => { errors++; console.log(`  ✖ ${msg}`); };
const warn = (msg) => { warnings++; console.log(`  ⚠ ${msg}`); };
const ok = (msg) => console.log(`  ✔ ${msg}`);

/** CSS-dən müəyyən selektorun bütün gövdələrini toplayır (media query-lər daxil) */
function rulesFor(selector) {
  const out = [];
  const re = new RegExp(`(^|[},])\\s*${selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*(,[^{]*)?\\{([^}]*)\\}`, 'gm');
  let m;
  while ((m = re.exec(css)) !== null) out.push(m[3]);
  return out;
}

console.log('\n── Götür mobil uyğunluq auditi ──\n');

/* ------------------------------------------------------------------ *
 * 1. Viewport konfiqurasiyası
 * ------------------------------------------------------------------ */
console.log('1. Viewport (hər səhifə)');
for (const page of PAGES) {
  const html = read(`public/${page}`);
  const meta = html.match(/<meta name="viewport" content="([^"]+)"/)?.[1] ?? '';
  if (!meta) fail(`${page}: viewport meta yoxdur`);
  else if (!meta.includes('width=device-width')) fail(`${page}: width=device-width yoxdur`);
  else if (!meta.includes('viewport-fit=cover')) warn(`${page}: viewport-fit=cover yoxdur (çentikli telefonlar)`);
  else ok(`${page}: ${meta}`);
}

/* ------------------------------------------------------------------ *
 * 2. Gizli təbəqələr klikləri bloklamasın
 * ------------------------------------------------------------------ */
console.log('\n2. Gizli təbəqələr (klik bloklanması)');
for (const selector of ['.drawer-backdrop', '.sidebar-backdrop']) {
  const all = rulesFor(selector);
  const openBody = rulesFor(`${selector}.open`)[0] ?? '';
  if (!all.length) { fail(`${selector}: CSS qaydası yoxdur`); continue; }
  // Bağlı hal: pointer-events:none, visibility:hidden və ya display:none olmalıdır
  const inert = all.some((b) => b.includes('pointer-events: none'))
    || all.some((b) => b.includes('visibility: hidden'))
    || all.some((b) => b.includes('display: none'));
  if (!inert) fail(`${selector}: bağlı halda klik keçirmir (pointer-events/visibility/display yoxdur) — klikləri bloklayacaq!`);
  else ok(`${selector}: bağlı halda klik keçirir`);

  if (!openBody) fail(`${selector}.open qaydası yoxdur`);
  else if (!openBody.includes('pointer-events: auto')) fail(`${selector}.open: «pointer-events: auto» yoxdur`);
  else ok(`${selector}.open: açıq halda klik qəbul edir`);
}

{
  // JS tərəfdə də gizli backdrop yaradılmamalıdır
  const customer = read('public/assets/customer.js');
  const bad = /drawer-backdrop\s*\$\{[^}]*\?\s*'open'/.test(customer);
  if (bad) fail('customer.js: backdrop açıq olmadıqda da DOM-a əlavə olunur');
  else ok('customer.js: backdrop yalnız açıq halda render olunur');
}

/* ------------------------------------------------------------------ *
 * 3. Üfüqi daşma riskləri
 * ------------------------------------------------------------------ */
console.log('\n3. Üfüqi daşma (overflow) riskləri');
{
  const guards = [
    ['html, body', /html,\s*body\s*\{[^}]*overflow-x:\s*hidden/],
    ['img', /(img,\s*svg|img)\s*\{[^}]*max-width:\s*100%/],
  ];
  for (const [name, re] of guards) {
    if (re.test(css)) ok(`${name}: daşma qoruması var`);
    else warn(`${name}: daşma qoruması yoxdur`);
  }

  // Media query daxilində olmayan sabit enlər (>=360px) — telefonda daşma yaradar
  const lines = css.split(/\r?\n/);
  let depth = 0;
  const suspects = [];
  lines.forEach((line, i) => {
    if (line.includes('@media')) depth++;
    if (depth === 0) {
      const m = line.match(/(?<!max-)(?<!min-)\bwidth:\s*(\d{3,})px/);
      if (m && Number(m[1]) >= 360 && !line.includes('max-width')) {
        suspects.push(`${i + 1}: ${line.trim()}`);
      }
    }
    if (line.includes('}') && depth > 0 && line.trim() === '}') depth--;
  });
  if (suspects.length) suspects.forEach((s) => warn(`sabit en: ${s}`));
  else ok('sabit en yoxdur (>=360px, media query xaricində)');
}

/* ------------------------------------------------------------------ *
 * 4. Breakpoint-lər və mobil qat
 * ------------------------------------------------------------------ */
console.log('\n4. Breakpoint-lər və mobil qat');
{
  const breakpoints = [...css.matchAll(/@media\s*\(max-width:\s*(\d+)px\)/g)].map((m) => Number(m[1]));
  const unique = [...new Set(breakpoints)].sort((a, b) => b - a);
  ok(`breakpoint-lər: ${unique.join(', ')} px`);
  for (const need of [980, 640]) {
    if (!unique.includes(need)) fail(`${need}px breakpoint yoxdur`);
  }
  const need = [
    ['.mobile-tabbar', 'müştəri alt naviqasiyası'],
    ['.panel-topbar', 'panel üst zolağı'],
    ['.sidebar.open', 'off-canvas yan panel'],
    ['.hide-sm', 'mobil üçün gizlədilən sütun'],
    ['.btn-label', 'mobil başlıqda gizlədilən mətn'],
  ];
  for (const [sel, label] of need) {
    if (new RegExp(`\\${sel}\\s*[,{]`).test(css)) ok(`${sel} — ${label}`);
    else warn(`${sel} qaydası tapılmadı (${label})`);
  }
}

/* ------------------------------------------------------------------ *
 * 5. Toxunuş hədəfləri və safe-area
 * ------------------------------------------------------------------ */
console.log('\n5. Toxunuş və safe-area');
{
  const mobileBlock = css.split('@media (max-width: 980px)').slice(1).join('');
  if (/\.btn\s*\{[^}]*min-height:\s*(4[0-9]|[5-9]\d)px/.test(mobileBlock)) ok('düymələr ≥40px (toxunuş hədəfi)');
  else fail('mobil üçün düymə min-height təyin olunmayıb');

  const safeArea = (css.match(/env\(safe-area-inset-bottom/g) ?? []).length;
  if (safeArea >= 3) ok(`safe-area-inset-bottom ${safeArea} yerdə istifadə olunur`);
  else fail(`safe-area-inset-bottom yalnız ${safeArea} yerdə — alt zolaqlar üçün lazımdır`);
}

/* ------------------------------------------------------------------ *
 * 6. Səhifələrdə mobil strukturlar
 * ------------------------------------------------------------------ */
console.log('\n6. Səhifə strukturları');
{
  const index = read('public/index.html');
  if (/class="mobile-tabbar"[^>]*id="tabbar"/.test(index)) ok('index.html: mobil tabbar konteyneri');
  else fail('index.html: #tabbar yoxdur');

  for (const page of ['satis.html', 'admin.html']) {
    const html = read(`public/${page}`);
    if (!html.includes('panel-topbar')) fail(`${page}: panel-topbar yoxdur (mobil menyu düyməsi)`);
    else if (!/data-act="menu"/.test(html)) fail(`${page}: hamburger düyməsi yoxdur`);
    else if (!html.includes('sidebar-backdrop')) fail(`${page}: sidebar-backdrop yoxdur`);
    else ok(`${page}: üst zolaq + hamburger + backdrop`);
  }

  const customer = read('public/assets/customer.js');
  if (customer.includes('renderTabbar()')) ok('customer.js: tabbar render olunur');
  else fail('customer.js: renderTabbar çağırılmır');
  for (const panel of ['vendor.js', 'admin.js']) {
    if (read(`public/assets/${panel}`).includes('initPanelMenu')) ok(`${panel}: off-canvas menyu bağlanır`);
    else fail(`${panel}: initPanelMenu çağırılmır`);
  }
}

/* ------------------------------------------------------------------ *
 * 7. Uzun mətnlər daşmasın
 * ------------------------------------------------------------------ */
console.log('\n7. Uzun mətn və cədvəllər');
{
  if (/\.table-wrap\s*\{[^}]*overflow-x:\s*auto/.test(css)) ok('cədvəl qabı üfüqi sürüşür');
  else fail('.table-wrap overflow-x yoxdur');
  if (/-webkit-overflow-scrolling:\s*touch/.test(css)) ok('toxunuşla sürüşmə aktivdir');
  else warn('-webkit-overflow-scrolling: touch yoxdur');
  if (/overflow-wrap:\s*anywhere/.test(css)) ok('uzun söz/mətn daşmır (overflow-wrap)');
  else warn('overflow-wrap: anywhere yoxdur');
}

/* ------------------------------------------------------------------ *
 * Yekun
 * ------------------------------------------------------------------ */
console.log(`\n${errors === 0 ? '✅' : '❌'} ${errors} xəta, ${warnings} xəbərdarlıq\n`);
process.exit(errors ? 1 : 0);
