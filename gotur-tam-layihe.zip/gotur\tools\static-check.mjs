/**
 * Götür — statik müqavilə yoxlaması.
 *
 * Frontend kodunun serverlə uyğunluğunu yoxlayır (brauzer tələb etmir):
 *   1) frontend-in çağırdığı hər /api/... yolu serverdə mövcuddurmu;
 *   2) hər `data-act` / `data-tab` / `data-*` selektorunun HTML-də "istehsalçısı" varmı;
 *   3) U.qs('#id') ilə axtarılan hər #id şablonlarda yaradılırmı;
 *   4) HTML-dəki hash-linklər müştəri marşrutlarına uyğundurmu.
 *
 * İstifadə:  node tools/static-check.mjs
 */
import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';
import { routeTable } from '../server/api.js';

const PUBLIC = 'public';
const problems = [];
const notes = [];

const files = [];
async function collect(dir) {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const full = join(dir, entry.name);
    if (entry.isDirectory()) await collect(full);
    else if (/\.(js|html)$/.test(entry.name)) files.push(full);
  }
}
await collect(PUBLIC);

const sources = new Map();
for (const file of files) sources.set(file.replace(/\\/g, '/'), await readFile(file, 'utf8'));

const allCode = [...sources.values()].join('\n');

/* ------------------------------------------------------------------ *
 * 1) API yolları
 * ------------------------------------------------------------------ */
const routes = routeTable();
const normalize = (p) => p.replace(/\$\{[^}]*\}/g, ':x').split('?')[0].replace(/\/+$/, '') || '/';

function matches(routePath, apiPath) {
  const a = routePath.split('/').filter(Boolean);
  const b = apiPath.split('/').filter(Boolean);
  if (a.length !== b.length) return false;
  return a.every((seg, i) => seg.startsWith(':') || seg === b[i]);
}

const usedApi = new Map();
for (const [file, code] of sources) {
  if (file.includes('/tools/') || file.endsWith('sw.js')) continue; // service worker yalnız prefiks yoxlayır
  for (const m of code.matchAll(/['"`](\/api\/[^'"`\s]*)['"`]/g)) {
    const raw = m[1];
    const path = normalize(raw);
    if (path.split('/').filter(Boolean).length < 2) continue; // sadəcə «/api/» prefiksi
    if (!usedApi.has(path)) usedApi.set(path, new Set());
    usedApi.get(path).add(file);
  }
}
// Şablon daxilində dinamik yollar: `/api/vendor/products/${...}` — regex onları da tutur,
// lakin bəziləri backtick içində birləşdirilir; əlavə olaraq belə nümunələri yığaq:
for (const [file, code] of sources) {
  if (file.endsWith('sw.js')) continue;
  for (const m of code.matchAll(/`(\/api\/[^`]*)`/g)) {
    const path = normalize(m[1]);
    if (!usedApi.has(path)) usedApi.set(path, new Set());
    usedApi.get(path).add(file);
  }
}

for (const [apiPath, where] of usedApi) {
  if (!routes.some((r) => matches(r.path, apiPath))) {
    problems.push(`Frontend mövcud olmayan API yolunu çağırır: ${apiPath}  (${[...where].join(', ')})`);
  }
}

/* ------------------------------------------------------------------ *
 * 2) data-* selektorları: istehsalçı (HTML) vs istifadəçi (JS)
 * ------------------------------------------------------------------ */
const produced = new Set();
const consumed = new Set();

for (const [file, code] of sources) {
  // İstehsal: şablon/HTML daxilində data-act="..." kimi sabit atributlar
  for (const m of code.matchAll(/data-(act|tab|status|detail|edit|del|active|vopen|vapprove|ofilter|vfilter|block|order-row|add|plus|minus|cat|scroll)="([^"$]*)"?/g)) {
    if (m[2]) produced.add(`data-${m[1]}="${m[2]}"`);
  }
}

const usedSelectors = [];
for (const [file, code] of sources) {
  if (!file.endsWith('.js')) continue;
  for (const m of code.matchAll(/['"`]\[(data-[a-z-]+)="([^"]+)"\]['"`]/g)) {
    usedSelectors.push({ file, sel: `${m[1]}="${m[2]}"` });
  }
}
for (const { file, sel } of usedSelectors) consumed.add(sel);

for (const sel of consumed) {
  if (!produced.has(sel)) {
    // Bəzi selektorlar JS tərəfindən dinamik qurulur (məsələn data-status="accepted") — yoxla
    const [attr, value] = sel.replace(/"/g, '').split('=');
    const where = usedSelectors.filter((u) => u.sel === sel).map((u) => u.file).join(', ');
    const dynamic = new RegExp(`${attr}="?\\$\\{`).test(allCode) || new RegExp(`${attr}=`).test(allCode);
    if (dynamic) notes.push(`Dinamik selektor (əl ilə yoxlanmalı): [${sel}] — ${where}`);
    else problems.push(`JS gözləyir, amma HTML heç vaxt yaratmır: [${sel}]  (${where})`);
  }
}

/* ------------------------------------------------------------------ *
 * 3) #id hədəfləri
 * ------------------------------------------------------------------ */
const ids = new Set([...allCode.matchAll(/id="([a-zA-Z][\w-]*)"/g)].map((m) => m[1]));
const dynamicIds = new Set([...allCode.matchAll(/id="?\$\{[^}]*\}/g)].map(() => '*'));
for (const [file, code] of sources) {
  if (!file.endsWith('.js')) continue;
  for (const m of code.matchAll(/qs\(['"`]#([\w-]+)['"`]/g)) {
    if (!ids.has(m[1]) && !/^sec-|^tab-/.test(m[1])) {
      problems.push(`#${m[1]} elementi heç bir şablonda yaradılmır (${file})`);
    }
  }
}
void dynamicIds;

/* ------------------------------------------------------------------ *
 * 4) Hash marşrutları
 * ------------------------------------------------------------------ */
const KNOWN_ROUTES = ['', 'k', 'v', 'sifarislerim', 'sifaris', 'giris', 'orders', 'menu', 'store', 'stats',
  'icmal', 'saticalar', 'sifarisler', 'istifadeciler', 'odenisler'];
const hashLinks = new Set([...allCode.matchAll(/href="(#\/?[\w/-]*)/g)].map((m) => m[1].replace(/^#\/?/, '').split('/')[0]));
for (const link of hashLinks) {
  if (!KNOWN_ROUTES.includes(link)) problems.push(`Naməlum hash marşrutu: #/${link}`);
}

/* ------------------------------------------------------------------ *
 * 5) "raw" köməkçilərinin səhv istifadəsi (düz şablon içində [object Object])
 * ------------------------------------------------------------------ */
const objectProducers = ['U.thumb(', 'U.statusBadge(', 'raw('];
for (const [file, code] of sources) {
  if (!file.endsWith('.js')) continue;
  const lines = code.split('\n');
  lines.forEach((line, i) => {
    // h`...` şablonu olmayan sətirdə raw qaytaran köməkçi işlədilirsə — risk
    for (const p of objectProducers) {
      if (!line.includes(p)) continue;
      const isH = line.includes('h`') || line.includes('raw(') || line.includes('=> raw(');
      const inTemplateMap = /join\(''\)/.test(line) || /map\(/.test(line);
      if (inTemplateMap && !line.includes('raw(')) {
        problems.push(`«${p}» düz şablon içində istifadə oluna bilər (sətir ${i + 1}) — ${file}: ${line.trim().slice(0, 90)}`);
      }
      void isH;
    }
  });
}

/* ------------------------------------------------------------------ *
 * Nəticə
 * ------------------------------------------------------------------ */
console.log('\n── Götür statik müqavilə yoxlaması ─────────────────\n');
console.log(`  Yoxlanan fayl     : ${files.length}`);
console.log(`  Server route-ları : ${routes.length}`);
console.log(`  Frontend API yolu : ${usedApi.size}`);
console.log(`  data-* selektor   : ${consumed.size} istifadəçi / ${produced.size} istehsalçı\n`);

if (notes.length) {
  console.log('  Qeydlər:');
  notes.forEach((n) => console.log(`   · ${n}`));
  console.log('');
}

if (problems.length) {
  console.log(`  ✖ ${problems.length} problem:`);
  problems.forEach((p) => console.log(`   - ${p}`));
  console.log('');
  process.exit(1);
}
console.log('  ✔ Problem tapılmadı\n');
