/**
 * Götür — brauzer (E2E) yoxlaması.
 *
 * Headless Chrome-u CDP (Chrome DevTools Protocol) ilə idarə edir, real istifadəçi
 * axınlarını klikləyir, konsol xətalarını toplayır və ekran görüntüləri çıxarır.
 * Heç bir npm paketi tələb olunmur — Node 24-ün daxili WebSocket + fetch-i kifayətdir.
 *
 * İstifadə:
 *   1) node server/index.js            (tətbiq işləməlidir)
 *   2) chrome --headless=new --remote-debugging-port=9333 --user-data-dir=...
 *   3) node tools/ui-check.mjs
 */
import { mkdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const CDP_PORT = Number(process.env.CDP_PORT || 9333);
const BASE = process.env.APP_URL || 'http://127.0.0.1:4173';
const SHOTS = process.env.SHOT_DIR || 'screenshots';

const problems = [];
const steps = [];

/* ------------------------------------------------------------------ *
 * Kiçik CDP klienti
 * ------------------------------------------------------------------ */
class CDP {
  constructor(ws) {
    this.ws = ws;
    this.seq = 0;
    this.pending = new Map();
    this.onEvent = () => {};
    ws.addEventListener('message', (event) => {
      const msg = JSON.parse(event.data);
      if (msg.id && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        if (msg.error) reject(new Error(`${msg.error.message} (${msg.error.code})`));
        else resolve(msg.result);
      } else if (msg.method) {
        this.onEvent(msg);
      }
    });
  }

  send(method, params = {}) {
    const id = ++this.seq;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params }));
      setTimeout(() => {
        if (this.pending.has(id)) { this.pending.delete(id); reject(new Error(`CDP timeout: ${method}`)); }
      }, 20000);
    });
  }
}

async function connect() {
  const list = await (await fetch(`http://127.0.0.1:${CDP_PORT}/json/list`)).json();
  const target = list.find((t) => t.type === 'page');
  if (!target) throw new Error('Chrome-da səhifə tapılmadı (--remote-debugging-port işləyir?)');
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve, { once: true });
    ws.addEventListener('error', () => reject(new Error('CDP WebSocket qoşulmadı')), { once: true });
  });
  return new CDP(ws);
}

/* ------------------------------------------------------------------ *
 * Köməkçilər
 * ------------------------------------------------------------------ */
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let cdp;
const evaluate = async (expression) => {
  const res = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (res.exceptionDetails) throw new Error(`JS xətası: ${res.exceptionDetails.text} ${res.exceptionDetails.exception?.description ?? ''}`);
  return res.result.value;
};

async function waitFor(expression, { timeout = 12000, label = expression } = {}) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    try {
      if (await evaluate(`Boolean(${expression})`)) return true;
    } catch { /* səhifə hələ yüklənir */ }
    await sleep(200);
  }
  throw new Error(`Gözləmə bitdi: ${label}`);
}

const click = (selector, index = 0) => evaluate(`(() => {
  const els = document.querySelectorAll(${JSON.stringify(selector)});
  if (!els[${index}]) return false;
  els[${index}].click();
  return true;
})()`);

const setValue = (selector, value) => evaluate(`(() => {
  const el = document.querySelector(${JSON.stringify(selector)});
  if (!el) return false;
  el.value = ${JSON.stringify(value)};
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
  return true;
})()`);

const text = (selector) => evaluate(`document.querySelector(${JSON.stringify(selector)})?.textContent?.trim() ?? null`);
const count = (selector) => evaluate(`document.querySelectorAll(${JSON.stringify(selector)}).length`);

async function goto(url, readyExpression, label) {
  await cdp.send('Page.navigate', { url });
  await waitFor(`document.readyState === 'complete'`, { label: 'səhifə yüklənsin' });
  if (readyExpression) await waitFor(readyExpression, { label });
  await sleep(350);
}

async function shot(name) {
  const { data } = await cdp.send('Page.captureScreenshot', { format: 'png' });
  await writeFile(join(SHOTS, name), Buffer.from(data, 'base64'));
  steps.push(`📸 ${name}`);
}

function check(condition, message) {
  if (condition) steps.push(`✔ ${message}`);
  else { steps.push(`✖ ${message}`); problems.push(message); }
  return condition;
}

/* ------------------------------------------------------------------ *
 * Ssenarilər
 * ------------------------------------------------------------------ */
async function scenarioCustomer() {
  await goto(`${BASE}/`, `document.querySelectorAll('.vendor-card').length >= 10`, 'mağaza kartları');
  const vendors = await count('.vendor-card');
  check(vendors >= 12, `Ana səhifədə ${vendors} mağaza kartı render olundu`);
  check(await evaluate(`document.body.textContent.includes('Restoranlar')`), 'Restoranlar bölməsi var');
  check(await evaluate(`document.body.textContent.includes('Marketlər')`), 'Marketlər bölməsi var');
  check(!(await evaluate(`document.body.textContent.includes('undefined')`)), 'DOM-da "undefined" mətni yoxdur');
  check(!(await evaluate(`document.body.innerHTML.includes('[object Object]')`)), 'DOM-da "[object Object]" sızması yoxdur');
  await shot('01-ana-sehife.png');

  // Axtarış
  await setValue('[data-act="search"]', 'dolma');
  await sleep(900);
  const found = await count('.vendor-card');
  check(found >= 1, `«dolma» axtarışı ${found} nəticə qaytardı`);

  // Mağaza səhifəsi
  await goto(`${BASE}/#/v/sirvansah-kabab`, `document.querySelectorAll('[data-add]').length >= 8`, 'menyu məhsulları');
  const items = await count('[data-add]');
  check(items >= 10, `Şirvanşah menyusunda ${items} sifariş düyməsi var`);
  check(await evaluate(`document.body.textContent.includes('Şirvanşah')`), 'Mağaza adı görünür');
  check(await evaluate(`document.body.textContent.includes('Necə işləyir')`), '«Necə işləyir» bloku var');
  await shot('02-magaza-menyu.png');

  // Səbətə əlavə
  await click('[data-add]', 0);
  await sleep(250);
  await click('[data-add]', 1);
  await sleep(250);
  await click('[data-plus]', 0);
  await sleep(300);
  const badge = await text('.cart-count');
  check(String(badge) === '3', `Səbət nişanı 3-dür (faktiki: ${badge})`);

  await click('[data-act="cart"]');
  await waitFor(`document.querySelector('.drawer.open')`, { label: 'səbət paneli açılsın' });
  await sleep(400);
  check(await evaluate(`document.body.textContent.includes('Çatdırılma')`), 'Səbətdə çatdırılma sətri var');
  check(await evaluate(`document.body.textContent.includes('özün götürürsən')`), '«özün götürürsən» izahı var');
  await shot('03-sebet.png');

  // Checkout
  await click('[data-act="checkout"]');
  await waitFor(`document.querySelector('.modal')`, { label: 'checkout pəncərəsi' });
  await setValue('.modal [name="name"]', 'E2E Test Müştəri');
  await setValue('.modal [name="phone"]', '0509990011');
  await setValue('.modal [name="note"]', 'E2E avtomatik sifariş');
  await sleep(200);
  await shot('04-checkout.png');
  await click('.modal [data-submit]');

  await waitFor(`location.hash.startsWith('#/sifaris/')`, { timeout: 15000, label: 'sifariş izləmə səhifəsi' });
  await waitFor(`document.querySelector('.pickup-box .code')`, { label: 'götürmə kodu' });
  await sleep(400);
  const pickup = await text('.pickup-box .code');
  const code = await evaluate(`location.hash.replace('#/sifaris/','')`);
  check(/^\d{4}$/.test(pickup ?? ''), `Götürmə kodu göstərilir: ${pickup}`);
  check(await evaluate(`document.body.textContent.includes('Sifariş göndərildi')`), 'Status zaman xətti var');
  check(await evaluate(`!localStorage.getItem('gotur.cart.v1') || JSON.parse(localStorage.getItem('gotur.cart.v1')).items.length === 0`),
    'Sifarişdən sonra səbət boşaldı');
  await shot('05-sifaris-izleme.png');
  return { code, pickup };
}

async function scenarioVendor(orderCode) {
  await goto(`${BASE}/satis.html`, `document.querySelector('[data-act="login"]')`, 'satıcı girişi');
  await setValue('[name="phone"]', '0501110001');
  await setValue('[name="password"]', 'vendor123');
  await click('[data-act="login"]');
  await waitFor(`document.querySelector('#sidebar .brand')`, { timeout: 15000, label: 'satıcı paneli' });
  await waitFor(`document.querySelectorAll('.order-card').length >= 1`, { timeout: 15000, label: 'sifariş kartları' });
  const cards = await count('.order-card');
  check(cards >= 1, `Satıcı panelində ${cards} sifariş kartı var`);
  check(await evaluate(`document.body.textContent.includes('Yeni sifariş')`), 'Yeni sifariş statusu görünür');
  check(await evaluate(`document.querySelector('.sidebar a.active') !== null`), 'Yan menyuda aktiv bölmə var');
  await shot('06-satici-sifarisler.png');

  // Status dəyişimi: qəbul et → hazırla
  const before = await text('[data-status="accepted"]');
  await click('[data-status="accepted"]');
  await sleep(1200);
  check(await evaluate(`document.body.textContent.includes('Qəbul edildi')`), `«${before}» düyməsi işlədi — status dəyişdi`);

  // Menyu bölməsi
  await goto(`${BASE}/satis.html#menu`, `document.querySelector('#menu-area table')`, 'menyu cədvəli');
  const rows = await count('#menu-area tbody tr');
  check(rows >= 10, `Menyuda ${rows} məhsul sətri var`);
  await click('[data-act="new-product"]');
  await waitFor(`document.querySelector('.modal [name="name"]')`, { label: 'məhsul forması' });
  await sleep(300);
  await shot('07-satici-menyu.png');
  await click('.modal [data-close]');
  await sleep(200);

  // Statistika
  await goto(`${BASE}/satis.html#stats`, `document.querySelector('.stat-grid')`, 'statistika');
  const stats = await count('.stat');
  check(stats >= 4, `Statistikada ${stats} göstərici kartı var`);
  await shot('08-satici-statistika.png');

  // Mağaza ayarları
  await goto(`${BASE}/satis.html#store`, `document.querySelector('[data-act="save-store"]')`, 'mağaza ayarları');
  check(await evaluate(`document.querySelector('[name="address"]').value.length > 3`), 'Ünvan sahəsi dolu gəldi');
  await shot('09-satici-magaza.png');

  // Yeni sifariş gəldikdə yan menyu nişanı
  void orderCode;
}

async function scenarioAdmin() {
  await goto(`${BASE}/admin.html`, `document.querySelector('[data-act="login"]')`, 'admin girişi');
  await setValue('[name="phone"]', '0500000000');
  await setValue('[name="password"]', 'admin123');
  await click('[data-act="login"]');
  await waitFor(`document.querySelector('.stat-grid')`, { timeout: 15000, label: 'admin icmalı' });
  const stats = await count('.stat');
  check(stats >= 6, `Admin icmalında ${stats} göstərici var`);
  check(await evaluate(`document.body.textContent.includes('kuryer modulu yoxdur')`), 'Kuryersiz model izahı var');
  await shot('10-admin-icmal.png');

  await goto(`${BASE}/admin.html#saticalar`, `document.querySelector('#vendors-area table')`, 'satıcı cədvəli');
  const vendorRows = await count('#vendors-area tbody tr');
  check(vendorRows >= 12, `Satıcı cədvəlində ${vendorRows} sətir var`);
  await shot('11-admin-saticilar.png');

  await goto(`${BASE}/admin.html#sifarisler`, `document.querySelector('#orders-area table')`, 'sifariş cədvəli');
  const orderRows = await count('#orders-area tbody tr');
  check(orderRows >= 5, `Sifariş cədvəlində ${orderRows} sətir var`);
  await click('[data-order-row]');
  await waitFor(`document.querySelector('.modal')`, { label: 'sifariş detalları' });
  await sleep(400);
  check(await evaluate(`document.body.textContent.includes('Tarixçə')`), 'Sifariş detalında tarixçə var');
  await shot('12-admin-sifaris-detali.png');
  await click('.modal [data-close]');

  await goto(`${BASE}/admin.html#istifadeciler`, `document.querySelector('#users-area table')`, 'istifadəçi cədvəli');
  const users = await count('#users-area tbody tr');
  check(users >= 5, `İstifadəçi cədvəlində ${users} sətir var`);
  await shot('13-admin-istifadeciler.png');
}

/* ------------------------------------------------------------------ *
 * İşə salma
 * ------------------------------------------------------------------ */
(async function run() {
  await mkdir(SHOTS, { recursive: true });
  cdp = await connect();

  const consoleErrors = [];
  cdp.onEvent = (msg) => {
    if (msg.method === 'Runtime.exceptionThrown') {
      const d = msg.params.exceptionDetails;
      consoleErrors.push(`exception: ${d.exception?.description ?? d.text}`);
    }
    if (msg.method === 'Runtime.consoleAPICalled' && msg.params.type === 'error') {
      consoleErrors.push(`console.error: ${msg.params.args.map((a) => a.value ?? a.description).join(' ')}`);
    }
  };

  await cdp.send('Page.enable');
  await cdp.send('Runtime.enable');
  await cdp.send('Emulation.setDeviceMetricsOverride', {
    width: 1440, height: 950, deviceScaleFactor: 1, mobile: false,
  });

  console.log('\n── Götür E2E yoxlaması ─────────────────────────────\n');

  const { code, pickup } = await scenarioCustomer();
  await scenarioVendor(code);
  await scenarioAdmin();

  // Mobil görünüş
  await cdp.send('Emulation.setDeviceMetricsOverride', { width: 414, height: 860, deviceScaleFactor: 2, mobile: true });
  await goto(`${BASE}/`, `document.querySelectorAll('.vendor-card').length >= 10`, 'mobil ana səhifə');
  await shot('14-mobil-ana-sehife.png');
  await goto(`${BASE}/#/v/market-247`, `document.querySelectorAll('[data-add]').length >= 5`, 'mobil mağaza');
  await shot('15-mobil-market.png');
  await cdp.send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 950, deviceScaleFactor: 1, mobile: false });

  steps.forEach((s) => console.log(' ', s));
  console.log(`\n  Sifariş kodu: ${code} · götürmə kodu: ${pickup}`);

  const realErrors = consoleErrors.filter((e) => !/favicon|net::ERR_/.test(e));
  if (realErrors.length) {
    console.log('\n  ⚠ Brauzer xətaları:');
    realErrors.forEach((e) => console.log(`   - ${e}`));
  } else {
    console.log('\n  ✔ Brauzer konsolunda xəta yoxdur');
  }

  const failed = problems.length + realErrors.length;
  console.log(`\n  Nəticə: ${steps.filter((s) => s.startsWith('✔')).length} yoxlama keçdi, ${failed} problem`);
  console.log(`  Ekran görüntüləri: ${SHOTS}/\n`);
  process.exit(failed ? 1 : 0);
})().catch((err) => {
  console.error('\n  ✖ E2E yoxlaması kəsildi:', err.message);
  steps.forEach((s) => console.error('   ', s));
  process.exit(1);
});
